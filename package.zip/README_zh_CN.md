# 思盘-思源文件与网盘管理器

**思盘**是思源里的网盘聚合管理器：支持 25+ 网盘和磁盘挂载、300+ 文件格式预览，联动思阅和思播，把远程文件、媒体、阅读、分享和文档引用放进同一个思源工作流。文件留在网盘，本地空间更轻，资料随时可浏览、可插入、可分享。

## 最近更新

### 0.8.5（2026/11/17）

#### 新增

- 文件树、文件管理器和动态目录块中的阅读类文件新增阅读器专用链接 `data-reader-href`（`siyuan://plugins/siyuan-cloud/open?path=…`），与文档内插入、复制的链接同源。

#### 修复

- 修复网盘 PDF 交给阅读器后提示 `is not an asset path`、无法打开的问题。
- 修复 WebDAV 等需要 Basic 认证的挂载经下载路由（`/d/`）取文件时，302 跳转上游直链会丢掉 `Authorization`、拿回错误页的问题；这类驱动现在强制由服务端代理转发。
- 修复代理读取文件时透传浏览器 `Accept-Encoding`、上游改用 gzip 返回而响应头缺少 `Content-Encoding` 时，客户端只能拿到压缩字节、EPUB 等文件打不开的问题；代理现在固定 `Accept-Encoding: identity`。
- 点击仍保留 `/p` 预览链接，旧版本阅读器与媒体链路行为不变；含 `%`、`#`、空格的文件名按规范转义。

### 0.8.1（2026/11/12）

#### 新增

- 动态目录块（文件列表块）的文件行新增右键菜单，提供「打开」和「复制链接」两项，操作方式与文件管理器页签保持一致。

#### 修复

- 修复百度网盘部分视频文件名为 `.flv`、实际却下发 m3u8 转码流或 mp4，导致思播等播放器按扩展名选错解码器而无法播放的问题；百度网盘驱动现在按真实字节识别 FLV / HLS / MPEG-TS / MP4，并通过 `media_type` 返回给调用方。
- 修复百度 CDN 把视频统一标记为 `video/mp4` 时，媒体类型判断偏离真实内容的问题；类型探测只取前 16 字节，且有缓存，不影响列表加载速度。
- 修复百度网盘 MPEG-TS 视频因缺少总时长导致进度条无法拖动、时间戳跳转回到 0 秒的问题；现在从文件信息与 `mediainfo` 中提取时长，并通过 `duration` 返回给调用方。

### 0.8.0（2026/10/26）

#### 新增

- 合并网盘文件插入命令为 `/思盘`：选择文件插入链接，点击文件夹插入动态目录块，按住 Shift 点击文件夹插入文件夹链接。

#### 修复

- 修复思盘链接中的中文路径显示为 URL 百分号编码的问题；中文路径现可直接阅读，特殊字符仍会正确转义。

### 0.7.4

#### 修复
- 修复旧版非路径格式的网盘链接无法解析播放的问题。
- 修复网盘媒体链接生成临时路径的问题。
- 修复思盘链接中的 URL 百分号编码导致链接不可读或无法正确识别的问题。

### 0.7.3

#### 优化
- 优化目录和文件加载：根据挂载驱动直接分流到本地、OpenList/AList 或内核路径，缓存挂载配置，避免文件详情重复绕回路由，并仅在确实限流时重试请求。
- 更新 123 云盘下载流程，优先使用当前 v2 下载接口，同时保留旧版双地址回退，兼容旧环境和接口不可用的情况。

#### 修复

- 适配思源 3.8.3 的文件写入流程，直接调用 `putFile` 时带上当前前端 `appId`，避免误触发覆盖通知和重复刷新。
- 统一工作空间与预览模块的思源文件写入路径，保持现有 `POST /api/file/putFile` 方式。

### 0.7.1

#### 优化

- 整理预览模块分类：Open File Viewer 保持轻量，Flyfish File Viewer 改为独立完整的分类能力矩阵。
- 将 `.xmind` 支持归入 Flyfish File Viewer，并为 Office、图表/脑图、电子书、邮件等分类补充更清晰的 Lucide 风格图标。

#### 修复

- 修复未安装或未加载思阅时 PDF/EPUB 无法继续兜底打开的问题，现在可交给预览模块处理。

### 0.7.0

#### 新增

- 新增可下载预览模块：可在工具页安装 `open-file-viewer` 和 Flyfish File Viewer 到 `/data/public/preview-modules`，插件只在需要时加载模块资源。
- 新增通用预览页签，支持 Office、PDF、Markdown、代码、文本、压缩包、邮件、工程图、3D/GIS 等多类格式。
- 新增思源空间 `.sy` 文档原生打开，文件名符合思源文档 ID 时直接打开思源页签。

#### 优化

- 工具页改为入口式子页面，索引、配置、预览模块、外部预览和 Torrent 工具分开管理。
- 统一文件打开逻辑：图片继续用思源图片查看器，音视频优先走思播，其他可预览文件走预览模块。
- 思源空间挂载改用 `/api/file/readDir` 直接读取目录，打开更快，并能显示用户新建文件夹、点号开头文件和正确大小。
- 预览模块样式接入思源主题变量，Dock 和工具页图标统一为 OpenList/Lucide 风格。

#### 移除

- 删除旧的文本预览、压缩包浏览和原生音视频 `Dialog` 兜底，统一交给预览模块处理。

> 详细版本变化请打开[更新日志](https://my.feishu.cn/wiki/Qvjjw63iMiVwBRkMREfcDuWDnrb)。

## 它能做什么

| 能力 | 说明 |
| --- | --- |
| 网盘聚合 | 挂载 115、123Pan、天翼云盘、阿里云盘、百度网盘、夸克/UC、OneDrive、WPS、GitHub Releases、OpenList/AList、WebDAV、S3、本地磁盘、思源工作空间等 |
| 文件管理 | 在 Dock 文件树和顶部文件管理器中浏览、上传、下载、复制、移动、重命名、删除 |
| 预览增强 | 按需安装预览模块，覆盖 Office、PDF、Markdown、代码、文本、压缩包、邮件、工程图、3D/GIS、XMind 等 300+ 格式 |
| 媒体与阅读 | 图片走思源图片查看器，音视频优先联动思播，PDF/EPUB 优先联动思阅；缺少伴侣插件时可由预览模块兜底 |
| 文档引用 | 复制 Markdown 图片、音频、视频、下载链接或 `siyuan://plugins/siyuan-cloud/open?...`；通过 `/思盘` 选择文件插入链接，点击文件夹插入动态目录块，按住 Shift 点击文件夹插入链接 |
| 在线分享 | 生成 `/sd/{id}` 分享链接，适合在可信环境里快速分享文件或目录 |
| 图床/视频文件床 | 网盘文件可作为图片、音频、视频资源链接插入笔记，减少附件进入思源空间 |
| 兼容接口 | 提供 OpenList 风格文件 API、WebDAV 和 S3 兼容能力，方便本机工具、自动化和其它插件接入 |

## 能力总览

思盘已经从单一文件管理入口，逐步收敛成思源内的 OpenList 兼容运行时：

- **挂载与驱动**：接入 115、123Pan、189Cloud、阿里云盘、百度网盘、夸克/UC、OneDrive、WPS、GitHub Releases、S3/Doge、WebDAV、OpenList/AList、本地磁盘和思源工作空间等运行时驱动，并补齐对应驱动说明。
- **文件与传输**：支持列表、详情、链接、上传、下载、复制、移动、删除、重命名、批量下载、Motrix Next 投递、拖拽上传和传输状态提示。
- **预览与播放**：图片、音频、视频、PDF、EPUB、Office、Markdown、代码、压缩包、邮件、工程图、3D/GIS、XMind 等文件可以按原生查看器、思阅/思播或可下载预览模块打开。
- **文档工作流**：支持右键复制链接、拖入文档、`/` 命令插入文件链接；图片、音频、视频可生成可直接预览/播放的 Markdown 或 HTML 片段，并自动保持网盘路径的可读格式，避免 URL 百分号编码影响识别。
- **分享与权限**：具备 OpenList 风格用户、会话、权限、meta、分享链接、访问控制、密码、过期时间、访问次数限制和公开读取复核。
- **搜索与任务**：提供本地持久搜索索引、索引建立/停止/清空/进度查询，以及任务状态、取消、重试等 OpenList 形态的基础能力。
- **协议与自动化**：提供 `/api/public/api`、`/api/public/routes`、状态能力矩阵、OpenList 风格 FS API、WebDAV、S3 和 companion 插件可消费的 `/p`、`/d` 资源路径。
- **界面与体验**：Dock、文件管理器、工具页、状态页、用户、分享、任务和图标体系持续整理，思源工作空间挂载打开更快，用户自建文件夹、点号文件和文件大小显示更稳定。

## 快速开始

- 打开 Dock 面板，进入 **挂载**。
- 新增一个挂载，选择已经接入运行时的驱动。
- 在 Dock 文件树或顶部文件管理器中浏览文件。
- 右键文件可预览、复制链接、插入文档、分享、下载或管理文件。
- 在文档中输入 `/思盘`，选择文件插入链接；点击文件夹插入可浏览、可刷新的动态目录块，按住 Shift 点击文件夹插入文件夹链接。
- 需要 Office、代码、XMind、压缩包等增强预览时，到 **工具 -> 预览模块** 安装并启用对应模块。

## 文档入口

| 内容 | 入口 |
| --- | --- |
| 版本变化 | [更新日志](https://my.feishu.cn/wiki/Qvjjw63iMiVwBRkMREfcDuWDnrb) |
| API 文档 | [飞书 API](https://my.feishu.cn/wiki/YCDlwD0qJioublkADxOcYVJpnOf) |
| 驱动教程 | [驱动说明](https://my.feishu.cn/wiki/Y1gqwvRmwi9mEGk6AHGcGX4OnTg) |
| OpenList/AList 本地挂载 | [OpenList AList 本地挂载与代理](https://my.feishu.cn/wiki/Np9wwXWi3irGOoknwl0cwK7Sn9c) |
| 百度网盘 | [百度网盘挂载](https://my.feishu.cn/wiki/Gig1wzFKSi0pCbkn1XKcLr8rnvl) |
| Local 本地存储 | [Local 本地存储](https://my.feishu.cn/wiki/Q6s7wW4LRi7CZLkeNZkcbAJjnth) |

Dock/关于页的 API 入口会用预览模块打开正在运行的 `/api/public/api` 实时接口清单；README 中的 API 链接指向飞书文档。

## 已接入运行时驱动

- [OpenList 兼容挂载](https://my.feishu.cn/wiki/UHWbwHFeGiXjGkkTW92cFxynnm3)
- [OpenList AList 本地挂载与代理](https://my.feishu.cn/wiki/Np9wwXWi3irGOoknwl0cwK7Sn9c)
- [WebDAV 挂载](https://my.feishu.cn/wiki/JJ4Pw3NRVi19AekGbY8cWFNcnmg)
- [S3 兼容存储](https://my.feishu.cn/wiki/AlvawbjIuiU22mkDAfLcGdbSnKc)
- [DogeCloud 挂载](https://my.feishu.cn/wiki/DUcmwbwxniEOLVkuUVUchknFnmb)
- [115 Cloud 挂载](https://my.feishu.cn/wiki/XxXqwvlBcip8JJkdH8lcz2vpnuf)
- [115 Open 挂载](https://my.feishu.cn/wiki/SEo2wAbOpi8TTukfLx4cnCw6nre)
- [115 Share 挂载](https://my.feishu.cn/wiki/TY0FwQyeii2ql4kevuaccuFIn49)
- [OneDrive 挂载](https://my.feishu.cn/wiki/MRpFwCZcQiOpVUkPjjCcdOAvnB2)
- [123Pan 挂载](https://my.feishu.cn/wiki/IY7FwsKh7i0WU3kd0OLcoJIcnzd)
- [百度网盘挂载](https://my.feishu.cn/wiki/Gig1wzFKSi0pCbkn1XKcLr8rnvl)
- [GitHub Releases](https://my.feishu.cn/wiki/VFiCwOcoOiHKE0kLBJocS3vinIf)
- [阿里云盘开放平台](https://my.feishu.cn/wiki/LQRHwC0BciZFjmkoA7ycwNTknre)
- [189Cloud 系列](https://my.feishu.cn/wiki/HBCiwsGnPiEJAvkRD65cjYxLnPg)
- [Quark UC 系列](https://my.feishu.cn/wiki/Gx06wqy5xiyH6jkENAxcDOxrn5F)
- [WPS 云文档](https://my.feishu.cn/wiki/QXhCwMFztiGy16kCIl1cMqZWnLe)
- [Local 本地存储](https://my.feishu.cn/wiki/Q6s7wW4LRi7CZLkeNZkcbAJjnth)
- [思源工作空间](https://my.feishu.cn/wiki/OpSrwXiUniBI7akO94ocSpqTnjc)
- 内置虚拟存储

其它 OpenList 驱动可能保留 metadata/config 参考；没有真实运行时的驱动不会出现在常规挂载列表里。

## 网盘文件读取与压缩

`/d/`（下载）与 `/p/`（预览）都由思源内核按 `ResponseProxy` 描述符代为转发：插件只决定"请求哪个地址、带哪些请求头"，响应头是否原样到达浏览器取决于内核版本与上游反代。为保证客户端拿到的永远是原始字节：

- 代理请求固定 `Accept-Encoding: identity`，客户端的压缩偏好不会外传，上游不会把文件压成 gzip。
- 若上游仍然压缩，思源内核（≥ 3.7.0）会把 `Content-Encoding` 透传给客户端，浏览器自动解压。
- 要切回"请求压缩 + 透传压缩体"的完全透明代理，把 `src/kernel/server/common/proxy.js` 里的 `PROXY_ACCEPT_ENCODING` 改成 `null`；前提是确认响应头 `Content-Encoding` 确实能到达浏览器。

文件打不开时，看响应体前 4 个字节即可判断：`50 4b 03 04` 是正常 EPUB（zip）、`25 50 44 46` 是正常 PDF、`1f 8b 08` 说明取到的是 gzip 压缩体。确认上游是否压缩：

```bash
curl -sI -H 'Accept-Encoding: gzip' 'https://your-dav/books/a.epub' | grep -i content-encoding
```

## 边界

- `/plugin/private/siyuan-cloud/*` 是思源私有路由，不是公网匿名 OpenList 服务。
- `/sd/{id}` 分享链接仍是私有路由链接，外网访问需要你自己准备反代、隧道或其它 bridge。
- 搜索使用本地持久索引，还不是完整 OpenList search backend 矩阵。
- 任务接口已对齐 OpenList 形态，但真实异步队列、取消传播、重试调度和进度上报仍待实现。
- ZIP/tar/tgz 已支持；RAR/7z/ISO 等更复杂压缩格式由预览模块或后续 reader 能力覆盖。
- `/ae` 压缩包内媒体偏向 entry 提取，不等同于普通 `/p` 的可 seek 流式播放。

## 数据与同步

内核数据保存在思源插件存储中：

| 文件 | 内容 |
| --- | --- |
| `config.json` | settings、users、storages、metas、sharings、SSH keys |
| `runtime.json` | 虚拟 FS、tasks、messages、scan、WebDAV locks、S3 multipart 状态 |
| `search-index.json` | 本地搜索索引 |

思源默认会同步 `data/storage/petal/<plugin>`，用户可以通过 `.siyuan/syncignore` 排除。

## 致谢与许可

本项目以 MIT 许可证发布，并感谢这些上游项目：

- [OpenList](https://github.com/OpenListTeam/OpenList)：兼容路由、响应形状和驱动行为的重要参考；OpenList 主项目为 AGPL-3.0，OpenList Frontend 为 MIT。
- [open-file-viewer](https://github.com/xushanpei/open-file-viewer)：可选预览模块，MIT。
- [Flyfish File Viewer](https://github.com/flyfish-dev/file-viewer)：可选 Office 预览模块，Apache-2.0；其按需加载的 worker、WASM、字体和 vendor 资产保留各自随包许可证。
- [SiYuan plugin sample](https://github.com/siyuan-note/plugin-sample) 和思源插件生态中的 Monaco 编辑器类项目：插件结构、页签打开和编辑器集成参考，按各自上游许可证保留声明。
- [zip.js](https://github.com/gildas-lormeau/zip.js)：压缩包能力参考与开发依赖，BSD-3-Clause。

## 开发

```bash
pnpm install
pnpm test:kernel
pnpm build
```

内核源码位于 `src/kernel/**`。不要手改生成的 `kernel.js`；`pnpm dev` 和 `pnpm build` 会生成到插件输出目录。
