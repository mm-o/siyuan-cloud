(function() {
  "use strict";
  const OPENLIST_VERSION = "siyuan-cloud-port-0.3.0";
  const CONFIG_FILE = "config.json";
  const LEGACY_STATE_FILE = "siyuan-cloud/state.json";
  const RUNTIME_FILE = "runtime.json";
  const SEARCH_INDEX_FILE = "search-index.json";
  const TASK_TYPES = [
    "copy",
    "move",
    "upload",
    "offline_download",
    "offline_download_transfer",
    "aria2_down",
    "aria2_transfer",
    "qbit_down",
    "qbit_transfer",
    "decompress",
    "decompress_upload"
  ];
  const success = (data) => ({
    code: 200,
    message: "success",
    data: data === void 0 ? null : data
  });
  const successWithMessage = (message, data) => ({
    code: 200,
    message: message || "success",
    data: data === void 0 ? null : data
  });
  const failure = (message, code, data) => ({
    code: code || 500,
    message: message || "error",
    data: data === void 0 ? null : data
  });
  const jsonResponse = (payload, statusCode) => ({
    statusCode: statusCode || 200,
    headers: {
      "Content-Type": ["application/json; charset=utf-8"],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
    },
    body: {
      data: {
        type: "JSON",
        data: payload
      }
    }
  });
  const textResponse = (text2, statusCode, contentType) => ({
    statusCode: statusCode || 200,
    headers: {
      "Content-Type": [contentType || "text/plain; charset=utf-8"],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
    },
    body: {
      string: {
        format: "%s",
        values: [text2]
      }
    }
  });
  const rawResponse = (data, statusCode, contentType, extraHeaders = {}) => ({
    statusCode: statusCode || 200,
    headers: {
      "Content-Type": [contentType || "application/octet-stream"],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION],
      ...extraHeaders
    },
    body: {
      raw: {
        contentType: contentType || "application/octet-stream",
        data
      }
    }
  });
  const proxyResponse = (url, headers = {}, method = "GET") => {
    const normalizedHeaders = {};
    for (const [key, value] of Object.entries(headers || {})) {
      if (value === void 0 || value === null || value === "") continue;
      normalizedHeaders[key] = Array.isArray(value) ? value.map(String) : [String(value)];
    }
    return {
      statusCode: 200,
      headers: {
        "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
      },
      body: {
        proxy: {
          url,
          method,
          headers: normalizedHeaders
        }
      }
    };
  };
  const base64ToArrayBuffer = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "").replace(/-/g, "+").replace(/_/g, "/");
    const bytes2 = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars2.indexOf(clean[i]);
      const b = chars2.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars2.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars2.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      bytes2.push(a << 2 | b >> 4);
      if (c >= 0) bytes2.push((b & 15) << 4 | c >> 2);
      if (d >= 0) bytes2.push((c & 3) << 6 | d);
    }
    return new Uint8Array(bytes2).buffer;
  };
  const pageResp = (content, total) => ({
    content,
    total: total === void 0 ? content.length : total
  });
  const normalizePath = (input) => {
    let value = input === void 0 || input === null || input === "" ? "/" : String(input);
    if (!value.startsWith("/")) value = "/" + value;
    value = value.replace(/\\/g, "/").replace(/\/+/g, "/");
    const parts = [];
    for (const part of value.split("/")) {
      if (!part || part === ".") continue;
      if (part === "..") continue;
      parts.push(part);
    }
    return "/" + parts.join("/");
  };
  const dirname = (path) => {
    const normalized = normalizePath(path);
    if (normalized === "/") return "/";
    const index = normalized.lastIndexOf("/");
    return index <= 0 ? "/" : normalized.slice(0, index);
  };
  const basename = (path) => {
    const normalized = normalizePath(path);
    if (normalized === "/") return "";
    return normalized.slice(normalized.lastIndexOf("/") + 1);
  };
  const isSafeRelativeName = (name) => {
    const value = String(name || "").trim();
    return !!value && !/[\\/]/.test(value) && value !== "." && value !== "..";
  };
  const linkFromDriverData = (data = {}) => {
    const link = data.link || {};
    if (!link.url) throw new Error("driver read did not return link.url");
    return {
      url: link.url,
      header: link.header || {},
      method: link.method || "GET",
      content_length: Number(link.content_length || 0),
      concurrency: Number(link.concurrency || 0),
      part_size: Number(link.part_size || 0),
      range_reader: link.range_reader || null
    };
  };
  const SETTING_GROUP = {
    SINGLE: 0,
    SITE: 1,
    STYLE: 2,
    PREVIEW: 3,
    GLOBAL: 4,
    OFFLINE_DOWNLOAD: 5,
    INDEX: 6,
    SSO: 7,
    LDAP: 8,
    S3: 9,
    FTP: 10,
    TRAFFIC: 11
  };
  const SETTING_FLAG = {
    PUBLIC: 0,
    PRIVATE: 1,
    READONLY: 2
  };
  const USER_ROLE = {
    GENERAL: 0,
    GUEST: 1,
    ADMIN: 2
  };
  const ADMIN_PERMISSION = 29695;
  const sanitizeUser = (user) => {
    const result = { ...user || {} };
    result.password = "";
    result.otp_secret = "";
    result.otp = !!((user == null ? void 0 : user.otp) || (user == null ? void 0 : user.otp_secret));
    return result;
  };
  const normalizeUser = (input = {}, index = 0) => ({
    id: Number(input.id || index + 1),
    username: String(input.username || `user-${index + 1}`),
    password: input.password || "",
    role: Number(input.role ?? USER_ROLE.GENERAL),
    disabled: !!input.disabled,
    base_path: normalizePath(input.base_path || "/"),
    permission: Number(input.permission ?? 0),
    sso_id: input.sso_id || "",
    otp: !!(input.otp || input.otp_secret),
    otp_secret: input.otp_secret || "",
    allow_ldap: input.allow_ldap === void 0 ? true : !!input.allow_ldap,
    authn: input.authn || "[]",
    siyuan_account: input.siyuan_account || null
  });
  const defaultAdminUser = (username = "admin", account = null) => normalizeUser({
    id: 1,
    username,
    role: USER_ROLE.ADMIN,
    disabled: false,
    base_path: "/",
    permission: ADMIN_PERMISSION,
    siyuan_account: account
  }, 0);
  const defaultGuestUser = () => normalizeUser({
    id: 2,
    username: "guest",
    password: "guest",
    role: USER_ROLE.GUEST,
    disabled: true,
    base_path: "/",
    permission: 0
  }, 1);
  const pickAccountName = (conf) => {
    const user = (conf == null ? void 0 : conf.user) || (conf == null ? void 0 : conf.User) || {};
    return String(user.userNickname || user.userName || user.UserNickname || user.UserName || "").trim();
  };
  const accountFromSiyuanConf = (conf) => {
    const user = (conf == null ? void 0 : conf.user) || (conf == null ? void 0 : conf.User) || {};
    const username = pickAccountName(conf);
    if (!username) return null;
    return {
      user_id: String(user.userId || user.UserId || ""),
      user_name: String(user.userName || user.UserName || username),
      user_nickname: String(user.userNickname || user.UserNickname || username),
      user_avatar_url: String(user.userAvatarURL || user.UserAvatarURL || "")
    };
  };
  const syncDefaultUserWithSiyuan = (state, account) => {
    var _a;
    if (!((_a = state == null ? void 0 : state.users) == null ? void 0 : _a.length)) state.users = [defaultAdminUser()];
    const admin = state.users.find((user) => Number(user.role) === USER_ROLE.ADMIN) || state.users[0];
    if (!(account == null ? void 0 : account.user_nickname) && !(account == null ? void 0 : account.user_name)) {
      Object.assign(admin, normalizeUser(admin, 0), {
        id: Number(admin.id || 1),
        role: USER_ROLE.ADMIN,
        disabled: false,
        permission: Number(admin.permission || ADMIN_PERMISSION)
      });
      return false;
    }
    const username = account.user_nickname || account.user_name;
    const changed = admin.username !== username || JSON.stringify(admin.siyuan_account || null) !== JSON.stringify(account);
    Object.assign(admin, normalizeUser(admin, 0), {
      id: Number(admin.id || 1),
      username,
      role: USER_ROLE.ADMIN,
      disabled: false,
      base_path: normalizePath(admin.base_path || "/"),
      permission: Number(admin.permission || ADMIN_PERMISSION),
      sso_id: admin.sso_id || account.user_id || "",
      siyuan_account: account
    });
    return changed;
  };
  const field = (name, type = "string", defaultValue = "", options = "", required = false, help = "") => ({
    name,
    type,
    default: String(defaultValue ?? ""),
    options: Array.isArray(options) ? options.join(",") : options,
    required,
    help
  });
  const unsupported = (name, extra = [], common = [rootPath("/")]) => ({
    common,
    additional: extra,
    config: {
      name,
      local_sort: true,
      only_proxy: true,
      no_cache: false,
      no_upload: true,
      need_ms: false,
      default_root: "/",
      alert: "warning",
      only_indices: false,
      prefer_proxy: true,
      status: "metadata-only",
      note: "Driver metadata is copied for mount creation. Runtime behavior is still being ported to the SiYuan kernel JS environment."
    }
  });
  const supported = (name, extra = [], common) => {
    const info = unsupported(name, extra, common);
    info.config.status = "ported";
    info.config.note = "Runtime behavior is wired through SiYuan /api/network/forwardProxy in the kernel plugin.";
    info.config.no_upload = false;
    info.config.only_proxy = false;
    info.config.prefer_proxy = false;
    return info;
  };
  const preferProxy = (info) => {
    info.config.prefer_proxy = true;
    return info;
  };
  const configPatch = (info, patch) => {
    Object.assign(info.config, patch);
    return info;
  };
  const text = (name, required = false, help = "") => field(name, "string", "", "", required, help);
  const password = (name, required = false, help = "") => field(name, "password", "", "", required, help);
  const bool = (name, defaultValue = false, help = "") => field(name, "bool", defaultValue, "", false, help);
  const number = (name, defaultValue = "", required = false, help = "") => field(name, "number", defaultValue, "", required, help);
  const float = (name, defaultValue = "", required = false, help = "") => field(name, "float", defaultValue, "", required, help);
  const select = (name, options, defaultValue = "", required = false, help = "") => field(name, "select", defaultValue, options, required, help);
  const rootPath = (defaultValue = "/") => field("root_folder_path", "string", defaultValue, "", false, "OpenList root folder path.");
  const rootId$2 = (defaultValue = "") => field("root_folder_id", "string", defaultValue, "", false, defaultValue ? `OpenList default root: ${defaultValue}` : "");
  const metadataOnlyNames = [
    "139Yun",
    "Alias",
    "AutoIndex",
    "Azure Blob Storage",
    "BaiduPhoto",
    "CNB Releases",
    "ChaoXingGroupDrive",
    "Chunk",
    "Cloudreve V4",
    "Crypt",
    "Degoo",
    "Doubao",
    "DoubaoNew",
    "DoubaoShare",
    "FTP",
    "FebBox",
    "FeijiPan",
    "GitHub API",
    "GitHub Releases",
    "HalalCloud",
    "HalalCloudOpen",
    "ILanZou",
    "IPFS API",
    "KodBox",
    "LenovoNasShare",
    "MediaFire",
    "MediaTrack",
    "Mega_nz",
    "Misskey",
    "MoPan",
    "NeteaseMusic",
    "OpenListShare",
    "PikPakShare",
    "ProtonDrive",
    "Seafile",
    "Strm",
    "Teambition",
    "Teldrive",
    "Template",
    "Terabox",
    "ThunderBrowser",
    "ThunderBrowserExpert",
    "ThunderExpert",
    "ThunderX",
    "ThunderXExpert",
    "UrlTree",
    "WeiYun",
    "WoPan",
    "WPS",
    "YandexDisk"
  ];
  const withAliases = (map) => ({
    ...map,
    "115": map["115 Cloud"],
    "115Open": map["115 Open"],
    "115Share": map["115 Share"],
    "123": map["123Pan"],
    "123Open": map["123 Open"],
    "123Share": map["123PanShare"],
    "AliyunDrive": map.Aliyundrive,
    "AliyunDriveOpen": map.AliyundriveOpen,
    "AliyunDriveShare": map.AliyundriveShare,
    "OneDrive": map.Onedrive
  });
  const buildDriverInfoMap = () => withAliases({
    ...Object.fromEntries(metadataOnlyNames.map((name) => [name, unsupported(name)])),
    SiYuanKernel: {
      common: [field("root_folder_path", "string", "/", "", false, "Virtual OpenList root inside siyuan.storage.")],
      additional: [],
      config: {
        name: "SiYuanKernel",
        local_sort: true,
        only_proxy: false,
        no_cache: true,
        no_upload: false,
        need_ms: false,
        default_root: "/",
        alert: "success",
        only_indices: false,
        prefer_proxy: false,
        status: "ported",
        note: "Virtual OpenList storage backed by SiYuan kernel plugin storage."
      }
    },
    SiYuanWorkspace: {
      common: [field("root_folder_path", "string", "/@workspace", "", false, "SiYuan workspace files exposed through /api/file.")],
      additional: [],
      config: {
        name: "SiYuanWorkspace",
        local_sort: true,
        only_proxy: true,
        no_cache: true,
        no_upload: true,
        need_ms: false,
        default_root: "/@workspace",
        alert: "warning",
        only_indices: false,
        prefer_proxy: true,
        status: "ported",
        note: "Read/list/remove/rename are wired through SiYuan /api/file. Upload is still guarded."
      }
    },
    WebDav: preferProxy(supported("WebDav", [
      select("vendor", ["sharepoint", "other"], "other"),
      text("address", true),
      text("username", true),
      password("password", true),
      bool("tls_insecure_skip_verify", false)
    ])),
    OpenList: configPatch(supported("OpenList", [
      text("url", true),
      password("meta_password"),
      text("username"),
      password("password"),
      password("token"),
      bool("pass_ip_to_upsteam", true),
      bool("pass_ua_to_upsteam", true),
      bool("forward_archive_requests", true),
      bool("pass_refresh_flag_to_upsteam", false)
    ]), { proxy_range_option: true, link_cache_mode: "auto" }),
    AListV3: supported("AListV3", [
      text("url", true),
      text("username"),
      password("password"),
      password("token")
    ]),
    "AList V3": supported("AList V3", [
      text("url", true),
      text("username"),
      password("password"),
      password("token")
    ]),
    S3: configPatch(supported("S3", [
      rootPath("/"),
      text("bucket", true),
      text("endpoint", true),
      text("region"),
      text("access_key_id", true),
      password("secret_access_key", true),
      password("session_token"),
      text("custom_host"),
      bool("enable_custom_host_presign", false),
      number("sign_url_expire", 4),
      text("placeholder"),
      bool("force_path_style", false),
      select("list_object_version", ["v1", "v2"], "v1"),
      bool("remove_bucket", false),
      bool("add_filename_to_disposition", false),
      bool("enable_direct_upload", false),
      text("direct_upload_host")
    ]), { check_status: true }),
    Doge: configPatch(supported("Doge", [
      rootPath("/"),
      text("bucket", true),
      text("endpoint", true),
      text("region"),
      text("access_key_id", true),
      password("secret_access_key", true),
      password("session_token"),
      text("custom_host"),
      bool("enable_custom_host_presign", false),
      number("sign_url_expire", 4),
      text("placeholder"),
      bool("force_path_style", false),
      select("list_object_version", ["v1", "v2"], "v1"),
      bool("remove_bucket", false),
      bool("add_filename_to_disposition", false),
      bool("enable_direct_upload", false),
      text("direct_upload_host")
    ]), { check_status: true }),
    "115 Cloud": configPatch(supported("115 Cloud", [
      rootId$2("0"),
      text("cookie", false, "one of QR code token and cookie required"),
      text("qrcode_token", false, "one of QR code token and cookie required"),
      select("qrcode_source", ["web", "android", "ios", "tv", "alipaymini", "wechatmini", "qandroid"], "linux"),
      number("page_size", 1e3),
      float("limit_rate", 2)
    ]), {
      link_cache_mode: "ua",
      no_upload: true,
      note: "Runtime ports OpenList 115 Cloud cookie/QR-token login, list/get/read/link, basic management, and storage details. Upload/offline download remain structured placeholders."
    }),
    "115 Open": unsupported("115 Open", [
      rootId$2(),
      select("order_by", ["file_name", "file_size", "user_utime", "file_type"]),
      select("order_direction", ["asc", "desc"]),
      float("limit_rate", 1),
      number("page_size", 200),
      password("access_token", true),
      password("refresh_token", true)
    ]),
    "115 Share": unsupported("115 Share", [text("share_code", true), password("receive_code"), rootId$2()]),
    "123Pan": preferProxy(supported("123Pan", [
      rootId$2("0"),
      text("username", true),
      password("password", true),
      password("access_token"),
      number("UploadThread", 3),
      field("platform", "string", "web", "", false, "the platform header value, sent with API requests")
    ])),
    "123 Open": unsupported("123 Open", [
      rootId$2(),
      text("ClientID"),
      password("ClientSecret"),
      password("AccessToken"),
      password("RefreshToken"),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/123cloud/renewapi"),
      number("UploadThread", 3),
      bool("DirectLink", false),
      password("DirectLinkPrivateKey"),
      number("DirectLinkValidDuration", 30)
    ]),
    "123PanShare": unsupported("123PanShare", [text("share_key", true), password("share_pwd"), rootId$2()]),
    "123PanLink": unsupported("123PanLink", [text("url", true)]),
    "189Cloud": configPatch(supported("189Cloud", [rootId$2("-11"), text("username", true), password("password", true), text("cookie", false, "Fill in the cookie if need captcha")]), {
      alert: "info|You can try to use 189PC driver if this driver does not work."
    }),
    "189CloudPC": configPatch(supported("189CloudPC", [
      select("login_type", ["password", "qrcode"], "password", true),
      text("username", true),
      password("password", true),
      text("validate_code"),
      password("access_token"),
      password("refresh_token", false, "To switch accounts, please clear this field"),
      rootId$2("-11"),
      select("order_by", ["filename", "filesize", "lastOpTime"], "filename"),
      select("order_direction", ["asc", "desc"], "asc"),
      select("type", ["personal", "family"], "personal"),
      text("family_id"),
      select("upload_method", ["stream", "rapid", "old"], "stream"),
      field("upload_thread", "string", "3", "", false, "1<=thread<=32"),
      bool("family_transfer", false),
      bool("rapid_upload", false),
      bool("no_use_ocr", false),
      bool("generate_torrent", false, "Generate torrent file with CAS extension after upload")
    ]), {
      check_status: true,
      note: "Initial runtime ports OpenList 189CloudPC list/get/read/link and basic management when an access_token/session is available. Password/QR login and upload remain structured placeholders."
    }),
    "189CloudTV": configPatch(supported("189CloudTV", [
      rootId$2("-11"),
      password("access_token"),
      select("order_by", ["filename", "filesize", "lastOpTime"], "filename"),
      select("order_direction", ["asc", "desc"], "asc"),
      select("type", ["personal", "family"], "personal"),
      text("family_id"),
      field("upload_thread", "string", "3", "", false, "1<=thread<=32"),
      bool("rapid_upload", false)
    ]), {
      check_status: true,
      note: "Runtime ports OpenList 189CloudTV QR login, session refresh, list/get/read/link, and basic management. Upload remains a structured placeholder."
    }),
    Aliyundrive: unsupported("Aliyundrive", [
      rootId$2("root"),
      password("refresh_token", true),
      select("order_by", ["name", "size", "updated_at", "created_at"]),
      select("order_direction", ["ASC", "DESC"]),
      bool("rapid_upload", false),
      bool("internal_upload", false)
    ]),
    AliyundriveOpen: configPatch(supported("AliyundriveOpen", [
      select("drive_type", ["default", "resource", "backup"], "resource"),
      rootId$2(),
      password("refresh_token", true),
      select("order_by", ["name", "size", "updated_at", "created_at"]),
      select("order_direction", ["ASC", "DESC"]),
      bool("use_online_api", true),
      select("alipan_type", ["default", "alipanTV"], "default", true),
      field("api_url_address", "string", "https://api.oplist.org/alicloud/renewapi"),
      text("client_id"),
      password("client_secret"),
      select("remove_way", ["trash", "delete"], "trash", true),
      bool("rapid_upload", false),
      bool("internal_upload", false),
      select("livp_download_format", ["jpeg", "mov"], "jpeg"),
      password("access_token")
    ]), { default_root: "root", no_overwrite_upload: true }),
    AliyundriveShare: unsupported("AliyundriveShare", [
      rootId$2(),
      password("refresh_token", true),
      text("share_id", true),
      password("share_pwd"),
      select("order_by", ["name", "size", "updated_at", "created_at"]),
      select("order_direction", ["ASC", "DESC"])
    ]),
    BaiduNetdisk: preferProxy(supported("BaiduNetdisk", [
      rootPath("/"),
      select("order_by", ["name", "time", "size"], "name"),
      select("order_direction", ["asc", "desc"], "asc"),
      select("download_api", ["official", "crack", "crack_video"], "crack_video"),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/baiduyun/renewapi"),
      text("client_id"),
      password("client_secret"),
      field("custom_crack_ua", "string", "netdisk", "", true),
      password("access_token"),
      password("refresh_token", true),
      number("upload_thread", 3),
      number("upload_timeout", 60),
      field("upload_api", "string", "https://d.pcs.baidu.com"),
      bool("use_dynamic_upload_api", true),
      number("custom_upload_part_size", 0),
      bool("low_bandwith_upload_mode", false),
      bool("only_list_video_file", false)
    ])),
    Cloudreve: unsupported("Cloudreve", [text("address", true), text("username"), password("password"), password("token")]),
    Dropbox: unsupported("Dropbox", [password("refresh_token", true), text("client_id"), password("client_secret")]),
    GoogleDrive: unsupported("GoogleDrive", [
      rootId$2(),
      password("refresh_token", true),
      text("order_by", false, "such as: folder,name,modifiedTime"),
      select("order_direction", ["asc", "desc"]),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/googleui/renewapi"),
      text("client_id"),
      password("client_secret"),
      number("chunk_size", 5),
      bool("disable_disk_usage", false)
    ]),
    GooglePhoto: unsupported("GooglePhoto", [
      rootId$2(),
      password("refresh_token", true),
      field("client_id", "string", "202264815644.apps.googleusercontent.com", "", true),
      field("client_secret", "password", "X4Z3ca8xfWDb1Voo-F9a7ZxJ", "", true),
      bool("show_archive", false)
    ]),
    Lanzou: unsupported("Lanzou", [password("cookie", true)]),
    Onedrive: supported("Onedrive", [
      rootPath("/"),
      select("region", ["global", "cn", "us", "de"], "global", true),
      bool("is_sharepoint", false),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/onedrive/renewapi"),
      text("client_id"),
      password("client_secret"),
      field("redirect_uri", "string", "https://api.oplist.org/onedrive/callback", "", true),
      password("refresh_token", true),
      text("site_id"),
      number("chunk_size", 5),
      text("custom_host"),
      bool("disable_disk_usage", false),
      bool("enable_direct_upload", false)
    ]),
    OnedriveAPP: unsupported("OnedriveAPP", [
      rootPath("/"),
      select("region", ["global", "cn", "us", "de"], "global", true),
      text("client_id", true),
      password("client_secret", true),
      text("tenant_id"),
      text("email"),
      number("chunk_size", 5),
      text("custom_host"),
      bool("disable_disk_usage", false),
      bool("enable_direct_upload", false)
    ]),
    "Onedrive Sharelink": unsupported("Onedrive Sharelink", [text("share_url", true), rootPath("/")]),
    PikPak: unsupported("PikPak", [text("username", true), password("password", true)]),
    Quark: configPatch(supported("Quark", [
      password("cookie", true),
      rootId$2("0"),
      select("order_by", ["none", "file_type", "file_name", "updated_at"], "none"),
      select("order_direction", ["asc", "desc"], "asc"),
      bool("use_transcoding_address", true),
      bool("only_list_video_file", false),
      number("addition_version", 2)
    ]), { default_root: "0", no_overwrite_upload: true }),
    UC: configPatch(supported("UC", [
      password("cookie", true),
      rootId$2("0"),
      select("order_by", ["none", "file_type", "file_name", "updated_at"], "none"),
      select("order_direction", ["asc", "desc"], "asc"),
      bool("use_transcoding_address", false),
      bool("only_list_video_file", false),
      number("addition_version", 2)
    ]), {
      default_root: "0",
      no_overwrite_upload: true,
      only_proxy: true
    }),
    QuarkOpen: configPatch(supported("QuarkOpen", [
      rootId$2("0"),
      select("order_by", ["none", "file_type", "file_name", "updated_at", "created_at"], "none"),
      select("order_direction", ["asc", "desc"], "asc"),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/quarkyun/renewapi"),
      password("access_token"),
      password("refresh_token", true),
      text("app_id", true, "Keep it empty if you don't have one"),
      password("sign_key", true, "Keep it empty if you don't have one")
    ]), {
      default_root: "0",
      no_overwrite_upload: true,
      only_proxy: true,
      note: "Runtime ports OpenList QuarkOpen list/get/read/link and basic management. Multipart upload remains a structured placeholder."
    }),
    QuarkTV: configPatch(supported("QuarkTV", [
      rootId$2("0"),
      select("order_by", ["file_name", "updated_at"], "updated_at"),
      select("order_direction", ["asc", "desc"], "desc"),
      password("refresh_token"),
      text("device_id"),
      text("query_token", false, "don't edit'"),
      select("link_method", ["download", "streaming"], "streaming", true)
    ]), {
      default_root: "0",
      no_overwrite_upload: true,
      no_upload: true,
      note: "Runtime ports OpenList QuarkTV login token refresh, list/get/read/link. OpenList marks management and upload methods as NotImplement."
    }),
    UCTV: configPatch(supported("UCTV", [
      rootId$2("0"),
      select("order_by", ["file_name", "updated_at"], "updated_at"),
      select("order_direction", ["asc", "desc"], "desc"),
      password("refresh_token"),
      text("device_id"),
      text("query_token", false, "don't edit'"),
      select("link_method", ["download", "streaming"], "streaming", true)
    ]), {
      default_root: "0",
      no_overwrite_upload: true,
      no_upload: true,
      note: "Runtime ports OpenList UCTV login token refresh, list/get/read/link. OpenList marks management and upload methods as NotImplement."
    }),
    SFTP: unsupported("SFTP", [text("address", true), text("username", true), password("password"), password("private_key")]),
    SMB: unsupported("SMB", [text("address", true), text("username"), password("password"), text("share_name")]),
    Thunder: unsupported("Thunder", [text("username"), password("password"), password("refresh_token")]),
    URLTree: unsupported("URLTree", [text("url", true)]),
    USS: unsupported("USS", [text("bucket", true), text("endpoint", true), text("operator", true), password("password", true)]),
    Virtual: unsupported("Virtual", []),
    Local: configPatch(unsupported("Local", [
      rootPath("/"),
      bool("directory_size", false, "This might impact host performance"),
      bool("thumbnail", false, "enable thumbnail"),
      text("thumb_cache_folder"),
      field("thumb_concurrency", "string", "16", "", false, "Number of concurrent thumbnail generation goroutines."),
      field("video_thumb_pos", "string", "20%", "", false, "The position of the video thumbnail."),
      bool("show_hidden", true, "show hidden directories and files"),
      field("mkdir_perm", "string", "777"),
      field("recycle_bin_path", "string", "delete permanently")
    ]), {
      no_cache: true,
      no_link_url: true,
      note: "Desktop frontend runtime accesses host fs through Electron. The kernel OpenList HTTP runtime keeps Local metadata only and does not proxy local disks."
    })
  });
  const driverInfoMap = () => buildDriverInfoMap();
  const exposedDriverNames = [
    "SiYuanKernel",
    "SiYuanWorkspace",
    "Local",
    "WebDav",
    "OpenList",
    "AListV3",
    "AList V3",
    "S3",
    "Doge",
    "115 Cloud",
    "123Pan",
    "189Cloud",
    "189CloudPC",
    "189CloudTV",
    "AliyundriveOpen",
    "BaiduNetdisk",
    "Onedrive",
    "Quark",
    "UC",
    "QuarkOpen",
    "QuarkTV",
    "UCTV"
  ];
  const driverNames = () => {
    const map = driverInfoMap();
    return exposedDriverNames.filter((name) => map[name]);
  };
  const boolValue$2 = (value, fallback = false) => {
    if (value === void 0 || value === null || value === "") return fallback;
    return value === true || value === "true" || value === 1 || value === "1";
  };
  const parseTime$1 = (value) => {
    if (!value) return (/* @__PURE__ */ new Date()).toISOString();
    if (typeof value === "number") {
      const date2 = new Date(value > 1e11 ? value : value * 1e3);
      return Number.isNaN(date2.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date2.toISOString();
    }
    const normalized = String(value).replace(/-/g, "/");
    const date = new Date(normalized);
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const dirnameOf = dirname;
  const basenameOf = basename;
  const rawDownloadUrl = (storage, relPath, proxy2 = false) => {
    const prefix = proxy2 ? "/p" : "/d";
    return `/plugin/private/siyuan-cloud${prefix}${normalizePath(storage.mount_path + "/" + relPath)}`;
  };
  const persistAddition$1 = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const createStorageCache = ({ ttl = 5 * 60 * 1e3, linkTtl = 30 * 60 * 1e3 } = {}) => {
    const list = /* @__PURE__ */ new Map();
    const file = /* @__PURE__ */ new Map();
    const link = /* @__PURE__ */ new Map();
    const storageKey2 = (storage) => String(storage.id || storage.mount_path || JSON.stringify(storage.addition_json || {}));
    const cached2 = async (map, key, producer, ttlMs = ttl) => {
      const now = Date.now();
      const hit = map.get(key);
      if (hit && hit.expires > now) return hit.value;
      const value = await producer();
      map.set(key, { value, expires: now + ttlMs });
      return value;
    };
    const clear = (storage) => {
      const prefix = `${storageKey2(storage)}:`;
      for (const map of [list, file, link]) {
        for (const key of map.keys()) {
          if (key.startsWith(prefix)) map.delete(key);
        }
      }
    };
    return {
      clear,
      file: (storage, key, producer) => cached2(file, `${storageKey2(storage)}:file:${key}`, producer),
      link: (storage, key, producer) => cached2(link, `${storageKey2(storage)}:link:${key}`, producer, linkTtl),
      list: (storage, key, producer) => cached2(list, `${storageKey2(storage)}:list:${key}`, producer)
    };
  };
  const encodePayload = (payload) => {
    if (payload === void 0 || payload === null) return "";
    return typeof payload === "string" ? payload : JSON.stringify(payload);
  };
  const proxyPayload = (body, contentType) => {
    if (body === void 0 || body === null) return { payload: "", payloadEncoding: "text" };
    if (typeof body !== "string" && String(contentType || "").includes("application/json")) {
      return { payload: body, payloadEncoding: "json" };
    }
    return { payload: encodePayload(body), payloadEncoding: "json" };
  };
  const forwardProxy = async (client, url, {
    body,
    allowErrorStatus = false,
    contentType = "application/json",
    headers = {},
    method = "GET",
    payloadEncoding,
    redirect,
    responseEncoding = "text",
    timeout = 3e4
  } = {}) => {
    const encoded = payloadEncoding ? { payload: body === void 0 || body === null ? "" : body, payloadEncoding } : proxyPayload(body, contentType);
    const headerPairs = Object.entries(headers).filter(([, value]) => value !== void 0 && value !== null && value !== "").map(([key, value]) => ({ [key]: String(value) }));
    const proxyRequest = {
      url,
      method,
      headers: headerPairs,
      contentType,
      payload: encoded.payload,
      payloadEncoding: encoded.payloadEncoding,
      responseEncoding,
      timeout
    };
    if (typeof redirect === "boolean") proxyRequest.redirect = redirect;
    const response = await client.fetch("/api/network/forwardProxy", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(proxyRequest)
    });
    const payload = await response.json();
    if (payload.code !== 0) throw new Error(payload.msg || "forwardProxy failed");
    const data = payload.data || {};
    if (!allowErrorStatus && data.status >= 400) throw new Error(`HTTP ${data.status}: ${String(data.body || "").slice(0, 300)}`);
    return data;
  };
  const remoteJson = async (client, url, options) => {
    const data = await forwardProxy(client, url, options);
    try {
      return JSON.parse(data.body || "{}");
    } catch (error) {
      throw new Error(`invalid JSON response from ${url}: ${error.message}`);
    }
  };
  const basicAuth = (username, password2) => {
    if (!username && !password2) return "";
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const input = unescape(encodeURIComponent(`${username || ""}:${password2 || ""}`));
    let output = "";
    for (let i = 0; i < input.length; i += 3) {
      const a = input.charCodeAt(i);
      const b = input.charCodeAt(i + 1);
      const c = input.charCodeAt(i + 2);
      output += chars2[a >> 2];
      output += chars2[(a & 3) << 4 | (Number.isNaN(b) ? 0 : b >> 4)];
      output += Number.isNaN(b) ? "=" : chars2[(b & 15) << 2 | (Number.isNaN(c) ? 0 : c >> 6)];
      output += Number.isNaN(c) ? "=" : chars2[c & 63];
    }
    return `Basic ${output}`;
  };
  const joinUrl = (base, path) => {
    const trimmed = String(base || "").replace(/\/+$/, "");
    const encoded = String(path || "/").split("/").filter(Boolean).map((part) => encodeURIComponent(part)).join("/");
    return encoded ? `${trimmed}/${encoded}` : `${trimmed}/`;
  };
  const N = BigInt("0x8686980c0f5a24c4b9d43020cd2c22703ff3f450756529058b1cf88f09b8602136477198a6e2683149659bd122c33592fdb5ad47944ad1ea4d36c6b172aad6338c3bb6ac6227502d010993ac967d1aef00f0c8e038de2e4d3bc2ec368af2e9f10a6f1eda4f7262f136420c07c331b871bf139f74f3010e3c4fe57df3afb71683");
  const E = BigInt("0x10001");
  const KEY_LENGTH = 128;
  const xorKeySeed = [
    240,
    229,
    105,
    174,
    191,
    220,
    191,
    138,
    26,
    69,
    232,
    190,
    125,
    166,
    115,
    184,
    222,
    143,
    231,
    196,
    69,
    218,
    134,
    196,
    155,
    100,
    139,
    20,
    106,
    180,
    241,
    170,
    56,
    1,
    53,
    158,
    38,
    105,
    44,
    134,
    0,
    107,
    79,
    165,
    54,
    52,
    98,
    166,
    42,
    150,
    104,
    24,
    242,
    74,
    253,
    189,
    107,
    151,
    143,
    77,
    143,
    137,
    19,
    183,
    108,
    142,
    147,
    237,
    14,
    13,
    72,
    62,
    215,
    47,
    136,
    216,
    254,
    254,
    126,
    134,
    80,
    149,
    79,
    209,
    235,
    131,
    38,
    52,
    219,
    102,
    123,
    156,
    126,
    157,
    122,
    129,
    50,
    234,
    182,
    51,
    222,
    58,
    169,
    89,
    52,
    102,
    59,
    170,
    186,
    129,
    96,
    72,
    185,
    213,
    129,
    156,
    248,
    108,
    132,
    119,
    255,
    84,
    120,
    38,
    95,
    190,
    232,
    30,
    54,
    159,
    52,
    128,
    92,
    69,
    44,
    155,
    118,
    213,
    27,
    143,
    204,
    195,
    184,
    245
  ];
  const xorClientKey = [120, 6, 173, 76, 51, 134, 93, 24, 76, 1, 63, 70];
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const utf8Bytes$7 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    return Uint8Array.from([...text2].map((char) => char.charCodeAt(0)));
  };
  const utf8Text = (bytes2) => {
    const binary = [...bytes2].map((byte) => String.fromCharCode(byte)).join("");
    try {
      return decodeURIComponent(escape(binary));
    } catch (_) {
      return binary;
    }
  };
  const bytesToBase64$7 = (bytes2) => {
    let out = "";
    for (let i = 0; i < bytes2.length; i += 3) {
      const a = bytes2[i];
      const b = bytes2[i + 1];
      const c = bytes2[i + 2];
      out += chars[a >> 2];
      out += chars[(a & 3) << 4 | (b || 0) >> 4];
      out += i + 1 < bytes2.length ? chars[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i + 2 < bytes2.length ? chars[c & 63] : "=";
    }
    return out;
  };
  const base64ToBytes$8 = (value) => {
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars.indexOf(clean[i]);
      const b = chars.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const modPow$1 = (base, exp, mod) => {
    let result = 1n;
    let value = base % mod;
    let power = exp;
    while (power > 0n) {
      if (power & 1n) result = result * value % mod;
      value = value * value % mod;
      power >>= 1n;
    }
    return result;
  };
  const bytesToBigInt$1 = (bytes2) => {
    let value = 0n;
    for (const byte of bytes2) value = (value << 8n) + BigInt(byte);
    return value;
  };
  const bigIntToBytes$1 = (value, length) => {
    const out = new Uint8Array(length);
    let current = value;
    for (let i = length - 1; i >= 0; i -= 1) {
      out[i] = Number(current & 0xffn);
      current >>= 8n;
    }
    return out;
  };
  const randomNonZero = () => Math.max(1, Math.floor(Math.random() * 255));
  const rsaEncryptSlice = (input) => {
    const padSize = KEY_LENGTH - input.length - 3;
    const block = new Uint8Array(KEY_LENGTH);
    block[0] = 0;
    block[1] = 2;
    for (let i = 0; i < padSize; i += 1) block[2 + i] = randomNonZero();
    block[padSize + 2] = 0;
    block.set(input, padSize + 3);
    return bigIntToBytes$1(modPow$1(bytesToBigInt$1(block), E, N), KEY_LENGTH);
  };
  const rsaEncrypt = (input) => {
    const chunks = [];
    for (let i = 0; i < input.length; i += KEY_LENGTH - 11) {
      chunks.push(rsaEncryptSlice(input.slice(i, i + KEY_LENGTH - 11)));
    }
    return Uint8Array.from(chunks.flatMap((chunk) => [...chunk]));
  };
  const rsaDecryptSlice = (input) => {
    const data = bigIntToBytes$1(modPow$1(bytesToBigInt$1(input), E, N), KEY_LENGTH);
    const start = data.findIndex((byte, index) => index > 0 && byte === 0);
    return start >= 0 ? data.slice(start + 1) : new Uint8Array();
  };
  const rsaDecrypt = (input) => {
    const chunks = [];
    for (let i = 0; i < input.length; i += KEY_LENGTH) chunks.push(rsaDecryptSlice(input.slice(i, i + KEY_LENGTH)));
    return Uint8Array.from(chunks.flatMap((chunk) => [...chunk]));
  };
  const xorDeriveKey = (seed, size) => {
    const key = new Uint8Array(size);
    for (let i = 0; i < size; i += 1) {
      key[i] = seed[i] + xorKeySeed[size * i] & 255 ^ xorKeySeed[size * (size - i - 1)];
    }
    return key;
  };
  const xorTransform = (data, key) => {
    const mod = data.length % 4;
    for (let i = 0; i < data.length; i += 1) {
      const keyIndex = i < mod ? i % key.length : (i - mod) % key.length;
      data[i] ^= key[keyIndex];
    }
  };
  const reverse = (data) => data.reverse();
  const generateKey = () => Uint8Array.from({ length: 16 }, () => Math.floor(Math.random() * 256));
  const encode115 = (input, key = generateKey()) => {
    const bytes2 = utf8Bytes$7(input);
    const buf = new Uint8Array(16 + bytes2.length);
    buf.set(key, 0);
    buf.set(bytes2, 16);
    const body = buf.slice(16);
    xorTransform(body, xorDeriveKey(key, 4));
    reverse(body);
    xorTransform(body, xorClientKey);
    buf.set(body, 16);
    return bytesToBase64$7(rsaEncrypt(buf));
  };
  const decode115WithKey = (input, key) => {
    const data = rsaDecrypt(base64ToBytes$8(input));
    const decodeKey = key || data.slice(0, 16);
    const output = data.slice(16);
    xorTransform(output, xorDeriveKey(data.slice(0, 16), 12));
    reverse(output);
    xorTransform(output, xorDeriveKey(decodeKey, 4));
    return {
      key: data.slice(0, 16),
      text: utf8Text(output)
    };
  };
  const decode115 = (input, key) => decode115WithKey(input, key).text;
  const API_LOGIN_CHECK = "https://passportapi.115.com/app/1.0/web/1.0/check/sso";
  const API_FILE_LIST = "https://webapi.115.com/files";
  const API_DIR_ADD = "https://webapi.115.com/files/add";
  const API_FILE_DELETE = "https://webapi.115.com/rb/delete";
  const API_FILE_MOVE = "https://webapi.115.com/files/move";
  const API_FILE_COPY = "https://webapi.115.com/files/copy";
  const API_FILE_RENAME = "https://webapi.115.com/files/batch_rename";
  const API_FILE_INDEX_INFO = "https://webapi.115.com/files/index_info";
  const API_DOWNLOAD_URL = "https://proapi.115.com/app/chrome/downurl";
  const API_QRCODE_LOGIN = "https://passportapi.115.com/app/1.0/%s/1.0/login/qrcode";
  const UA$1 = "Mozilla/5.0 115Browser/35.6.0.3";
  const MAX_PAGE_SIZE = 1150;
  const limiterState = /* @__PURE__ */ new WeakMap();
  const additionValue$1 = (addition, lowerName, upperName, fallback = "") => {
    const value = (addition == null ? void 0 : addition[lowerName]) ?? (addition == null ? void 0 : addition[upperName]);
    return value === void 0 || value === null || value === "" ? fallback : value;
  };
  const cookieHeader$2 = (addition) => additionValue$1(addition, "cookie", "Cookie");
  const rootId$1 = (addition) => additionValue$1(addition, "root_folder_id", "RootFolderID", "0");
  const pageSize = (addition) => Math.min(MAX_PAGE_SIZE, Math.max(1, Number(additionValue$1(addition, "page_size", "PageSize", 1e3)) || 1e3));
  const limitRate = (addition) => Math.max(0, Number(additionValue$1(addition, "limit_rate", "LimitRate", 2)) || 0);
  const toForm = (data) => new URLSearchParams(Object.entries(data).filter(([, value]) => value !== void 0 && value !== null).map(([key, value]) => [key, String(value)])).toString();
  const requestHeaders = (storage, extra = {}) => ({
    Cookie: cookieHeader$2(storage.addition_json),
    "User-Agent": UA$1,
    ...extra
  });
  const check115 = (payload, fallback = "115 request failed") => {
    const code = Number((payload == null ? void 0 : payload.errno) ?? (payload == null ? void 0 : payload.errNo) ?? (payload == null ? void 0 : payload.code) ?? 0);
    if ((payload == null ? void 0 : payload.state) === false || code !== 0 || (payload == null ? void 0 : payload.error)) {
      throw new Error((payload == null ? void 0 : payload.msg) || (payload == null ? void 0 : payload.message) || (payload == null ? void 0 : payload.error) || `${fallback}: ${code}`);
    }
    return payload;
  };
  const requestJson = async (client, storage, url, {
    body,
    headers = {},
    method = "GET",
    query = {}
  } = {}) => {
    const target = new URL(url);
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const formBody2 = body ? toForm(body) : void 0;
    const payload = await remoteJson(client, target.toString(), {
      body: formBody2,
      contentType: body ? "application/x-www-form-urlencoded" : "application/json;charset=UTF-8",
      headers: requestHeaders(storage, headers),
      method,
      payloadEncoding: body ? "text" : void 0
    });
    return check115(payload);
  };
  const parse115Time = (value) => {
    if (!value) return (/* @__PURE__ */ new Date()).toISOString();
    if (/^\d+$/.test(String(value))) {
      const date2 = new Date(Number(value) * 1e3);
      return Number.isNaN(date2.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date2.toISOString();
    }
    const date = /* @__PURE__ */ new Date(String(value).replace(/-/g, "/") + " GMT+0800");
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const isDirInfo = (item) => !(item == null ? void 0 : item.fid);
  const fileToObj$9 = (item, relPath, storage) => {
    const isDir2 = isDirInfo(item);
    const id = String(isDir2 ? item.cid : item.fid);
    return {
      name: String(item.n || item.name || ""),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(item.s || 0),
      modified: parse115Time(item.t),
      created: parse115Time(item.tp),
      thumb: item.u || "",
      sign: "",
      type: isDir2 ? 1 : 0,
      hashinfo: item.sha || "",
      hash_info: item.sha ? { sha1: item.sha } : {},
      id,
      pick_code: item.pc || item.pick_code || "",
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider: "115 Cloud"
    };
  };
  const listById = async (client, storage, id) => {
    const addition = storage.addition_json;
    const limit = pageSize(addition);
    const content = [];
    for (let offset = 0; ; offset += limit) {
      const data = await requestJson(client, storage, API_FILE_LIST, {
        query: {
          aid: "1",
          asc: "1",
          cid: id || "0",
          fc_mix: "0",
          format: "json",
          limit,
          natsort: "0",
          o: "user_ptime",
          offset,
          record_open_time: "1",
          show_dir: "1",
          snap: "0"
        }
      });
      content.push(...data.data || []);
      if (offset + limit >= Number(data.count || content.length)) break;
    }
    return content;
  };
  const findChild = async (client, storage, parentId, name) => {
    const items = await listById(client, storage, parentId);
    const target = items.find((item) => String(item.n || item.name || "") === name);
    if (!target) throw new Error(`object [${name}] not found`);
    return target;
  };
  const resolveFile$9 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    if (clean === "/") {
      return {
        cid: rootId$1(storage.addition_json),
        n: "root",
        t: Math.floor(Date.now() / 1e3),
        tp: Math.floor(Date.now() / 1e3)
      };
    }
    const parts = clean.split("/").filter(Boolean);
    let parentId = rootId$1(storage.addition_json);
    let item = null;
    for (const part of parts) {
      item = await findChild(client, storage, parentId, part);
      parentId = String(isDirInfo(item) ? item.cid : item.fid);
    }
    return item;
  };
  const saveDriverStorage$1 = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const waitLimit = async (storage) => {
    const rate = limitRate(storage.addition_json);
    if (rate <= 0) return;
    const interval = 1e3 / rate;
    const now = Date.now();
    const previous = limiterState.get(storage) || 0;
    const wait = Math.max(0, previous - now);
    limiterState.set(storage, Math.max(now, previous) + interval);
    if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
  };
  const loginByQrToken = async (client, storage) => {
    var _a;
    const addition = storage.addition_json;
    const token = additionValue$1(addition, "qrcode_token", "QRCodeToken");
    if (!token) return false;
    const source = additionValue$1(addition, "qrcode_source", "QRCodeSource", "web");
    const data = await requestJson(client, storage, API_QRCODE_LOGIN.replace("%s", encodeURIComponent(source)), {
      body: { account: token, app: source },
      method: "POST"
    });
    const credential = ((_a = data.data) == null ? void 0 : _a.cookie) || {};
    if (!credential.UID || !credential.CID || !credential.SEID) throw new Error("115 QR login returned empty credential");
    addition.cookie = `UID=${credential.UID};CID=${credential.CID};SEID=${credential.SEID};KID=${credential.KID || ""}`;
    addition.qrcode_token = "";
    await saveDriverStorage$1(storage);
    return true;
  };
  const ensureLogin$2 = async (client, storage) => {
    if (!cookieHeader$2(storage.addition_json)) await loginByQrToken(client, storage);
    if (!cookieHeader$2(storage.addition_json)) throw new Error("missing cookie or qrcode account");
    const data = await requestJson(client, storage, API_LOGIN_CHECK, {
      query: { _: Date.now() }
    });
    return data;
  };
  const downloadInfo = async (client, storage, file, userAgent = UA$1) => {
    var _a;
    const key = generateKey();
    const data = encode115(JSON.stringify({ pickcode: file.pick_code || file.pc }), key);
    const resp = await requestJson(client, storage, API_DOWNLOAD_URL, {
      body: { data },
      headers: { "User-Agent": userAgent },
      method: "POST",
      query: { t: Date.now() }
    });
    const decoded = JSON.parse(decode115(String(resp.data || ""), key) || "{}");
    const first = Object.values(decoded)[0];
    if (!((_a = first == null ? void 0 : first.url) == null ? void 0 : _a.url)) throw new Error("115 download url is empty");
    return first;
  };
  const create115Driver = ({ client }) => ({
    async test(storage) {
      var _a;
      const data = await ensureLogin$2(client, storage);
      return ((_a = data == null ? void 0 : data.data) == null ? void 0 : _a.user_id) ? `115 user ${data.data.user_id}` : "115 login ok";
    },
    async list(storage, relPath) {
      await waitLimit(storage);
      await ensureLogin$2(client, storage);
      const dir = await resolveFile$9(client, storage, relPath);
      const dirId = String(dir.cid || dir.fid || rootId$1(storage.addition_json));
      const content = (await listById(client, storage, dirId)).map((item) => fileToObj$9(item, normalizePath(relPath + "/" + String(item.n || item.name || "")), storage));
      return {
        content,
        direct_upload_tools: [],
        header: "",
        provider: "115 Cloud",
        readme: "",
        total: content.length,
        write: true
      };
    },
    async get(storage, relPath) {
      await waitLimit(storage);
      await ensureLogin$2(client, storage);
      const item = await resolveFile$9(client, storage, relPath);
      const obj = fileToObj$9(item, relPath, storage);
      return {
        ...obj,
        raw_url: obj.is_dir ? "" : rawDownloadUrl(storage, relPath),
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      await waitLimit(storage);
      await ensureLogin$2(client, storage);
      const item = await resolveFile$9(client, storage, relPath);
      const obj = fileToObj$9(item, relPath, storage);
      if (obj.is_dir) throw new Error("not file");
      const info = await downloadInfo(client, storage, obj, options.userAgent || UA$1);
      return {
        link: {
          url: info.url.url,
          header: info.header || {},
          content_length: Number(info.file_size || obj.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      await waitLimit(storage);
      await ensureLogin$2(client, storage);
      const parent = await resolveFile$9(client, storage, normalizePath(relPath).replace(/\/[^/]+$/, "") || "/");
      await requestJson(client, storage, API_DIR_ADD, {
        body: { cname: basename(relPath), pid: parent.cid || parent.fid || rootId$1(storage.addition_json) },
        method: "POST"
      });
    },
    async move(storage, relPath, dstRelPath) {
      await waitLimit(storage);
      await ensureLogin$2(client, storage);
      const item = await resolveFile$9(client, storage, relPath);
      const dst = await resolveFile$9(client, storage, dstRelPath);
      await requestJson(client, storage, API_FILE_MOVE, {
        body: { "fid[0]": item.fid || item.cid, pid: dst.cid || dst.fid },
        method: "POST"
      });
    },
    async copy(storage, relPath, dstRelPath) {
      await waitLimit(storage);
      await ensureLogin$2(client, storage);
      const item = await resolveFile$9(client, storage, relPath);
      const dst = await resolveFile$9(client, storage, dstRelPath);
      await requestJson(client, storage, API_FILE_COPY, {
        body: { "fid[0]": item.fid || item.cid, pid: dst.cid || dst.fid },
        method: "POST"
      });
    },
    async remove(storage, relPath) {
      await waitLimit(storage);
      await ensureLogin$2(client, storage);
      const item = await resolveFile$9(client, storage, relPath);
      await requestJson(client, storage, API_FILE_DELETE, {
        body: { "fid[0]": item.fid || item.cid },
        method: "POST"
      });
    },
    async rename(storage, relPath, newName) {
      await waitLimit(storage);
      await ensureLogin$2(client, storage);
      const item = await resolveFile$9(client, storage, relPath);
      const id = item.fid || item.cid;
      await requestJson(client, storage, API_FILE_RENAME, {
        body: { fid: id, file_name: newName, [`files_new_name[${id}]`]: newName },
        method: "POST"
      });
    },
    async put() {
      throw new Error("115 Cloud upload is not implemented in the SiYuan kernel port yet");
    },
    async details(storage) {
      var _a, _b, _c, _d, _e, _f;
      await waitLimit(storage);
      await ensureLogin$2(client, storage);
      const data = await requestJson(client, storage, API_FILE_INDEX_INFO);
      const total = Number(((_c = (_b = (_a = data.data) == null ? void 0 : _a.space_info) == null ? void 0 : _b.all_total) == null ? void 0 : _c.size) || 0);
      const used = Number(((_f = (_e = (_d = data.data) == null ? void 0 : _d.space_info) == null ? void 0 : _e.all_use) == null ? void 0 : _f.size) || 0);
      return {
        total_space: total,
        used_space: used,
        free_space: Math.max(0, total - used)
      };
    }
  });
  const utf8$2 = (input) => unescape(encodeURIComponent(String(input)));
  const rotr = (value, bits) => value >>> bits | value << 32 - bits;
  const hex$7 = (bytes2) => Array.from(bytes2, (b) => b.toString(16).padStart(2, "0")).join("");
  const bytes$2 = (input) => {
    if (input instanceof Uint8Array) return input;
    const text2 = utf8$2(input);
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const K = [
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ];
  const sha256Bytes = (message) => {
    const msg = bytes$2(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1779033703;
    let h1 = 3144134277;
    let h2 = 1013904242;
    let h3 = 2773480762;
    let h4 = 1359893119;
    let h5 = 2600822924;
    let h6 = 528734635;
    let h7 = 1541459225;
    const w = new Uint32Array(64);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4);
      for (let i = 16; i < 64; i += 1) {
        const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
        const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
        w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
      }
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      let f = h5;
      let g = h6;
      let h = h7;
      for (let i = 0; i < 64; i += 1) {
        const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const ch = e & f ^ ~e & g;
        const temp1 = h + s1 + ch + K[i] + w[i] >>> 0;
        const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const maj = a & b ^ a & c ^ b & c;
        const temp2 = s0 + maj >>> 0;
        h = g;
        g = f;
        f = e;
        e = d + temp1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = temp1 + temp2 >>> 0;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
      h5 = h5 + f >>> 0;
      h6 = h6 + g >>> 0;
      h7 = h7 + h >>> 0;
    }
    const out = new Uint8Array(32);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4, h5, h6, h7].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const sha256Hex = (message) => hex$7(sha256Bytes(message));
  const hmacSha256 = (key, message) => {
    let keyBytes = bytes$2(key);
    if (keyBytes.length > 64) keyBytes = sha256Bytes(keyBytes);
    const ipad = new Uint8Array(64);
    const opad = new Uint8Array(64);
    for (let i = 0; i < 64; i += 1) {
      const b = keyBytes[i] || 0;
      ipad[i] = b ^ 54;
      opad[i] = b ^ 92;
    }
    const inner = new Uint8Array(ipad.length + bytes$2(message).length);
    inner.set(ipad);
    inner.set(bytes$2(message), ipad.length);
    const outer = new Uint8Array(opad.length + 32);
    outer.set(opad);
    outer.set(sha256Bytes(inner), opad.length);
    return sha256Bytes(outer);
  };
  const amzDate$1 = (date) => date.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp$1 = (date) => amzDate$1(date).slice(0, 8);
  const encodeRfc3986$1 = (value) => encodeURIComponent(value).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
  const signAwsV4 = ({ accessKeyId, body = "", headers = {}, method, region, secretAccessKey, service = "s3", sessionToken = "", url }) => {
    const parsed = new URL(url);
    const now = /* @__PURE__ */ new Date();
    const amz = amzDate$1(now);
    const date = dateStamp$1(now);
    const payloadHash = sha256Hex(body || "");
    const normalizedHeaders = {
      host: parsed.host,
      "x-amz-content-sha256": payloadHash,
      "x-amz-date": amz,
      ...Object.fromEntries(Object.entries(headers).map(([key, value]) => [key.toLowerCase(), String(value).trim()]))
    };
    if (sessionToken) normalizedHeaders["x-amz-security-token"] = sessionToken;
    const signedHeaders = Object.keys(normalizedHeaders).sort();
    const canonicalHeaders = signedHeaders.map((key) => `${key}:${normalizedHeaders[key]}
`).join("");
    const query = [...parsed.searchParams.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => `${encodeRfc3986$1(key)}=${encodeRfc3986$1(value)}`).join("&");
    const canonicalRequest = [
      method.toUpperCase(),
      parsed.pathname || "/",
      query,
      canonicalHeaders,
      signedHeaders.join(";"),
      payloadHash
    ].join("\n");
    const scope = `${date}/${region || "us-east-1"}/${service}/aws4_request`;
    const stringToSign = [
      "AWS4-HMAC-SHA256",
      amz,
      scope,
      sha256Hex(canonicalRequest)
    ].join("\n");
    const kDate = hmacSha256(`AWS4${secretAccessKey}`, date);
    const kRegion = hmacSha256(kDate, region || "us-east-1");
    const kService = hmacSha256(kRegion, service);
    const kSigning = hmacSha256(kService, "aws4_request");
    const signature = hex$7(hmacSha256(kSigning, stringToSign));
    return {
      ...normalizedHeaders,
      Authorization: `AWS4-HMAC-SHA256 Credential=${accessKeyId}/${scope}, SignedHeaders=${signedHeaders.join(";")}, Signature=${signature}`
    };
  };
  const B_API = "https://www.123pan.com/b/api";
  const LOGIN_API = "https://login.123pan.com/api";
  const SIGN_IN = LOGIN_API + "/user/sign_in";
  const USER_INFO = B_API + "/user/info";
  const FILE_LIST = B_API + "/file/list/new";
  const DOWNLOAD_INFO = B_API + "/file/download_info";
  const MKDIR = B_API + "/file/upload_request";
  const UPLOAD_REQUEST = B_API + "/file/upload_request";
  const UPLOAD_COMPLETE = B_API + "/file/upload_complete";
  const S3_PRE_SIGNED_URLS = B_API + "/file/s3_repare_upload_parts_batch";
  const S3_AUTH = B_API + "/file/s3_upload_object/auth";
  const UPLOAD_COMPLETE_V2 = B_API + "/file/upload_complete/v2";
  const MOVE = B_API + "/file/mod_pid";
  const RENAME = B_API + "/file/rename";
  const TRASH = B_API + "/file/trash";
  const UPLOAD_CHUNK_SIZE = 16 * 1024 * 1024;
  const crcTable = (() => {
    const table = [];
    for (let i = 0; i < 256; i += 1) {
      let c = i;
      for (let j = 0; j < 8; j += 1) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
      table[i] = c >>> 0;
    }
    return table;
  })();
  const crc32 = (value) => {
    let crc = 4294967295;
    const input = unescape(encodeURIComponent(String(value || "")));
    for (let i = 0; i < input.length; i += 1) {
      crc = crc >>> 8 ^ crcTable[(crc ^ input.charCodeAt(i)) & 255];
    }
    return ((crc ^ 4294967295) >>> 0).toString();
  };
  const pad = (value) => String(value).padStart(2, "0");
  const signPath = (path, os = "web", version = "3") => {
    const table = ["a", "d", "e", "f", "g", "h", "l", "m", "y", "i", "j", "n", "o", "p", "k", "q", "r", "s", "t", "u", "b", "c", "v", "w", "s", "z"];
    const random = String(Math.round(1e7 * Math.random()));
    const now = new Date(Date.now() + 8 * 3600 * 1e3);
    const timestamp2 = String(Math.floor(now.getTime() / 1e3));
    const nowStr = `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}${pad(now.getUTCHours())}${pad(now.getUTCMinutes())}`;
    const encodedTime = nowStr.split("").map((char) => table[Number(char)]).join("");
    const timeSign = crc32(encodedTime);
    const data = [timestamp2, random, path, os, version, timeSign].join("|");
    const dataSign = crc32(data);
    return [timeSign, [timestamp2, random, dataSign].join("-")];
  };
  const signedApi = (rawUrl) => {
    const url = new URL(rawUrl);
    const [key, value] = signPath(url.pathname, "web", "3");
    url.searchParams.append(key, value);
    return url.toString();
  };
  const isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || ""));
  const cleanUsername = (value) => String(value || "").trim().replace(/[\s-]/g, "");
  const decodeBase64 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    let output = "";
    let buffer = 0;
    let bits = 0;
    for (const char of String(value || "")) {
      if (char === "=") break;
      const index = chars2.indexOf(char);
      if (index < 0) continue;
      buffer = buffer << 6 | index;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        output += String.fromCharCode(buffer >> bits & 255);
      }
    }
    try {
      return decodeURIComponent(escape(output));
    } catch (_) {
      return output;
    }
  };
  const base64ToBytes$7 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars2.indexOf(clean[i]);
      const b = chars2.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars2.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars2.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$6 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i = 0; i < bytes2.length; i += 3) {
      const a = bytes2[i];
      const b = bytes2[i + 1];
      const c = bytes2[i + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$6 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const leftRotate$5 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$5 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$6(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i = 0; i < 64; i += 1) {
        let f;
        let g;
        if (i < 16) {
          f = b & c | ~b & d;
          g = i;
        } else if (i < 32) {
          f = d & b | ~d & c;
          g = (5 * i + 1) % 16;
        } else if (i < 48) {
          f = b ^ c ^ d;
          g = (3 * i + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i % 16;
        }
        const tmp = d;
        const word = view.getUint32(offset + g * 4, true);
        d = c;
        c = b;
        b = b + leftRotate$5(a + f + k[i] + word >>> 0, s[i]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const uploadBytes$6 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$7(content || "") : utf8Bytes$6(content || "");
  const platform = (addition) => addition.platform || addition.Platform || "web";
  const headersFor$1 = (addition, token = addition.access_token || addition.AccessToken || "") => ({
    origin: "https://www.123pan.com",
    referer: "https://www.123pan.com/",
    authorization: token ? `Bearer ${token}` : "",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) siyuan-cloud-client",
    platform: platform(addition),
    "app-version": "3"
  });
  const check123 = (payload) => {
    const code = Number((payload == null ? void 0 : payload.code) ?? 0);
    if (code !== 0) throw new Error((payload == null ? void 0 : payload.message) || `123Pan code ${code}`);
    return payload;
  };
  const login$1 = async (client, addition) => {
    var _a;
    const username = addition.username || addition.Username || "";
    const passport = cleanUsername(username);
    const password2 = addition.password || addition.Password || "";
    const body = isEmail(username) ? { mail: String(username).trim(), password: password2, type: 2 } : { passport, password: password2, remember: true };
    const payload = await remoteJson(client, SIGN_IN, {
      body,
      headers: {
        origin: "https://www.123pan.com",
        referer: "https://www.123pan.com/",
        "user-agent": "Dart/2.19(dart:io)-siyuan-cloud",
        platform: "web",
        "app-version": "3"
      },
      method: "POST"
    });
    if (Number(payload == null ? void 0 : payload.code) !== 200) throw new Error((payload == null ? void 0 : payload.message) || "123Pan login failed");
    addition.access_token = ((_a = payload == null ? void 0 : payload.data) == null ? void 0 : _a.token) || "";
    return addition.access_token;
  };
  const request123 = async (client, storage, url, {
    body,
    method = "GET",
    query,
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    if (!addition.access_token && !addition.AccessToken) await login$1(client, addition);
    const api = new URL(url);
    for (const [key, value] of Object.entries(query || {})) api.searchParams.set(key, String(value));
    const payload = await remoteJson(client, signedApi(api.toString()), {
      allowErrorStatus: true,
      body,
      headers: headersFor$1(addition),
      method
    });
    if (Number(payload == null ? void 0 : payload.code) === 401 && retry) {
      await login$1(client, addition);
      return request123(client, storage, url, { body, method, query, retry: false });
    }
    return check123(payload);
  };
  const parseTime = (value) => {
    const date = value ? new Date(value) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const idOf = (file) => String((file == null ? void 0 : file.FileId) ?? (file == null ? void 0 : file.fileId) ?? (file == null ? void 0 : file.id) ?? "");
  const fileNameOf$3 = (file) => (file == null ? void 0 : file.FileName) || (file == null ? void 0 : file.fileName) || (file == null ? void 0 : file.name) || "";
  const isDir$3 = (file) => Number((file == null ? void 0 : file.Type) ?? (file == null ? void 0 : file.type) ?? 0) === 1;
  const thumbOf = (file) => {
    const raw = (file == null ? void 0 : file.DownloadUrl) || (file == null ? void 0 : file.downloadUrl) || "";
    if (!raw) return "";
    try {
      const url = new URL(raw);
      url.pathname = url.pathname.replace(/_24_24$/, "") + "_70_70";
      url.searchParams.set("w", "70");
      url.searchParams.set("h", "70");
      if (!url.searchParams.has("type")) url.searchParams.set("type", basename(fileNameOf$3(file)).replace(/^\./, ""));
      if (!url.searchParams.has("trade_key")) url.searchParams.set("trade_key", "123pan-thumbnail");
      return url.toString();
    } catch (_) {
      return "";
    }
  };
  const objFromFile = (file, relPath, storage) => {
    const dir = isDir$3(file);
    return {
      name: fileNameOf$3(file),
      path: normalizePath(relPath),
      is_dir: dir,
      size: Number((file == null ? void 0 : file.Size) ?? (file == null ? void 0 : file.size) ?? 0),
      modified: parseTime((file == null ? void 0 : file.UpdateAt) || (file == null ? void 0 : file.updateAt)),
      created: parseTime((file == null ? void 0 : file.UpdateAt) || (file == null ? void 0 : file.updateAt)),
      sign: "",
      thumb: thumbOf(file),
      type: dir ? 1 : 0,
      hashinfo: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) || "",
      hash_info: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) ? { md5: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) } : {},
      id: idOf(file),
      raw_url: dir ? "" : `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
      provider: "123Pan",
      file
    };
  };
  const rootId = (addition) => String(addition.root_folder_id || addition.RootFolderID || "0");
  const listByParentId = async (client, storage, parentId, parentName) => {
    let page = 1;
    let total = 0;
    const result = [];
    for (; ; ) {
      const payload = await request123(client, storage, FILE_LIST, {
        method: "GET",
        query: {
          driveId: "0",
          limit: "100",
          next: "0",
          orderBy: "file_id",
          orderDirection: "desc",
          parentFileId: parentId,
          trashed: "false",
          SearchData: "",
          Page: page,
          OnlyLookAbnormalFile: "0",
          event: "homeListFile",
          operateType: "4",
          inDirectSpace: "false"
        }
      });
      const data = payload.data || {};
      const list = data.InfoList || data.infoList || [];
      result.push(...list);
      total = Number(data.Total || data.total || total);
      page += 1;
      if (!list.length || String(data.Next ?? data.next) === "-1") break;
    }
    if (total && result.length !== total) {
      result.warning = `incorrect file count from remote at ${parentName}: expected ${total}, got ${result.length}`;
    }
    return result;
  };
  const resolveFile$8 = async (client, storage, relPath) => {
    const current = normalizePath(relPath || "/");
    if (current === "/") return { id: rootId(storage.addition_json), name: "root", path: "/", isRoot: true };
    let parentId = rootId(storage.addition_json);
    let parentPath = "/";
    let found = null;
    for (const part of current.split("/").filter(Boolean)) {
      const files = await listByParentId(client, storage, parentId, parentPath);
      found = files.find((file) => fileNameOf$3(file) === part);
      if (!found) throw new Error(`object not found: ${current}`);
      parentId = idOf(found);
      parentPath = normalizePath(parentPath + "/" + part);
    }
    return { file: found, id: idOf(found), name: fileNameOf$3(found), path: current };
  };
  const downloadUrlFor = async (client, storage, file) => {
    var _a, _b, _c, _d;
    const payload = await request123(client, storage, DOWNLOAD_INFO, {
      body: {
        driveId: 0,
        etag: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) || "",
        fileId: Number(idOf(file)),
        fileName: fileNameOf$3(file),
        s3keyFlag: (file == null ? void 0 : file.S3KeyFlag) || (file == null ? void 0 : file.s3KeyFlag) || "",
        size: Number((file == null ? void 0 : file.Size) ?? (file == null ? void 0 : file.size) ?? 0),
        type: Number((file == null ? void 0 : file.Type) ?? (file == null ? void 0 : file.type) ?? 0)
      },
      method: "POST"
    });
    const raw = ((_a = payload == null ? void 0 : payload.data) == null ? void 0 : _a.DownloadUrl) || ((_b = payload == null ? void 0 : payload.data) == null ? void 0 : _b.downloadUrl) || "";
    if (!raw) throw new Error("get download url failed");
    let referer = "https://www.123pan.com/";
    try {
      const original = new URL(raw);
      referer = `${original.protocol}//${original.host}/`;
    } catch (_) {
    }
    let candidate = raw;
    try {
      const url = new URL(raw);
      const params = url.searchParams.get("params");
      candidate = params ? decodeBase64(params) : url.toString();
    } catch (_) {
      candidate = raw;
    }
    try {
      const resolved = await forwardProxy(client, candidate, {
        allowErrorStatus: true,
        contentType: "application/json",
        headers: { Referer: "https://www.123pan.com/" },
        method: "GET",
        responseEncoding: "text"
      });
      const data = JSON.parse(resolved.body || "{}");
      return {
        url: ((_c = data == null ? void 0 : data.data) == null ? void 0 : _c.redirect_url) || ((_d = data == null ? void 0 : data.data) == null ? void 0 : _d.redirectUrl) || candidate,
        referer
      };
    } catch (_) {
      return { url: candidate, referer };
    }
  };
  const linkFor$5 = async (client, storage, file) => {
    const { url, referer } = await downloadUrlFor(client, storage, file);
    return {
      link: {
        url,
        header: {
          Referer: [referer]
        },
        content_length: Number((file == null ? void 0 : file.Size) ?? (file == null ? void 0 : file.size) ?? 0)
      }
    };
  };
  const uploadReqData = (data = {}) => data.data || data.Data || {};
  const uploadField = (data, name) => (data == null ? void 0 : data[name]) ?? (data == null ? void 0 : data[name.charAt(0).toLowerCase() + name.slice(1)]) ?? "";
  const getS3UploadUrls = async (client, storage, upReq, start, end, multipart) => {
    const data = uploadReqData(upReq);
    const payload = await request123(client, storage, multipart ? S3_PRE_SIGNED_URLS : S3_AUTH, {
      body: {
        StorageNode: uploadField(data, "StorageNode"),
        bucket: uploadField(data, "Bucket"),
        key: uploadField(data, "Key"),
        partNumberEnd: end,
        partNumberStart: start,
        uploadId: uploadField(data, "UploadId")
      },
      method: "POST"
    });
    return uploadReqData(payload).presignedUrls || uploadReqData(payload).PreSignedUrls || {};
  };
  const completeS3V2 = (client, storage, upReq, size, isMultipart) => {
    const data = uploadReqData(upReq);
    return request123(client, storage, UPLOAD_COMPLETE_V2, {
      body: {
        StorageNode: uploadField(data, "StorageNode"),
        bucket: uploadField(data, "Bucket"),
        fileId: uploadField(data, "FileId"),
        fileSize: size,
        isMultipart,
        key: uploadField(data, "Key"),
        uploadId: uploadField(data, "UploadId")
      },
      method: "POST"
    });
  };
  const putPresignedChunks = async (client, storage, upReq, bytes2) => {
    const chunkCount = Math.max(1, Math.ceil(bytes2.length / UPLOAD_CHUNK_SIZE));
    const multipart = chunkCount > 1;
    const batchSize = multipart ? 10 : 1;
    for (let index = 1; index <= chunkCount; index += batchSize) {
      const start = index;
      const end = Math.min(index + batchSize, chunkCount + 1);
      const urls = await getS3UploadUrls(client, storage, upReq, start, end, multipart);
      for (let cur = start; cur < end; cur += 1) {
        const offset = (cur - 1) * UPLOAD_CHUNK_SIZE;
        const chunk = bytes2.slice(offset, Math.min(offset + UPLOAD_CHUNK_SIZE, bytes2.length));
        const url = urls[String(cur)];
        if (!url) throw new Error(`upload url is empty for 123Pan chunk ${cur}`);
        await forwardProxy(client, url, {
          body: bytesToBase64$6(chunk),
          contentType: "application/octet-stream",
          headers: { "Content-Length": String(chunk.length) },
          method: "PUT",
          payloadEncoding: "base64",
          responseEncoding: "text",
          timeout: 12e4
        });
      }
    }
    await completeS3V2(client, storage, upReq, bytes2.length, multipart);
  };
  const putAwsS3 = async (client, upReq, bytes2, mime) => {
    const data = uploadReqData(upReq);
    const endpoint = String(uploadField(data, "EndPoint")).replace(/\/+$/, "");
    const bucket = uploadField(data, "Bucket");
    const key = uploadField(data, "Key");
    const url = `${endpoint}/${encodeURIComponent(bucket)}/${String(key).split("/").map(encodeURIComponent).join("/")}`;
    const body = bytesToBase64$6(bytes2);
    const headers = signAwsV4({
      accessKeyId: uploadField(data, "AccessKeyId"),
      body: bytes2,
      headers: {
        "content-type": mime || "application/octet-stream"
      },
      method: "PUT",
      region: "123pan",
      secretAccessKey: uploadField(data, "SecretAccessKey"),
      sessionToken: uploadField(data, "SessionToken"),
      url
    });
    await forwardProxy(client, url, {
      body,
      contentType: mime || "application/octet-stream",
      headers,
      method: "PUT",
      payloadEncoding: "base64",
      responseEncoding: "text",
      timeout: 12e4
    });
  };
  const create123PanDriver = ({ client }) => ({
    async list(storage, relPath) {
      const target = await resolveFile$8(client, storage, relPath);
      const files = await listByParentId(client, storage, target.id, target.name);
      const content = files.map((file) => objFromFile(file, normalizePath(relPath + "/" + fileNameOf$3(file)), storage));
      return {
        content,
        total: content.length,
        readme: "",
        header: files.warning || "",
        write: true,
        provider: "123Pan",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const target = await resolveFile$8(client, storage, relPath);
      if (target.isRoot) {
        return {
          name: "root",
          path: "/",
          is_dir: true,
          size: 0,
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString(),
          provider: "123Pan",
          related: []
        };
      }
      const obj = objFromFile(target.file, relPath, storage);
      if (!obj.is_dir && !options.skipLink) {
        obj.raw_url = (await linkFor$5(client, storage, target.file)).link.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath) {
      const target = await resolveFile$8(client, storage, relPath);
      if (target.isRoot || isDir$3(target.file)) throw new Error("not file");
      return linkFor$5(client, storage, target.file);
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$8(client, storage, dirname(relPath));
      await request123(client, storage, MKDIR, {
        body: {
          driveId: 0,
          etag: "",
          fileName: basename(relPath),
          parentFileId: parent.id,
          size: 0,
          type: 1
        },
        method: "POST"
      });
    },
    async remove(storage, relPath) {
      const target = await resolveFile$8(client, storage, relPath);
      if (target.isRoot) throw new Error("root cannot be removed");
      await request123(client, storage, TRASH, {
        body: {
          driveId: 0,
          operation: true,
          fileTrashInfoList: [target.file]
        },
        method: "POST"
      });
    },
    async rename(storage, relPath, newName) {
      const target = await resolveFile$8(client, storage, relPath);
      if (target.isRoot) throw new Error("root cannot be renamed");
      await request123(client, storage, RENAME, {
        body: {
          driveId: 0,
          fileId: Number(target.id),
          fileName: newName
        },
        method: "POST"
      });
    },
    async move(storage, relPath, dstRelPath) {
      const target = await resolveFile$8(client, storage, relPath);
      const dst = await resolveFile$8(client, storage, dstRelPath);
      await request123(client, storage, MOVE, {
        body: {
          fileIdList: [{ FileId: target.id }],
          parentFileId: dst.id
        },
        method: "POST"
      });
    },
    async put(storage, relPath, content, mime, options = {}) {
      const parent = await resolveFile$8(client, storage, dirname(relPath));
      const bytes2 = uploadBytes$6(content, options);
      const uploadReq = await request123(client, storage, UPLOAD_REQUEST, {
        body: {
          driveId: 0,
          duplicate: 2,
          etag: md5Hex$5(bytes2).toLowerCase(),
          fileName: basename(relPath),
          parentFileId: parent.id,
          size: Number(options.size ?? bytes2.length),
          type: 0
        },
        method: "POST"
      });
      const data = uploadReqData(uploadReq);
      if (uploadField(data, "Reuse") || !uploadField(data, "Key")) return;
      if (uploadField(data, "AccessKeyId") && uploadField(data, "SecretAccessKey") && uploadField(data, "SessionToken")) {
        await putAwsS3(client, uploadReq, bytes2, mime);
        await request123(client, storage, UPLOAD_COMPLETE, {
          body: { fileId: uploadField(data, "FileId") },
          method: "POST"
        });
        return;
      }
      await putPresignedChunks(client, storage, uploadReq, bytes2);
    },
    async test(storage) {
      const payload = await request123(client, storage, USER_INFO, {
        method: "GET"
      });
      const data = payload.data || {};
      return {
        ok: true,
        addition: storage.addition_json,
        user: {
          uid: data.UID || data.uid || 0,
          nickname: data.Nickname || data.nickname || "",
          space_used: data.SpaceUsed || data.spaceUsed || 0,
          space_permanent: data.SpacePermanent || data.spacePermanent || 0,
          space_temp: data.SpaceTemp || data.spaceTemp || 0,
          file_count: data.FileCount || data.fileCount || 0
        }
      };
    }
  });
  const DEFAULT_SLICE_SIZE$1 = 10485760;
  const utf8Bytes$5 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const base64ToBytes$6 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars2.indexOf(clean[i]);
      const b = chars2.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars2.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars2.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$5 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i = 0; i < bytes2.length; i += 3) {
      const a = bytes2[i];
      const b = bytes2[i + 1];
      const c = bytes2[i + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const uploadBytes$5 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$6(content || "") : utf8Bytes$5(content || "");
  const hex$6 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const leftRotate$4 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$4 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$5(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i = 0; i < 64; i += 1) {
        let f;
        let g;
        if (i < 16) {
          f = b & c | ~b & d;
          g = i;
        } else if (i < 32) {
          f = d & b | ~d & c;
          g = (5 * i + 1) % 16;
        } else if (i < 48) {
          f = b ^ c ^ d;
          g = (3 * i + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate$4(a + f + k[i] + view.getUint32(offset + g * 4, true) >>> 0, s[i]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    const out = new Uint8Array(16);
    const outView = new DataView(out.buffer);
    [a0, b0, c0, d0].forEach((value, index) => outView.setUint32(index * 4, value, true));
    return hex$6(out);
  };
  const md5Bytes = (input) => {
    const clean = md5Hex$4(input);
    const out = new Uint8Array(clean.length / 2);
    for (let i = 0; i < out.length; i += 1) out[i] = Number.parseInt(clean.slice(i * 2, i * 2 + 2), 16);
    return out;
  };
  const rol$5 = (value, bits) => value << bits | value >>> 32 - bits;
  const sha1Bytes$5 = (message) => {
    const msg = message instanceof Uint8Array ? message : utf8Bytes$5(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4);
      for (let i = 16; i < 80; i += 1) w[i] = rol$5(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i = 0; i < 80; i += 1) {
        let f;
        let k;
        if (i < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$5(a, 5) + f + e + k + w[i] >>> 0;
        e = d;
        d = c;
        c = rol$5(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const hmacSha1 = (data, secret) => {
    let keyBytes = utf8Bytes$5(secret);
    if (keyBytes.length > 64) keyBytes = sha1Bytes$5(keyBytes);
    const ipad = new Uint8Array(64);
    const opad = new Uint8Array(64);
    for (let i = 0; i < 64; i += 1) {
      const b = keyBytes[i] || 0;
      ipad[i] = b ^ 54;
      opad[i] = b ^ 92;
    }
    const msg = utf8Bytes$5(data);
    const inner = new Uint8Array(ipad.length + msg.length);
    inner.set(ipad);
    inner.set(msg, ipad.length);
    const outer = new Uint8Array(opad.length + 20);
    outer.set(opad);
    outer.set(sha1Bytes$5(inner), opad.length);
    return hex$6(sha1Bytes$5(outer));
  };
  const randomHex$1 = (pattern) => pattern.replace(/[xy]/g, (char) => {
    const t = Math.floor(16 * Math.random());
    const value = char === "x" ? t : 3 & t | 8;
    return value.toString(16);
  });
  const qs = (form) => {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(form || {})) params.set(key, String(value));
    return Array.from(params.entries()).map(([key, value]) => `${key}=${value}`).join("&");
  };
  const encode = (value) => encodeURIComponent(String(value || ""));
  const decodeURIComponent189 = (value) => {
    try {
      return decodeURIComponent(String(value || ""));
    } catch (_) {
      return String(value || "");
    }
  };
  const sbox = Uint8Array.from([
    99,
    124,
    119,
    123,
    242,
    107,
    111,
    197,
    48,
    1,
    103,
    43,
    254,
    215,
    171,
    118,
    202,
    130,
    201,
    125,
    250,
    89,
    71,
    240,
    173,
    212,
    162,
    175,
    156,
    164,
    114,
    192,
    183,
    253,
    147,
    38,
    54,
    63,
    247,
    204,
    52,
    165,
    229,
    241,
    113,
    216,
    49,
    21,
    4,
    199,
    35,
    195,
    24,
    150,
    5,
    154,
    7,
    18,
    128,
    226,
    235,
    39,
    178,
    117,
    9,
    131,
    44,
    26,
    27,
    110,
    90,
    160,
    82,
    59,
    214,
    179,
    41,
    227,
    47,
    132,
    83,
    209,
    0,
    237,
    32,
    252,
    177,
    91,
    106,
    203,
    190,
    57,
    74,
    76,
    88,
    207,
    208,
    239,
    170,
    251,
    67,
    77,
    51,
    133,
    69,
    249,
    2,
    127,
    80,
    60,
    159,
    168,
    81,
    163,
    64,
    143,
    146,
    157,
    56,
    245,
    188,
    182,
    218,
    33,
    16,
    255,
    243,
    210,
    205,
    12,
    19,
    236,
    95,
    151,
    68,
    23,
    196,
    167,
    126,
    61,
    100,
    93,
    25,
    115,
    96,
    129,
    79,
    220,
    34,
    42,
    144,
    136,
    70,
    238,
    184,
    20,
    222,
    94,
    11,
    219,
    224,
    50,
    58,
    10,
    73,
    6,
    36,
    92,
    194,
    211,
    172,
    98,
    145,
    149,
    228,
    121,
    231,
    200,
    55,
    109,
    141,
    213,
    78,
    169,
    108,
    86,
    244,
    234,
    101,
    122,
    174,
    8,
    186,
    120,
    37,
    46,
    28,
    166,
    180,
    198,
    232,
    221,
    116,
    31,
    75,
    189,
    139,
    138,
    112,
    62,
    181,
    102,
    72,
    3,
    246,
    14,
    97,
    53,
    87,
    185,
    134,
    193,
    29,
    158,
    225,
    248,
    152,
    17,
    105,
    217,
    142,
    148,
    155,
    30,
    135,
    233,
    206,
    85,
    40,
    223,
    140,
    161,
    137,
    13,
    191,
    230,
    66,
    104,
    65,
    153,
    45,
    15,
    176,
    84,
    187,
    22
  ]);
  const rcon = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54];
  const xtime = (value) => (value << 1 ^ (value & 128 ? 27 : 0)) & 255;
  const addRoundKey = (state, keys, round) => {
    for (let i = 0; i < 16; i += 1) state[i] ^= keys[round * 16 + i];
  };
  const subBytes = (state) => {
    for (let i = 0; i < 16; i += 1) state[i] = sbox[state[i]];
  };
  const shiftRows = (state) => {
    const copy = Uint8Array.from(state);
    state[1] = copy[5];
    state[5] = copy[9];
    state[9] = copy[13];
    state[13] = copy[1];
    state[2] = copy[10];
    state[6] = copy[14];
    state[10] = copy[2];
    state[14] = copy[6];
    state[3] = copy[15];
    state[7] = copy[3];
    state[11] = copy[7];
    state[15] = copy[11];
  };
  const mixColumns = (state) => {
    for (let c = 0; c < 4; c += 1) {
      const i = c * 4;
      const a0 = state[i];
      const a1 = state[i + 1];
      const a2 = state[i + 2];
      const a3 = state[i + 3];
      const t = a0 ^ a1 ^ a2 ^ a3;
      state[i] ^= t ^ xtime(a0 ^ a1);
      state[i + 1] ^= t ^ xtime(a1 ^ a2);
      state[i + 2] ^= t ^ xtime(a2 ^ a3);
      state[i + 3] ^= t ^ xtime(a3 ^ a0);
    }
  };
  const expandKey = (key) => {
    const expanded = new Uint8Array(176);
    expanded.set(key.slice(0, 16));
    let bytesGenerated = 16;
    let rconIteration = 1;
    const temp = new Uint8Array(4);
    while (bytesGenerated < 176) {
      temp.set(expanded.slice(bytesGenerated - 4, bytesGenerated));
      if (bytesGenerated % 16 === 0) {
        const first = temp[0];
        temp[0] = sbox[temp[1]] ^ rcon[rconIteration];
        temp[1] = sbox[temp[2]];
        temp[2] = sbox[temp[3]];
        temp[3] = sbox[first];
        rconIteration += 1;
      }
      for (let i = 0; i < 4; i += 1) {
        expanded[bytesGenerated] = expanded[bytesGenerated - 16] ^ temp[i];
        bytesGenerated += 1;
      }
    }
    return expanded;
  };
  const aesBlockEncrypt = (block, keys) => {
    const state = Uint8Array.from(block);
    addRoundKey(state, keys, 0);
    for (let round = 1; round < 10; round += 1) {
      subBytes(state);
      shiftRows(state);
      mixColumns(state);
      addRoundKey(state, keys, round);
    }
    subBytes(state);
    shiftRows(state);
    addRoundKey(state, keys, 10);
    return state;
  };
  const pkcs7Padding = (data, blockSize) => {
    const padding = blockSize - data.length % blockSize;
    const out = new Uint8Array(data.length + padding);
    out.set(data);
    out.fill(padding, data.length);
    return out;
  };
  const aesEncrypt = (data, key) => {
    const keys = expandKey(key.slice(0, 16));
    const padded = pkcs7Padding(data, 16);
    const out = new Uint8Array(padded.length);
    for (let offset = 0; offset < padded.length; offset += 16) {
      out.set(aesBlockEncrypt(padded.slice(offset, offset + 16), keys), offset);
    }
    return out;
  };
  const randomNonZeroByte = () => {
    let value = 0;
    while (value === 0) value = Math.floor(Math.random() * 256);
    return value;
  };
  const bytesToBigInt = (input) => BigInt(`0x${hex$6(input) || "0"}`);
  const bigIntToBytes = (value, length) => {
    let clean = value.toString(16);
    if (clean.length % 2) clean = `0${clean}`;
    const out = new Uint8Array(length);
    const start = Math.max(0, length - clean.length / 2);
    for (let i = 0; i < Math.min(length, clean.length / 2); i += 1) {
      out[start + i] = Number.parseInt(clean.slice(i * 2, i * 2 + 2), 16);
    }
    return out;
  };
  const modPow = (base, exponent, modulus) => {
    let result = 1n;
    let b = base % modulus;
    let e = exponent;
    while (e > 0n) {
      if (e & 1n) result = result * b % modulus;
      e >>= 1n;
      b = b * b % modulus;
    }
    return result;
  };
  const readDerLength = (bytes2, cursor) => {
    let length = bytes2[cursor.index];
    cursor.index += 1;
    if (length < 128) return length;
    const count = length & 127;
    length = 0;
    for (let i = 0; i < count; i += 1) {
      length = length << 8 | bytes2[cursor.index];
      cursor.index += 1;
    }
    return length;
  };
  const readDer = (bytes2, cursor, tag) => {
    if (bytes2[cursor.index] !== tag) throw new Error("invalid 189Cloud RSA public key");
    cursor.index += 1;
    const length = readDerLength(bytes2, cursor);
    const start = cursor.index;
    cursor.index += length;
    return bytes2.slice(start, start + length);
  };
  const parseRsaPublicKey = (jRsakey) => {
    const der = base64ToBytes$6(String(jRsakey || "").replace(/-----[^-]+-----/g, "").replace(/\s+/g, ""));
    const outerCursor = { index: 0 };
    const spki = readDer(der, outerCursor, 48);
    const spkiCursor = { index: 0 };
    readDer(spki, spkiCursor, 48);
    const bitString = readDer(spki, spkiCursor, 3);
    const rsaDer = bitString.slice(1);
    const rsaCursor = { index: 0 };
    const sequence = readDer(rsaDer, rsaCursor, 48);
    const seqCursor = { index: 0 };
    let modulus = readDer(sequence, seqCursor, 2);
    const exponent = readDer(sequence, seqCursor, 2);
    while (modulus.length > 1 && modulus[0] === 0) modulus = modulus.slice(1);
    return { exponent: bytesToBigInt(exponent), modulus: bytesToBigInt(modulus), size: modulus.length };
  };
  const b64map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const biRm = "0123456789abcdefghijklmnopqrstuvwxyz";
  const int2char = (value) => biRm[value];
  const b64tohex = (value) => {
    let out = "";
    let e = 0;
    let c = 0;
    for (const item of String(value || "")) {
      if (item === "=") continue;
      const v = b64map.indexOf(item);
      if (v < 0) continue;
      if (e === 0) {
        e = 1;
        out += int2char(v >> 2);
        c = 3 & v;
      } else if (e === 1) {
        e = 2;
        out += int2char(c << 2 | v >> 4);
        c = 15 & v;
      } else if (e === 2) {
        e = 3;
        out += int2char(c);
        out += int2char(v >> 2);
        c = 3 & v;
      } else {
        e = 0;
        out += int2char(c << 2 | v >> 4);
        out += int2char(15 & v);
      }
    }
    if (e === 1) out += int2char(c << 2);
    return out;
  };
  const rsaEncode = (origData, jRsakey, hexOutput) => {
    const { exponent, modulus, size } = parseRsaPublicKey(jRsakey);
    if (origData.length > size - 11) throw new Error("189Cloud RSA payload too large");
    const encoded = new Uint8Array(size);
    encoded[0] = 0;
    encoded[1] = 2;
    const padEnd = size - origData.length - 1;
    for (let i = 2; i < padEnd; i += 1) encoded[i] = randomNonZeroByte();
    encoded[padEnd] = 0;
    encoded.set(origData, padEnd + 1);
    const encrypted = bigIntToBytes(modPow(bytesToBigInt(encoded), exponent, modulus), size);
    const b64 = bytesToBase64$5(encrypted);
    return hexOutput ? b64tohex(b64) : b64;
  };
  const getSessionKey = async (client, storage) => {
    const resp = await remoteJson(client, "https://cloud.189.cn/v2/getUserBriefInfo.action", {
      allowErrorStatus: true,
      headers: {
        Accept: "application/json;charset=UTF-8",
        Cookie: storage.addition_json.cookie || storage.addition_json.Cookie || "",
        Referer: "https://cloud.189.cn/",
        "User-Agent": "Mozilla/5.0"
      },
      method: "GET"
    });
    const sessionKey = (resp == null ? void 0 : resp.sessionKey) || "";
    if (!sessionKey) throw new Error("get 189Cloud sessionKey failed");
    return sessionKey;
  };
  const getResKey = async (client, storage) => {
    const addition = storage.addition_json || {};
    const now = Date.now();
    if (Number(addition.rsa_expire || addition.rsaExpire || 0) > now && (addition.rsa_pub_key || addition.pubKey) && (addition.rsa_pk_id || addition.pkId)) {
      return {
        pubKey: addition.rsa_pub_key || addition.pubKey,
        pkId: addition.rsa_pk_id || addition.pkId
      };
    }
    const resp = await remoteJson(client, "https://cloud.189.cn/api/security/generateRsaKey.action", {
      allowErrorStatus: true,
      headers: {
        Accept: "application/json;charset=UTF-8",
        Cookie: addition.cookie || addition.Cookie || "",
        Referer: "https://cloud.189.cn/",
        "User-Agent": "Mozilla/5.0"
      },
      method: "GET"
    });
    if (!(resp == null ? void 0 : resp.pubKey) || !(resp == null ? void 0 : resp.pkId)) throw new Error("get 189Cloud rsa key failed");
    addition.rsa_pub_key = resp.pubKey;
    addition.rsa_pk_id = resp.pkId;
    addition.rsa_expire = resp.expire;
    return { pubKey: resp.pubKey, pkId: resp.pkId };
  };
  const uploadRequest189 = async (client, storage, uri, form, sessionKey) => {
    const date = String(Date.now());
    const requestId = randomHex$1("xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx");
    let key = randomHex$1("xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx");
    key = key.slice(0, 16 + Math.floor(16 * Math.random()));
    const plain = qs(form);
    const encrypted = aesEncrypt(utf8Bytes$5(plain), utf8Bytes$5(key.slice(0, 16)));
    const params = hex$6(encrypted);
    const signature = hmacSha1(`SessionKey=${sessionKey}&Operate=GET&RequestURI=${uri}&Date=${date}&params=${params}`, key);
    const { pubKey, pkId } = await getResKey(client, storage);
    const encryptionText = rsaEncode(utf8Bytes$5(key), pubKey, false);
    const resp = await remoteJson(client, `https://upload.cloud.189.cn${uri}?params=${params}`, {
      allowErrorStatus: true,
      headers: {
        accept: "application/json;charset=UTF-8",
        SessionKey: sessionKey,
        Signature: signature,
        "X-Request-Date": date,
        "X-Request-ID": requestId,
        EncryptionText: encryptionText,
        PkId: pkId
      },
      method: "GET"
    });
    if ((resp == null ? void 0 : resp.code) !== "SUCCESS") throw new Error(`${uri}---${(resp == null ? void 0 : resp.msg) || (resp == null ? void 0 : resp.code) || "189Cloud upload request failed"}`);
    return resp;
  };
  const parseUploadHeaders = (value) => {
    const headers = {};
    for (const item of decodeURIComponent189(value).split("&")) {
      const index = item.indexOf("=");
      if (index <= 0) continue;
      headers[item.slice(0, index)] = item.slice(index + 1);
    }
    return headers;
  };
  const sliceMd5 = (bytes2) => {
    const md5s = [];
    for (let offset = 0; offset < bytes2.length; offset += DEFAULT_SLICE_SIZE$1) {
      md5s.push(md5Hex$4(bytes2.slice(offset, Math.min(offset + DEFAULT_SLICE_SIZE$1, bytes2.length))).toUpperCase());
    }
    if (!md5s.length) md5s.push(md5Hex$4(new Uint8Array()).toUpperCase());
    return bytes2.length > DEFAULT_SLICE_SIZE$1 ? md5Hex$4(md5s.join("\n")) : md5s[0].toLowerCase();
  };
  const put189 = async (client, storage, resolveFile2, relPath, content, mime, options = {}) => {
    var _a, _b, _c;
    const dstDir = await resolveFile2(client, storage, dirnameOf(relPath));
    const bytes2 = uploadBytes$5(content, options);
    const sessionKey = await getSessionKey(client, storage);
    const fileMd5 = md5Hex$4(bytes2);
    const sliceMd5Hex = sliceMd5(bytes2);
    const init = await uploadRequest189(client, storage, "/person/initMultiUpload", {
      parentFolderId: String(dstDir.id || ""),
      fileName: encode(basenameOf(relPath)),
      fileSize: String(bytes2.length),
      sliceSize: String(DEFAULT_SLICE_SIZE$1),
      fileMd5,
      sliceMd5: sliceMd5Hex
    }, sessionKey);
    const uploadFileId = ((_a = init == null ? void 0 : init.data) == null ? void 0 : _a.uploadFileId) || "";
    if (!uploadFileId) throw new Error("189Cloud initMultiUpload missing uploadFileId");
    if (Number(((_b = init == null ? void 0 : init.data) == null ? void 0 : _b.fileDataExists) || 0) === 1) {
      await uploadRequest189(client, storage, "/person/commitMultiUploadFile", {
        uploadFileId,
        fileMd5,
        sliceMd5: sliceMd5Hex,
        lazyCheck: "1",
        opertype: "3"
      }, sessionKey);
      return;
    }
    const count = Math.ceil(bytes2.length / DEFAULT_SLICE_SIZE$1) || 1;
    for (let index = 1; index <= count; index += 1) {
      const start = (index - 1) * DEFAULT_SLICE_SIZE$1;
      const chunk = bytes2.slice(start, Math.min(start + DEFAULT_SLICE_SIZE$1, bytes2.length));
      const urls = await uploadRequest189(client, storage, "/person/getMultiUploadUrls", {
        partInfo: `${index}-${bytesToBase64$5(md5Bytes(chunk))}`,
        uploadFileId
      }, sessionKey);
      const uploadData = ((_c = urls == null ? void 0 : urls.uploadUrls) == null ? void 0 : _c[`partNumber_${index}`]) || {};
      if (!uploadData.requestURL) throw new Error(`189Cloud getMultiUploadUrls missing partNumber_${index}`);
      await forwardProxy(client, uploadData.requestURL, {
        body: bytesToBase64$5(chunk),
        contentType: mime || "application/octet-stream",
        headers: parseUploadHeaders(uploadData.requestHeader),
        method: "PUT",
        payloadEncoding: "base64",
        responseEncoding: "text"
      });
    }
    await uploadRequest189(client, storage, "/person/commitMultiUploadFile", {
      uploadFileId,
      fileMd5,
      sliceMd5: sliceMd5Hex,
      lazyCheck: "1",
      opertype: "3"
    }, sessionKey);
  };
  const USER_AGENT = "Mozilla/5.0 (Macintosh; Apple macOS 26_1_0) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36 Chrome/142.0.0.0 OpenList/425.6.30";
  const headerValue$5 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of headerEntries(headers)) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? value.join("; ") : String(value || "");
    }
    return "";
  };
  const headerEntries = (headers = {}) => {
    if (Array.isArray(headers)) {
      return headers.flatMap((item) => {
        if (!item || typeof item !== "object") return [];
        return Object.entries(item);
      });
    }
    return Object.entries(headers || {});
  };
  const cookiePairs = (cookie) => String(cookie || "").split(";").map((item) => item.trim()).filter(Boolean).filter((item) => item.includes("="));
  const cookieNames = (cookie) => cookiePairs(cookie).map((item) => item.slice(0, item.indexOf("=")).trim()).filter(Boolean).sort();
  const filterCookieNames = (cookie, names) => {
    const values = /* @__PURE__ */ new Map();
    for (const item of cookiePairs(cookie)) {
      const name = item.slice(0, item.indexOf("=")).trim();
      values.set(name, item);
    }
    return names.map((name) => values.get(name)).filter(Boolean).join("; ");
  };
  const cookieForUrl = (storage, url) => {
    var _a, _b;
    const cookie = ((_a = storage.addition_json) == null ? void 0 : _a.cookie) || ((_b = storage.addition_json) == null ? void 0 : _b.Cookie) || "";
    try {
      const host = new URL(url).hostname;
      if (host === "open.e.189.cn") return filterCookieNames(cookie, ["pageOp", "LT", "GUID"]);
    } catch {
    }
    return cookie;
  };
  const mergeCookies = (...cookies) => {
    const merged = /* @__PURE__ */ new Map();
    for (const cookie of cookies) {
      for (const pair of cookiePairs(cookie)) {
        const index = pair.indexOf("=");
        const key = pair.slice(0, index).trim();
        if (!key) continue;
        merged.set(key, pair.slice(index + 1).trim());
      }
    }
    return Array.from(merged, ([key, value]) => `${key}=${value}`).join("; ");
  };
  const setCookieToCookie = (headers = {}) => {
    const values = [];
    for (const [key, value] of headerEntries(headers)) {
      if (String(key).toLowerCase() !== "set-cookie") continue;
      if (Array.isArray(value)) values.push(...value.map((item) => String(item || "")));
      else values.push(...String(value || "").split(/,(?=\s*[^;,=\s]+=[^;,]*)/));
    }
    return values.map((item) => item.trim().split(";")[0]).filter((item) => item.includes("=")).join("; ");
  };
  const formBody$3 = (data) => {
    const body = new URLSearchParams();
    for (const [key, value] of Object.entries(data || {})) body.set(key, String(value ?? ""));
    return body.toString();
  };
  const responseLocation = (response, baseUrl) => {
    const location = headerValue$5(response == null ? void 0 : response.headers, "Location");
    if (!location) return "";
    try {
      return new URL(location, baseUrl).toString();
    } catch {
      return location;
    }
  };
  const isRedirectStatus = (status) => [301, 302, 303, 307, 308].includes(Number(status));
  const remember189Cookies = async (storage, response) => {
    const addition = storage.addition_json || {};
    const setCookie = setCookieToCookie(response == null ? void 0 : response.headers);
    if (!setCookie) return;
    addition.cookie = mergeCookies(addition.cookie || addition.Cookie || "", setCookie);
    await persistAddition$1(storage);
  };
  const requestText = async (client, storage, url, options = {}) => {
    const headers = {
      Cookie: options.cookie === void 0 ? cookieForUrl(storage, url) : options.cookie,
      "User-Agent": USER_AGENT,
      ...options.headers || {}
    };
    const response = await forwardProxy(client, url, {
      allowErrorStatus: true,
      headers,
      redirect: options.redirect,
      responseEncoding: "text",
      body: options.body,
      contentType: options.contentType,
      method: options.method
    });
    await remember189Cookies(storage, response);
    return response;
  };
  const followLoginRedirect = async (client, storage, startUrl) => {
    let current = startUrl;
    let response = null;
    const chain = [];
    for (let index = 0; index < 10; index += 1) {
      response = await requestText(client, storage, current, {
        method: "GET",
        redirect: false
      });
      const location = responseLocation(response, current);
      chain.push({
        from: safeUrl(current),
        location: location ? safeUrl(location) : "",
        status: Number((response == null ? void 0 : response.status) || 0)
      });
      if (!isRedirectStatus(response.status) || !location) {
        return { chain, response, url: current };
      }
      current = location;
    }
    return { chain, response, url: current };
  };
  const safeUrl = (value) => {
    try {
      const url = new URL(value);
      const keys = Array.from(url.searchParams.keys()).sort();
      return `${url.origin}${url.pathname}${keys.length ? `?${keys.join(",")}` : ""}`;
    } catch {
      return String(value || "").split("?")[0];
    }
  };
  const loginContextSummary = ({ appId, chain, redirected, reqId: reqId2, storage, lt } = {}) => {
    var _a, _b;
    return JSON.stringify({
      app_id_present: !!appId,
      cookie_names: cookieNames(((_a = storage == null ? void 0 : storage.addition_json) == null ? void 0 : _a.cookie) || ((_b = storage == null ? void 0 : storage.addition_json) == null ? void 0 : _b.Cookie) || ""),
      final_url: safeUrl(redirected || ""),
      has_lt: !!lt,
      has_reqid: !!reqId2,
      redirect_chain: chain || []
    });
  };
  const postJson = async (client, storage, url, body, headers) => {
    const response = await requestText(client, storage, url, {
      body,
      contentType: "application/x-www-form-urlencoded; charset=UTF-8",
      headers,
      method: "POST"
    });
    try {
      return JSON.parse(response.body || "{}");
    } catch {
      throw new Error(`189Cloud invalid JSON response from ${url}`);
    }
  };
  const hasLoginCookie = (addition) => cookieNames((addition == null ? void 0 : addition.cookie) || (addition == null ? void 0 : addition.Cookie) || "").some((name) => /^(cookieUserSession|COOKIE_LOGIN_USER)$/i.test(name));
  const completeLogin = async (client, storage, payload) => {
    const addition = storage.addition_json || {};
    if (payload == null ? void 0 : payload.toUrl) {
      await followLoginRedirect(client, storage, payload.toUrl);
    }
    if (!hasLoginCookie(addition)) {
      throw new Error("189Cloud login failed: missing login cookie after successful authentication");
    }
    await persistAddition$1(storage);
  };
  class Cloud189SmsVerifyRequired extends Error {
    constructor(message, {
      addition,
      context,
      mobile,
      showName
    } = {}) {
      super(message);
      this.name = "Cloud189SmsVerifyRequired";
      this.verify = {
        type: "sms",
        mobile: mobile || "",
        second_context: context || null,
        show_name: showName || ""
      };
      this.addition = addition || {};
    }
  }
  const secondAuthHeaders = (context) => ({
    accept: "application/json;charset=UTF-8",
    "User-Agent": USER_AGENT,
    "X-Requested-With": "XMLHttpRequest",
    lt: context.lt || "",
    reqId: context.reqId || "",
    Referer: context.redirected || "",
    Origin: "https://open.e.189.cn"
  });
  const secondAuthData = (addition, context, smsCode) => {
    const conf = context.conf || {};
    const encrypt = context.encrypt || {};
    const userName = context.username || addition.username || "";
    return {
      mobile: context.mobile || "",
      appKey: context.appId || "cloud",
      userName: context.romaSecondAuth === "true" ? userName : `${encrypt.pre || ""}${rsaEncode(utf8Bytes$5(userName), encrypt.pubKey, true)}`,
      epd: `${encrypt.pre || ""}${rsaEncode(utf8Bytes$5(smsCode), encrypt.pubKey, true)}`,
      accountType: conf.accountType || "01",
      returnUrl: encodeURIComponent(conf.returnUrl || ""),
      isOauth2: String(!!conf.isOauth2),
      cb_SaveName: "3",
      state: conf.state || "",
      paramId: conf.paramId || ""
    };
  };
  const submitSecondAuth = async (client, storage, addition, context, smsCode) => {
    if (!context || !smsCode) throw new Error("189Cloud submitForSecondAuth failed: missing SMS verify context or code");
    const payload = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/submitForSecondAuth.do", formBody$3(secondAuthData(addition, context, smsCode)), secondAuthHeaders(context));
    if (Number(payload == null ? void 0 : payload.result) !== 0) {
      throw new Error(`189Cloud submitForSecondAuth failed: ${(payload == null ? void 0 : payload.msg) || ""}`);
    }
    await completeLogin(client, storage, payload);
  };
  const submit189Sms = async (client, storage, verify = {}) => {
    const addition = storage.addition_json || {};
    await submitSecondAuth(client, storage, addition, verify.second_context, verify.sms_code);
    return { addition };
  };
  const login189 = async (client, storage, { allowSms = true } = {}) => {
    const addition = storage.addition_json || {};
    if (!addition.username || !addition.password) return;
    const loginUrl = "https://cloud.189.cn/api/portal/loginUrl.action?redirectURL=https%3A%2F%2Fcloud.189.cn%2Fmain.action";
    const loginPage = await followLoginRedirect(client, storage, loginUrl);
    const redirected = loginPage.url || loginUrl;
    if (redirected === "https://cloud.189.cn/web/main") return;
    const redirectedUrl = new URL(redirected);
    const lt = redirectedUrl.searchParams.get("lt") || "";
    const reqId2 = redirectedUrl.searchParams.get("reqId") || "";
    const appId = redirectedUrl.searchParams.get("appId") || "cloud";
    const authHeaders = {
      lt,
      reqId: reqId2,
      Referer: redirected,
      Origin: "https://open.e.189.cn"
    };
    const ajaxHeaders = {
      accept: "application/json;charset=UTF-8",
      "User-Agent": USER_AGENT,
      "X-Requested-With": "XMLHttpRequest",
      ...authHeaders
    };
    const appConf = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/appConf.do", formBody$3({ version: "2.0", appKey: appId }), ajaxHeaders);
    if (String(appConf == null ? void 0 : appConf.result) !== "0") {
      throw new Error(`189Cloud appConf failed: ${(appConf == null ? void 0 : appConf.msg) || ""}; context=${loginContextSummary({
        appId,
        chain: loginPage.chain,
        redirected,
        reqId: reqId2,
        storage,
        lt
      })}`);
    }
    const encryptConf = await postJson(client, storage, "https://open.e.189.cn/api/logbox/config/encryptConf.do", formBody$3({ appId }), ajaxHeaders);
    if (Number(encryptConf == null ? void 0 : encryptConf.result) !== 0) throw new Error(`189Cloud encryptConf failed: ${(encryptConf == null ? void 0 : encryptConf.msg) || ""}`);
    const conf = appConf.data || {};
    const encrypt = encryptConf.data || {};
    const loginData = (apToken = "") => ({
      version: "v2.0",
      apToken,
      appKey: appId,
      pageKey: conf.pageKey || "",
      accountType: conf.accountType || "01",
      userName: `${encrypt.pre || ""}${rsaEncode(utf8Bytes$5(addition.username), encrypt.pubKey, true)}`,
      epd: `${encrypt.pre || ""}${rsaEncode(utf8Bytes$5(addition.password), encrypt.pubKey, true)}`,
      captchaType: "",
      validateCode: "",
      smsValidateCode: "",
      captchaToken: "",
      returnUrl: encodeURIComponent(conf.returnUrl || ""),
      mailSuffix: conf.mailSuffix || "@pan.cn",
      dynamicCheck: "FALSE",
      clientType: String(conf.clientType || 10010),
      cb_SaveName: "3",
      isOauth2: String(!!conf.isOauth2),
      state: "",
      paramId: conf.paramId || ""
    });
    let payload = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/loginSubmit.do", formBody$3(loginData()), ajaxHeaders);
    if (Number(payload == null ? void 0 : payload.result) === -134 && (payload == null ? void 0 : payload.apToken)) {
      payload = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/loginSubmit.do", formBody$3(loginData(payload.apToken)), ajaxHeaders);
    }
    if (Number(payload == null ? void 0 : payload.result) === -133) {
      if (!allowSms) {
        throw new Error("189Cloud SMS second verification is required; open the mount settings and verify SMS before browsing files");
      }
      const mobile = (payload == null ? void 0 : payload.mobile) || "";
      const showName = (payload == null ? void 0 : payload.showName) || "";
      const context = {
        appId,
        conf: {
          accountType: conf.accountType || "01",
          isOauth2: !!conf.isOauth2,
          paramId: conf.paramId || "",
          returnUrl: conf.returnUrl || "",
          state: conf.state || ""
        },
        encrypt: {
          pre: encrypt.pre || "",
          pubKey: encrypt.pubKey || ""
        },
        lt,
        mobile,
        redirected,
        reqId: reqId2,
        romaSecondAuth: (payload == null ? void 0 : payload.romaSecondAuth) || "",
        username: addition.username
      };
      const sendPayload = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/sendSmsCodeForSecondAuth.do", formBody$3({
        mobile,
        appKey: appId
      }), ajaxHeaders);
      if (Number(sendPayload == null ? void 0 : sendPayload.result) !== 0) throw new Error(`189Cloud send second auth SMS failed: ${(sendPayload == null ? void 0 : sendPayload.msg) || ""}`);
      throw new Cloud189SmsVerifyRequired("189Cloud SMS second verification is required", {
        addition,
        context,
        mobile,
        showName
      });
    }
    if (Number(payload == null ? void 0 : payload.result) !== 0) throw new Error(`189Cloud loginSubmit failed: ${(payload == null ? void 0 : payload.msg) || ""}`);
    await completeLogin(client, storage, payload);
  };
  const randomNoCache = () => String(Date.now()) + String(Math.random()).slice(2, 8);
  const loginChecked = /* @__PURE__ */ new Set();
  const cookieHeader$1 = (addition) => addition.cookie || addition.Cookie || "";
  const storageLoginKey = (storage) => {
    var _a, _b;
    return String(storage.id || storage.mount_path || JSON.stringify({
      username: ((_a = storage.addition_json) == null ? void 0 : _a.username) || "",
      root_folder_id: ((_b = storage.addition_json) == null ? void 0 : _b.root_folder_id) || ""
    }));
  };
  const ensureLogin$1 = async (client, storage, { allowSms = false, force = false } = {}) => {
    const addition = storage.addition_json || {};
    if (!addition.username || !addition.password) return;
    const key = storageLoginKey(storage);
    if (!force && loginChecked.has(key)) return;
    if (!force && cookieHeader$1(addition)) {
      loginChecked.add(key);
      return;
    }
    await login189(client, storage, { allowSms });
    loginChecked.add(key);
  };
  const invalidSession = (payload) => {
    const text2 = [
      payload == null ? void 0 : payload.errorCode,
      payload == null ? void 0 : payload.errorMsg,
      payload == null ? void 0 : payload.res_message,
      payload == null ? void 0 : payload.resMessage,
      payload == null ? void 0 : payload.msg,
      payload == null ? void 0 : payload.message
    ].filter(Boolean).join(" ");
    return /InvalidSessionKey|cookieUserSession/i.test(text2);
  };
  const check189 = (payload) => {
    if (payload == null ? void 0 : payload.errorCode) throw new Error(payload.errorMsg || payload.errorCode);
    const code = Number((payload == null ? void 0 : payload.res_code) || (payload == null ? void 0 : payload.resCode) || 0);
    if (code !== 0) throw new Error((payload == null ? void 0 : payload.res_message) || (payload == null ? void 0 : payload.resMessage) || "189Cloud request failed");
    return payload;
  };
  const request189 = async (client, storage, url, {
    allowRelogin = false,
    body,
    contentType = "application/json",
    method = "GET",
    query = {},
    retried = false
  } = {}) => {
    await ensureLogin$1(client, storage);
    const target = new URL(url);
    target.searchParams.set("noCache", randomNoCache());
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const response = await forwardProxy(client, target.toString(), {
      allowErrorStatus: true,
      body,
      contentType,
      headers: {
        Accept: "application/json;charset=UTF-8",
        Cookie: cookieHeader$1(storage.addition_json),
        Referer: "https://cloud.189.cn/",
        "User-Agent": "Mozilla/5.0"
      },
      method
    });
    await remember189Cookies(storage, response);
    let resp;
    try {
      resp = JSON.parse(response.body || "{}");
    } catch (error) {
      throw new Error(`invalid JSON response from ${target.toString()}: ${error.message}`);
    }
    if (invalidSession(resp) && !retried) {
      if (!allowRelogin || cookieHeader$1(storage.addition_json)) {
        throw new Error("189Cloud login cookie is invalid or expired; open the mount settings and verify SMS again before browsing files");
      }
      await ensureLogin$1(client, storage, { force: true });
      return request189(client, storage, url, {
        allowRelogin,
        body,
        contentType,
        method,
        query,
        retried: true
      });
    }
    return check189(resp);
  };
  const formBody$2 = (data) => new URLSearchParams(
    Object.entries(data).map(([key, value]) => [key, typeof value === "string" ? value : JSON.stringify(value)])
  ).toString();
  const fileToObj$8 = (file, relPath, storage, isDir2) => {
    var _a;
    return {
      name: file.name || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: !!isDir2,
      size: Number(file.size || 0),
      modified: parseTime$1(file.lastOpTime),
      created: parseTime$1(file.lastOpTime),
      sign: "",
      thumb: ((_a = file.icon) == null ? void 0 : _a.smallUrl) || file.smallUrl || "",
      type: isDir2 ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: String(file.id || ""),
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider: "189Cloud",
      file: { ...file, is_dir: !!isDir2 }
    };
  };
  const rootFolderId$3 = (addition) => addition.root_folder_id || addition.RootFolderID || "-11";
  const listByParent$6 = async (client, storage, parentId) => {
    const result = [];
    let pageNum = 1;
    for (; ; ) {
      const resp = await request189(client, storage, "https://cloud.189.cn/api/open/file/listFiles.action", {
        method: "GET",
        query: {
          pageSize: "60",
          pageNum,
          mediaType: "0",
          folderId: parentId,
          iconOption: "5",
          orderBy: "lastOpTime",
          descending: "true"
        }
      });
      const list = resp.fileListAO || {};
      for (const folder of list.folderList || []) result.push({ ...folder, is_dir: true });
      for (const file of list.fileList || []) result.push({ ...file, is_dir: false });
      if (!list.count || !(list.folderList || []).length && !(list.fileList || []).length) break;
      pageNum += 1;
    }
    return result;
  };
  const resolveFile$7 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    if (clean === "/") {
      return {
        id: rootFolderId$3(storage.addition_json),
        name: "root",
        is_dir: true,
        path: "/"
      };
    }
    let parentId = rootFolderId$3(storage.addition_json);
    let current = null;
    for (const part of clean.split("/").filter(Boolean)) {
      const files = await listByParent$6(client, storage, parentId);
      current = files.find((item) => item.name === part);
      if (!current) throw new Error(`object not found: ${clean}`);
      parentId = String(current.id || "");
    }
    return current;
  };
  const headerValue$4 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const resolveRedirect$2 = async (client, url) => {
    const resp = await forwardProxy(client, url, {
      allowErrorStatus: true,
      headers: { "User-Agent": "Mozilla/5.0" },
      method: "GET",
      responseEncoding: "text"
    });
    return headerValue$4(resp.headers, "location") || url;
  };
  const linkFor$4 = async (client, storage, file) => {
    const resp = await request189(client, storage, "https://cloud.189.cn/api/portal/getFileInfo.action", {
      method: "GET",
      query: { fileId: file.id }
    });
    let url = resp.downloadUrl || resp.fileDownloadUrl || "";
    if (!url) throw new Error("get download url failed");
    if (url.startsWith("//")) url = "https:" + url;
    url = url.replace(/^http:\/\//, "https://");
    const redirected = await resolveRedirect$2(client, url);
    return redirected.replace(/^http:\/\//, "https://");
  };
  const batchTask$2 = async (client, storage, type, targetFolderId, files) => {
    const taskInfos = files.map((file) => ({
      fileId: String(file.id || ""),
      fileName: file.name || "",
      isFolder: file.is_dir ? 1 : 0
    }));
    await request189(client, storage, "https://cloud.189.cn/api/open/batch/createBatchTask.action", {
      body: formBody$2({
        type,
        targetFolderId: targetFolderId || "",
        taskInfos
      }),
      contentType: "application/x-www-form-urlencoded",
      method: "POST"
    });
  };
  const create189CloudDriver = ({ client }) => ({
    async verify(storage, verify) {
      if ((verify == null ? void 0 : verify.type) !== "sms") throw new Error("unsupported 189Cloud verify type");
      return submit189Sms(client, storage, verify);
    },
    async test(storage) {
      await ensureLogin$1(client, storage, { allowSms: true, force: true });
      await request189(client, storage, "https://cloud.189.cn/api/portal/getUserSizeInfo.action", { allowRelogin: true });
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$7(client, storage, relPath);
      const content = (await listByParent$6(client, storage, String(parent.id || ""))).map((file) => fileToObj$8(file, normalizePath(relPath + "/" + file.name), storage, file.is_dir));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "189Cloud",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$7(client, storage, relPath);
      const obj = fileToObj$8(file, relPath, storage, file.is_dir);
      if (!obj.is_dir && !options.skipLink) {
        const url = await linkFor$4(client, storage, file);
        obj.raw_url = url;
        obj.url = url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$7(client, storage, relPath);
      if (file.is_dir) throw new Error("not file");
      const url = await linkFor$4(client, storage, file);
      return {
        link: {
          url,
          header: options.proxyHeaders || options.headers || {},
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$7(client, storage, dirnameOf(relPath));
      await request189(client, storage, "https://cloud.189.cn/api/open/file/createFolder.action", {
        body: formBody$2({
          parentFolderId: String(parent.id || ""),
          folderName: basenameOf(relPath)
        }),
        contentType: "application/x-www-form-urlencoded",
        method: "POST"
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$7(client, storage, relPath);
      const dst = await resolveFile$7(client, storage, dstRelPath);
      await batchTask$2(client, storage, "MOVE", String(dst.id || ""), [file]);
    },
    async copy(storage, relPath, dstRelPath) {
      const file = await resolveFile$7(client, storage, relPath);
      const dst = await resolveFile$7(client, storage, dstRelPath);
      await batchTask$2(client, storage, "COPY", String(dst.id || ""), [file]);
    },
    async remove(storage, relPath) {
      const file = await resolveFile$7(client, storage, relPath);
      await batchTask$2(client, storage, "DELETE", "", [file]);
    },
    async rename(storage, relPath, newName) {
      const file = await resolveFile$7(client, storage, relPath);
      const isDir2 = !!file.is_dir;
      await request189(client, storage, isDir2 ? "https://cloud.189.cn/api/open/file/renameFolder.action" : "https://cloud.189.cn/api/open/file/renameFile.action", {
        body: formBody$2(isDir2 ? { folderId: String(file.id || ""), destFolderName: newName } : { fileId: String(file.id || ""), destFileName: newName }),
        contentType: "application/x-www-form-urlencoded",
        method: "POST"
      });
    },
    async put(storage, relPath, content, mime, options = {}) {
      await put189(client, storage, resolveFile$7, relPath, content, mime, options);
    }
  });
  const API_URL$2 = "https://api.cloud.189.cn";
  const TV_APP_KEY$1 = "600100885";
  const TV_APP_SIGNATURE_SECRET$1 = "fe5734c74c2f96a38157f420b32dc995";
  const utf8$1 = (input) => unescape(encodeURIComponent(String(input)));
  const bytes$1 = (input) => {
    if (input instanceof Uint8Array) return input;
    const text2 = utf8$1(input);
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const hex$5 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const rol$4 = (value, bits) => value << bits | value >>> 32 - bits;
  const sha1Bytes$4 = (message) => {
    const msg = bytes$1(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4);
      for (let i = 16; i < 80; i += 1) w[i] = rol$4(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i = 0; i < 80; i += 1) {
        let f;
        let k;
        if (i < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$4(a, 5) + f + e + k + w[i] >>> 0;
        e = d;
        d = c;
        c = rol$4(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const hmacSha1Hex$1 = (key, message) => {
    let keyBytes = bytes$1(key);
    if (keyBytes.length > 64) keyBytes = sha1Bytes$4(keyBytes);
    const ipad = new Uint8Array(64);
    const opad = new Uint8Array(64);
    for (let i = 0; i < 64; i += 1) {
      const b = keyBytes[i] || 0;
      ipad[i] = b ^ 54;
      opad[i] = b ^ 92;
    }
    const msg = bytes$1(message);
    const inner = new Uint8Array(ipad.length + msg.length);
    inner.set(ipad);
    inner.set(msg, ipad.length);
    const outer = new Uint8Array(opad.length + 20);
    outer.set(opad);
    outer.set(sha1Bytes$4(inner), opad.length);
    return hex$5(sha1Bytes$4(outer)).toUpperCase();
  };
  const pathOfUrl$1 = (url) => new URL(url).pathname || "/";
  const httpDate$1 = () => (/* @__PURE__ */ new Date()).toUTCString();
  const timestamp$1 = () => Date.now();
  const randomSuffix$1 = () => `${Math.floor(Math.random() * 1e5)}_${Math.floor(Math.random() * 1e10)}`;
  const tvClientSuffix = () => ({
    clientType: "FAMILY_TV",
    version: "6.5.5",
    channelId: "home02",
    clientSn: "unknown",
    model: "PJX110",
    osFamily: "Android",
    osVersion: "35",
    networkAccessMode: "WIFI",
    telecomsOperator: "46011"
  });
  const toDesc$1 = (order) => order === "desc" ? "true" : "false";
  const toFamilyOrderBy$1 = (order) => {
    if (order === "filesize") return "2";
    if (order === "lastOpTime") return "3";
    return "1";
  };
  const familyMode$1 = (addition) => (addition.type || addition.Type || "personal") === "family";
  const rootFolderId$2 = (addition, isFamily) => {
    const value = addition.root_folder_id || addition.RootFolderID;
    if (isFamily && value === "-11") return "";
    if (value !== void 0 && value !== null && value !== "") return String(value);
    return isFamily ? "" : "-11";
  };
  const familyId$1 = (addition) => String(addition.family_id || addition.FamilyID || "");
  const normalize189SessionAddition = (addition) => {
    if (familyMode$1(addition) && (addition.root_folder_id || addition.RootFolderID) === "-11") {
      addition.root_folder_id = "";
      delete addition.RootFolderID;
    }
    if (!familyMode$1(addition) && !(addition.root_folder_id || addition.RootFolderID)) {
      addition.root_folder_id = "-11";
      delete addition.RootFolderID;
    }
  };
  const checkResp$2 = (payload) => {
    if (!payload || typeof payload !== "object") return payload;
    const resCode = payload.res_code ?? payload.resCode;
    if (resCode !== void 0 && resCode !== null && resCode !== "" && Number(resCode) !== 0) {
      throw new Error(payload.res_message || payload.resMessage || `res_code: ${resCode}`);
    }
    if (payload.errorCode) throw new Error(payload.errorMsg || payload.errorCode);
    if (payload.code && payload.code !== "SUCCESS") throw new Error(payload.message || payload.msg || payload.code);
    if (payload.error) throw new Error(payload.message || payload.error);
    return payload;
  };
  const parse189Json$1 = (text2, url) => {
    const safe = String(text2 || "{}").replace(
      /"((?:id|parentId|familyId|fileId|folderId|targetFolderId|uploadFileId|userFileId|operId|srcFileOwnerId|taskId))"\s*:\s*(-?\d{15,})/gi,
      (_, key, value) => `"${key}":"${value}"`
    );
    try {
      return JSON.parse(safe);
    } catch (error) {
      throw new Error(`invalid JSON response from ${url}: ${error.message}`);
    }
  };
  const remote189Json$1 = async (client, url, options) => {
    const data = await forwardProxy(client, url, options);
    return parse189Json$1(data.body, url);
  };
  const headerValue$3 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const resolveRedirect$1 = async (client, url) => {
    const resp = await forwardProxy(client, url, {
      allowErrorStatus: true,
      headers: { "User-Agent": "Mozilla/5.0" },
      method: "GET",
      redirect: false,
      responseEncoding: "text"
    });
    return headerValue$3(resp.headers, "location") || url;
  };
  const requestTvAppKeyJson = async (client, url, query = {}) => {
    const target = new URL(url);
    for (const [key, value] of Object.entries({ ...tvClientSuffix(), ...query })) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const tempTime = timestamp$1();
    const signText = `AppKey=${TV_APP_KEY$1}&Operate=GET&RequestURI=${pathOfUrl$1(url)}&Timestamp=${tempTime}`;
    const resp = await remote189Json$1(client, target.toString(), {
      allowErrorStatus: true,
      headers: {
        Accept: "application/json;charset=UTF-8",
        AppKey: TV_APP_KEY$1,
        AppSignature: hmacSha1Hex$1(TV_APP_SIGNATURE_SECRET$1, signText),
        Timestamp: String(tempTime),
        "User-Agent": "EcloudTV/6.5.5 (PJX110; unknown; home02) Android/35",
        "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}`
      },
      method: "GET"
    });
    return checkResp$2(resp);
  };
  const jsonWithSignedQuery$1 = async (client, url, {
    addition,
    body,
    isFamily = false,
    method = "GET",
    mode,
    query = {},
    responseEncoding = "text"
  } = {}) => {
    const target = new URL(url);
    const suffix = mode === "tv" ? tvClientSuffix() : {
      clientType: "TELEPC",
      version: "6.2",
      channelId: "web_cloud.189.cn",
      rand: randomSuffix$1()
    };
    for (const [key, value] of Object.entries({ ...suffix, ...query })) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const sessionKey = isFamily ? addition.familySessionKey : addition.sessionKey;
    const sessionSecret = isFamily ? addition.familySessionSecret : addition.sessionSecret;
    if (!sessionKey || !sessionSecret) throw new Error(`${mode === "tv" ? "189CloudTV" : "189CloudPC"} requires access_token plus sessionKey/sessionSecret fields. Re-save after upstream login/session migration or import an OpenList-compatible session addition.`);
    const date = httpDate$1();
    const signText = `SessionKey=${sessionKey}&Operate=${method}&RequestURI=${pathOfUrl$1(url)}&Date=${date}`;
    const headers = {
      Accept: "application/json;charset=UTF-8",
      Date: date,
      SessionKey: sessionKey,
      Signature: hmacSha1Hex$1(sessionSecret, signText),
      "User-Agent": mode === "tv" ? "EcloudTV/6.5.5 (PJX110; unknown; home02) Android/35" : "Mozilla/5.0",
      "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}`
    };
    const resp = await remote189Json$1(client, target.toString(), {
      allowErrorStatus: true,
      body,
      contentType: "application/x-www-form-urlencoded",
      headers,
      method,
      responseEncoding
    });
    return checkResp$2(resp);
  };
  const refreshPcSession$1 = async (client, storage) => {
    const addition = storage.addition_json;
    const accessToken = addition.access_token || addition.AccessToken;
    if (!accessToken) throw new Error("189CloudPC access_token is empty; password/qrcode login is not implemented in the SiYuan kernel port yet");
    const url = new URL(`${API_URL$2}/getSessionForPC.action`);
    url.searchParams.set("clientType", "TELEPC");
    url.searchParams.set("version", "6.2");
    url.searchParams.set("channelId", "web_cloud.189.cn");
    url.searchParams.set("rand", randomSuffix$1());
    url.searchParams.set("appId", "8025431004");
    url.searchParams.set("accessToken", accessToken);
    const resp = checkResp$2(await remote189Json$1(client, url.toString(), {
      allowErrorStatus: true,
      headers: { "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}` },
      method: "GET"
    }));
    addition.sessionKey = resp.sessionKey;
    addition.sessionSecret = resp.sessionSecret;
    addition.familySessionKey = resp.familySessionKey;
    addition.familySessionSecret = resp.familySessionSecret;
    addition.loginName = resp.loginName;
    await persistAddition$1(storage);
    return addition;
  };
  const refreshTvSession$1 = async (client, storage) => {
    const addition = storage.addition_json;
    normalize189SessionAddition(addition);
    const accessToken = addition.access_token || addition.AccessToken;
    if (!accessToken) throw new Error("189CloudTV access_token is empty; QR-code login is required");
    const url = `${API_URL$2}/family/manage/loginFamilyMerge.action`;
    const resp = await requestTvAppKeyJson(client, url, {
      e189AccessToken: accessToken
    });
    addition.sessionKey = resp.sessionKey;
    addition.sessionSecret = resp.sessionSecret;
    addition.familySessionKey = resp.familySessionKey;
    addition.familySessionSecret = resp.familySessionSecret;
    addition.loginName = resp.loginName;
    if (familyMode$1(addition) && !familyId$1(addition)) {
      const familyResp = await jsonWithSignedQuery$1(client, `${API_URL$2}/family/manage/getFamilyList.action`, {
        addition,
        isFamily: true,
        mode: "tv"
      });
      const families = Array.isArray(familyResp.familyInfoResp) ? familyResp.familyInfoResp : [];
      const matched = families.find((item) => addition.loginName && String(item.remarkName || "").includes(addition.loginName)) || families.find((item) => addition.loginName && String(addition.loginName).includes(item.remarkName || "\0")) || families[0];
      if ((matched == null ? void 0 : matched.familyId) !== void 0 && (matched == null ? void 0 : matched.familyId) !== null) addition.family_id = String(matched.familyId);
    }
    await persistAddition$1(storage);
    return addition;
  };
  const loginTvByQrCode = async (client, storage) => {
    const addition = storage.addition_json;
    if (!addition.access_token && !addition.AccessToken) {
      const tempUuid = addition.temp_uuid || addition.TempUuid;
      if (!tempUuid) {
        const resp2 = await requestTvAppKeyJson(client, `${API_URL$2}/family/manage/getQrCodeUUID.action`);
        if (!resp2.uuid) throw new Error("uuidInfo is empty");
        addition.temp_uuid = resp2.uuid;
        await persistAddition$1(storage);
        throw new Error(`need verify: 
<body>
    <a href="${resp2.uuid}">${resp2.uuid}</a>
</body>`);
      }
      const resp = await requestTvAppKeyJson(client, `${API_URL$2}/family/manage/qrcodeLoginResult.action`, {
        uuid: tempUuid
      });
      const accessToken = resp.accessToken || resp.e189AccessToken;
      if (!accessToken) throw new Error("E189AccessToken is empty");
      addition.access_token = accessToken;
      delete addition.AccessToken;
      delete addition.temp_uuid;
      delete addition.TempUuid;
    }
    return refreshTvSession$1(client, storage);
  };
  const ensureSession$1 = async (client, storage, mode) => {
    const addition = storage.addition_json;
    if (addition.sessionKey && addition.sessionSecret) return addition;
    return mode === "tv" ? refreshTvSession$1(client, storage) : refreshPcSession$1(client, storage);
  };
  const request189Session$1 = async (client, storage, url, opts = {}) => {
    const addition = await ensureSession$1(client, storage, opts.mode);
    return jsonWithSignedQuery$1(client, url, { ...opts, addition });
  };
  const fileToObj$7 = (file, relPath, storage, provider) => {
    var _a;
    const isDir2 = !!file.is_dir;
    return {
      name: file.name || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: parseTime$1(file.lastOpTime || file.createDate),
      created: parseTime$1(file.createDate || file.lastOpTime),
      sign: "",
      thumb: ((_a = file.icon) == null ? void 0 : _a.smallUrl) || file.smallUrl || "",
      type: isDir2 ? 1 : 0,
      hashinfo: file.md5 || file.Md5 || "",
      hash_info: file.md5 ? { md5: file.md5 } : {},
      id: String(file.id || ""),
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider,
      file: { ...file, is_dir: isDir2 }
    };
  };
  const listByParent$5 = async (client, storage, parentId, mode) => {
    const addition = storage.addition_json;
    const isFamily = familyMode$1(addition);
    const url = `${API_URL$2}${isFamily ? "/family/file" : ""}/listFiles.action`;
    const result = [];
    const pageSize2 = 130;
    for (let pageNum = 1; ; pageNum += 1) {
      const query = {
        folderId: parentId,
        fileType: "0",
        mediaAttr: "0",
        iconOption: "5",
        pageNum,
        pageSize: pageSize2,
        recursive: isFamily ? void 0 : "0",
        orderBy: isFamily ? toFamilyOrderBy$1(addition.order_by || addition.OrderBy || "filename") : addition.order_by || addition.OrderBy || "filename",
        descending: toDesc$1(addition.order_direction || addition.OrderDirection || "asc"),
        familyId: isFamily ? familyId$1(addition) : void 0
      };
      const resp = await request189Session$1(client, storage, url, { isFamily, mode, query });
      const list = resp.fileListAO || {};
      for (const folder of list.folderList || []) result.push({ ...folder, is_dir: true });
      for (const file of list.fileList || []) result.push({ ...file, is_dir: false });
      if (!list.count || !(list.folderList || []).length && !(list.fileList || []).length) break;
    }
    return result;
  };
  const resolveFile$6 = async (client, storage, relPath, mode) => {
    const addition = storage.addition_json;
    const isFamily = familyMode$1(addition);
    const clean = normalizePath(relPath || "/");
    if (clean === "/") {
      return {
        id: rootFolderId$2(addition, isFamily),
        name: "root",
        is_dir: true,
        path: "/"
      };
    }
    let parentId = rootFolderId$2(addition, isFamily);
    let current = null;
    for (const part of clean.split("/").filter(Boolean)) {
      const files = await listByParent$5(client, storage, parentId, mode);
      current = files.find((item) => item.name === part);
      if (!current) throw new Error(`object not found: ${clean}`);
      parentId = String(current.id || "");
    }
    return current;
  };
  const linkFor$3 = async (client, storage, file, mode) => {
    const addition = storage.addition_json;
    const isFamily = familyMode$1(addition);
    const url = `${API_URL$2}${isFamily ? "/family/file" : ""}/getFileDownloadUrl.action`;
    const resp = await request189Session$1(client, storage, url, {
      isFamily,
      mode,
      query: {
        fileId: file.id,
        familyId: isFamily ? familyId$1(addition) : void 0,
        dt: isFamily ? void 0 : "3",
        flag: isFamily ? void 0 : "1"
      }
    });
    let downloadUrl = resp.fileDownloadUrl || resp.downloadUrl || "";
    if (!downloadUrl) throw new Error("get download url failed");
    if (downloadUrl.startsWith("//")) downloadUrl = "https:" + downloadUrl;
    downloadUrl = downloadUrl.replace(/&amp;/g, "&").replace(/^http:\/\//, "https://");
    return (await resolveRedirect$1(client, downloadUrl)).replace(/^http:\/\//, "https://");
  };
  const formBody$1 = (data) => new URLSearchParams(
    Object.entries(data).filter(([, value]) => value !== void 0 && value !== null && value !== "").map(([key, value]) => [key, typeof value === "string" ? value : JSON.stringify(value)])
  ).toString();
  const batchTask$1 = async (client, storage, mode, type, targetFolderId, files, other = {}) => {
    const addition = storage.addition_json;
    const isFamily = familyMode$1(addition);
    const taskInfos = files.map((file) => ({
      fileId: String(file.id || ""),
      fileName: file.name || "",
      isFolder: file.is_dir ? 1 : 0
    }));
    await request189Session$1(client, storage, `${API_URL$2}/batch/createBatchTask.action`, {
      body: formBody$1({
        type,
        targetFolderId,
        familyId: isFamily ? familyId$1(addition) : void 0,
        taskInfos,
        ...other
      }),
      isFamily,
      method: "POST",
      mode
    });
  };
  const create189SessionDriver$1 = ({ client, mode, provider }) => ({
    async test(storage) {
      await loginTvByQrCode(client, storage);
      await request189Session$1(client, storage, `${API_URL$2}/getUserInfo.action`, { mode });
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$6(client, storage, relPath, mode);
      const content = (await listByParent$5(client, storage, String(parent.id || ""), mode)).map((file) => fileToObj$7(file, normalizePath(relPath + "/" + file.name), storage, provider));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider,
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$6(client, storage, relPath, mode);
      const obj = fileToObj$7(file, relPath, storage, provider);
      if (!obj.is_dir && !options.skipLink) {
        const url = await linkFor$3(client, storage, file, mode);
        obj.raw_url = url;
        obj.url = url;
      }
      return { ...obj, readme: "", header: "", related: [] };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$6(client, storage, relPath, mode);
      if (file.is_dir) throw new Error("not file");
      const url = await linkFor$3(client, storage, file, mode);
      return {
        link: {
          url,
          header: { "User-Agent": "Mozilla/5.0", ...options.proxyHeaders || options.headers || {} },
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      const addition = storage.addition_json;
      const isFamily = familyMode$1(addition);
      const parent = await resolveFile$6(client, storage, dirnameOf(relPath), mode);
      await request189Session$1(client, storage, `${API_URL$2}${isFamily ? "/family/file" : ""}/createFolder.action`, {
        isFamily,
        method: "POST",
        mode,
        query: {
          familyId: isFamily ? familyId$1(addition) : void 0,
          parentId: isFamily ? String(parent.id || "") : void 0,
          parentFolderId: isFamily ? void 0 : String(parent.id || ""),
          folderName: basenameOf(relPath),
          relativePath: ""
        }
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$6(client, storage, relPath, mode);
      const dst = await resolveFile$6(client, storage, dstRelPath, mode);
      await batchTask$1(client, storage, mode, "MOVE", String(dst.id || ""), [file], { targetFileName: dst.name || "" });
    },
    async copy(storage, relPath, dstRelPath) {
      const file = await resolveFile$6(client, storage, relPath, mode);
      const dst = await resolveFile$6(client, storage, dstRelPath, mode);
      await batchTask$1(client, storage, mode, "COPY", String(dst.id || ""), [file], { targetFileName: dst.name || "" });
    },
    async remove(storage, relPath) {
      const file = await resolveFile$6(client, storage, relPath, mode);
      await batchTask$1(client, storage, mode, "DELETE", "", [file]);
    },
    async rename(storage, relPath, newName) {
      const addition = storage.addition_json;
      const isFamily = familyMode$1(addition);
      const file = await resolveFile$6(client, storage, relPath, mode);
      const isDir2 = !!file.is_dir;
      await request189Session$1(client, storage, `${API_URL$2}${isFamily ? "/family/file" : ""}/${isDir2 ? "renameFolder" : "renameFile"}.action`, {
        isFamily,
        method: isFamily ? "GET" : "POST",
        mode,
        query: {
          familyId: isFamily ? familyId$1(addition) : void 0,
          folderId: isDir2 ? String(file.id || "") : void 0,
          fileId: isDir2 ? void 0 : String(file.id || ""),
          destFolderName: isDir2 ? newName : void 0,
          destFileName: isDir2 ? void 0 : newName
        }
      });
    },
    async put() {
      const uploadType = "old upload / rapid upload";
      throw new Error(`${provider} ${uploadType} is not implemented in the SiYuan kernel port yet`);
    }
  });
  const create189CloudTVDriver = ({ client }) => create189SessionDriver$1({
    client,
    mode: "tv",
    provider: "189CloudTV"
  });
  const API_URL$1 = "https://api.cloud.189.cn";
  const TV_APP_KEY = "600100885";
  const TV_APP_SIGNATURE_SECRET = "fe5734c74c2f96a38157f420b32dc995";
  const utf8 = (input) => unescape(encodeURIComponent(String(input)));
  const bytes = (input) => {
    if (input instanceof Uint8Array) return input;
    const text2 = utf8(input);
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const hex$4 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const rol$3 = (value, bits) => value << bits | value >>> 32 - bits;
  const sha1Bytes$3 = (message) => {
    const msg = bytes(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4);
      for (let i = 16; i < 80; i += 1) w[i] = rol$3(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i = 0; i < 80; i += 1) {
        let f;
        let k;
        if (i < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$3(a, 5) + f + e + k + w[i] >>> 0;
        e = d;
        d = c;
        c = rol$3(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const hmacSha1Hex = (key, message) => {
    let keyBytes = bytes(key);
    if (keyBytes.length > 64) keyBytes = sha1Bytes$3(keyBytes);
    const ipad = new Uint8Array(64);
    const opad = new Uint8Array(64);
    for (let i = 0; i < 64; i += 1) {
      const b = keyBytes[i] || 0;
      ipad[i] = b ^ 54;
      opad[i] = b ^ 92;
    }
    const msg = bytes(message);
    const inner = new Uint8Array(ipad.length + msg.length);
    inner.set(ipad);
    inner.set(msg, ipad.length);
    const outer = new Uint8Array(opad.length + 20);
    outer.set(opad);
    outer.set(sha1Bytes$3(inner), opad.length);
    return hex$4(sha1Bytes$3(outer)).toUpperCase();
  };
  const pathOfUrl = (url) => new URL(url).pathname || "/";
  const httpDate = () => (/* @__PURE__ */ new Date()).toUTCString();
  const timestamp = () => Date.now();
  const randomSuffix = () => `${Math.floor(Math.random() * 1e5)}_${Math.floor(Math.random() * 1e10)}`;
  const toDesc = (order) => order === "desc" ? "true" : "false";
  const toFamilyOrderBy = (order) => {
    if (order === "filesize") return "2";
    if (order === "lastOpTime") return "3";
    return "1";
  };
  const familyMode = (addition) => (addition.type || addition.Type || "personal") === "family";
  const rootFolderId$1 = (addition, isFamily) => {
    const value = addition.root_folder_id || addition.RootFolderID;
    if (isFamily && value === "-11") return "";
    if (value !== void 0 && value !== null && value !== "") return String(value);
    return isFamily ? "" : "-11";
  };
  const familyId = (addition) => String(addition.family_id || addition.FamilyID || "");
  const checkResp$1 = (payload) => {
    if (!payload || typeof payload !== "object") return payload;
    const resCode = payload.res_code ?? payload.resCode;
    if (resCode !== void 0 && resCode !== null && resCode !== "" && Number(resCode) !== 0) {
      throw new Error(payload.res_message || payload.resMessage || `res_code: ${resCode}`);
    }
    if (payload.errorCode) throw new Error(payload.errorMsg || payload.errorCode);
    if (payload.code && payload.code !== "SUCCESS") throw new Error(payload.message || payload.msg || payload.code);
    if (payload.error) throw new Error(payload.message || payload.error);
    return payload;
  };
  const parse189Json = (text2, url) => {
    const safe = String(text2 || "{}").replace(
      /"((?:id|parentId|familyId|fileId|folderId|targetFolderId|uploadFileId|userFileId|operId|srcFileOwnerId|taskId))"\s*:\s*(-?\d{15,})/gi,
      (_, key, value) => `"${key}":"${value}"`
    );
    try {
      return JSON.parse(safe);
    } catch (error) {
      throw new Error(`invalid JSON response from ${url}: ${error.message}`);
    }
  };
  const remote189Json = async (client, url, options) => {
    const data = await forwardProxy(client, url, options);
    return parse189Json(data.body, url);
  };
  const headerValue$2 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const resolveRedirect = async (client, url) => {
    const resp = await forwardProxy(client, url, {
      allowErrorStatus: true,
      headers: { "User-Agent": "Mozilla/5.0" },
      method: "GET",
      redirect: false,
      responseEncoding: "text"
    });
    return headerValue$2(resp.headers, "location") || url;
  };
  const jsonWithSignedQuery = async (client, url, {
    addition,
    body,
    isFamily = false,
    method = "GET",
    mode,
    query = {},
    responseEncoding = "text"
  } = {}) => {
    const target = new URL(url);
    const suffix = mode === "tv" ? {
      clientType: "FAMILY_TV",
      version: "6.5.5",
      channelId: "home02",
      clientSn: "unknown",
      model: "PJX110",
      osFamily: "Android",
      osVersion: "35",
      networkAccessMode: "WIFI",
      telecomsOperator: "46011"
    } : {
      clientType: "TELEPC",
      version: "6.2",
      channelId: "web_cloud.189.cn",
      rand: randomSuffix()
    };
    for (const [key, value] of Object.entries({ ...suffix, ...query })) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const sessionKey = isFamily ? addition.familySessionKey : addition.sessionKey;
    const sessionSecret = isFamily ? addition.familySessionSecret : addition.sessionSecret;
    if (!sessionKey || !sessionSecret) throw new Error(`${mode === "tv" ? "189CloudTV" : "189CloudPC"} requires access_token plus sessionKey/sessionSecret fields. Re-save after upstream login/session migration or import an OpenList-compatible session addition.`);
    const date = httpDate();
    const signText = `SessionKey=${sessionKey}&Operate=${method}&RequestURI=${pathOfUrl(url)}&Date=${date}`;
    const headers = {
      Accept: "application/json;charset=UTF-8",
      Date: date,
      SessionKey: sessionKey,
      Signature: hmacSha1Hex(sessionSecret, signText),
      "User-Agent": mode === "tv" ? "EcloudTV/6.5.5 (PJX110; unknown; home02) Android/35" : "Mozilla/5.0",
      "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}`
    };
    const resp = await remote189Json(client, target.toString(), {
      allowErrorStatus: true,
      body,
      contentType: "application/x-www-form-urlencoded",
      headers,
      method,
      responseEncoding
    });
    return checkResp$1(resp);
  };
  const refreshPcSession = async (client, storage) => {
    const addition = storage.addition_json;
    const accessToken = addition.access_token || addition.AccessToken;
    if (!accessToken) throw new Error("189CloudPC access_token is empty; password/qrcode login is not implemented in the SiYuan kernel port yet");
    const url = new URL(`${API_URL$1}/getSessionForPC.action`);
    url.searchParams.set("clientType", "TELEPC");
    url.searchParams.set("version", "6.2");
    url.searchParams.set("channelId", "web_cloud.189.cn");
    url.searchParams.set("rand", randomSuffix());
    url.searchParams.set("appId", "8025431004");
    url.searchParams.set("accessToken", accessToken);
    const resp = checkResp$1(await remote189Json(client, url.toString(), {
      allowErrorStatus: true,
      headers: { "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}` },
      method: "GET"
    }));
    addition.sessionKey = resp.sessionKey;
    addition.sessionSecret = resp.sessionSecret;
    addition.familySessionKey = resp.familySessionKey;
    addition.familySessionSecret = resp.familySessionSecret;
    addition.loginName = resp.loginName;
    await persistAddition$1(storage);
    return addition;
  };
  const refreshTvSession = async (client, storage) => {
    const addition = storage.addition_json;
    const accessToken = addition.access_token || addition.AccessToken;
    if (!accessToken) throw new Error("189CloudTV access_token is empty; QR-code login is not implemented in the SiYuan kernel port yet");
    const url = `${API_URL$1}/family/manage/loginFamilyMerge.action`;
    const target = new URL(url);
    const tempTime = timestamp();
    const signText = `AppKey=${TV_APP_KEY}&Operate=GET&RequestURI=${pathOfUrl(url)}&Timestamp=${tempTime}`;
    for (const [key, value] of Object.entries({
      clientType: "FAMILY_TV",
      version: "6.5.5",
      channelId: "home02",
      clientSn: "unknown",
      model: "PJX110",
      osFamily: "Android",
      osVersion: "35",
      networkAccessMode: "WIFI",
      telecomsOperator: "46011",
      e189AccessToken: accessToken
    })) {
      target.searchParams.set(key, String(value));
    }
    const resp = checkResp$1(await remote189Json(client, target.toString(), {
      allowErrorStatus: true,
      headers: {
        AppKey: TV_APP_KEY,
        AppSignature: hmacSha1Hex(TV_APP_SIGNATURE_SECRET, signText),
        Timestamp: String(tempTime),
        "User-Agent": "EcloudTV/6.5.5 (PJX110; unknown; home02) Android/35",
        "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}`
      },
      method: "GET"
    }));
    addition.sessionKey = resp.sessionKey;
    addition.sessionSecret = resp.sessionSecret;
    addition.familySessionKey = resp.familySessionKey;
    addition.familySessionSecret = resp.familySessionSecret;
    addition.loginName = resp.loginName;
    await persistAddition$1(storage);
    return addition;
  };
  const ensureSession = async (client, storage, mode) => {
    const addition = storage.addition_json;
    if (addition.sessionKey && addition.sessionSecret) return addition;
    return mode === "tv" ? refreshTvSession(client, storage) : refreshPcSession(client, storage);
  };
  const request189Session = async (client, storage, url, opts = {}) => {
    const addition = await ensureSession(client, storage, opts.mode);
    return jsonWithSignedQuery(client, url, { ...opts, addition });
  };
  const fileToObj$6 = (file, relPath, storage, provider) => {
    var _a;
    const isDir2 = !!file.is_dir;
    return {
      name: file.name || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: parseTime$1(file.lastOpTime || file.createDate),
      created: parseTime$1(file.createDate || file.lastOpTime),
      sign: "",
      thumb: ((_a = file.icon) == null ? void 0 : _a.smallUrl) || file.smallUrl || "",
      type: isDir2 ? 1 : 0,
      hashinfo: file.md5 || file.Md5 || "",
      hash_info: file.md5 ? { md5: file.md5 } : {},
      id: String(file.id || ""),
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider,
      file: { ...file, is_dir: isDir2 }
    };
  };
  const listByParent$4 = async (client, storage, parentId, mode) => {
    const addition = storage.addition_json;
    const isFamily = familyMode(addition);
    const url = `${API_URL$1}${isFamily ? "/family/file" : ""}/listFiles.action`;
    const result = [];
    const pageSize2 = 1e3;
    for (let pageNum = 1; ; pageNum += 1) {
      const query = {
        folderId: parentId,
        fileType: "0",
        mediaAttr: "0",
        iconOption: "5",
        pageNum,
        pageSize: pageSize2,
        recursive: isFamily ? void 0 : "0",
        orderBy: isFamily ? toFamilyOrderBy(addition.order_by || addition.OrderBy || "filename") : addition.order_by || addition.OrderBy || "filename",
        descending: toDesc(addition.order_direction || addition.OrderDirection || "asc"),
        familyId: isFamily ? familyId(addition) : void 0
      };
      const resp = await request189Session(client, storage, url, { isFamily, mode, query });
      const list = resp.fileListAO || {};
      for (const folder of list.folderList || []) result.push({ ...folder, is_dir: true });
      for (const file of list.fileList || []) result.push({ ...file, is_dir: false });
      if (!list.count || !(list.folderList || []).length && !(list.fileList || []).length) break;
    }
    return result;
  };
  const resolveFile$5 = async (client, storage, relPath, mode) => {
    const addition = storage.addition_json;
    const isFamily = familyMode(addition);
    const clean = normalizePath(relPath || "/");
    if (clean === "/") {
      return {
        id: rootFolderId$1(addition, isFamily),
        name: "root",
        is_dir: true,
        path: "/"
      };
    }
    let parentId = rootFolderId$1(addition, isFamily);
    let current = null;
    for (const part of clean.split("/").filter(Boolean)) {
      const files = await listByParent$4(client, storage, parentId, mode);
      current = files.find((item) => item.name === part);
      if (!current) throw new Error(`object not found: ${clean}`);
      parentId = String(current.id || "");
    }
    return current;
  };
  const linkFor$2 = async (client, storage, file, mode) => {
    const addition = storage.addition_json;
    const isFamily = familyMode(addition);
    const url = `${API_URL$1}${isFamily ? "/family/file" : ""}/getFileDownloadUrl.action`;
    const resp = await request189Session(client, storage, url, {
      isFamily,
      mode,
      query: {
        fileId: file.id,
        familyId: isFamily ? familyId(addition) : void 0,
        dt: isFamily ? void 0 : "3",
        flag: isFamily ? void 0 : "1"
      }
    });
    let downloadUrl = resp.fileDownloadUrl || resp.downloadUrl || "";
    if (!downloadUrl) throw new Error("get download url failed");
    if (downloadUrl.startsWith("//")) downloadUrl = "https:" + downloadUrl;
    downloadUrl = downloadUrl.replace(/&amp;/g, "&").replace(/^http:\/\//, "https://");
    return (await resolveRedirect(client, downloadUrl)).replace(/^http:\/\//, "https://");
  };
  const formBody = (data) => new URLSearchParams(
    Object.entries(data).filter(([, value]) => value !== void 0 && value !== null && value !== "").map(([key, value]) => [key, typeof value === "string" ? value : JSON.stringify(value)])
  ).toString();
  const batchTask = async (client, storage, mode, type, targetFolderId, files, other = {}) => {
    const addition = storage.addition_json;
    const isFamily = familyMode(addition);
    const taskInfos = files.map((file) => ({
      fileId: String(file.id || ""),
      fileName: file.name || "",
      isFolder: file.is_dir ? 1 : 0
    }));
    await request189Session(client, storage, `${API_URL$1}/batch/createBatchTask.action`, {
      body: formBody({
        type,
        targetFolderId,
        familyId: isFamily ? familyId(addition) : void 0,
        taskInfos,
        ...other
      }),
      isFamily,
      method: "POST",
      mode
    });
  };
  const create189SessionDriver = ({ client, mode, provider }) => ({
    async test(storage) {
      await refreshPcSession(client, storage);
      await request189Session(client, storage, `${API_URL$1}/getUserInfo.action`, { mode });
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$5(client, storage, relPath, mode);
      const content = (await listByParent$4(client, storage, String(parent.id || ""), mode)).map((file) => fileToObj$6(file, normalizePath(relPath + "/" + file.name), storage, provider));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider,
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$5(client, storage, relPath, mode);
      const obj = fileToObj$6(file, relPath, storage, provider);
      if (!obj.is_dir && !options.skipLink) {
        const url = await linkFor$2(client, storage, file, mode);
        obj.raw_url = url;
        obj.url = url;
      }
      return { ...obj, readme: "", header: "", related: [] };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$5(client, storage, relPath, mode);
      if (file.is_dir) throw new Error("not file");
      const url = await linkFor$2(client, storage, file, mode);
      return {
        link: {
          url,
          header: { "User-Agent": "Mozilla/5.0", ...options.proxyHeaders || options.headers || {} },
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      const addition = storage.addition_json;
      const isFamily = familyMode(addition);
      const parent = await resolveFile$5(client, storage, dirnameOf(relPath), mode);
      await request189Session(client, storage, `${API_URL$1}${isFamily ? "/family/file" : ""}/createFolder.action`, {
        isFamily,
        method: "POST",
        mode,
        query: {
          familyId: isFamily ? familyId(addition) : void 0,
          parentId: isFamily ? String(parent.id || "") : void 0,
          parentFolderId: isFamily ? void 0 : String(parent.id || ""),
          folderName: basenameOf(relPath),
          relativePath: ""
        }
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$5(client, storage, relPath, mode);
      const dst = await resolveFile$5(client, storage, dstRelPath, mode);
      await batchTask(client, storage, mode, "MOVE", String(dst.id || ""), [file], { targetFileName: dst.name || "" });
    },
    async copy(storage, relPath, dstRelPath) {
      const file = await resolveFile$5(client, storage, relPath, mode);
      const dst = await resolveFile$5(client, storage, dstRelPath, mode);
      await batchTask(client, storage, mode, "COPY", String(dst.id || ""), [file], { targetFileName: dst.name || "" });
    },
    async remove(storage, relPath) {
      const file = await resolveFile$5(client, storage, relPath, mode);
      await batchTask(client, storage, mode, "DELETE", "", [file]);
    },
    async rename(storage, relPath, newName) {
      const addition = storage.addition_json;
      const isFamily = familyMode(addition);
      const file = await resolveFile$5(client, storage, relPath, mode);
      const isDir2 = !!file.is_dir;
      await request189Session(client, storage, `${API_URL$1}${isFamily ? "/family/file" : ""}/${isDir2 ? "renameFolder" : "renameFile"}.action`, {
        isFamily,
        method: isFamily ? "GET" : "POST",
        mode,
        query: {
          familyId: isFamily ? familyId(addition) : void 0,
          folderId: isDir2 ? String(file.id || "") : void 0,
          fileId: isDir2 ? void 0 : String(file.id || ""),
          destFolderName: isDir2 ? newName : void 0,
          destFileName: isDir2 ? void 0 : newName
        }
      });
    },
    async put() {
      const uploadType = "stream / rapid / old upload";
      throw new Error(`${provider} ${uploadType} is not implemented in the SiYuan kernel port yet`);
    }
  });
  const create189CloudPCDriver = ({ client }) => create189SessionDriver({
    client,
    mode: "pc",
    provider: "189CloudPC"
  });
  const API_URL = "https://openapi.alipan.com";
  const DEFAULT_RENEW_API$1 = "https://api.oplist.org/alicloud/renewapi";
  const CACHE_TTL = 55 * 1e3;
  const UPLOAD_PART_SIZE = 20 * 1024 * 1024;
  const listCache = /* @__PURE__ */ new Map();
  const fileCache = /* @__PURE__ */ new Map();
  const linkCache = /* @__PURE__ */ new Map();
  const storageKey$2 = (storage) => String(storage.id || storage.mount_path || JSON.stringify(storage.addition_json || {}));
  const cached = async (map, key, producer, ttl = CACHE_TTL) => {
    const now = Date.now();
    const hit = map.get(key);
    if (hit && hit.expires > now) return hit.value;
    const value = await producer();
    map.set(key, { value, expires: now + ttl });
    return value;
  };
  const clearStorageCache = (storage) => {
    const prefix = `${storageKey$2(storage)}:`;
    for (const map of [listCache, fileCache, linkCache]) {
      for (const key of map.keys()) {
        if (key.startsWith(prefix)) map.delete(key);
      }
    }
  };
  const checkAli = (payload) => {
    if (payload == null ? void 0 : payload.code) throw new Error(`${payload.code}:${payload.message || ""}`.replace(/:$/, ""));
    return payload;
  };
  const driverTxt = (addition) => addition.alipan_type === "alipanTV" ? "alicloud_tv" : "alicloud_qr";
  const refreshToken$2 = async (client, storage) => {
    const addition = storage.addition_json || storage;
    const refreshTokenValue = addition.refresh_token || addition.RefreshToken || "";
    if (!refreshTokenValue) throw new Error("empty refresh_token");
    if (boolValue$2(addition.use_online_api ?? addition.UseOnlineAPI, true) && (addition.api_url_address || DEFAULT_RENEW_API$1)) {
      const url = new URL(addition.api_url_address || DEFAULT_RENEW_API$1);
      url.searchParams.set("refresh_ui", refreshTokenValue);
      url.searchParams.set("server_use", "true");
      url.searchParams.set("driver_txt", driverTxt(addition));
      const resp2 = await remoteJson(client, url.toString(), { method: "GET" });
      if (!resp2.refresh_token || !resp2.access_token) {
        throw new Error(resp2.text || "empty token returned from official API, a wrong refresh token may have been used");
      }
      addition.refresh_token = resp2.refresh_token;
      addition.access_token = resp2.access_token;
      await persistAddition$1(storage);
      return addition.access_token;
    }
    const clientId = addition.client_id || addition.ClientID || "";
    const clientSecret = addition.client_secret || addition.ClientSecret || "";
    if (!clientId || !clientSecret) throw new Error("empty ClientID or ClientSecret");
    const resp = checkAli(await remoteJson(client, `${API_URL}/oauth/access_token`, {
      body: {
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: "refresh_token",
        refresh_token: refreshTokenValue
      },
      method: "POST"
    }));
    if (!resp.refresh_token || !resp.access_token) throw new Error("empty token returned from alipan");
    addition.refresh_token = resp.refresh_token;
    addition.access_token = resp.access_token;
    await persistAddition$1(storage);
    return addition.access_token;
  };
  const ensureToken = async (client, storage) => {
    const addition = storage.addition_json || storage;
    if (addition.access_token || addition.AccessToken) return addition.access_token || addition.AccessToken;
    return refreshToken$2(client, storage);
  };
  const requestAli = async (client, storage, uri, {
    allowAliError = false,
    body,
    method = "POST",
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    await ensureToken(client, storage);
    const resp = await remoteJson(client, `${API_URL}${uri}`, {
      allowErrorStatus: true,
      body: body || {},
      headers: {
        Authorization: `Bearer ${addition.access_token || addition.AccessToken || ""}`
      },
      method
    });
    if ((resp == null ? void 0 : resp.code) && retry && ["AccessTokenInvalid", "AccessTokenExpired", "I400JD"].includes(resp.code)) {
      await refreshToken$2(client, storage);
      return requestAli(client, storage, uri, { allowAliError, body, method, retry: false });
    }
    if (allowAliError) return resp;
    return checkAli(resp);
  };
  const initDrive = async (client, storage) => {
    const addition = storage.addition_json;
    if (addition.drive_id) return addition.drive_id;
    const resp = await requestAli(client, storage, "/adrive/v1.0/user/getDriveInfo");
    const driveType = addition.drive_type || addition.DriveType || "resource";
    const driveId = resp[`${driveType}_drive_id`] || resp.default_drive_id || resp.resource_drive_id || resp.backup_drive_id;
    if (!driveId) throw new Error("get aliyundrive drive_id failed");
    addition.drive_id = driveId;
    await persistAddition$1(storage);
    return driveId;
  };
  const rootFolderId = (addition) => addition.root_folder_id || addition.RootFolderID || "root";
  const base64ToBytes$5 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars2.indexOf(clean[i]);
      const b = chars2.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars2.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars2.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$4 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i = 0; i < bytes2.length; i += 3) {
      const a = bytes2[i];
      const b = bytes2[i + 1];
      const c = bytes2[i + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$4 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const uploadBytes$4 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$5(content || "") : utf8Bytes$4(content || "");
  const hex$3 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const rol$2 = (value, bits) => value << bits | value >>> 32 - bits;
  const sha1Bytes$2 = (message) => {
    const msg = message instanceof Uint8Array ? message : utf8Bytes$4(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4);
      for (let i = 16; i < 80; i += 1) w[i] = rol$2(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i = 0; i < 80; i += 1) {
        let f;
        let k;
        if (i < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$2(a, 5) + f + e + k + w[i] >>> 0;
        e = d;
        d = c;
        c = rol$2(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const sha1Hex$2 = (message) => hex$3(sha1Bytes$2(message));
  const leftRotate$3 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$3 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$4(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i = 0; i < 64; i += 1) {
        let f;
        let g;
        if (i < 16) {
          f = b & c | ~b & d;
          g = i;
        } else if (i < 32) {
          f = d & b | ~d & c;
          g = (5 * i + 1) % 16;
        } else if (i < 48) {
          f = b ^ c ^ d;
          g = (3 * i + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate$3(a + f + k[i] + view.getUint32(offset + g * 4, true) >>> 0, s[i]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const proofCode$1 = (accessToken, bytes2) => {
    if (!bytes2.length) return "";
    const start = Number(BigInt(`0x${md5Hex$3(accessToken).slice(0, 16)}`) % BigInt(bytes2.length));
    return bytesToBase64$4(bytes2.slice(start, Math.min(start + 8, bytes2.length)));
  };
  const makePartInfos = (count) => Array.from({ length: count }, (_, index) => ({ part_number: index + 1 }));
  const uploadTime = () => (/* @__PURE__ */ new Date()).toISOString().replace(/\.\d{3}Z$/, ".000Z");
  const uploadUrlOf = (storage, url) => boolValue$2(storage.addition_json.internal_upload ?? storage.addition_json.InternalUpload, false) ? String(url || "").replace("https://cn-beijing-data.aliyundrive.net/", "http://ccp-bj29-bj-1592982087.oss-cn-beijing-internal.aliyuncs.com/") : url;
  const fileToObj$5 = (file, relPath, storage) => {
    const isDir2 = file.type === "folder";
    return {
      name: file.name || file.file_name || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: parseTime$1(file.updated_at),
      created: parseTime$1(file.created_at),
      sign: "",
      thumb: file.thumbnail || "",
      type: isDir2 ? 1 : 0,
      hashinfo: file.content_hash || "",
      hash_info: file.content_hash ? { sha1: file.content_hash } : {},
      id: file.file_id || "",
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider: "AliyundriveOpen",
      file
    };
  };
  const listByParent$3 = async (client, storage, parentId) => {
    const cacheKey2 = `${storageKey$2(storage)}:list:${parentId}`;
    return cached(listCache, cacheKey2, async () => {
      const addition = storage.addition_json;
      const driveId = await initDrive(client, storage);
      const result = [];
      let marker = "";
      do {
        const resp = await requestAli(client, storage, "/adrive/v1.0/openFile/list", {
          body: {
            drive_id: driveId,
            limit: 200,
            marker,
            order_by: addition.order_by || addition.OrderBy || "",
            order_direction: addition.order_direction || addition.OrderDirection || "",
            parent_file_id: parentId
          }
        });
        result.push(...resp.items || []);
        marker = resp.next_marker || "";
      } while (marker);
      return result;
    });
  };
  const resolveFile$4 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    const cacheKey2 = `${storageKey$2(storage)}:file:${clean}`;
    return cached(fileCache, cacheKey2, async () => {
      if (clean === "/") {
        return {
          file_id: rootFolderId(storage.addition_json),
          name: "root",
          type: "folder",
          path: "/"
        };
      }
      let parentId = rootFolderId(storage.addition_json);
      let current = null;
      const parts = clean.split("/").filter(Boolean);
      for (const part of parts) {
        const files = await listByParent$3(client, storage, parentId);
        current = files.find((item) => (item.name || item.file_name) === part);
        if (!current) throw new Error(`object not found: ${clean}`);
        parentId = current.file_id;
      }
      return current;
    });
  };
  const linkFor$1 = async (client, storage, file) => {
    const cacheKey2 = `${storageKey$2(storage)}:link:${file.file_id || ""}`;
    return cached(linkCache, cacheKey2, async () => {
      var _a;
      const driveId = await initDrive(client, storage);
      const resp = await requestAli(client, storage, "/adrive/v1.0/openFile/getDownloadUrl", {
        body: {
          drive_id: driveId,
          file_id: file.file_id,
          expire_sec: 14400
        }
      });
      const url = resp.url || ((_a = resp.streamsUrl) == null ? void 0 : _a[storage.addition_json.livp_download_format || "jpeg"]) || "";
      if (!url) throw new Error("get download url failed");
      return url;
    });
  };
  const createAliyundriveOpenDriver = ({ client }) => ({
    async test(storage) {
      await initDrive(client, storage);
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$4(client, storage, relPath);
      const content = (await listByParent$3(client, storage, parent.file_id)).map((file) => fileToObj$5(file, normalizePath(relPath + "/" + (file.name || file.file_name)), storage));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "AliyundriveOpen",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$4(client, storage, relPath);
      const obj = fileToObj$5(file, relPath, storage);
      if (!obj.is_dir && !options.skipLink) {
        const url = await linkFor$1(client, storage, file);
        obj.raw_url = url;
        obj.url = url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$4(client, storage, relPath);
      if (file.type === "folder") throw new Error("not file");
      const url = await linkFor$1(client, storage, file);
      return {
        link: {
          url,
          header: options.proxyHeaders || options.headers || {},
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      const driveId = await initDrive(client, storage);
      const parent = await resolveFile$4(client, storage, dirnameOf(relPath));
      await requestAli(client, storage, "/adrive/v1.0/openFile/create", {
        body: {
          drive_id: driveId,
          parent_file_id: parent.file_id,
          name: basenameOf(relPath),
          type: "folder",
          check_name_mode: "refuse"
        }
      });
      clearStorageCache(storage);
    },
    async move(storage, relPath, dstRelPath) {
      const driveId = await initDrive(client, storage);
      const file = await resolveFile$4(client, storage, relPath);
      const dst = await resolveFile$4(client, storage, dstRelPath);
      await requestAli(client, storage, "/adrive/v1.0/openFile/move", {
        body: {
          drive_id: driveId,
          file_id: file.file_id,
          to_parent_file_id: dst.file_id,
          check_name_mode: "ignore"
        }
      });
      clearStorageCache(storage);
    },
    async copy(storage, relPath, dstRelPath) {
      const driveId = await initDrive(client, storage);
      const file = await resolveFile$4(client, storage, relPath);
      const dst = await resolveFile$4(client, storage, dstRelPath);
      await requestAli(client, storage, "/adrive/v1.0/openFile/copy", {
        body: {
          drive_id: driveId,
          file_id: file.file_id,
          to_parent_file_id: dst.file_id,
          auto_rename: false
        }
      });
      clearStorageCache(storage);
    },
    async remove(storage, relPath) {
      const driveId = await initDrive(client, storage);
      const file = await resolveFile$4(client, storage, relPath);
      const uri = storage.addition_json.remove_way === "delete" ? "/adrive/v1.0/openFile/delete" : "/adrive/v1.0/openFile/recyclebin/trash";
      await requestAli(client, storage, uri, {
        body: {
          drive_id: driveId,
          file_id: file.file_id
        }
      });
      clearStorageCache(storage);
    },
    async rename(storage, relPath, newName) {
      const driveId = await initDrive(client, storage);
      const file = await resolveFile$4(client, storage, relPath);
      await requestAli(client, storage, "/adrive/v1.0/openFile/update", {
        body: {
          drive_id: driveId,
          file_id: file.file_id,
          name: newName
        }
      });
      clearStorageCache(storage);
    },
    async put(storage, relPath, content, mime, options = {}) {
      var _a;
      const driveId = await initDrive(client, storage);
      const parent = await resolveFile$4(client, storage, dirnameOf(relPath));
      const bytes2 = uploadBytes$4(content, options);
      const count = Math.ceil(Number(options.size ?? bytes2.length) / UPLOAD_PART_SIZE);
      const createdAt = uploadTime();
      const rapidUpload = !options.forceStreamUpload && bytes2.length > 100 * 1024 && boolValue$2(storage.addition_json.rapid_upload ?? storage.addition_json.RapidUpload, false);
      const createData = {
        drive_id: driveId,
        parent_file_id: parent.file_id,
        name: basenameOf(relPath),
        type: "file",
        check_name_mode: "ignore",
        local_modified_at: createdAt,
        local_created_at: createdAt,
        part_info_list: makePartInfos(count)
      };
      if (rapidUpload) {
        createData.size = bytes2.length;
        createData.pre_hash = sha1Hex$2(bytes2.slice(0, 1024));
      }
      let createResp = await requestAli(client, storage, "/adrive/v1.0/openFile/create", {
        allowAliError: rapidUpload,
        body: createData
      });
      if (createResp == null ? void 0 : createResp.code) {
        if (createResp.code !== "PreHashMatched" || !rapidUpload) checkAli(createResp);
        delete createData.pre_hash;
        createData.proof_version = "v1";
        createData.content_hash_name = "sha1";
        createData.content_hash = sha1Hex$2(bytes2);
        createData.proof_code = proofCode$1(storage.addition_json.access_token || storage.addition_json.AccessToken || "", bytes2);
        createResp = await requestAli(client, storage, "/adrive/v1.0/openFile/create", {
          body: createData
        });
      }
      if (!createResp.rapid_upload) {
        for (let index = 0; index < (createResp.part_info_list || []).length; index += 1) {
          const offset = index * UPLOAD_PART_SIZE;
          const chunk = bytes2.slice(offset, Math.min(offset + UPLOAD_PART_SIZE, bytes2.length));
          const resp = await forwardProxy(client, uploadUrlOf(storage, (_a = createResp.part_info_list[index]) == null ? void 0 : _a.upload_url), {
            allowErrorStatus: true,
            body: bytesToBase64$4(chunk),
            contentType: mime || "application/octet-stream",
            method: "PUT",
            payloadEncoding: "base64",
            responseEncoding: "text",
            timeout: 12e4
          });
          if (![200, 409].includes(Number(resp.status || 0))) throw new Error(`upload status: ${resp.status}`);
        }
      }
      await requestAli(client, storage, "/adrive/v1.0/openFile/complete", {
        body: {
          drive_id: driveId,
          file_id: createResp.file_id,
          upload_id: createResp.upload_id
        }
      });
      clearStorageCache(storage);
    }
  });
  const API$1 = "https://pan.baidu.com/rest/2.0";
  const OPEN_API = "https://openapi.baidu.com/oauth/2.0/token";
  const DEFAULT_RENEW_API = "https://api.oplist.org/baiduyun/renewapi";
  const LIST_CACHE_TTL = 5 * 60 * 1e3;
  const FILE_CACHE_TTL = 5 * 60 * 1e3;
  const LINK_CACHE_TTL = 10 * 60 * 1e3;
  const baiduCache = /* @__PURE__ */ new Map();
  const storageKey$1 = (storage) => String((storage == null ? void 0 : storage.id) || (storage == null ? void 0 : storage.mount_path) || (storage == null ? void 0 : storage.mount_path_hash) || "default");
  const cacheKey = (storage, type, key) => `${storageKey$1(storage)}:${type}:${key}`;
  const getCache = (key) => {
    const hit = baiduCache.get(key);
    if (!hit) return void 0;
    if (hit.expires <= Date.now()) {
      baiduCache.delete(key);
      return void 0;
    }
    return hit.value;
  };
  const setCache = (key, value, ttl) => {
    baiduCache.set(key, { expires: Date.now() + ttl, value });
    if (baiduCache.size > 512) {
      for (const cacheKeyValue of baiduCache.keys()) {
        baiduCache.delete(cacheKeyValue);
        if (baiduCache.size <= 384) break;
      }
    }
    return value;
  };
  const invalidateStorageCache = (storage) => {
    const prefix = `${storageKey$1(storage)}:`;
    for (const key of baiduCache.keys()) {
      if (key.startsWith(prefix)) baiduCache.delete(key);
    }
  };
  const boolValue$1 = (value, fallback = false) => {
    if (value === void 0 || value === null || value === "") return fallback;
    return value === true || value === "true";
  };
  const rootedPath$1 = (addition, relPath) => {
    const root = normalizePath(addition.root_folder_path || addition.RootFolderPath || "/");
    return normalizePath(root + "/" + normalizePath(relPath || "/"));
  };
  const baiduTime = (value) => {
    const date = Number(value || 0) ? new Date(Number(value) * 1e3) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const checkBaidu = (payload) => {
    const errno = Number((payload == null ? void 0 : payload.errno) || (payload == null ? void 0 : payload.error_code) || 0);
    if (errno && errno !== 31023) throw new Error((payload == null ? void 0 : payload.errmsg) || (payload == null ? void 0 : payload.error_msg) || `baidu errno: ${errno}`);
    return payload;
  };
  const persistAddition = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const refreshToken$1 = async (client, storage) => {
    const addition = storage.addition_json || storage;
    const refreshTokenValue = addition.refresh_token || addition.RefreshToken || "";
    if (!refreshTokenValue) throw new Error("empty refresh_token");
    const useOnlineApi = boolValue$1(addition.use_online_api ?? addition.UseOnlineAPI, true);
    if (useOnlineApi) {
      const url2 = new URL(addition.api_url_address || addition.APIAddress || DEFAULT_RENEW_API);
      url2.searchParams.set("refresh_ui", refreshTokenValue);
      url2.searchParams.set("server_use", "true");
      url2.searchParams.set("driver_txt", "baiduyun_go");
      const resp2 = await remoteJson(client, url2.toString(), { method: "GET" });
      if (!resp2.refresh_token || !resp2.access_token) throw new Error(resp2.text || "empty token returned from official API");
      addition.access_token = resp2.access_token;
      addition.refresh_token = resp2.refresh_token;
      await persistAddition(storage);
      return addition;
    }
    if (!addition.client_id || !addition.client_secret) throw new Error("empty ClientID or ClientSecret");
    const url = new URL(OPEN_API);
    url.searchParams.set("grant_type", "refresh_token");
    url.searchParams.set("refresh_token", refreshTokenValue);
    url.searchParams.set("client_id", addition.client_id);
    url.searchParams.set("client_secret", addition.client_secret);
    const resp = await remoteJson(client, url.toString(), { method: "GET" });
    if (resp.error) throw new Error(`${resp.error}: ${resp.error_description || ""}`.trim());
    if (!resp.refresh_token || !resp.access_token) throw new Error("empty token returned from official API");
    addition.access_token = resp.access_token;
    addition.refresh_token = resp.refresh_token;
    await persistAddition(storage);
    return addition;
  };
  const ensureAccessToken = async (client, storage) => {
    const addition = storage.addition_json || storage;
    if (addition.access_token || addition.AccessToken) return;
    await refreshToken$1(client, storage);
  };
  const requestBaidu = async (client, storage, url, {
    allowErrorStatus = false,
    body,
    contentType = "application/json",
    method = "GET",
    query = {},
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    await ensureAccessToken(client, storage);
    const target = new URL(url);
    target.searchParams.set("access_token", addition.access_token || addition.AccessToken || "");
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const resp = await remoteJson(client, target.toString(), {
      allowErrorStatus,
      body,
      contentType,
      method
    });
    const errno = Number((resp == null ? void 0 : resp.errno) || (resp == null ? void 0 : resp.error_code) || 0);
    if ((errno === 111 || errno === -6) && retry) {
      await refreshToken$1(client, storage);
      return requestBaidu(client, storage, url, { allowErrorStatus, body, contentType, method, query, retry: false });
    }
    return checkBaidu(resp);
  };
  const get = (client, storage, pathname, query, retry) => requestBaidu(client, storage, `${API$1}${pathname}`, { method: "GET", query, retry });
  const postForm = (client, storage, pathname, query, form) => requestBaidu(client, storage, `${API$1}${pathname}`, {
    body: new URLSearchParams(form).toString(),
    contentType: "application/x-www-form-urlencoded",
    method: "POST",
    query
  });
  const DEFAULT_UPLOAD_API = "https://d.pcs.baidu.com";
  const DEFAULT_SLICE_SIZE = 4 * 1024 * 1024;
  const VIP_SLICE_SIZE = 16 * 1024 * 1024;
  const SVIP_SLICE_SIZE = 32 * 1024 * 1024;
  const MAX_SLICE_NUM = 2048;
  const SLICE_STEP = 1024 * 1024;
  const SLICE_MD5_SIZE = 256 * 1024;
  const base64ToBytes$4 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars2.indexOf(clean[i]);
      const b = chars2.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars2.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars2.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$3 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i = 0; i < bytes2.length; i += 3) {
      const a = bytes2[i];
      const b = bytes2[i + 1];
      const c = bytes2[i + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$3 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const uploadBytes$3 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$4(content || "") : utf8Bytes$3(content || "");
  const leftRotate$2 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$2 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$3(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i = 0; i < 64; i += 1) {
        let f;
        let g;
        if (i < 16) {
          f = b & c | ~b & d;
          g = i;
        } else if (i < 32) {
          f = d & b | ~d & c;
          g = (5 * i + 1) % 16;
        } else if (i < 48) {
          f = b ^ c ^ d;
          g = (3 * i + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate$2(a + f + k[i] + view.getUint32(offset + g * 4, true) >>> 0, s[i]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const joinTime = (form, ctime, mtime) => {
    if (!mtime || !ctime) return;
    form.local_mtime = String(mtime);
    form.local_ctime = String(ctime);
  };
  const getSliceSize = (storage, filesize) => {
    const addition = storage.addition_json || {};
    const vipType = Number(addition.vip_type || addition.VipType || 0);
    const custom = Number(addition.custom_upload_part_size || addition.CustomUploadPartSize || 0);
    if (vipType === 0) return DEFAULT_SLICE_SIZE;
    if (custom) {
      if (custom < DEFAULT_SLICE_SIZE) return DEFAULT_SLICE_SIZE;
      if (vipType === 1 && custom > VIP_SLICE_SIZE) return VIP_SLICE_SIZE;
      if (vipType === 2 && custom > SVIP_SLICE_SIZE) return SVIP_SLICE_SIZE;
      return custom;
    }
    const maxSliceSize = vipType === 1 ? VIP_SLICE_SIZE : SVIP_SLICE_SIZE;
    if (boolValue$1(addition.low_bandwith_upload_mode ?? addition.LowBandwithUploadMode, false)) {
      for (let size = DEFAULT_SLICE_SIZE; size <= maxSliceSize; size += SLICE_STEP) {
        if (filesize <= MAX_SLICE_NUM * size) return size;
      }
    }
    return maxSliceSize;
  };
  const createFile = async (client, storage, path, size, isdir, uploadid, blockList, mtime, ctime) => {
    const form = {
      path,
      size: String(size),
      isdir: String(isdir),
      rtype: "3"
    };
    joinTime(form, ctime, mtime);
    if (uploadid) form.uploadid = uploadid;
    if (blockList) form.block_list = blockList;
    return postForm(client, storage, "/xpan/file", { method: "create" }, form);
  };
  const precreate = async (client, storage, path, size, blockList, contentMd5, sliceMd52, ctime, mtime) => {
    const form = {
      path,
      size: String(size),
      isdir: "0",
      autoinit: "1",
      rtype: "3",
      block_list: blockList
    };
    if (contentMd5 && sliceMd52) {
      form["content-md5"] = contentMd5;
      form["slice-md5"] = sliceMd52;
    }
    joinTime(form, ctime, mtime);
    return postForm(client, storage, "/xpan/file", { method: "precreate" }, form);
  };
  const requestForUploadUrl = async (client, storage, path, uploadid) => {
    var _a, _b, _c, _d;
    const payload = await requestBaidu(client, storage, `${DEFAULT_UPLOAD_API}/rest/2.0/pcs/file`, {
      method: "GET",
      query: {
        method: "locateupload",
        appid: "250528",
        path,
        uploadid,
        upload_version: "2.0"
      }
    });
    const server = ((_b = (_a = payload == null ? void 0 : payload.servers) == null ? void 0 : _a[0]) == null ? void 0 : _b.server) || ((_d = (_c = payload == null ? void 0 : payload.bak_servers) == null ? void 0 : _c[0]) == null ? void 0 : _d.server) || "";
    if (!server) throw new Error("upload URL is empty");
    return server;
  };
  const uploadApiOf = (storage) => {
    const api = storage.addition_json.upload_api || storage.addition_json.UploadAPI || DEFAULT_UPLOAD_API;
    try {
      return new URL(api).toString().replace(/\/+$/, "");
    } catch (_) {
      return DEFAULT_UPLOAD_API;
    }
  };
  const getUploadUrl = async (client, storage, path, uploadid) => {
    if (!boolValue$1(storage.addition_json.use_dynamic_upload_api ?? storage.addition_json.UseDynamicUploadAPI, true) || !uploadid) {
      return uploadApiOf(storage);
    }
    try {
      return await requestForUploadUrl(client, storage, path, uploadid);
    } catch (_) {
      return uploadApiOf(storage);
    }
  };
  const multipartBody = (fieldName, fileName, bytes2, boundary) => {
    const head = utf8Bytes$3(`--${boundary}\r
Content-Disposition: form-data; name="${fieldName}"; filename="${fileName}"\r
Content-Type: application/octet-stream\r
\r
`);
    const tail = utf8Bytes$3(`\r
--${boundary}--\r
`);
    const body = new Uint8Array(head.length + bytes2.length + tail.length);
    body.set(head);
    body.set(bytes2, head.length);
    body.set(tail, head.length + bytes2.length);
    return body;
  };
  const uploadSlice = async (client, storage, uploadUrl, params, fileName, bytes2) => {
    const target = new URL(`${uploadUrl.replace(/\/+$/, "")}/rest/2.0/pcs/superfile2`);
    for (const [key, value] of Object.entries(params)) target.searchParams.set(key, String(value));
    const boundary = `----siyuan-baidu-${Date.now().toString(16)}`;
    const body = multipartBody("file", fileName, bytes2, boundary);
    const resp = await forwardProxy(client, target.toString(), {
      allowErrorStatus: true,
      body: bytesToBase64$3(body),
      contentType: `multipart/form-data; boundary=${boundary}`,
      method: "POST",
      payloadEncoding: "base64",
      responseEncoding: "text",
      timeout: Number(storage.addition_json.upload_timeout || storage.addition_json.UploadSliceTimeout || 60) * 1e3
    });
    let payload = {};
    try {
      payload = JSON.parse(resp.body || "{}");
    } catch (_) {
      payload = {};
    }
    const lower = String(resp.body || "").toLowerCase();
    if (lower.includes("uploadid") && (lower.includes("invalid") || lower.includes("expired") || lower.includes("not found"))) {
      throw new Error("uploadid expired");
    }
    const errno = Number((payload == null ? void 0 : payload.errno) || (payload == null ? void 0 : payload.error_code) || 0);
    if (errno) throw new Error(`error uploading to baidu, response=${resp.body || ""}`);
  };
  const putRapid = async (client, storage, path, bytes2, mtime, ctime) => {
    const contentMd5 = md5Hex$2(bytes2);
    const blockList = JSON.stringify([contentMd5]);
    return createFile(client, storage, path, bytes2.length, 0, "", blockList, mtime, ctime);
  };
  const fileNameOf$2 = (file) => (file == null ? void 0 : file.server_filename) || (file == null ? void 0 : file.name) || basename((file == null ? void 0 : file.path) || "");
  const isDir$2 = (file) => Number((file == null ? void 0 : file.isdir) || 0) === 1;
  const VIDEO_EXTS = /* @__PURE__ */ new Set(["mp4", "mkv", "avi", "mov", "rmvb", "webm", "flv", "m3u8", "m4v"]);
  const AUDIO_EXTS = /* @__PURE__ */ new Set(["mp3", "flac", "ogg", "m4a", "wav", "opus", "wma"]);
  const fileExtOf = (file) => {
    var _a;
    return ((_a = fileNameOf$2(file).split(".").pop()) == null ? void 0 : _a.toLowerCase()) || "";
  };
  const isStreamMediaFile = (file) => [1, 2].includes(Number((file == null ? void 0 : file.category) || 0)) || VIDEO_EXTS.has(fileExtOf(file)) || AUDIO_EXTS.has(fileExtOf(file));
  const effectiveDownloadApi = (storage, file) => {
    const api = storage.addition_json.download_api || "official";
    return api === "crack_video" && !isStreamMediaFile(file) ? "official" : api;
  };
  const fileToObj$4 = (file, relPath, storage) => {
    var _a;
    const actualPath = (file == null ? void 0 : file.path) || rootedPath$1(storage.addition_json, relPath);
    const dir = isDir$2(file);
    return {
      name: fileNameOf$2(file),
      path: normalizePath(relPath),
      is_dir: dir,
      size: Number((file == null ? void 0 : file.size) || 0),
      modified: baiduTime((file == null ? void 0 : file.server_mtime) || (file == null ? void 0 : file.mtime)),
      created: baiduTime((file == null ? void 0 : file.server_ctime) || (file == null ? void 0 : file.ctime)),
      sign: "",
      thumb: ((_a = file == null ? void 0 : file.thumbs) == null ? void 0 : _a.url3) || "",
      type: dir ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: String((file == null ? void 0 : file.fs_id) || (file == null ? void 0 : file.id) || ""),
      raw_url: dir ? "" : `/plugin/private/siyuan-cloud/p${normalizePath(storage.mount_path + "/" + relPath)}`,
      provider: "BaiduNetdisk",
      file: { ...file, path: actualPath }
    };
  };
  const listFiles = async (client, storage, relPath) => {
    const cleanRelPath = normalizePath(relPath || "/");
    const cached2 = getCache(cacheKey(storage, "list", cleanRelPath));
    if (cached2) return cached2;
    const addition = storage.addition_json;
    const dir = rootedPath$1(addition, cleanRelPath);
    const result = [];
    for (let start = 0; ; start += 1e3) {
      const query = {
        method: "list",
        dir,
        web: "web",
        start,
        limit: 1e3
      };
      if (addition.order_by) {
        query.order = addition.order_by;
        if (addition.order_direction === "desc") query.desc = "1";
      }
      const payload = await get(client, storage, "/xpan/file", {
        ...query
      });
      const list = payload.list || [];
      for (const file of list) {
        if (!boolValue$1(addition.only_list_video_file) || file.isdir === 1 || file.category === 1) result.push(file);
      }
      if (list.length < 1e3) break;
    }
    return setCache(cacheKey(storage, "list", cleanRelPath), result, LIST_CACHE_TTL);
  };
  const resolveFile$3 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    if (clean === "/") return { isRoot: true, id: "", name: "root", path: "/" };
    const cached2 = getCache(cacheKey(storage, "file", clean));
    if (cached2) return cached2;
    const parent = dirname(clean);
    const name = basename(clean);
    const files = await listFiles(client, storage, parent);
    const file = files.find((entry) => fileNameOf$2(entry) === name);
    if (!file) throw new Error(`object not found: ${clean}`);
    return setCache(cacheKey(storage, "file", clean), { file, id: String(file.fs_id || ""), name: fileNameOf$2(file), path: clean }, FILE_CACHE_TTL);
  };
  const headerValue$1 = (headers = {}, name) => {
    const lower = String(name || "").toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== lower) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const resolveHeadLocation = async (client, url, headers) => {
    try {
      const resp = await forwardProxy(client, url, {
        allowErrorStatus: true,
        contentType: "application/octet-stream",
        headers,
        method: "HEAD",
        redirect: false,
        responseEncoding: "text",
        timeout: 3e4
      });
      return headerValue$1(resp.headers, "Location") || headerValue$1(resp.headers, "location");
    } catch (_) {
      return "";
    }
  };
  const linkOfficial = async (client, storage, file) => {
    var _a, _b;
    const payload = await get(client, storage, "/xpan/multimedia", {
      method: "filemetas",
      fsids: `[${file.fs_id || file.id}]`,
      dlink: "1"
    });
    const dlink = ((_b = (_a = payload == null ? void 0 : payload.list) == null ? void 0 : _a[0]) == null ? void 0 : _b.dlink) || "";
    if (!dlink) throw new Error("get baidu dlink failed");
    const headers = { "User-Agent": "pan.baidu.com" };
    const url = `${dlink}&access_token=${encodeURIComponent(storage.addition_json.access_token || "")}`;
    const location = await resolveHeadLocation(client, url, headers);
    return {
      headers,
      url: location || url
    };
  };
  const linkCrack = async (client, storage, file) => {
    var _a, _b;
    const payload = await requestBaidu(client, storage, "https://pan.baidu.com/api/filemetas", {
      method: "GET",
      query: {
        target: `["${file.path}"]`,
        dlink: "1",
        web: "5",
        origin: "dlna"
      }
    });
    const url = ((_b = (_a = payload == null ? void 0 : payload.info) == null ? void 0 : _a[0]) == null ? void 0 : _b.dlink) || "";
    if (!url) throw new Error("get baidu crack dlink failed");
    return {
      headers: { "User-Agent": storage.addition_json.custom_crack_ua || "netdisk" },
      url
    };
  };
  const linkCrackVideo = async (client, storage, file) => {
    var _a, _b, _c;
    const payload = await requestBaidu(client, storage, "https://pan.baidu.com/api/mediainfo", {
      allowErrorStatus: true,
      method: "GET",
      query: {
        type: "VideoURL",
        path: file.path,
        fs_id: file.fs_id || file.id,
        devuid: "0%1",
        clienttype: "1",
        channel: "android_15_25010PN30C_bd-netdisk_1523a",
        nom3u8: "1",
        dlink: "1",
        media: "1",
        origin: "dlna"
      }
    });
    const url = ((_a = payload == null ? void 0 : payload.info) == null ? void 0 : _a.dlink) || ((_c = (_b = payload == null ? void 0 : payload.info) == null ? void 0 : _b[0]) == null ? void 0 : _c.dlink) || "";
    if (!url) throw new Error("get baidu video dlink failed");
    return {
      headers: { "User-Agent": storage.addition_json.custom_crack_ua || "netdisk" },
      url
    };
  };
  const linkFor = async (client, storage, file) => {
    const api = effectiveDownloadApi(storage, file);
    const key = cacheKey(storage, "link", [
      api,
      file.fs_id || file.id || "",
      file.size || "",
      file.server_mtime || file.mtime || ""
    ].join(":"));
    const cached2 = getCache(key);
    if (cached2) return cached2;
    let link;
    switch (api) {
      case "crack":
        link = await linkCrack(client, storage, file);
        break;
      case "crack_video":
        link = await linkCrackVideo(client, storage, file);
        break;
      default:
        link = await linkOfficial(client, storage, file);
    }
    return setCache(key, link, LINK_CACHE_TTL);
  };
  const manage = (client, storage, opera, filelist) => postForm(client, storage, "/xpan/file", {
    method: "filemanager",
    opera
  }, {
    async: "0",
    filelist: JSON.stringify(filelist),
    ondup: "fail"
  });
  const createBaiduNetdiskDriver = ({ client }) => ({
    async test(storage) {
      await ensureAccessToken(client, storage);
      await get(client, storage, "/xpan/nas", { method: "uinfo" });
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const content = (await listFiles(client, storage, relPath)).map((file) => fileToObj$4(file, normalizePath(relPath + "/" + fileNameOf$2(file)), storage));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "BaiduNetdisk",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const target = await resolveFile$3(client, storage, relPath);
      if (target.isRoot) {
        return {
          name: "root",
          path: "/",
          is_dir: true,
          size: 0,
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString(),
          provider: "BaiduNetdisk",
          related: []
        };
      }
      const obj = fileToObj$4(target.file, relPath, storage);
      if (!obj.is_dir && !options.skipLink) {
        const link = await linkFor(client, storage, target.file);
        obj.raw_url = link.url;
        obj.url = link.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      var _a;
      const target = await resolveFile$3(client, storage, relPath);
      if (target.isRoot || isDir$2(target.file)) throw new Error("not file");
      const link = await linkFor(client, storage, target.file);
      if (link.body !== void 0) {
        return {
          body: link.body,
          contentType: link.contentType || "application/vnd.apple.mpegurl",
          headers: link.headers || {},
          media_type: link.media_type || "m3u8",
          status: 200
        };
      }
      const header = { ...link.headers, ...options.proxyHeaders || options.headers || {} };
      return {
        link: {
          url: link.url,
          header,
          content_length: Number(((_a = target.file) == null ? void 0 : _a.size) || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      await postForm(client, storage, "/xpan/file", { method: "create" }, {
        path: rootedPath$1(storage.addition_json, relPath),
        size: "0",
        isdir: "1",
        rtype: "3"
      });
      invalidateStorageCache(storage);
    },
    async remove(storage, relPath) {
      const target = await resolveFile$3(client, storage, relPath);
      await manage(client, storage, "delete", [target.file.path]);
      invalidateStorageCache(storage);
    },
    async rename(storage, relPath, newName) {
      const target = await resolveFile$3(client, storage, relPath);
      await manage(client, storage, "rename", [{ path: target.file.path, newname: newName }]);
      invalidateStorageCache(storage);
    },
    async put(storage, relPath, content, mime, options = {}) {
      const bytes2 = uploadBytes$3(content, options);
      if (bytes2.length < 1) throw new Error("empty files are not allowed by baidu netdisk");
      const path = rootedPath$1(storage.addition_json, relPath);
      const now = Math.floor(Date.now() / 1e3);
      const mtime = Number(options.mtime || options.modified || now);
      const ctime = Number(options.ctime || options.created || now);
      try {
        await putRapid(client, storage, path, bytes2, mtime, ctime);
        invalidateStorageCache(storage);
        return;
      } catch (_) {
      }
      const sliceSize = getSliceSize(storage, bytes2.length);
      const blockList = [];
      for (let offset = 0; offset < bytes2.length; offset += sliceSize) {
        blockList.push(md5Hex$2(bytes2.slice(offset, Math.min(offset + sliceSize, bytes2.length))));
      }
      const blockListStr = JSON.stringify(blockList);
      const contentMd5 = md5Hex$2(bytes2);
      const sliceMd52 = md5Hex$2(bytes2.slice(0, Math.min(SLICE_MD5_SIZE, bytes2.length)));
      const pre = await precreate(client, storage, path, bytes2.length, blockListStr, contentMd5, sliceMd52, ctime, mtime);
      if (Number((pre == null ? void 0 : pre.return_type) || 0) === 2) {
        invalidateStorageCache(storage);
        return;
      }
      const uploadid = (pre == null ? void 0 : pre.uploadid) || "";
      if (!uploadid) throw new Error("baidu precreate missing uploadid");
      const partseqs = Array.isArray(pre == null ? void 0 : pre.block_list) && pre.block_list.length ? pre.block_list.map((part) => Number(part)) : blockList.map((_, index) => index);
      const uploadUrl = await getUploadUrl(client, storage, path, uploadid);
      const fileName = basename(path);
      for (const partseq of partseqs) {
        if (partseq < 0) continue;
        const offset = partseq * sliceSize;
        const chunk = bytes2.slice(offset, Math.min(offset + sliceSize, bytes2.length));
        await uploadSlice(client, storage, uploadUrl, {
          method: "upload",
          access_token: storage.addition_json.access_token || storage.addition_json.AccessToken || "",
          type: "tmpfile",
          path,
          uploadid,
          partseq
        }, fileName, chunk);
      }
      await createFile(client, storage, path, bytes2.length, 0, uploadid, blockListStr, mtime, ctime);
      invalidateStorageCache(storage);
    }
  });
  const hosts = {
    global: {
      oauth: "https://login.microsoftonline.com",
      api: "https://graph.microsoft.com"
    },
    cn: {
      oauth: "https://login.chinacloudapi.cn",
      api: "https://microsoftgraph.chinacloudapi.cn"
    },
    us: {
      oauth: "https://login.microsoftonline.us",
      api: "https://graph.microsoft.us"
    },
    de: {
      oauth: "https://login.microsoftonline.de",
      api: "https://graph.microsoft.de"
    }
  };
  const hostFor = (addition) => hosts[addition.region || addition.Region || "global"] || hosts.global;
  const additionValue = (addition, lowerName, upperName, fallback = "") => {
    const value = (addition == null ? void 0 : addition[lowerName]) ?? (addition == null ? void 0 : addition[upperName]);
    return value === void 0 || value === null || value === "" ? fallback : value;
  };
  const boolValue = (value, fallback = false) => {
    if (value === void 0 || value === null || value === "") return fallback;
    return value === true || value === "true";
  };
  const encodePath = (path) => {
    const clean = normalizePath(path || "/");
    if (clean === "/") return "/";
    return "/" + clean.split("/").filter(Boolean).map(encodeURIComponent).join("/");
  };
  const rootedPath = (addition, relPath) => {
    const root = normalizePath(additionValue(addition, "root_folder_path", "RootFolderPath", "/"));
    return normalizePath(root + "/" + normalizePath(relPath || "/"));
  };
  const base64ToBytes$3 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars2.indexOf(clean[i]);
      const b = chars2.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars2.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars2.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$2 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i = 0; i < bytes2.length; i += 3) {
      const a = bytes2[i];
      const b = bytes2[i + 1];
      const c = bytes2[i + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$2 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const uploadBytes$2 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$3(content || "") : utf8Bytes$2(content || "");
  const metaUrl = (addition, relPath) => {
    const host = hostFor(addition);
    const path = encodePath(rootedPath(addition, relPath));
    const isSharepoint = boolValue(additionValue(addition, "is_sharepoint", "IsSharepoint"));
    const siteId = additionValue(addition, "site_id", "SiteId");
    if (isSharepoint) {
      if (path === "/") return `${host.api}/v1.0/sites/${encodeURIComponent(siteId)}/drive/root`;
      return `${host.api}/v1.0/sites/${encodeURIComponent(siteId)}/drive/root:${path}:`;
    }
    if (path === "/") return `${host.api}/v1.0/me/drive/root`;
    return `${host.api}/v1.0/me/drive/root:${path}:`;
  };
  const chunkSizeOf = (addition) => Math.max(1, Number(addition.chunk_size || addition.ChunkSize || 5)) * 1024 * 1024;
  const metadataFromOptions = (options = {}) => {
    const fileSystemInfo = {};
    const modified = options.mtime || options.modified;
    const created = options.ctime || options.created;
    if (modified) fileSystemInfo.lastModifiedDateTime = new Date(modified).toISOString();
    if (created) fileSystemInfo.createdDateTime = new Date(created).toISOString();
    return { fileSystemInfo };
  };
  const updateMetadata = async (client, storage, relPath, options = {}) => {
    const metadata = metadataFromOptions(options);
    if (!Object.keys(metadata.fileSystemInfo).length) return;
    await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), {
      body: metadata,
      method: "PATCH"
    });
  };
  const createUploadSession = async (client, storage, relPath, metadata) => {
    const payload = await requestGraph(client, storage, `${metaUrl(storage.addition_json, relPath)}/createUploadSession`, {
      body: { item: metadata },
      method: "POST"
    });
    const uploadUrl = (payload == null ? void 0 : payload.uploadUrl) || "";
    if (!uploadUrl) throw new Error("failed to get upload URL from response");
    return uploadUrl;
  };
  const uploadSessionBytes = async (client, uploadUrl, bytes2, chunkSize) => {
    for (let start = 0; start < bytes2.length; start += chunkSize) {
      const end = Math.min(start + chunkSize, bytes2.length);
      const chunk = bytes2.slice(start, end);
      await forwardProxy(client, uploadUrl, {
        allowErrorStatus: false,
        body: bytesToBase64$2(chunk),
        contentType: "application/octet-stream",
        headers: {
          "Content-Length": String(chunk.length),
          "Content-Range": `bytes ${start}-${end - 1}/${bytes2.length}`
        },
        method: "PUT",
        payloadEncoding: "base64",
        responseEncoding: "text",
        timeout: 3e4
      });
    }
  };
  const tokenUrl = (addition) => `${hostFor(addition).oauth}/common/oauth2/v2.0/token`;
  const graphHeaders = (addition) => ({
    Authorization: `Bearer ${addition.access_token || addition.AccessToken || ""}`
  });
  const checkGraph = (payload) => {
    var _a;
    if ((_a = payload == null ? void 0 : payload.error) == null ? void 0 : _a.message) throw new Error(payload.error.message);
    if (payload == null ? void 0 : payload.error_description) throw new Error(payload.error_description);
    return payload;
  };
  const saveDriverStorage = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const refreshToken = async (client, storage) => {
    const addition = storage.addition_json || storage;
    const useOnlineApi = boolValue(addition.use_online_api ?? addition.UseOnlineAPI, true);
    const apiAddress = addition.api_url_address || addition.APIAddress || "https://api.oplist.org/onedrive/renewapi";
    const refreshTokenValue = addition.refresh_token || addition.RefreshToken || "";
    if (useOnlineApi && apiAddress) {
      const url = new URL(apiAddress);
      url.searchParams.set("refresh_ui", refreshTokenValue);
      url.searchParams.set("server_use", "true");
      url.searchParams.set("driver_txt", "onedrive_pr");
      const resp2 = checkGraph(await remoteJson(client, url.toString(), { method: "GET" }));
      if (!resp2.refresh_token || !resp2.access_token) {
        throw new Error(resp2.text || "empty token returned from official API, a wrong refresh token may have been used");
      }
      addition.refresh_token = resp2.refresh_token;
      addition.access_token = resp2.access_token;
      await saveDriverStorage(storage);
      return addition.access_token;
    }
    const clientId = addition.client_id || addition.ClientID || "";
    const clientSecret = addition.client_secret || addition.ClientSecret || "";
    if (!clientId || !clientSecret) throw new Error("empty ClientID or ClientSecret");
    const form = new URLSearchParams({
      grant_type: "refresh_token",
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: addition.redirect_uri || addition.RedirectUri || "https://api.oplist.org/onedrive/callback",
      refresh_token: refreshTokenValue
    });
    const resp = checkGraph(await remoteJson(client, tokenUrl(addition), {
      body: form.toString(),
      contentType: "application/x-www-form-urlencoded",
      method: "POST"
    }));
    if (!resp.refresh_token || !resp.access_token) throw new Error("empty token returned from Microsoft Graph");
    addition.refresh_token = resp.refresh_token;
    addition.access_token = resp.access_token;
    await saveDriverStorage(storage);
    return addition.access_token;
  };
  const requestGraph = async (client, storage, url, {
    body,
    contentType = "application/json",
    method = "GET",
    payloadEncoding,
    retry = true
  } = {}) => {
    var _a;
    const addition = storage.addition_json;
    if (!addition.access_token && !addition.AccessToken) await refreshToken(client, storage);
    const resp = await remoteJson(client, url, {
      allowErrorStatus: true,
      body,
      contentType,
      headers: graphHeaders(addition),
      method,
      payloadEncoding
    });
    if (((_a = resp == null ? void 0 : resp.error) == null ? void 0 : _a.code) === "InvalidAuthenticationToken" && retry) {
      await refreshToken(client, storage);
      return requestGraph(client, storage, url, { body, contentType, method, payloadEncoding, retry: false });
    }
    return checkGraph(resp);
  };
  const fileTime = (file) => {
    var _a;
    const raw = ((_a = file == null ? void 0 : file.fileSystemInfo) == null ? void 0 : _a.lastModifiedDateTime) || (file == null ? void 0 : file.lastModifiedDateTime) || (file == null ? void 0 : file.createdDateTime);
    const date = raw ? new Date(raw) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const fileToObj$3 = (file, relPath, storage) => {
    var _a, _b, _c, _d;
    const isDir2 = !file.file;
    return {
      name: file.name || basename(relPath),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: fileTime(file),
      created: ((_a = file == null ? void 0 : file.fileSystemInfo) == null ? void 0 : _a.createdDateTime) || fileTime(file),
      thumb: ((_d = (_c = (_b = file == null ? void 0 : file.thumbnails) == null ? void 0 : _b[0]) == null ? void 0 : _c.medium) == null ? void 0 : _d.url) || "",
      sign: "",
      type: isDir2 ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: file.id || "",
      raw_url: isDir2 ? "" : `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
      provider: "Onedrive"
    };
  };
  const customDownloadUrl = (addition, rawUrl) => {
    const customHost = additionValue(addition, "custom_host", "CustomHost");
    if (!customHost || !rawUrl) return rawUrl || "";
    try {
      const url = new URL(rawUrl);
      url.host = customHost;
      return url.toString();
    } catch (_) {
      return rawUrl || "";
    }
  };
  const driveUrl = (addition) => {
    const host = hostFor(addition);
    if (boolValue(additionValue(addition, "is_sharepoint", "IsSharepoint"))) {
      return `${host.api}/v1.0/sites/${encodeURIComponent(additionValue(addition, "site_id", "SiteId"))}/drive`;
    }
    return `${host.api}/v1.0/me/drive`;
  };
  const createOneDriveDriver = ({ client }) => ({
    async list(storage, relPath) {
      const content = [];
      let next = `${metaUrl(storage.addition_json, relPath)}/children?$top=1000&$expand=thumbnails($select=medium)&$select=id,name,size,fileSystemInfo,content.downloadUrl,file,parentReference`;
      while (next) {
        const data = await requestGraph(client, storage, next);
        for (const file of data.value || []) {
          content.push(fileToObj$3(file, normalizePath(relPath + "/" + file.name), storage));
        }
        next = data["@odata.nextLink"] || "";
      }
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "Onedrive",
        direct_upload_tools: boolValue(additionValue(storage.addition_json, "enable_direct_upload", "EnableDirectUpload")) ? ["HttpDirect"] : []
      };
    },
    async get(storage, relPath) {
      const file = await requestGraph(client, storage, metaUrl(storage.addition_json, relPath));
      const url = customDownloadUrl(storage.addition_json, file["@microsoft.graph.downloadUrl"]);
      return {
        ...fileToObj$3(file, relPath, storage),
        raw_url: file.file ? url : "",
        url,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath) {
      const file = await requestGraph(client, storage, metaUrl(storage.addition_json, relPath));
      if (!file.file) throw new Error("not file");
      const url = customDownloadUrl(storage.addition_json, file["@microsoft.graph.downloadUrl"]);
      if (!url) throw new Error("get download url failed");
      return {
        link: {
          url,
          header: {},
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      await requestGraph(client, storage, `${metaUrl(storage.addition_json, dirname(relPath))}/children`, {
        body: {
          name: basename(relPath),
          folder: {},
          "@microsoft.graph.conflictBehavior": "rename"
        },
        method: "POST"
      });
    },
    async move(storage, relPath, dstRelPath) {
      const dst = await requestGraph(client, storage, metaUrl(storage.addition_json, dstRelPath));
      await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), {
        body: {
          parentReference: {
            id: dst.id
          },
          name: basename(relPath)
        },
        method: "PATCH"
      });
    },
    async copy(storage, relPath, dstRelPath) {
      var _a;
      const dst = await requestGraph(client, storage, metaUrl(storage.addition_json, dstRelPath));
      await requestGraph(client, storage, `${metaUrl(storage.addition_json, relPath)}/copy`, {
        body: {
          parentReference: {
            driveId: ((_a = dst.parentReference) == null ? void 0 : _a.driveId) || dst.driveId,
            id: dst.id
          },
          name: basename(relPath)
        },
        method: "POST"
      });
    },
    async remove(storage, relPath) {
      await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), { method: "DELETE" });
    },
    async rename(storage, relPath, newName) {
      var _a;
      const file = await requestGraph(client, storage, metaUrl(storage.addition_json, relPath));
      await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), {
        body: {
          parentReference: {
            id: ((_a = file.parentReference) == null ? void 0 : _a.id) || "root"
          },
          name: newName
        },
        method: "PATCH"
      });
    },
    async put(storage, relPath, content, mime, options = {}) {
      const bytes2 = uploadBytes$2(content, options);
      if (bytes2.length <= 4 * 1024 * 1024) {
        await requestGraph(client, storage, `${metaUrl(storage.addition_json, relPath)}/content`, {
          body: content || "",
          contentType: mime || "application/octet-stream",
          method: "PUT",
          payloadEncoding: options.bodyEncoding === "base64" ? "base64" : void 0
        });
        await updateMetadata(client, storage, relPath, options);
        return;
      }
      const uploadUrl = await createUploadSession(client, storage, relPath, metadataFromOptions(options));
      await uploadSessionBytes(client, uploadUrl, bytes2, chunkSizeOf(storage.addition_json));
    },
    async getDirectUploadInfo(storage, relPath) {
      if (!boolValue(additionValue(storage.addition_json, "enable_direct_upload", "EnableDirectUpload"), false)) {
        throw new Error("direct upload is not implemented for this storage");
      }
      const uploadUrl = await createUploadSession(client, storage, relPath, {
        "@microsoft.graph.conflictBehavior": "rename"
      });
      return {
        upload_url: uploadUrl,
        uploadUrl,
        chunk_size: chunkSizeOf(storage.addition_json),
        chunkSize: chunkSizeOf(storage.addition_json),
        method: "PUT"
      };
    },
    async details(storage) {
      var _a, _b;
      if (boolValue(additionValue(storage.addition_json, "disable_disk_usage", "DisableDiskUsage"))) {
        throw new Error("storage details are disabled");
      }
      const drive = await requestGraph(client, storage, driveUrl(storage.addition_json), { retry: false });
      const total = Number(((_a = drive == null ? void 0 : drive.quota) == null ? void 0 : _a.total) || 0);
      const used = Number(((_b = drive == null ? void 0 : drive.quota) == null ? void 0 : _b.used) || 0);
      return {
        total_space: total,
        used_space: used,
        free_space: Math.max(0, total - used)
      };
    }
  });
  const trimAddress = (address) => String(address || "").replace(/\/+$/, "");
  const headersFor = (addition) => ({
    Authorization: addition.token || addition.Token || ""
  });
  const checkResp = (payload) => {
    if (payload.code && payload.code !== 200) throw new Error(payload.message || `OpenList code ${payload.code}`);
    return payload.data;
  };
  const login = async (client, storage) => {
    var _a;
    const addition = storage.addition_json;
    if (!addition.username && !addition.Username) return;
    const payload = await remoteJson(
      client,
      `${trimAddress(addition.url || addition.address || addition.Address)}/api/auth/login`,
      {
        body: {
          username: addition.username || addition.Username || "",
          password: addition.password || addition.Password || ""
        },
        method: "POST",
        timeout: Number(addition.timeout || 3e4)
      }
    );
    addition.token = ((_a = payload == null ? void 0 : payload.data) == null ? void 0 : _a.token) || "";
    if (storage.saveDriverStorage) await storage.saveDriverStorage(addition);
  };
  const objFrom = (item, path) => ({
    name: item.name,
    path,
    is_dir: !!item.is_dir,
    size: Number(item.size || 0),
    modified: item.modified || (/* @__PURE__ */ new Date()).toISOString(),
    created: item.created || item.modified || (/* @__PURE__ */ new Date()).toISOString(),
    thumb: item.thumb || "",
    sign: item.sign || "",
    type: item.type || 0,
    hashinfo: item.hashinfo || item.hash_info || ""
  });
  const createOpenListDriver = ({ client }) => {
    const request = async (storage, apiPath, method, body, retry = false) => {
      const addition = storage.addition_json;
      const payload = await remoteJson(
        client,
        `${trimAddress(addition.url || addition.address || addition.Address)}/api${apiPath}`,
        {
          body,
          headers: headersFor(addition),
          method,
          timeout: Number(addition.timeout || 3e4)
        }
      );
      if ((payload.code === 401 || payload.code === 403) && !retry) {
        await login(client, storage);
        return request(storage, apiPath, method, body, true);
      }
      return checkResp(payload);
    };
    return {
      async list(storage, relPath, req) {
        var _a;
        const addition = storage.addition_json;
        const data = await request(storage, "/fs/list", "POST", {
          page: Number(req.page || 1),
          per_page: Number(req.per_page || req.perPage || 0),
          path: relPath,
          password: addition.meta_password || "",
          refresh: !!req.refresh
        });
        return {
          content: (data.content || []).map((item) => objFrom(item, normalizePath(relPath + "/" + item.name))),
          total: Number(data.total || ((_a = data.content) == null ? void 0 : _a.length) || 0),
          readme: data.readme || "",
          header: data.header || "",
          write: data.write !== false,
          provider: "OpenList",
          direct_upload_tools: []
        };
      },
      async get(storage, relPath) {
        const addition = storage.addition_json;
        const data = await request(storage, "/fs/get", "POST", {
          path: relPath,
          password: addition.meta_password || ""
        });
        return {
          ...objFrom(data, relPath),
          raw_url: data.raw_url || "",
          readme: data.readme || "",
          header: data.header || "",
          provider: "OpenList",
          related: data.related || []
        };
      },
      async mkdir(storage, relPath) {
        await request(storage, "/fs/mkdir", "POST", { path: relPath });
      },
      async move(storage, relPath, dstRelPath) {
        await request(storage, "/fs/move", "POST", {
          src_dir: dirname(relPath),
          dst_dir: normalizePath(dstRelPath),
          names: [basename(relPath)]
        });
      },
      async copy(storage, relPath, dstRelPath) {
        await request(storage, "/fs/copy", "POST", {
          src_dir: dirname(relPath),
          dst_dir: normalizePath(dstRelPath),
          names: [basename(relPath)]
        });
      },
      async remove(storage, relPath) {
        await request(storage, "/fs/remove", "POST", {
          dir: dirname(relPath),
          names: [relPath.split("/").filter(Boolean).pop()]
        });
      },
      async rename(storage, relPath, newName) {
        await request(storage, "/fs/rename", "POST", { path: relPath, name: newName });
      },
      async put(storage, relPath, content, mime, options = {}) {
        const addition = storage.addition_json;
        const response = await forwardProxy(
          client,
          `${trimAddress(addition.url || addition.address || addition.Address)}/api/fs/put`,
          {
            allowErrorStatus: true,
            body: content || "",
            contentType: mime || "application/octet-stream",
            headers: {
              Authorization: addition.token || addition.Token || "",
              "File-Path": relPath,
              Password: addition.meta_password || ""
            },
            method: "PUT",
            payloadEncoding: options.bodyEncoding === "base64" ? "base64" : void 0,
            responseEncoding: "text",
            timeout: Number(addition.timeout || 3e4)
          }
        );
        const payload = JSON.parse(response.body || "{}");
        checkResp(payload);
      }
    };
  };
  const API = "https://open-api-drive.quark.cn";
  const UA = "go-resty/3.0.0-beta.1 (https://resty.dev)";
  const cache$2 = createStorageCache();
  const randomHex = () => Math.floor(Math.random() * 4294967295).toString(16).padStart(8, "0");
  const reqId = () => `${randomHex()}-${randomHex().slice(0, 4)}-${randomHex().slice(0, 4)}-${randomHex().slice(0, 4)}-${randomHex()}${randomHex().slice(0, 4)}`;
  const checkQuarkOpen = (payload) => {
    if (Number((payload == null ? void 0 : payload.status) || 0) >= 400 || Number((payload == null ? void 0 : payload.errno) || 0) !== 0) {
      throw new Error((payload == null ? void 0 : payload.error_info) || (payload == null ? void 0 : payload.message) || "quark open request failed");
    }
    return payload;
  };
  const generateReqSign$1 = (method, pathname, signKey) => {
    const timestamp2 = String(Date.now());
    return {
      req_id: reqId(),
      tm: timestamp2,
      token: sha256Hex(`${method.toUpperCase()}&${pathname}&${timestamp2}&${signKey || ""}`)
    };
  };
  const refreshTokenOnline = async (client, storage) => {
    const addition = storage.addition_json;
    if (!boolValue$2(addition.use_online_api, true)) {
      throw new Error("local refresh token logic is not implemented yet, please use online API or contact the developer");
    }
    const target = new URL(addition.api_url_address || "https://api.oplist.org/quarkyun/renewapi");
    target.searchParams.set("refresh_ui", addition.refresh_token || "");
    target.searchParams.set("server_use", "true");
    target.searchParams.set("driver_txt", "quarkyun_oa");
    const resp = await remoteJson(client, target.toString(), { method: "GET" });
    if (!(resp == null ? void 0 : resp.refresh_token) || !(resp == null ? void 0 : resp.access_token)) {
      throw new Error((resp == null ? void 0 : resp.text) || "empty token returned from official API, a wrong refresh token may have been used");
    }
    addition.refresh_token = resp.refresh_token;
    addition.access_token = resp.access_token;
    if (resp.app_id) addition.app_id = resp.app_id;
    if (resp.sign_key) addition.sign_key = resp.sign_key;
    await persistAddition$1(storage);
  };
  const requestQuarkOpen = async (client, storage, pathname, {
    body,
    manualSign,
    method = "GET",
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    const sign = manualSign || generateReqSign$1(method, pathname, addition.sign_key);
    const target = new URL(`${API}${pathname}`);
    target.searchParams.set("req_id", sign.req_id);
    target.searchParams.set("access_token", addition.access_token || "");
    const resp = await remoteJson(client, target.toString(), {
      allowErrorStatus: true,
      body,
      headers: {
        Accept: "application/json, text/plain, */*",
        "User-Agent": UA,
        "x-pan-client-id": addition.app_id || "",
        "x-pan-tm": sign.tm,
        "x-pan-token": sign.token
      },
      method
    });
    const tokenExpired = Number((resp == null ? void 0 : resp.status) || 0) === -1 && (Number((resp == null ? void 0 : resp.errno) || 0) === 11001 || Number((resp == null ? void 0 : resp.errno) || 0) === 14001 && String((resp == null ? void 0 : resp.error_info) || "").includes("access_token"));
    if (tokenExpired && retry) {
      await refreshTokenOnline(client, storage);
      return requestQuarkOpen(client, storage, pathname, { body, method, retry: false });
    }
    return checkQuarkOpen(resp);
  };
  const base64ToBytes$2 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars2.indexOf(clean[i]);
      const b = chars2.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars2.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars2.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$1 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i = 0; i < bytes2.length; i += 3) {
      const a = bytes2[i];
      const b = bytes2[i + 1];
      const c = bytes2[i + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$1 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const uploadBytes$1 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$2(content || "") : utf8Bytes$1(content || "");
  const hex$2 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const rol$1 = (value, bits) => value << bits | value >>> 32 - bits;
  const sha1Bytes$1 = (message) => {
    const msg = message instanceof Uint8Array ? message : utf8Bytes$1(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4);
      for (let i = 16; i < 80; i += 1) w[i] = rol$1(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i = 0; i < 80; i += 1) {
        let f;
        let k;
        if (i < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$1(a, 5) + f + e + k + w[i] >>> 0;
        e = d;
        d = c;
        c = rol$1(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const sha1Hex$1 = (message) => hex$2(sha1Bytes$1(message));
  const leftRotate$1 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$1 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$1(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i = 0; i < 64; i += 1) {
        let f;
        let g;
        if (i < 16) {
          f = b & c | ~b & d;
          g = i;
        } else if (i < 32) {
          f = d & b | ~d & c;
          g = (5 * i + 1) % 16;
        } else if (i < 48) {
          f = b ^ c ^ d;
          g = (3 * i + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate$1(a + f + k[i] + view.getUint32(offset + g * 4, true) >>> 0, s[i]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const proofCode = (seed, bytes2) => {
    if (!bytes2.length) return "";
    const start = Number(BigInt(`0x${md5Hex$1(seed).slice(0, 16)}`) % BigInt(bytes2.length));
    return bytesToBase64$1(bytes2.slice(start, Math.min(start + 8, bytes2.length)));
  };
  const partInfoList = (size, partSize) => {
    const parts = [];
    for (let left = size, part = 1; left > 0; part += 1) {
      const current = Math.min(partSize, left);
      parts.push({ part_number: part, part_size: current });
      left -= current;
    }
    return parts;
  };
  const timeFromMs$2 = (value) => parseTime$1(Number(value || 0));
  const fileNameOf$1 = (file) => file.filename || file.file_name || file.name || "";
  const isDir$1 = (file) => String(file.file_type) === "0";
  const fileToObj$2 = (file, relPath) => {
    const dir = isDir$1(file);
    return {
      name: fileNameOf$1(file) || basenameOf(relPath),
      is_dir: dir,
      size: Number(file.size || 0),
      modified: timeFromMs$2(file.updated_at),
      created: timeFromMs$2(file.created_at),
      sign: "",
      thumb: file.thumbnail_url || "",
      type: dir ? 1 : 0,
      hashinfo: file.content_hash || "",
      hash_info: file.content_hash ? { sha1: file.content_hash } : {},
      id: file.fid || "",
      file
    };
  };
  const listByParent$2 = async (client, storage, parentId) => {
    const cacheKey2 = parentId || storage.addition_json.root_folder_id || "0";
    return cache$2.list(storage, cacheKey2, async () => {
      const addition = storage.addition_json;
      const result = [];
      let queryCursor = null;
      for (; ; ) {
        const reqBody = {
          parent_fid: parentId || addition.root_folder_id || "0",
          size: 100,
          sort: "file_name:asc"
        };
        if ((addition.order_by || "none") !== "none") {
          reqBody.sort = `${addition.order_by}:${addition.order_direction || "asc"}`;
        }
        if (queryCursor == null ? void 0 : queryCursor.token) reqBody.query_cursor = queryCursor;
        const resp = await requestQuarkOpen(client, storage, "/open/v1/file/list", {
          body: reqBody,
          method: "POST"
        });
        const data = (resp == null ? void 0 : resp.data) || {};
        result.push(...data.file_list || []);
        if (data.last_page) break;
        queryCursor = data.next_query_cursor || null;
        if (!(queryCursor == null ? void 0 : queryCursor.token)) break;
      }
      return result;
    });
  };
  const resolveFile$2 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    return cache$2.file(storage, clean, async () => {
      const rootId2 = storage.addition_json.root_folder_id || storage.addition_json.RootFolderID || "0";
      if (clean === "/") {
        return {
          fid: rootId2,
          filename: "root",
          file_type: "0",
          path: "/"
        };
      }
      let parentId = rootId2;
      let current = null;
      for (const part of clean.split("/").filter(Boolean)) {
        const files = await listByParent$2(client, storage, parentId);
        current = files.find((item) => fileNameOf$1(item) === part);
        if (!current) throw new Error(`object not found: ${clean}`);
        parentId = current.fid;
      }
      return current;
    });
  };
  const downloadLink$2 = async (client, storage, file) => {
    return cache$2.link(storage, file.fid || "", async () => {
      var _a;
      const resp = await requestQuarkOpen(client, storage, "/open/v1/file/get_download_url", {
        body: { fid: file.fid },
        method: "POST"
      });
      const url = ((_a = resp == null ? void 0 : resp.data) == null ? void 0 : _a.download_url) || "";
      if (!url) throw new Error("get download url failed");
      return {
        header: {
          Cookie: `x_pan_client_id=${storage.addition_json.app_id || ""}; x_pan_access_token=${storage.addition_json.access_token || ""}`
        },
        url,
        content_length: Number(file.size || 0)
      };
    });
  };
  const manageFile$1 = async (client, storage, pathname, body) => {
    await requestQuarkOpen(client, storage, pathname, { body, method: "POST" });
    cache$2.clear(storage);
  };
  const createQuarkOpenDriver = ({ client }) => ({
    async test(storage) {
      const resp = await requestQuarkOpen(client, storage, "/open/v1/user/info", { method: "GET" });
      return { user: (resp == null ? void 0 : resp.data) || {}, addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$2(client, storage, relPath);
      const content = (await listByParent$2(client, storage, parent.fid)).map((file) => fileToObj$2(file, normalizePath(relPath + "/" + fileNameOf$1(file))));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: storage.driver || "QuarkOpen",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$2(client, storage, relPath);
      const obj = fileToObj$2(file, relPath);
      if (!obj.is_dir && !options.skipLink) {
        const link = await downloadLink$2(client, storage, file);
        obj.raw_url = link.url;
        obj.url = link.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$2(client, storage, relPath);
      if (isDir$1(file)) throw new Error("not file");
      const link = await downloadLink$2(client, storage, file);
      return {
        link: {
          url: link.url,
          header: { ...link.header, ...options.proxyHeaders || options.headers || {} },
          content_length: link.content_length,
          concurrency: 3,
          part_size: 10 * 1024 * 1024
        }
      };
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$2(client, storage, dirnameOf(relPath));
      await manageFile$1(client, storage, "/open/v1/dir", {
        dir_path: basenameOf(relPath),
        pdir_fid: parent.fid
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$2(client, storage, relPath);
      const dst = await resolveFile$2(client, storage, dstRelPath);
      await manageFile$1(client, storage, "/open/v1/file/move", {
        action_type: 1,
        fid_list: [file.fid],
        to_pdir_fid: dst.fid
      });
    },
    async remove(storage, relPath) {
      const file = await resolveFile$2(client, storage, relPath);
      await manageFile$1(client, storage, "/open/v1/file/delete", {
        action_type: 1,
        fid_list: [file.fid]
      });
    },
    async rename(storage, relPath, newName) {
      const file = await resolveFile$2(client, storage, relPath);
      await manageFile$1(client, storage, "/open/v1/file/rename", {
        conflict_mode: "REUSE",
        fid: file.fid,
        file_name: newName
      });
    },
    async copy() {
      throw new Error("QuarkOpen copy is not supported by the OpenList driver");
    },
    async put(storage, relPath, content, mime, options = {}) {
      var _a, _b, _c, _d, _e, _f, _g;
      const parent = await resolveFile$2(client, storage, dirnameOf(relPath));
      const bytes2 = uploadBytes$1(content, options);
      const prePath = "/open/v1/file/upload_pre";
      const preSign = generateReqSign$1("POST", prePath, storage.addition_json.sign_key);
      const proofSeed1 = md5Hex$1(`${storage.addition_json.user_id || ""}${preSign.token}`);
      const proofSeed2 = md5Hex$1(String(bytes2.length));
      const pre = await requestQuarkOpen(client, storage, prePath, {
        body: {
          file_name: basenameOf(relPath),
          size: bytes2.length,
          format_type: mime || "application/octet-stream",
          md5: md5Hex$1(bytes2),
          sha1: sha1Hex$1(bytes2),
          l_created_at: Date.now(),
          l_updated_at: Date.now(),
          pdir_fid: parent.fid,
          same_path_reuse: true,
          proof_version: "v1",
          proof_seed1: proofSeed1,
          proof_seed2: proofSeed2,
          proof_code1: proofCode(proofSeed1, bytes2),
          proof_code2: proofCode(proofSeed2, bytes2)
        },
        manualSign: preSign,
        method: "POST"
      });
      const preData = (pre == null ? void 0 : pre.data) || {};
      if (preData.finish) {
        cache$2.clear(storage);
        return;
      }
      const partSize = Number(preData.part_size || bytes2.length || 1);
      const parts = partInfoList(bytes2.length, partSize);
      const uploadInfo = await requestQuarkOpen(client, storage, "/open/v1/file/get_upload_urls", {
        body: {
          task_id: preData.task_id,
          part_info_list: parts
        },
        method: "POST"
      });
      const uploadData = (uploadInfo == null ? void 0 : uploadInfo.data) || {};
      const etags = [];
      for (let index = 0; index < (uploadData.upload_urls || []).length; index += 1) {
        const part = parts[index];
        const start = (part.part_number - 1) * partSize;
        const chunk = bytes2.slice(start, Math.min(start + part.part_size, bytes2.length));
        const uploadUrl = uploadData.upload_urls[index];
        const resp = await forwardProxy(client, uploadUrl.upload_url, {
          allowErrorStatus: true,
          body: bytesToBase64$1(chunk),
          contentType: "application/octet-stream",
          headers: {
            Authorization: ((_a = uploadUrl.signature_info) == null ? void 0 : _a.signature) || "",
            "X-Oss-Date": ((_b = uploadData.common_headers) == null ? void 0 : _b["X-Oss-Date"]) || "",
            "X-Oss-Content-Sha256": ((_c = uploadData.common_headers) == null ? void 0 : _c["X-Oss-Content-Sha256"]) || "",
            "Accept-Encoding": "gzip",
            "User-Agent": "Go-http-client/1.1"
          },
          method: "PUT",
          payloadEncoding: "base64",
          responseEncoding: "text",
          timeout: 12e4
        });
        if (Number(resp.status || 0) !== 200) throw new Error(`up status: ${resp.status}`);
        etags.push(((_d = resp.headers) == null ? void 0 : _d.Etag) || ((_e = resp.headers) == null ? void 0 : _e.ETag) || ((_f = resp.headers) == null ? void 0 : _f.etag) || "");
      }
      const finishParts = parts.map((part, index) => ({
        part_number: part.part_number,
        part_size: part.part_size,
        etag: etags[index]
      }));
      const finish = await requestQuarkOpen(client, storage, "/open/v1/file/upload_finish", {
        body: {
          task_id: preData.task_id,
          part_info_list: finishParts
        },
        method: "POST"
      });
      if (((_g = finish == null ? void 0 : finish.data) == null ? void 0 : _g.finish) !== true) throw new Error(`upload finish failed, task_id: ${preData.task_id}`);
      cache$2.clear(storage);
    }
  });
  const configs$1 = {
    Quark: {
      api: "https://drive.quark.cn/1/clouddrive",
      pr: "ucpro",
      referer: "https://pan.quark.cn",
      ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) quark-cloud-drive/2.5.20 Chrome/100.0.4896.160 Electron/18.3.5.4-b478491100 Safari/537.36 Channel/pckk_other_ch"
    },
    UC: {
      api: "https://pc-api.uc.cn/1/clouddrive",
      pr: "UCBrowser",
      referer: "https://drive.uc.cn",
      ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) uc-cloud-drive/2.5.20 Chrome/100.0.4896.160 Electron/18.3.5.4-b478491100 Safari/537.36 Channel/pckk_other_ch"
    }
  };
  const checkQuark = (payload) => {
    if (Number((payload == null ? void 0 : payload.status) || 0) >= 400 || Number((payload == null ? void 0 : payload.code) || 0) !== 0) {
      throw new Error((payload == null ? void 0 : payload.message) || "quark request failed");
    }
    return payload;
  };
  const cookieHeader = (addition) => addition.cookie || addition.Cookie || "";
  const confFor$1 = (storage) => configs$1[storage.driver] || configs$1.Quark;
  const cache$1 = createStorageCache();
  const requestQuark = async (client, storage, pathname, {
    body,
    method = "GET",
    query = {},
    userAgent
  } = {}) => {
    const conf = confFor$1(storage);
    const target = new URL(`${conf.api}${pathname}`);
    target.searchParams.set("pr", conf.pr);
    target.searchParams.set("fr", "pc");
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const resp = await remoteJson(client, target.toString(), {
      allowErrorStatus: true,
      body,
      headers: {
        Accept: "application/json, text/plain, */*",
        Cookie: cookieHeader(storage.addition_json),
        Referer: conf.referer,
        "User-Agent": userAgent || conf.ua
      },
      method
    });
    return checkQuark(resp);
  };
  const base64ToBytes$1 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars2.indexOf(clean[i]);
      const b = chars2.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars2.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars2.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i = 0; i < bytes2.length; i += 3) {
      const a = bytes2[i];
      const b = bytes2[i + 1];
      const c = bytes2[i + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const uploadBytes = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$1(content || "") : utf8Bytes(content || "");
  const hex$1 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const hexToBytes = (value) => {
    const clean = String(value || "");
    const out = new Uint8Array(clean.length / 2);
    for (let i = 0; i < out.length; i += 1) out[i] = Number.parseInt(clean.slice(i * 2, i * 2 + 2), 16);
    return out;
  };
  const rol = (value, bits) => value << bits | value >>> 32 - bits;
  const sha1Bytes = (message) => {
    const msg = message instanceof Uint8Array ? message : utf8Bytes(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4);
      for (let i = 16; i < 80; i += 1) w[i] = rol(w[i - 3] ^ w[i - 8] ^ w[i - 14] ^ w[i - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i = 0; i < 80; i += 1) {
        let f;
        let k;
        if (i < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol(a, 5) + f + e + k + w[i] >>> 0;
        e = d;
        d = c;
        c = rol(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const sha1Hex = (message) => hex$1(sha1Bytes(message));
  const leftRotate = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i) => Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i = 0; i < 64; i += 1) {
        let f;
        let g;
        if (i < 16) {
          f = b & c | ~b & d;
          g = i;
        } else if (i < 32) {
          f = d & b | ~d & c;
          g = (5 * i + 1) % 16;
        } else if (i < 48) {
          f = b ^ c ^ d;
          g = (3 * i + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate(a + f + k[i] + view.getUint32(offset + g * 4, true) >>> 0, s[i]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const httpTime = () => (/* @__PURE__ */ new Date()).toUTCString();
  const OSS_USER_AGENT = "aliyun-sdk-js/6.6.1 Chrome 98.0.4758.80 on Windows 10 64-bit";
  const timeFromMs$1 = (value) => parseTime$1(Number(value || 0));
  const fileToObj$1 = (file, relPath) => {
    const isDir2 = !file.file;
    return {
      name: file.file_name || basenameOf(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: timeFromMs$1(file.updated_at || file.l_updated_at),
      created: timeFromMs$1(file.created_at || file.l_created_at),
      sign: "",
      thumb: file.thumbnail || "",
      type: isDir2 ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: file.fid || "",
      file
    };
  };
  const listByParent$1 = async (client, storage, parentId) => {
    const cacheKey2 = parentId || storage.addition_json.root_folder_id || "0";
    return cache$1.list(storage, cacheKey2, async () => {
      var _a, _b;
      const addition = storage.addition_json;
      const result = [];
      const size = 100;
      let page = 1;
      for (; ; ) {
        const query = {
          pdir_fid: parentId || addition.root_folder_id || "0",
          _size: size,
          _fetch_total: "1",
          fetch_all_file: "1",
          fetch_risk_file_name: "1",
          _page: page
        };
        if ((addition.order_by || "none") !== "none") {
          query._sort = `file_type:asc,${addition.order_by}:${addition.order_direction || "asc"}`;
        }
        const resp = await requestQuark(client, storage, "/file/sort", { method: "GET", query });
        const list = ((_a = resp == null ? void 0 : resp.data) == null ? void 0 : _a.list) || [];
        for (const file of list) {
          if (!boolValue$2(addition.only_list_video_file) || !file.file || Number(file.category || 0) === 1) {
            result.push({ ...file, file_name: decodeHtml(file.file_name || "") });
          }
        }
        if (page * size >= Number(((_b = resp == null ? void 0 : resp.metadata) == null ? void 0 : _b._total) || list.length)) break;
        page += 1;
      }
      return result;
    });
  };
  const decodeHtml = (value) => String(value || "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  const resolveFile$1 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    return cache$1.file(storage, clean, async () => {
      const rootId2 = storage.addition_json.root_folder_id || storage.addition_json.RootFolderID || "0";
      if (clean === "/") {
        return {
          fid: rootId2,
          file_name: "root",
          file: false,
          path: "/"
        };
      }
      let parentId = rootId2;
      let current = null;
      for (const part of clean.split("/").filter(Boolean)) {
        const files = await listByParent$1(client, storage, parentId);
        current = files.find((item) => item.file_name === part);
        if (!current) throw new Error(`object not found: ${clean}`);
        parentId = current.fid;
      }
      return current;
    });
  };
  const downloadLink$1 = async (client, storage, file) => {
    return cache$1.link(storage, `${storage.driver || "Quark"}:${file.fid}:${boolValue$2(storage.addition_json.use_transcoding_address)}`, async () => {
      var _a, _b, _c, _d;
      const conf = confFor$1(storage);
      if (boolValue$2(storage.addition_json.use_transcoding_address) && storage.driver === "Quark" && Number(file.category || 0) === 1 && Number(file.size || 0) > 0) {
        const resp2 = await requestQuark(client, storage, "/file/v2/play/project", {
          body: {
            fid: file.fid,
            resolutions: "low,normal,high,super,2k,4k",
            supports: "fmp4_av,m3u8,dolby_vision"
          },
          method: "POST",
          userAgent: conf.ua
        });
        for (const info of ((_a = resp2 == null ? void 0 : resp2.data) == null ? void 0 : _a.video_list) || []) {
          if ((_b = info == null ? void 0 : info.video_info) == null ? void 0 : _b.url) {
            return {
              header: {},
              url: info.video_info.url,
              content_length: Number(info.video_info.size || file.size || 0)
            };
          }
        }
        throw new Error("no link found");
      }
      const resp = await requestQuark(client, storage, "/file/download", {
        body: { fids: [file.fid] },
        method: "POST",
        userAgent: conf.ua
      });
      const url = ((_d = (_c = resp == null ? void 0 : resp.data) == null ? void 0 : _c[0]) == null ? void 0 : _d.download_url) || "";
      if (!url) throw new Error("get download url failed");
      return {
        header: {
          Cookie: cookieHeader(storage.addition_json),
          Referer: conf.referer,
          "User-Agent": conf.ua
        },
        url,
        content_length: Number(file.size || 0)
      };
    });
  };
  const manageFile = async (client, storage, pathname, body) => {
    await requestQuark(client, storage, pathname, { body, method: "POST" });
    cache$1.clear(storage);
  };
  const uploadHost = (preData) => `https://${preData.bucket}.${String(preData.upload_url || "").slice(7)}/${preData.obj_key}`;
  const upPre = async (client, storage, relPath, parentId, bytes2, mime) => {
    const now = Date.now();
    return requestQuark(client, storage, "/file/upload/pre", {
      body: {
        ccp_hash_update: true,
        dir_name: "",
        file_name: basenameOf(relPath),
        format_type: mime,
        l_created_at: now,
        l_updated_at: now,
        pdir_fid: parentId,
        size: bytes2.length
      },
      method: "POST"
    });
  };
  const upHash = async (client, storage, md5, sha1, taskId) => {
    var _a;
    const resp = await requestQuark(client, storage, "/file/update/hash", {
      body: {
        md5,
        sha1,
        task_id: taskId
      },
      method: "POST"
    });
    return Boolean((_a = resp == null ? void 0 : resp.data) == null ? void 0 : _a.finish);
  };
  const upPart = async (client, storage, pre, mime, partNumber, bytes2) => {
    var _a, _b, _c, _d;
    const data = (pre == null ? void 0 : pre.data) || {};
    const timeStr = httpTime();
    const auth = await requestQuark(client, storage, "/file/upload/auth", {
      body: {
        auth_info: data.auth_info,
        auth_meta: `PUT

${mime}
${timeStr}
x-oss-date:${timeStr}
x-oss-user-agent:${OSS_USER_AGENT}
/${data.bucket}/${data.obj_key}?partNumber=${partNumber}&uploadId=${data.upload_id}`,
        task_id: data.task_id
      },
      method: "POST"
    });
    const target = new URL(uploadHost(data));
    target.searchParams.set("partNumber", String(partNumber));
    target.searchParams.set("uploadId", data.upload_id);
    const resp = await forwardProxy(client, target.toString(), {
      allowErrorStatus: true,
      body: bytesToBase64(bytes2),
      contentType: mime,
      headers: {
        Authorization: ((_a = auth == null ? void 0 : auth.data) == null ? void 0 : _a.auth_key) || "",
        "Content-Type": mime,
        Referer: "https://pan.quark.cn/",
        "x-oss-date": timeStr,
        "x-oss-user-agent": OSS_USER_AGENT
      },
      method: "PUT",
      payloadEncoding: "base64",
      responseEncoding: "text",
      timeout: 12e4
    });
    if (Number(resp.status || 0) !== 200) throw new Error(`up status: ${resp.status}, error: ${resp.body || ""}`);
    return ((_b = resp.headers) == null ? void 0 : _b.Etag) || ((_c = resp.headers) == null ? void 0 : _c.ETag) || ((_d = resp.headers) == null ? void 0 : _d.etag) || "";
  };
  const upCommit = async (client, storage, pre, etags) => {
    var _a;
    const data = (pre == null ? void 0 : pre.data) || {};
    const timeStr = httpTime();
    const body = `<?xml version="1.0" encoding="UTF-8"?>
<CompleteMultipartUpload>
${etags.map((etag, index) => `<Part>
<PartNumber>${index + 1}</PartNumber>
<ETag>${etag}</ETag>
</Part>
`).join("")}</CompleteMultipartUpload>`;
    const contentMd5 = bytesToBase64(hexToBytes(md5Hex(body)));
    const callbackBase64 = bytesToBase64(utf8Bytes(JSON.stringify(data.callback || {})));
    const auth = await requestQuark(client, storage, "/file/upload/auth", {
      body: {
        auth_info: data.auth_info,
        auth_meta: `POST
${contentMd5}
application/xml
${timeStr}
x-oss-callback:${callbackBase64}
x-oss-date:${timeStr}
x-oss-user-agent:${OSS_USER_AGENT}
/${data.bucket}/${data.obj_key}?uploadId=${data.upload_id}`,
        task_id: data.task_id
      },
      method: "POST"
    });
    const target = new URL(uploadHost(data));
    target.searchParams.set("uploadId", data.upload_id);
    const resp = await forwardProxy(client, target.toString(), {
      allowErrorStatus: true,
      body,
      contentType: "application/xml",
      headers: {
        Authorization: ((_a = auth == null ? void 0 : auth.data) == null ? void 0 : _a.auth_key) || "",
        "Content-MD5": contentMd5,
        "Content-Type": "application/xml",
        Referer: "https://pan.quark.cn/",
        "x-oss-callback": callbackBase64,
        "x-oss-date": timeStr,
        "x-oss-user-agent": OSS_USER_AGENT
      },
      method: "POST",
      responseEncoding: "text",
      timeout: 12e4
    });
    if (Number(resp.status || 0) !== 200) throw new Error(`up status: ${resp.status}, error: ${resp.body || ""}`);
  };
  const upFinish = async (client, storage, pre) => {
    const data = (pre == null ? void 0 : pre.data) || {};
    await requestQuark(client, storage, "/file/upload/finish", {
      body: {
        obj_key: data.obj_key,
        task_id: data.task_id
      },
      method: "POST"
    });
    cache$1.clear(storage);
  };
  const createQuarkDriver = ({ client }) => ({
    async test(storage) {
      await requestQuark(client, storage, "/config");
      if (storage.addition_json.AdditionVersion !== 2 && storage.addition_json.addition_version !== 2) {
        storage.addition_json.addition_version = 2;
        await persistAddition$1(storage);
      }
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$1(client, storage, relPath);
      const content = (await listByParent$1(client, storage, parent.fid)).map((file) => fileToObj$1(file, normalizePath(relPath + "/" + file.file_name)));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: storage.driver || "Quark",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$1(client, storage, relPath);
      const obj = fileToObj$1(file, relPath);
      if (!obj.is_dir && !options.skipLink) {
        const link = await downloadLink$1(client, storage, file);
        obj.raw_url = link.url;
        obj.url = link.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$1(client, storage, relPath);
      if (!file.file) throw new Error("not file");
      const link = await downloadLink$1(client, storage, file);
      const header = { ...link.header, ...options.proxyHeaders || options.headers || {} };
      return {
        link: {
          url: link.url,
          header,
          content_length: link.content_length,
          concurrency: 3,
          part_size: 10 * 1024 * 1024
        }
      };
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$1(client, storage, dirnameOf(relPath));
      await manageFile(client, storage, "/file", {
        dir_init_lock: false,
        dir_path: "",
        file_name: basenameOf(relPath),
        pdir_fid: parent.fid
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$1(client, storage, relPath);
      const dst = await resolveFile$1(client, storage, dstRelPath);
      await manageFile(client, storage, "/file/move", {
        action_type: 1,
        exclude_fids: [],
        filelist: [file.fid],
        to_pdir_fid: dst.fid
      });
    },
    async remove(storage, relPath) {
      const file = await resolveFile$1(client, storage, relPath);
      await manageFile(client, storage, "/file/delete", {
        action_type: 1,
        exclude_fids: [],
        filelist: [file.fid]
      });
    },
    async rename(storage, relPath, newName) {
      const file = await resolveFile$1(client, storage, relPath);
      await manageFile(client, storage, "/file/rename", {
        fid: file.fid,
        file_name: newName
      });
    },
    async copy() {
      throw new Error("Quark copy is not supported by the OpenList driver");
    },
    async put(storage, relPath, content, mime, options = {}) {
      var _a, _b;
      const parent = await resolveFile$1(client, storage, dirnameOf(relPath));
      const bytes2 = uploadBytes(content, options);
      const uploadMime = mime || "application/octet-stream";
      const pre = await upPre(client, storage, relPath, parent.fid, bytes2, uploadMime);
      if (await upHash(client, storage, md5Hex(bytes2), sha1Hex(bytes2), ((_a = pre == null ? void 0 : pre.data) == null ? void 0 : _a.task_id) || "")) {
        cache$1.clear(storage);
        return;
      }
      const partSize = Number(((_b = pre == null ? void 0 : pre.metadata) == null ? void 0 : _b.part_size) || bytes2.length || 1);
      const etags = [];
      for (let offset = 0, partNumber = 1; offset < bytes2.length; offset += partSize, partNumber += 1) {
        const chunk = bytes2.slice(offset, Math.min(offset + partSize, bytes2.length));
        const etag = await upPart(client, storage, pre, uploadMime, partNumber, chunk);
        if (etag === "finish") {
          cache$1.clear(storage);
          return;
        }
        etags.push(etag);
      }
      await upCommit(client, storage, pre, etags);
      await upFinish(client, storage, pre);
    }
  });
  const UserAgent = "Mozilla/5.0 (Linux; U; Android 13; zh-cn; M2004J7AC Build/UKQ1.231108.001) AppleWebKit/533.1 (KHTML, like Gecko) Mobile Safari/533.1";
  const DeviceBrand = "Xiaomi";
  const Platform = "tv";
  const DeviceName = "M2004J7AC";
  const DeviceModel = "M2004J7AC";
  const BuildDevice = "M2004J7AC";
  const BuildProduct = "M2004J7AC";
  const DeviceGpu = "Adreno (TM) 550";
  const ActivityRect = "{}";
  const accessTokenCache = /* @__PURE__ */ new Map();
  const cache = createStorageCache();
  const configs = {
    QuarkTV: {
      api: "https://open-api-drive.quark.cn",
      clientID: "d3194e61504e493eb6222857bccfed94",
      signKey: "kw2dvtd7p4t3pjl2d9ed9yc8yej8kw2d",
      appVer: "1.8.2.2",
      channel: "GENERAL",
      codeApi: "http://api.extscreen.com/quarkdrive"
    },
    UCTV: {
      api: "https://open-api-drive.uc.cn",
      clientID: "5acf882d27b74502b7040b0c65519aa7",
      signKey: "l3srvtd7p42l0d0x1u8d7yc8ye9kki4d",
      appVer: "1.7.2.2",
      channel: "UCTVOFFICIALWEB",
      codeApi: "http://api.extscreen.com/ucdrive"
    }
  };
  const confFor = (storage) => configs[storage.driver] || configs.QuarkTV;
  const storageKey = (storage) => `${storage.driver || "QuarkTV"}:${storage.id || storage.mount_path || ""}`;
  const accessTokenFor = (storage) => accessTokenCache.get(storageKey(storage)) || storage.addition_json.access_token || "";
  const checkQuarkTV = (payload) => {
    if (Number((payload == null ? void 0 : payload.status) || 0) >= 400 || Number((payload == null ? void 0 : payload.errno) || 0) !== 0) {
      throw new Error((payload == null ? void 0 : payload.error_info) || (payload == null ? void 0 : payload.message) || "quark tv request failed");
    }
    return payload;
  };
  const ensureDeviceID = async (storage) => {
    if (!storage.addition_json.device_id) {
      storage.addition_json.device_id = sha256Hex(String(Date.now())).slice(0, 32);
      await persistAddition$1(storage);
    }
    return storage.addition_json.device_id;
  };
  const generateReqSign = async (storage, method, pathname, signKey) => {
    const timestamp2 = String(Date.now());
    const deviceID = await ensureDeviceID(storage);
    return {
      req_id: sha256Hex(`${deviceID}${timestamp2}`).slice(0, 32),
      tm: timestamp2,
      token: sha256Hex(`${method.toUpperCase()}&${pathname}&${timestamp2}&${signKey || ""}`)
    };
  };
  const commonQuery = (storage, conf, sign) => ({
    req_id: sign.req_id,
    access_token: accessTokenFor(storage),
    app_ver: conf.appVer,
    device_id: storage.addition_json.device_id || "",
    device_brand: DeviceBrand,
    platform: Platform,
    device_name: DeviceName,
    device_model: DeviceModel,
    build_device: BuildDevice,
    build_product: BuildProduct,
    device_gpu: DeviceGpu,
    activity_rect: ActivityRect,
    channel: conf.channel
  });
  const refreshTokenByTV = async (client, storage, code, isRefresh) => {
    const conf = confFor(storage);
    const sign = await generateReqSign(storage, "POST", "/token", conf.signKey);
    const body = {
      ...commonQuery(storage, conf, sign)
    };
    delete body.access_token;
    if (isRefresh) body.refresh_token = code;
    else body.code = code;
    const resp = await remoteJson(client, `${conf.codeApi}/token`, {
      body,
      headers: { "Content-Type": "application/json" },
      method: "POST"
    });
    if (Number((resp == null ? void 0 : resp.code) || 0) !== 200) throw new Error((resp == null ? void 0 : resp.message) || "refresh token failed");
    const data = (resp == null ? void 0 : resp.data) || {};
    if (!data.refresh_token) throw new Error("refresh token is empty");
    storage.addition_json.refresh_token = data.refresh_token;
    accessTokenCache.set(storageKey(storage), data.access_token || "");
    await persistAddition$1(storage);
  };
  const requestQuarkTV = async (client, storage, pathname, {
    method = "GET",
    query = {},
    retry = true
  } = {}) => {
    const conf = confFor(storage);
    const sign = await generateReqSign(storage, method, pathname, conf.signKey);
    const target = new URL(`${conf.api}${pathname}`);
    const mergedQuery = {
      ...commonQuery(storage, conf, sign),
      ...query
    };
    for (const [key, value] of Object.entries(mergedQuery)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const resp = await remoteJson(client, target.toString(), {
      allowErrorStatus: true,
      headers: {
        Accept: "application/json, text/plain, */*",
        "User-Agent": UserAgent,
        "x-pan-client-id": conf.clientID,
        "x-pan-tm": sign.tm,
        "x-pan-token": sign.token
      },
      method
    });
    const errInfo = String((resp == null ? void 0 : resp.error_info) || "").toLowerCase();
    const maybeTokenInvalid = Number((resp == null ? void 0 : resp.status) || 0) === -1 && [10001, 11001].includes(Number((resp == null ? void 0 : resp.errno) || 0)) || errInfo && (errInfo.includes("access token") || errInfo.includes("access_token") || errInfo.includes("token"));
    if (maybeTokenInvalid && retry) {
      await refreshTokenByTV(client, storage, storage.addition_json.refresh_token, true);
      return requestQuarkTV(client, storage, pathname, { method, query, retry: false });
    }
    return checkQuarkTV(resp);
  };
  const getLoginCode = async (client, storage) => {
    const conf = confFor(storage);
    const resp = await requestQuarkTV(client, storage, "/oauth/authorize", {
      method: "GET",
      query: {
        auth_type: "code",
        client_id: conf.clientID,
        scope: "netdisk",
        qrcode: "1",
        qr_width: "460",
        qr_height: "460"
      }
    });
    if (resp == null ? void 0 : resp.query_token) {
      storage.addition_json.query_token = resp.query_token;
      await persistAddition$1(storage);
    }
    return (resp == null ? void 0 : resp.qr_data) || "";
  };
  const getCode = async (client, storage) => {
    const conf = confFor(storage);
    const resp = await requestQuarkTV(client, storage, "/oauth/code", {
      method: "GET",
      query: {
        client_id: conf.clientID,
        scope: "netdisk",
        query_token: storage.addition_json.query_token || ""
      }
    });
    return (resp == null ? void 0 : resp.code) || "";
  };
  const ensureLogin = async (client, storage) => {
    await ensureDeviceID(storage);
    if (!storage.addition_json.refresh_token) {
      if (!storage.addition_json.query_token) {
        const qrData = await getLoginCode(client, storage);
        throw new Error(`need verify: 
<body>
        <img src="data:image/jpeg;base64,${qrData}"/>
    </body>`);
      }
      const code = await getCode(client, storage);
      await refreshTokenByTV(client, storage, code, false);
    }
    if (!accessTokenFor(storage)) {
      await refreshTokenByTV(client, storage, storage.addition_json.refresh_token, true);
    }
    await requestQuarkTV(client, storage, "/user", {
      method: "GET",
      query: { method: "user_info" }
    });
  };
  const timeFromMs = (value) => parseTime$1(Number(value || 0));
  const fileNameOf = (file) => file.filename || file.file_name || file.name || "";
  const isDir = (file) => Number(file.isdir || 0) === 1 || String(file.file_type) === "0";
  const fileToObj = (file, relPath) => {
    const dir = isDir(file);
    return {
      name: fileNameOf(file) || basenameOf(relPath),
      is_dir: dir,
      size: Number(file.size || 0),
      modified: timeFromMs(file.updated_at),
      created: timeFromMs(file.created_at),
      sign: "",
      thumb: file.thumbnail_url || "",
      type: dir ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: file.fid || "",
      file
    };
  };
  const listByParent = async (client, storage, parentId) => {
    const cacheKey2 = parentId || storage.addition_json.root_folder_id || "0";
    return cache.list(storage, cacheKey2, async () => {
      const addition = storage.addition_json;
      const result = [];
      const pageSize2 = 100;
      let pageIndex = 0;
      const desc = (addition.order_direction || "desc") === "asc" ? "0" : "1";
      const orderBy = (addition.order_by || "updated_at") === "file_name" ? "1" : "3";
      for (; ; ) {
        const resp = await requestQuarkTV(client, storage, "/file", {
          method: "GET",
          query: {
            method: "list",
            parent_fid: parentId || addition.root_folder_id || "0",
            order_by: orderBy,
            desc,
            category: "",
            source: "",
            ex_source: "",
            list_all: "0",
            page_size: pageSize2,
            page_index: pageIndex
          }
        });
        const data = (resp == null ? void 0 : resp.data) || {};
        result.push(...data.files || []);
        if (result.length >= Number(data.total_count || result.length) || (data.files || []).length < pageSize2) break;
        pageIndex += 1;
      }
      return result;
    });
  };
  const resolveFile = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    return cache.file(storage, clean, async () => {
      const rootId2 = storage.addition_json.root_folder_id || storage.addition_json.RootFolderID || "0";
      if (clean === "/") {
        return {
          fid: rootId2,
          filename: "root",
          file_type: "0",
          isdir: 1,
          path: "/"
        };
      }
      let parentId = rootId2;
      let current = null;
      for (const part of clean.split("/").filter(Boolean)) {
        const files = await listByParent(client, storage, parentId);
        current = files.find((item) => fileNameOf(item) === part);
        if (!current) throw new Error(`object not found: ${clean}`);
        parentId = current.fid;
      }
      return current;
    });
  };
  const getTranscodingLink = async (client, storage, file) => {
    var _a;
    const resp = await requestQuarkTV(client, storage, "/file", {
      method: "GET",
      query: {
        method: "streaming",
        group_by: "source",
        fid: file.fid,
        resolution: "low,normal,high,super,2k,4k",
        support: "dolby_vision"
      }
    });
    for (const info of ((_a = resp == null ? void 0 : resp.data) == null ? void 0 : _a.video_info) || []) {
      if (info == null ? void 0 : info.url) {
        return {
          header: {},
          url: info.url,
          content_length: Number(info.size || file.size || 0)
        };
      }
    }
    throw new Error("no link found");
  };
  const getDownloadLink = async (client, storage, file) => {
    var _a, _b;
    const resp = await requestQuarkTV(client, storage, "/file", {
      method: "GET",
      query: {
        method: "download",
        group_by: "source",
        fid: file.fid,
        resolution: "low,normal,high,super,2k,4k",
        support: "dolby_vision"
      }
    });
    const url = ((_a = resp == null ? void 0 : resp.data) == null ? void 0 : _a.download_url) || "";
    if (!url) throw new Error("get download url failed");
    return {
      header: {},
      url,
      content_length: Number(((_b = resp == null ? void 0 : resp.data) == null ? void 0 : _b.size) || file.size || 0)
    };
  };
  const downloadLink = async (client, storage, file) => {
    return cache.link(storage, `${file.fid || ""}:${storage.addition_json.link_method || "download"}`, async () => {
      if ((storage.addition_json.link_method || "download") === "streaming" && Number(file.category || 0) === 1 && Number(file.size || 0) > 0) {
        return getTranscodingLink(client, storage, file);
      }
      return getDownloadLink(client, storage, file);
    });
  };
  const createQuarkUCTVDriver = ({ client }) => ({
    async test(storage) {
      await ensureLogin(client, storage);
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      await ensureLogin(client, storage);
      const parent = await resolveFile(client, storage, relPath);
      const content = (await listByParent(client, storage, parent.fid)).map((file) => fileToObj(file, normalizePath(relPath + "/" + fileNameOf(file))));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: false,
        provider: storage.driver || "QuarkTV",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      await ensureLogin(client, storage);
      const file = await resolveFile(client, storage, relPath);
      const obj = fileToObj(file, relPath);
      if (!obj.is_dir && !options.skipLink) {
        const link = await downloadLink(client, storage, file);
        obj.raw_url = link.url;
        obj.url = link.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      await ensureLogin(client, storage);
      const file = await resolveFile(client, storage, relPath);
      if (isDir(file)) throw new Error("not file");
      const link = await downloadLink(client, storage, file);
      return {
        link: {
          url: link.url,
          header: { ...link.header, ...options.proxyHeaders || options.headers || {} },
          content_length: link.content_length,
          concurrency: 3,
          part_size: 10 * 1024 * 1024
        }
      };
    },
    async mkdir() {
      throw new Error("QuarkTV mkdir is not implemented by the OpenList driver");
    },
    async move() {
      throw new Error("QuarkTV move is not implemented by the OpenList driver");
    },
    async remove() {
      throw new Error("QuarkTV remove is not implemented by the OpenList driver");
    },
    async rename() {
      throw new Error("QuarkTV rename is not implemented by the OpenList driver");
    },
    async copy() {
      throw new Error("QuarkTV copy is not implemented by the OpenList driver");
    },
    async put() {
      throw new Error("QuarkTV upload is not implemented by the OpenList driver");
    }
  });
  const tagText$1 = (xml, name) => {
    var _a;
    return ((_a = String(xml || "").match(new RegExp(`<${name}>([\\s\\S]*?)<\\/${name}>`, "i"))) == null ? void 0 : _a[1]) || "";
  };
  const decodeXml = (value) => String(value || "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  const hex = (bytes2) => Array.from(bytes2, (b) => b.toString(16).padStart(2, "0")).join("");
  const keyFor = (path, dir = false) => {
    const key = normalizePath(path).replace(/^\/+/, "");
    return key && dir ? `${key}/` : key;
  };
  const base64ToBytes = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const bytes2 = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars2.indexOf(clean[i]);
      const b = chars2.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars2.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars2.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      bytes2.push(a << 2 | b >> 4);
      if (c >= 0) bytes2.push((b & 15) << 4 | c >> 2);
      if (d >= 0) bytes2.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(bytes2);
  };
  const s3Url = (addition, key = "", query = "") => {
    const endpoint = String(addition.endpoint || "").replace(/\/+$/, "");
    const bucket = addition.bucket;
    const forcePathStyle = addition.force_path_style !== false;
    const path = forcePathStyle ? normalizePath(`/${bucket}/${key}`) : normalizePath(`/${key}`);
    const base = forcePathStyle ? endpoint : endpoint.replace("://", `://${bucket}.`);
    return `${joinUrl(base, path)}${query ? `?${query}` : ""}`;
  };
  const directUploadUrl = (addition, key = "") => {
    const url = new URL(s3Url(addition, key));
    const directHost = addition.direct_upload_host || addition.DirectUploadHost || "";
    if (directHost) {
      const split = String(directHost).split("://");
      if (split.length === 2 && ["http", "https"].includes(split[0])) {
        url.protocol = `${split[0]}:`;
        url.host = split[1];
      } else {
        url.host = directHost;
      }
    }
    return url.toString();
  };
  const amzDate = (date) => date.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp = (date) => amzDate(date).slice(0, 8);
  const encodeRfc3986 = (value) => encodeURIComponent(value).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
  const presignPutObject = (addition, key) => {
    const now = /* @__PURE__ */ new Date();
    const amz = amzDate(now);
    const date = dateStamp(now);
    const region = addition.region || "us-east-1";
    const scope = `${date}/${region}/s3/aws4_request`;
    const url = new URL(directUploadUrl(addition, key));
    const params = {
      "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
      "X-Amz-Credential": `${addition.access_key_id}/${scope}`,
      "X-Amz-Date": amz,
      "X-Amz-Expires": String(Number(addition.sign_url_expire || 4) * 3600),
      "X-Amz-SignedHeaders": "host"
    };
    if (addition.session_token) params["X-Amz-Security-Token"] = addition.session_token;
    for (const [name, value] of Object.entries(params)) url.searchParams.set(name, value);
    const query = [...url.searchParams.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([name, value]) => `${encodeRfc3986(name)}=${encodeRfc3986(value)}`).join("&");
    const canonicalRequest = [
      "PUT",
      url.pathname || "/",
      query,
      `host:${url.host}
`,
      "host",
      "UNSIGNED-PAYLOAD"
    ].join("\n");
    const stringToSign = [
      "AWS4-HMAC-SHA256",
      amz,
      scope,
      sha256Hex(canonicalRequest)
    ].join("\n");
    const kDate = hmacSha256(`AWS4${addition.secret_access_key}`, date);
    const kRegion = hmacSha256(kDate, region);
    const kService = hmacSha256(kRegion, "s3");
    const kSigning = hmacSha256(kService, "aws4_request");
    url.searchParams.set("X-Amz-Signature", hex(hmacSha256(kSigning, stringToSign)));
    return url.toString();
  };
  const signedRequest = (client, addition, method, key, {
    body = "",
    contentType = "application/octet-stream",
    headers: extraHeaders = {},
    payloadEncoding,
    query = "",
    signingBody,
    responseEncoding = "text"
  } = {}) => {
    const url = s3Url(addition, key, query);
    const headers = signAwsV4({
      accessKeyId: addition.access_key_id,
      body: signingBody === void 0 ? body : signingBody,
      headers: {
        ...contentType ? { "content-type": contentType } : {},
        ...extraHeaders
      },
      method,
      region: addition.region || "us-east-1",
      secretAccessKey: addition.secret_access_key,
      sessionToken: addition.session_token || "",
      url
    });
    return forwardProxy(client, url, {
      body,
      contentType,
      headers,
      method,
      payloadEncoding,
      responseEncoding,
      timeout: Number(addition.timeout || 6e4)
    });
  };
  const parseListObjects = (xml, relPath, addition) => {
    const placeholder = addition.placeholder || ".siyuan-cloud";
    const dirs = (String(xml || "").match(/<CommonPrefixes>[\s\S]*?<\/CommonPrefixes>/gi) || []).map((chunk) => decodeXml(tagText$1(chunk, "Prefix")).replace(/\/+$/, "")).map((prefix) => basename(prefix)).filter(Boolean).map((name) => ({
      name,
      path: normalizePath(relPath + "/" + name),
      is_dir: true,
      size: 0,
      modified: (/* @__PURE__ */ new Date()).toISOString(),
      created: (/* @__PURE__ */ new Date()).toISOString()
    }));
    const files = (String(xml || "").match(/<Contents>[\s\S]*?<\/Contents>/gi) || []).map((chunk) => {
      const key = decodeXml(tagText$1(chunk, "Key"));
      const name = basename(key);
      return {
        name,
        path: normalizePath(relPath + "/" + name),
        is_dir: false,
        size: Number(tagText$1(chunk, "Size") || 0),
        modified: new Date(tagText$1(chunk, "LastModified") || Date.now()).toISOString(),
        created: new Date(tagText$1(chunk, "LastModified") || Date.now()).toISOString()
      };
    }).filter((item) => item.name && item.name !== placeholder);
    return [...dirs, ...files];
  };
  const createS3Driver = ({ client }) => ({
    async list(storage, relPath, req) {
      const addition = storage.addition_json;
      const prefix = keyFor(relPath, true);
      const version = addition.list_object_version === "v2" ? "list-type=2&" : "";
      const data = await signedRequest(client, addition, "GET", "", {
        contentType: "",
        query: `${version}prefix=${encodeURIComponent(prefix)}&delimiter=%2F`
      });
      const content = parseListObjects(data.body, relPath, addition);
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "S3",
        direct_upload_tools: addition.enable_direct_upload ? ["HttpDirect"] : []
      };
    },
    async get(storage, relPath) {
      var _a, _b, _c, _d;
      const addition = storage.addition_json;
      const data = await signedRequest(client, addition, "HEAD", keyFor(relPath), { contentType: "" });
      return {
        name: basename(relPath),
        path: relPath,
        is_dir: false,
        size: Number(((_a = data.headers) == null ? void 0 : _a["Content-Length"]) || ((_b = data.headers) == null ? void 0 : _b["content-length"]) || 0),
        modified: new Date(((_c = data.headers) == null ? void 0 : _c["Last-Modified"]) || ((_d = data.headers) == null ? void 0 : _d["last-modified"]) || Date.now()).toISOString(),
        created: (/* @__PURE__ */ new Date()).toISOString(),
        raw_url: `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
        provider: "S3",
        related: []
      };
    },
    async read(storage, relPath) {
      return signedRequest(client, storage.addition_json, "GET", keyFor(relPath), { contentType: "", responseEncoding: "base64" });
    },
    async mkdir(storage, relPath) {
      const addition = storage.addition_json;
      const name = addition.placeholder || ".siyuan-cloud";
      await signedRequest(client, addition, "PUT", keyFor(normalizePath(relPath + "/" + name)), { body: "" });
    },
    async move(storage, relPath, dstRelPath) {
      const addition = storage.addition_json;
      const src = `${addition.bucket}/${keyFor(relPath)}`;
      const dst = normalizePath(dstRelPath + "/" + basename(relPath)).replace(/^\/+/, "");
      await signedRequest(client, addition, "PUT", dst, {
        contentType: "",
        headers: { "x-amz-copy-source": `/${encodeURIComponent(src).replace(/%2F/g, "/")}` }
      });
      await signedRequest(client, addition, "DELETE", keyFor(relPath), { contentType: "" });
    },
    async copy(storage, relPath, dstRelPath) {
      const addition = storage.addition_json;
      const src = `${addition.bucket}/${keyFor(relPath)}`;
      const dst = normalizePath(dstRelPath + "/" + basename(relPath)).replace(/^\/+/, "");
      await signedRequest(client, addition, "PUT", dst, {
        contentType: "",
        headers: { "x-amz-copy-source": `/${encodeURIComponent(src).replace(/%2F/g, "/")}` }
      });
    },
    async remove(storage, relPath) {
      await signedRequest(client, storage.addition_json, "DELETE", keyFor(relPath), { contentType: "" });
    },
    async rename(storage, relPath, newName) {
      const addition = storage.addition_json;
      const src = `${addition.bucket}/${keyFor(relPath)}`;
      const dst = normalizePath(dirname(relPath) + "/" + newName).replace(/^\/+/, "");
      await signedRequest(client, addition, "PUT", dst, {
        contentType: "",
        headers: { "x-amz-copy-source": `/${encodeURIComponent(src).replace(/%2F/g, "/")}` }
      });
      await signedRequest(client, addition, "DELETE", keyFor(relPath), { contentType: "" });
    },
    async put(storage, relPath, content, mime, options = {}) {
      const signingBody = options.bodyEncoding === "base64" ? base64ToBytes(content || "") : content || "";
      await signedRequest(client, storage.addition_json, "PUT", keyFor(relPath), {
        body: content || "",
        contentType: mime || "application/octet-stream",
        payloadEncoding: options.bodyEncoding === "base64" ? "base64" : void 0,
        signingBody
      });
    },
    async getDirectUploadInfo(storage, relPath) {
      const addition = storage.addition_json;
      if (!addition.enable_direct_upload) throw new Error("direct upload is not implemented for this storage");
      return {
        upload_url: presignPutObject(addition, keyFor(relPath)),
        method: "PUT"
      };
    }
  });
  const davHeaders = (addition, extra = {}) => ({
    Authorization: basicAuth(addition.username, addition.password),
    ...extra
  });
  const stripTags = (value) => String(value || "").replace(/<[^>]+>/g, "").trim();
  const hrefText = (xml) => {
    var _a;
    return stripTags(((_a = xml.match(/<[^:>]*:?href[^>]*>[\s\S]*?<\/[^:>]*:?href>/i)) == null ? void 0 : _a[0]) || "");
  };
  const tagText = (xml, name) => {
    var _a;
    return stripTags(((_a = xml.match(new RegExp(`<[^:>]*:?${name}[^>]*>[\\s\\S]*?<\\/[^:>]*:?${name}>`, "i"))) == null ? void 0 : _a[0]) || "");
  };
  const isCollection = (xml) => /<[^:>]*:?collection\b/i.test(xml);
  const parseDavDate = (raw) => {
    const date = raw ? new Date(raw) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const parsePropfind = (xml, relPath) => {
    const responses = String(xml || "").match(/<[^:>]*:?response\b[\s\S]*?<\/[^:>]*:?response>/gi) || [];
    const current = normalizePath(relPath || "/");
    return responses.map((chunk) => {
      const href = decodeURIComponent(hrefText(chunk));
      const name = tagText(chunk, "displayname") || basename(href.replace(/\/+$/, ""));
      const path = normalizePath(current + "/" + name);
      return {
        name,
        path,
        is_dir: isCollection(chunk),
        size: Number(tagText(chunk, "getcontentlength") || 0),
        modified: parseDavDate(tagText(chunk, "getlastmodified")),
        created: parseDavDate(tagText(chunk, "creationdate"))
      };
    }).filter((item) => item.name && normalizePath(item.path) !== current);
  };
  const createWebDavDriver = ({ client }) => {
    const request = (storage, relPath, options = {}) => {
      const addition = storage.addition_json;
      return forwardProxy(client, joinUrl(addition.address, normalizePath((addition.root_folder_path || "/") + "/" + relPath)), {
        ...options,
        headers: davHeaders(addition, options.headers || {}),
        timeout: Number(addition.timeout || 3e4)
      });
    };
    return {
      async list(storage, relPath) {
        const data = await request(storage, relPath, {
          body: '<?xml version="1.0"?><propfind xmlns="DAV:"><allprop/></propfind>',
          contentType: "application/xml",
          headers: { Depth: "1" },
          method: "PROPFIND"
        });
        const content = parsePropfind(data.body, relPath);
        return {
          content,
          total: content.length,
          readme: "",
          header: "",
          write: true,
          provider: "WebDav",
          direct_upload_tools: []
        };
      },
      async get(storage, relPath) {
        var _a, _b;
        const head = await request(storage, relPath, { method: "HEAD" });
        return {
          name: basename(relPath),
          path: relPath,
          is_dir: false,
          size: Number(((_a = head.headers) == null ? void 0 : _a["Content-Length"]) || ((_b = head.headers) == null ? void 0 : _b["content-length"]) || 0),
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString(),
          raw_url: `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
          provider: "WebDav",
          related: []
        };
      },
      async read(storage, relPath) {
        const addition = storage.addition_json;
        const url = joinUrl(addition.address, normalizePath((addition.root_folder_path || "/") + "/" + relPath));
        return {
          link: {
            url,
            header: davHeaders(addition)
          }
        };
      },
      async mkdir(storage, relPath) {
        await request(storage, relPath, { method: "MKCOL" });
      },
      async move(storage, relPath, dstRelPath) {
        const addition = storage.addition_json;
        await request(storage, relPath, {
          headers: { Destination: joinUrl(addition.address, normalizePath((addition.root_folder_path || "/") + "/" + dstRelPath + "/" + basename(relPath))) },
          method: "MOVE"
        });
      },
      async copy(storage, relPath, dstRelPath) {
        const addition = storage.addition_json;
        await request(storage, relPath, {
          headers: { Destination: joinUrl(addition.address, normalizePath((addition.root_folder_path || "/") + "/" + dstRelPath + "/" + basename(relPath))) },
          method: "COPY"
        });
      },
      async remove(storage, relPath) {
        await request(storage, relPath, { method: "DELETE" });
      },
      async rename(storage, relPath, newName) {
        const addition = storage.addition_json;
        await request(storage, relPath, {
          headers: { Destination: joinUrl(addition.address, normalizePath((addition.root_folder_path || "/") + "/" + dirname(relPath) + "/" + newName)) },
          method: "MOVE"
        });
      },
      async put(storage, relPath, content, mime, options = {}) {
        const body = content || "";
        await request(storage, relPath, {
          body,
          contentType: mime || "application/octet-stream",
          headers: {
            "Content-Length": String(options.size || (options.bodyEncoding === "base64" ? 0 : String(body).length)),
            "Content-Type": mime || "application/octet-stream"
          },
          method: "PUT",
          payloadEncoding: options.bodyEncoding === "base64" ? "base64" : void 0
        });
      }
    };
  };
  const parseAddition = (storage) => {
    if (storage.addition_json) return storage.addition_json;
    try {
      return JSON.parse(storage.addition || "{}");
    } catch (_) {
      return {};
    }
  };
  const relPathForMount = (mountPath, path) => {
    const mount = normalizePath(mountPath);
    const current = normalizePath(path);
    if (mount === "/") return current;
    const rest = current === mount ? "" : current.slice(mount.length);
    return normalizePath(rest || "/");
  };
  const createDriverRuntime = ({ client, getSettings, saveStorageAddition }) => {
    const drivers = {
      OpenList: createOpenListDriver({ client }),
      AListV3: createOpenListDriver({ client }),
      "AList V3": createOpenListDriver({ client }),
      S3: createS3Driver({ client }),
      Doge: createS3Driver({ client }),
      WebDav: createWebDavDriver({ client }),
      "115 Cloud": create115Driver({ client }),
      "115": create115Driver({ client }),
      Onedrive: createOneDriveDriver({ client }),
      OneDrive: createOneDriveDriver({ client }),
      "123Pan": create123PanDriver({ client }),
      "123": create123PanDriver({ client }),
      BaiduNetdisk: createBaiduNetdiskDriver({ client }),
      BaiduNetDisk: createBaiduNetdiskDriver({ client }),
      AliyundriveOpen: createAliyundriveOpenDriver({ client }),
      AliyunDriveOpen: createAliyundriveOpenDriver({ client }),
      "189Cloud": create189CloudDriver({ client }),
      "189CloudPC": create189CloudPCDriver({ client }),
      "189CloudTV": create189CloudTVDriver({ client }),
      Quark: createQuarkDriver({ client }),
      UC: createQuarkDriver({ client }),
      QuarkOpen: createQuarkOpenDriver({ client }),
      QuarkTV: createQuarkUCTVDriver({ client }),
      UCTV: createQuarkUCTVDriver({ client })
    };
    const runtime = {
      drivers,
      canHandle(storage) {
        return !!drivers[storage == null ? void 0 : storage.driver];
      },
      mountEntries(storages, now) {
        const seen = /* @__PURE__ */ new Set();
        return (storages || []).filter((storage) => !storage.disabled && normalizePath(storage.mount_path || "/") !== "/").map((storage) => normalizePath(storage.mount_path)).map((mountPath) => mountPath.split("/").filter(Boolean)[0]).filter((name) => {
          if (!name || seen.has(name)) return false;
          seen.add(name);
          return true;
        }).map((name) => ({
          name,
          path: `/${name}`,
          is_dir: true,
          size: 0,
          modified: now(),
          created: now(),
          provider: "mount"
        }));
      },
      resolve(storages, path) {
        const current = normalizePath(path || "/");
        const candidates = (storages || []).filter((storage2) => !storage2.disabled && runtime.canHandle(storage2)).map((storage2) => {
          const addition = parseAddition(storage2);
          return {
            ...storage2,
            addition_json: addition,
            mount_path: normalizePath(storage2.mount_path || "/"),
            settings: getSettings ? getSettings() : {},
            saveDriverStorage: async (updatedAddition = addition) => {
              if (saveStorageAddition) await saveStorageAddition(storage2, updatedAddition);
            }
          };
        }).filter((storage2) => storage2.mount_path !== "/" && (current === storage2.mount_path || current.startsWith(storage2.mount_path + "/"))).sort((a, b) => b.mount_path.length - a.mount_path.length);
        const storage = candidates[0];
        if (!storage) return null;
        return {
          storage,
          driver: drivers[storage.driver],
          relPath: relPathForMount(storage.mount_path, current)
        };
      },
      async test(driverName, addition) {
        const driver = drivers[driverName];
        if (!(driver == null ? void 0 : driver.test)) throw new Error(`driver [${driverName}] does not expose a test method`);
        return driver.test({
          addition_json: addition || {},
          driver: driverName,
          mount_path: "/",
          settings: getSettings ? getSettings() : {}
        });
      }
    };
    return runtime;
  };
  const defaultSettings = () => ({
    site_title: "Siyuan Cloud",
    version: OPENLIST_VERSION,
    main_color: "#1890ff",
    logo: "",
    favicon: "",
    announcement: "",
    announcements: "",
    allow_indexed: "false",
    allow_mounted: "true",
    hide_storage_details: "true",
    hide_storage_details_in_manage_page: "true",
    show_disk_usage_in_plain_text: "false",
    text_types: "txt,htm,html,xml,java,properties,sql,js,md,json,conf,ini,vue,php,py,bat,gitignore,yml,go,sh,c,cpp,h,hpp,tsx,vtt,srt,ass,rs,lrc,strm",
    audio_types: "mp3,flac,ogg,m4a,wav,opus,wma",
    video_types: "mp4,mkv,avi,mov,rmvb,webm,flv,m3u8",
    image_types: "jpg,tiff,jpeg,png,gif,bmp,svg,ico,swf,webp,avif",
    proxy_types: "m3u8,url",
    proxy_ignore_headers: "authorization,referer",
    external_previews: "{}",
    audio_autoplay: "true",
    video_autoplay: "true",
    preview_download_by_default: "false",
    preview_archives_by_default: "false",
    share_preview_download_by_default: "false",
    share_preview_archives_by_default: "false",
    readme_autorender: "true",
    filter_readme_scripts: "true",
    non_efs_zip_encoding: "IBM437",
    default_page_size: "30",
    package_download: "true",
    pagination_type: "all",
    robots_txt: "",
    hide_files: "",
    customize_head: "",
    customize_body: "",
    link_expiration: "0",
    sign_all: "true",
    privacy_regs: "",
    ocr_api: "https://api.example.com/ocr/file/json",
    filename_char_mapping: "",
    forward_direct_link_params: "",
    ignore_direct_link_params: "sign,sicloud_ts,raw",
    webauthn_login_enabled: "false",
    share_preview: "false",
    share_archive_preview: "false",
    share_force_proxy: "true",
    share_summary_content: "",
    handle_hook_after_writing: "false",
    handle_hook_rate_limit: "0",
    ignore_system_files: "false",
    search_index: "none",
    auto_update_index: "false",
    ignore_paths: "",
    max_index_depth: "20",
    index_progress: "{}",
    sso_login_enabled: "false",
    sso_login_platform: "Github",
    sso_client_id: "",
    sso_client_secret: "",
    sso_oidc_username_key: "name",
    sso_organization_name: "",
    sso_application_name: "",
    sso_endpoint_name: "",
    sso_jwt_public_key: "",
    sso_extra_scopes: "",
    sso_auto_register: "false",
    sso_default_dir: "/",
    sso_default_permission: "0",
    sso_compatibility_mode: "false",
    ldap_login_enabled: "false",
    ldap_server: "",
    ldap_skip_tls_verify: "false",
    ldap_manager_dn: "",
    ldap_manager_password: "",
    ldap_user_search_base: "",
    ldap_user_search_filter: "(uid=%s)",
    ldap_default_dir: "/",
    ldap_default_permission: "0",
    ldap_login_tips: "login with ldap",
    s3_access_key_id: "",
    s3_secret_access_key: "",
    s3_buckets: "[]",
    ftp_public_host: "127.0.0.1",
    ftp_pasv_port_map: "",
    ftp_mandatory_tls: "false",
    ftp_implicit_tls: "false",
    ftp_tls_private_key_path: "",
    ftp_tls_public_cert_path: "",
    sftp_disable_password_login: "false",
    task_offline_download_threads_num: "5",
    task_offline_download_transfer_threads_num: "5",
    task_upload_threads_num: "5",
    task_copy_threads_num: "5",
    task_decompress_download_threads_num: "5",
    task_decompress_upload_threads_num: "5",
    stream_max_client_download_speed: "-1",
    stream_max_client_upload_speed: "-1",
    stream_max_server_download_speed: "-1",
    stream_max_server_upload_speed: "-1",
    aria2_uri: "",
    aria2_secret: "",
    qbittorrent_url: "",
    qbittorrent_seedtime: "",
    transmission_uri: "",
    transmission_seedtime: "",
    "115_temp_dir": "",
    "123_temp_dir": "",
    "115_open_temp_dir": "",
    "123_open_temp_dir": "",
    "123_open_callback_url": "",
    pikpak_temp_dir: "",
    thunder_temp_dir: "",
    thunderx_temp_dir: "",
    thunder_browser_temp_dir: "",
    token: "siyuan-cloud-token"
  });
  const settingMeta = {
    version: { group: SETTING_GROUP.SITE, flag: SETTING_FLAG.READONLY },
    site_title: { group: SETTING_GROUP.SITE },
    announcement: { type: "text", group: SETTING_GROUP.SITE },
    announcements: { type: "text", group: SETTING_GROUP.SITE },
    allow_indexed: { type: "bool", group: SETTING_GROUP.SITE },
    allow_mounted: { type: "bool", group: SETTING_GROUP.SITE },
    robots_txt: { type: "text", group: SETTING_GROUP.SITE },
    logo: { type: "text", group: SETTING_GROUP.STYLE },
    favicon: { group: SETTING_GROUP.STYLE },
    main_color: { group: SETTING_GROUP.STYLE },
    hide_storage_details: { type: "bool", group: SETTING_GROUP.STYLE, flag: SETTING_FLAG.PRIVATE },
    hide_storage_details_in_manage_page: { type: "bool", group: SETTING_GROUP.STYLE, flag: SETTING_FLAG.PRIVATE },
    show_disk_usage_in_plain_text: { type: "bool", group: SETTING_GROUP.STYLE },
    text_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    audio_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    video_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    image_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    proxy_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    proxy_ignore_headers: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    external_previews: { type: "text", group: SETTING_GROUP.PREVIEW },
    audio_autoplay: { type: "bool", group: SETTING_GROUP.PREVIEW },
    video_autoplay: { type: "bool", group: SETTING_GROUP.PREVIEW },
    preview_download_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    preview_archives_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    share_preview_download_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    share_preview_archives_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    readme_autorender: { type: "bool", group: SETTING_GROUP.PREVIEW },
    filter_readme_scripts: { type: "bool", group: SETTING_GROUP.PREVIEW },
    non_efs_zip_encoding: { group: SETTING_GROUP.PREVIEW },
    hide_files: { type: "text", group: SETTING_GROUP.GLOBAL },
    customize_head: { type: "text", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    customize_body: { type: "text", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    link_expiration: { type: "number", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    sign_all: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    privacy_regs: { type: "text", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    ocr_api: { group: SETTING_GROUP.GLOBAL },
    filename_char_mapping: { type: "text", group: SETTING_GROUP.GLOBAL },
    forward_direct_link_params: { group: SETTING_GROUP.GLOBAL },
    ignore_direct_link_params: { group: SETTING_GROUP.GLOBAL },
    webauthn_login_enabled: { type: "bool", group: SETTING_GROUP.GLOBAL },
    share_preview: { type: "bool", group: SETTING_GROUP.GLOBAL },
    share_archive_preview: { type: "bool", group: SETTING_GROUP.GLOBAL },
    share_force_proxy: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    share_summary_content: { type: "text", group: SETTING_GROUP.GLOBAL },
    handle_hook_after_writing: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    handle_hook_rate_limit: { type: "number", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    ignore_system_files: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    token: { group: SETTING_GROUP.SINGLE, flag: SETTING_FLAG.PRIVATE },
    search_index: { type: "select", options: "none,bleve", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE },
    auto_update_index: { type: "bool", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE },
    ignore_paths: { type: "text", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE, help: "one path per line" },
    max_index_depth: { type: "number", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE, help: "max depth of index" },
    index_progress: { type: "text", group: SETTING_GROUP.SINGLE, flag: SETTING_FLAG.PRIVATE },
    sso_login_enabled: { type: "bool", group: SETTING_GROUP.SSO },
    sso_login_platform: { type: "select", options: "Casdoor,Github,Microsoft,Google,Dingtalk,OIDC", group: SETTING_GROUP.SSO },
    sso_client_id: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_client_secret: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_oidc_username_key: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_organization_name: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_application_name: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_endpoint_name: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_jwt_public_key: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_extra_scopes: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_auto_register: { type: "bool", group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_default_dir: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_default_permission: { type: "number", group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_compatibility_mode: { type: "bool", group: SETTING_GROUP.SSO },
    ldap_login_enabled: { type: "bool", group: SETTING_GROUP.LDAP },
    ldap_server: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_skip_tls_verify: { type: "bool", group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_manager_dn: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_manager_password: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_user_search_base: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_user_search_filter: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_default_dir: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_default_permission: { type: "number", group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_login_tips: { group: SETTING_GROUP.LDAP },
    s3_access_key_id: { group: SETTING_GROUP.S3, flag: SETTING_FLAG.PRIVATE },
    s3_secret_access_key: { group: SETTING_GROUP.S3, flag: SETTING_FLAG.PRIVATE },
    s3_buckets: { group: SETTING_GROUP.S3, flag: SETTING_FLAG.PRIVATE },
    ftp_public_host: { group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_pasv_port_map: { type: "text", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_mandatory_tls: { type: "bool", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_implicit_tls: { type: "bool", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_tls_private_key_path: { group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_tls_public_cert_path: { group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    sftp_disable_password_login: { type: "bool", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    task_offline_download_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_offline_download_transfer_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_upload_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_copy_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_decompress_download_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_decompress_upload_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_client_download_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_client_upload_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_server_download_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_server_upload_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    aria2_uri: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    aria2_secret: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    qbittorrent_url: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    qbittorrent_seedtime: { type: "number", group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    transmission_uri: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    transmission_seedtime: { type: "number", group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "115_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "123_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "115_open_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "123_open_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "123_open_callback_url": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    pikpak_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    thunder_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    thunderx_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    thunder_browser_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE }
  };
  const defaultState = (now) => ({
    settings: defaultSettings(),
    users: [
      defaultAdminUser(),
      defaultGuestUser()
    ],
    storages: [
      {
        id: 1,
        mount_path: "/",
        order: 0,
        driver: "SiYuanKernel",
        cache_expiration: 30,
        status: "work",
        addition: "{}",
        remark: "Virtual OpenList storage backed by SiYuan kernel plugin storage.",
        modified: now(),
        disabled: false
      }
    ],
    entries: {
      "/": {
        name: "",
        path: "/",
        is_dir: true,
        size: 0,
        modified: now(),
        created: now(),
        children: []
      }
    },
    tasks: {},
    metas: [],
    messages: [],
    ssh_keys: [],
    scan: { status: "idle", total: 0, done: 0 },
    webdav_locks: {},
    s3_multipart_uploads: {},
    sharings: [],
    search_nodes: []
  });
  const createVirtualFs = ({ getState, now }) => {
    const byteLengthForBase64 = (value) => {
      const clean = String(value || "").replace(/[\r\n\s]/g, "");
      if (!clean) return 0;
      const padding = clean.endsWith("==") ? 2 : clean.endsWith("=") ? 1 : 0;
      return Math.max(0, Math.floor(clean.length * 3 / 4) - padding);
    };
    const ensureDir = (path) => {
      const state = getState();
      const normalized = normalizePath(path);
      if (!state.entries[normalized]) {
        state.entries[normalized] = {
          name: basename(normalized),
          path: normalized,
          is_dir: true,
          size: 0,
          modified: now(),
          created: now(),
          children: []
        };
      }
      const parentPath = dirname(normalized);
      const parent = state.entries[parentPath];
      if (parent && parent.is_dir && normalized !== "/" && !parent.children.includes(normalized)) {
        parent.children.push(normalized);
        parent.children.sort();
        parent.modified = now();
      }
      return state.entries[normalized];
    };
    const createFile2 = (path, content, mime, options = {}) => {
      var _a;
      const state = getState();
      const normalized = normalizePath(path);
      const parent = ensureDir(dirname(normalized));
      const bodyEncoding = String(options.bodyEncoding || "text");
      const text2 = content === void 0 || content === null ? "" : String(content);
      const size = Number(options.size || 0) || (bodyEncoding.startsWith("base64") ? byteLengthForBase64(text2) : text2.length);
      state.entries[normalized] = {
        name: basename(normalized),
        path: normalized,
        is_dir: false,
        size,
        modified: now(),
        created: ((_a = state.entries[normalized]) == null ? void 0 : _a.created) || now(),
        content: text2,
        body_encoding: bodyEncoding,
        mime: mime || "text/plain; charset=utf-8"
      };
      if (!parent.children.includes(normalized)) {
        parent.children.push(normalized);
        parent.children.sort();
      }
      parent.modified = now();
      return state.entries[normalized];
    };
    const removeEntry = (path) => {
      const state = getState();
      const entry = state.entries[path];
      if (!entry || path === "/") return;
      if (entry.children) {
        for (const child of [...entry.children]) removeEntry(child);
      }
      const parent = state.entries[dirname(path)];
      if (parent && parent.children) {
        parent.children = parent.children.filter((item) => item !== path);
        parent.modified = now();
      }
      delete state.entries[path];
    };
    const cloneEntryTree = (srcPath, dstPath) => {
      const state = getState();
      const src = state.entries[srcPath];
      if (!src) throw new Error("object not found");
      if (src.is_dir) {
        ensureDir(dstPath);
        for (const child of src.children || []) {
          cloneEntryTree(child, normalizePath(dstPath + "/" + basename(child)));
        }
      } else {
        createFile2(dstPath, src.content || "", src.mime, {
          bodyEncoding: src.body_encoding || "text",
          size: src.size || 0
        });
      }
    };
    const moveEntryTree = (srcPath, dstPath) => {
      cloneEntryTree(srcPath, dstPath);
      removeEntry(srcPath);
    };
    const renameEntryInDir = (dir, srcName, newName, options) => {
      const state = getState();
      const srcPath = normalizePath(dir + "/" + srcName);
      const dstPath = normalizePath(dir + "/" + newName);
      if (!isSafeRelativeName(newName)) throw new Error("relative path is not allowed");
      if (!state.entries[srcPath]) return false;
      if (state.entries[dstPath] && dstPath !== srcPath && !(options == null ? void 0 : options.overwrite)) throw new Error(`file [${newName}] exists`);
      if (state.entries[dstPath] && dstPath !== srcPath) removeEntry(dstPath);
      moveEntryTree(srcPath, dstPath);
      return true;
    };
    const removeEmptyDirs = (rootPath2) => {
      var _a;
      const state = getState();
      let removed = 0;
      const walk = (path) => {
        const entry = state.entries[path];
        if (!entry || !entry.is_dir || path === "/") return false;
        for (const child of [...entry.children || []]) walk(child);
        if ((entry.children || []).length === 0) {
          removeEntry(path);
          removed += 1;
          return true;
        }
        return false;
      };
      for (const child of [...((_a = state.entries[rootPath2]) == null ? void 0 : _a.children) || []]) walk(child);
      return removed;
    };
    return {
      cloneEntryTree,
      createFile: createFile2,
      ensureDir,
      moveEntryTree,
      removeEmptyDirs,
      removeEntry,
      renameEntryInDir
    };
  };
  const createWorkspaceAdapter = ({
    client,
    extensionType,
    failure: failure2,
    now,
    page,
    toObjResp
  }) => {
    const isWorkspacePath = (path) => normalizePath(path).startsWith("/@workspace");
    const workspaceRelPath = (path) => {
      const normalized = normalizePath(path);
      const rel = normalized.replace(/^\/@workspace\/?/, "");
      return rel.replace(/^\/+/, "");
    };
    const siyuanApiJson = async (apiPath, data) => {
      const response = await client.fetch(apiPath, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data || {})
      });
      const contentType = response.headers && (response.headers["Content-Type"] || response.headers["content-type"] || "");
      if (String(contentType).includes("application/json")) return response.json();
      return {
        code: response.ok ? 0 : response.status,
        msg: response.statusText || "",
        data: await response.text()
      };
    };
    const workspaceObjResp = (item) => ({
      name: item.name,
      size: item.size || 0,
      is_dir: !!(item.isDir || item.is_dir),
      modified: new Date(Number(item.updated || 0) * 1e3 || Date.now()).toISOString(),
      created: new Date(Number(item.updated || 0) * 1e3 || Date.now()).toISOString(),
      sign: "",
      thumb: "",
      type: extensionType(item.name, item.isDir || item.is_dir),
      hashinfo: "",
      hash_info: {},
      provider: "siyuan-workspace"
    });
    const workspaceList = async (path, req) => {
      const rel = workspaceRelPath(path);
      const payload = await siyuanApiJson("/api/file/readDir", { path: rel });
      if (payload.code !== 0) return { error: failure2(payload.msg || "readDir failed", payload.code || 500) };
      const content = (payload.data || []).filter((item) => item && item.name && !String(item.name).startsWith(".")).map(workspaceObjResp);
      return {
        data: {
          content: page(content, req || {}),
          total: content.length,
          readme: "",
          header: "",
          write: true,
          write_content_bypass: false,
          provider: "siyuan-workspace",
          direct_upload_tools: []
        }
      };
    };
    const workspaceGet = async (path) => {
      if (normalizePath(path) === "/@workspace") {
        return {
          data: {
            ...toObjResp({ name: "@workspace", is_dir: true, size: 0, modified: now(), created: now() }),
            raw_url: "",
            readme: "",
            header: "",
            provider: "siyuan-workspace",
            related: []
          }
        };
      }
      const rel = workspaceRelPath(path);
      const parent = workspaceRelPath(dirname(path));
      const payload = await siyuanApiJson("/api/file/readDir", { path: parent });
      if (payload.code !== 0) return { error: failure2(payload.msg || "readDir failed", payload.code || 500) };
      const item = (payload.data || []).find((entry) => entry.name === basename(path));
      if (!item) return { error: failure2("object not found", 404) };
      return {
        data: {
          ...workspaceObjResp(item),
          raw_url: item.isDir ? "" : "/plugin/private/siyuan-cloud/d" + normalizePath("/@workspace/" + rel),
          readme: "",
          header: "",
          provider: "siyuan-workspace",
          related: []
        }
      };
    };
    const workspaceReadText = async (path) => {
      const response = await client.fetch("/api/file/getFile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: workspaceRelPath(path) })
      });
      return {
        ok: response.ok,
        status: response.status || 200,
        text: await response.text(),
        contentType: response.headers && (response.headers["Content-Type"] || response.headers["content-type"]) || "application/octet-stream"
      };
    };
    return {
      isWorkspacePath,
      siyuanApiJson,
      workspaceGet,
      workspaceList,
      workspaceReadText,
      workspaceRelPath
    };
  };
  const DONE_STATES = /* @__PURE__ */ new Set(["canceled", "failed", "succeeded"]);
  const UNDONE_STATES = /* @__PURE__ */ new Set(["pending", "running", "canceling", "errored", "failing", "waiting_retry", "before_retry"]);
  const ensureTaskBuckets = (state) => {
    state.tasks = state.tasks || {};
    for (const type of TASK_TYPES) {
      state.tasks[type] = state.tasks[type] || {};
    }
    return state.tasks;
  };
  const createTaskRecord = ({
    creator,
    error,
    name,
    now,
    status,
    totalBytes,
    type
  }) => {
    const time = now();
    return {
      id: `${type}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
      name: name || type,
      creator: (creator == null ? void 0 : creator.username) || "admin",
      creator_role: (creator == null ? void 0 : creator.role) ?? 2,
      state: error ? "failed" : "succeeded",
      status: status || (error ? "failed" : "completed"),
      progress: error ? 0 : 100,
      start_time: time,
      end_time: time,
      total_bytes: totalBytes || 0,
      error: error || ""
    };
  };
  const normalizeTaskRecord = (task = {}) => ({
    id: String(task.id || ""),
    name: String(task.name || ""),
    creator: String(task.creator || "admin"),
    creator_role: Number(task.creator_role ?? 2),
    state: String(task.state || "succeeded"),
    status: String(task.status || ""),
    progress: Number.isFinite(Number(task.progress)) ? Number(task.progress) : 100,
    start_time: task.start_time || null,
    end_time: task.end_time || null,
    total_bytes: Number(task.total_bytes || 0),
    error: String(task.error || "")
  });
  const createTaskStore = ({
    getState,
    now,
    saveState: saveState2
  }) => {
    const addTask = async (type, input) => {
      var _a;
      const state = getState();
      const tasks = ensureTaskBuckets(state);
      const task = createTaskRecord({
        ...input,
        creator: (_a = state.users) == null ? void 0 : _a[0],
        now,
        type
      });
      tasks[type][task.id] = normalizeTaskRecord(task);
      await saveState2();
      return tasks[type][task.id];
    };
    const getTask = (type, id) => {
      var _a;
      const tasks = ensureTaskBuckets(getState());
      const task = ((_a = tasks[type]) == null ? void 0 : _a[id]) || null;
      return task ? normalizeTaskRecord(task) : null;
    };
    const listTasks = (type, done) => {
      const tasks = ensureTaskBuckets(getState());
      return Object.values(tasks[type] || {}).map(normalizeTaskRecord).filter((task) => done ? DONE_STATES.has(task.state) : UNDONE_STATES.has(task.state)).sort((a, b) => String(b.start_time || "").localeCompare(String(a.start_time || "")));
    };
    const removeTask = async (type, id) => {
      var _a;
      const tasks = ensureTaskBuckets(getState());
      if (!((_a = tasks[type]) == null ? void 0 : _a[id])) return false;
      delete tasks[type][id];
      await saveState2();
      return true;
    };
    const clearByState = async (type, states) => {
      const tasks = ensureTaskBuckets(getState());
      for (const task of Object.values(tasks[type] || {})) {
        if (states.has(task.state)) delete tasks[type][task.id];
      }
      await saveState2();
    };
    const markCanceled = async (type, id) => {
      var _a;
      const tasks = ensureTaskBuckets(getState());
      const task = (_a = tasks[type]) == null ? void 0 : _a[id];
      if (!task) return false;
      if (task) {
        task.state = "canceled";
        task.status = "canceled";
        task.end_time = now();
      }
      await saveState2();
      return true;
    };
    const retryTask = async (type, id) => {
      var _a;
      const tasks = ensureTaskBuckets(getState());
      const task = (_a = tasks[type]) == null ? void 0 : _a[id];
      if (!task) return false;
      task.state = "succeeded";
      task.status = "completed";
      task.progress = 100;
      task.error = "";
      task.end_time = now();
      await saveState2();
      return true;
    };
    const retryFailed = async (type) => {
      const tasks = ensureTaskBuckets(getState());
      for (const task of Object.values(tasks[type] || {})) {
        if (task.state !== "failed") continue;
        task.state = "succeeded";
        task.status = "completed";
        task.progress = 100;
        task.error = "";
        task.end_time = now();
      }
      await saveState2();
    };
    return {
      addTask,
      clearDone: (type) => clearByState(type, DONE_STATES),
      clearSucceeded: (type) => clearByState(type, /* @__PURE__ */ new Set(["succeeded"])),
      getTask,
      listTasks,
      markCanceled,
      removeTask,
      retryFailed,
      retryTask
    };
  };
  const progress = (objCount = 0, isDone = true, error = "", lastDoneTime = null) => ({
    obj_count: Number(objCount || 0),
    is_done: !!isDone,
    last_done_time: lastDoneTime,
    error: error || ""
  });
  const whereInParent = (node, parent) => {
    const normalized = normalizePath(parent || "/");
    if (normalized === "/") return true;
    return node.parent === normalized || node.parent.startsWith(`${normalized}/`);
  };
  const nodePath = (node) => normalizePath(`${node.parent}/${node.name}`);
  const parseIgnorePaths = (value) => String(value || "").split("\n").map((item) => normalizePath(item.trim())).filter((item) => item && item !== "/");
  const isIgnoredPath = (path, ignorePaths) => ignorePaths.some((item) => path.startsWith(item));
  const normalizeNode = (node) => ({
    parent: normalizePath(node.parent || "/"),
    name: String(node.name || ""),
    is_dir: !!node.is_dir,
    size: Number(node.size || 0)
  });
  const ensureSearchState = (state) => {
    if (!Array.isArray(state.search_nodes)) state.search_nodes = [];
    state.search_nodes = state.search_nodes.map(normalizeNode).filter((node) => node.name);
    if (!state.settings) state.settings = {};
    if (!state.settings.index_progress) {
      state.settings.index_progress = JSON.stringify(progress());
    }
  };
  const createSearchIndex = ({
    getObj,
    getState,
    isIndexDisabled,
    listObjs,
    now,
    saveState: saveState2
  }) => {
    const getProgress = () => {
      ensureSearchState(getState());
      try {
        return { ...progress(), ...JSON.parse(getState().settings.index_progress || "{}") };
      } catch (_) {
        return progress();
      }
    };
    const writeProgress = async (value) => {
      getState().settings.index_progress = JSON.stringify({ ...progress(), ...value || {} });
      await saveState2();
    };
    const clear = async () => {
      ensureSearchState(getState());
      getState().search_nodes = [];
      await saveState2();
    };
    const buildStateNodes = (paths, maxDepth) => {
      var _a, _b;
      const state = getState();
      const roots = (Array.isArray(paths) && paths.length ? paths : ["/"]).map(normalizePath);
      const ignorePaths = parseIgnorePaths((_a = state.settings) == null ? void 0 : _a.ignore_paths);
      const depthLimit = Math.max(1, Number(maxDepth || ((_b = state.settings) == null ? void 0 : _b.max_index_depth) || 20));
      return Object.values(state.entries || {}).filter((entry) => entry && entry.path && entry.path !== "/").filter((entry) => !isIgnoredPath(normalizePath(entry.path), ignorePaths)).filter((entry) => !(isIndexDisabled == null ? void 0 : isIndexDisabled(normalizePath(entry.path)))).filter((entry) => roots.some((root) => entry.path === root || entry.path.startsWith(`${root === "/" ? "" : root}/`))).filter((entry) => {
        const root = roots.find((item) => entry.path === item || entry.path.startsWith(`${item === "/" ? "" : item}/`)) || "/";
        const rel = entry.path.slice(root === "/" ? 1 : root.length + 1);
        return rel.split("/").filter(Boolean).length <= depthLimit;
      }).map((entry) => normalizeNode({
        parent: dirname(entry.path),
        name: entry.name || basename(entry.path),
        is_dir: entry.is_dir,
        size: entry.size
      }));
    };
    const walkNodes = async (paths, maxDepth) => {
      var _a, _b;
      if (!getObj || !listObjs) return buildStateNodes(paths, maxDepth);
      const roots = (Array.isArray(paths) && paths.length ? paths : ["/"]).map(normalizePath);
      const ignorePaths = parseIgnorePaths((_a = getState().settings) == null ? void 0 : _a.ignore_paths);
      const depthLimit = Math.max(1, Number(maxDepth || ((_b = getState().settings) == null ? void 0 : _b.max_index_depth) || 20));
      const nodes = [];
      const seen = /* @__PURE__ */ new Set();
      const walk = async (path, depth) => {
        const normalized = normalizePath(path);
        if (seen.has(normalized) || depth > depthLimit) return;
        seen.add(normalized);
        if (isIgnoredPath(normalized, ignorePaths)) return;
        if (isIndexDisabled == null ? void 0 : isIndexDisabled(normalized)) return;
        const obj = await getObj(normalized);
        if (!obj) return;
        if (normalized !== "/") {
          nodes.push(normalizeNode({
            parent: dirname(normalized),
            name: obj.name || basename(normalized),
            is_dir: obj.is_dir,
            size: obj.size
          }));
        }
        if (!obj.is_dir || depth >= depthLimit) return;
        const children = await listObjs(normalized);
        for (const child of children || []) {
          if (!(child == null ? void 0 : child.name)) continue;
          await walk(normalizePath(`${normalized}/${child.name}`), depth + 1);
        }
      };
      for (const root of roots) {
        await walk(root, 0);
      }
      return nodes;
    };
    const build = async ({ clearFirst = true, paths = ["/"], maxDepth, count = true } = {}) => {
      ensureSearchState(getState());
      await writeProgress(progress(0, false));
      if (clearFirst) getState().search_nodes = [];
      let nodes = [];
      try {
        nodes = await walkNodes(paths, maxDepth);
      } catch (error) {
        await writeProgress(progress(0, true, (error == null ? void 0 : error.message) || String(error), now()));
        throw error;
      }
      if (!clearFirst) {
        for (const path of paths) {
          await del(path, { persist: false });
        }
      }
      getState().search_nodes.push(...nodes);
      const doneAt = now();
      if (count) await writeProgress(progress(nodes.length, true, "", doneAt));
      else await writeProgress(progress(getState().search_nodes.length, true, "", doneAt));
      await saveState2();
    };
    const del = async (path, { persist = true } = {}) => {
      ensureSearchState(getState());
      const normalized = normalizePath(path || "/");
      getState().search_nodes = getState().search_nodes.filter((node) => {
        const current = nodePath(node);
        return current !== normalized && !whereInParent(node, normalized);
      });
      if (persist) await saveState2();
    };
    const search = (req) => {
      ensureSearchState(getState());
      const parent = normalizePath(req.parent || "/");
      const keywords = String(req.keywords || "").toLowerCase().split(/\s+/).filter(Boolean);
      const scope = Number(req.scope || 0);
      const page = Math.max(1, Number(req.page || 1));
      const perPage = Math.max(1, Number(req.per_page || req.perPage || 30));
      const filtered = getState().search_nodes.filter((node) => whereInParent(node, parent)).filter((node) => !keywords.length || keywords.every((keyword) => node.name.toLowerCase().includes(keyword))).filter((node) => scope === 0 || (scope === 1 ? node.is_dir : !node.is_dir)).sort((left, right) => left.name.localeCompare(right.name));
      const start = (page - 1) * perPage;
      return {
        content: filtered.slice(start, start + perPage),
        total: filtered.length
      };
    };
    return {
      build,
      clear,
      del,
      getProgress,
      search,
      writeProgress
    };
  };
  const lastWritten = /* @__PURE__ */ new Map();
  const readJson = async (storage, path) => {
    try {
      const file = await storage.get(path);
      if (file == null ? void 0 : file.text) {
        const content = await file.text();
        lastWritten.set(path, content);
        return JSON.parse(content);
      }
      const value = await file.json();
      lastWritten.set(path, JSON.stringify(value, null, 2));
      return value;
    } catch (_) {
      return null;
    }
  };
  const writeJson = async (storage, path, value) => {
    const content = JSON.stringify(value, null, 2);
    if (lastWritten.get(path) === content) return;
    await storage.put(path, content);
    lastWritten.set(path, content);
  };
  const pickConfigState = (state) => ({
    version: 1,
    settings: state.settings || {},
    users: state.users || [],
    storages: state.storages || [],
    metas: state.metas || [],
    sharings: state.sharings || [],
    ssh_keys: state.ssh_keys || []
  });
  const pickRuntimeState = (state) => ({
    version: 1,
    entries: state.entries || {},
    tasks: state.tasks || {},
    messages: state.messages || [],
    scan: state.scan || { status: "idle", total: 0, done: 0 },
    webdav_locks: state.webdav_locks || {},
    s3_multipart_uploads: state.s3_multipart_uploads || {}
  });
  const pickSearchState = (state) => ({
    version: 1,
    search_nodes: state.search_nodes || []
  });
  const normalizeUsers = (users) => {
    const normalized = Array.isArray(users) ? users.map(normalizeUser) : [];
    if (!normalized.some((user) => user.role === USER_ROLE.ADMIN)) {
      normalized.unshift(defaultAdminUser());
    }
    if (!normalized.some((user) => user.role === USER_ROLE.GUEST)) {
      normalized.push(defaultGuestUser());
    }
    return normalized.map((user, index) => ({
      ...user,
      id: Number(user.id || index + 1),
      disabled: user.role === USER_ROLE.ADMIN ? false : !!user.disabled
    }));
  };
  const normalizeDomains = (domains) => {
    if (!domains) return ["config", "runtime", "search"];
    if (typeof domains === "string") return [domains];
    if (Array.isArray(domains)) return domains;
    return ["config", "runtime", "search"];
  };
  const saveState = async (storage, state, domains) => {
    const items = new Set(normalizeDomains(domains));
    if (items.has("config")) await writeJson(storage, CONFIG_FILE, pickConfigState(state));
    if (items.has("runtime")) await writeJson(storage, RUNTIME_FILE, pickRuntimeState(state));
    if (items.has("search")) await writeJson(storage, SEARCH_INDEX_FILE, pickSearchState(state));
  };
  const loadConfigState = async ({ storage }) => {
    const config = await readJson(storage, CONFIG_FILE);
    if (!config) return null;
    return {
      settings: { ...defaultSettings(), ...config.settings || {} },
      users: normalizeUsers(config.users),
      storages: Array.isArray(config.storages) ? config.storages : [],
      metas: config.metas || [],
      sharings: config.sharings || [],
      ssh_keys: config.ssh_keys || []
    };
  };
  const loadState = async ({ now, storage }) => {
    try {
      const config = await loadConfigState({ storage });
      const runtime = await readJson(storage, RUNTIME_FILE);
      const search = await readJson(storage, SEARCH_INDEX_FILE);
      const legacyState = !config && !runtime && !search ? await readJson(storage, LEGACY_STATE_FILE) : null;
      const loaded = legacyState || (config || runtime || search ? {
        ...runtime || {},
        ...config || {},
        ...search || {}
      } : null);
      if (loaded && (loaded.entries || loaded.users || loaded.storages || loaded.sharings)) {
        return {
          shouldSave: !!legacyState,
          state: {
            ...defaultState(now),
            ...loaded,
            settings: { ...defaultSettings(), ...loaded.settings || {} },
            users: normalizeUsers(loaded.users),
            tasks: loaded.tasks || {},
            metas: loaded.metas || [],
            messages: loaded.messages || [],
            ssh_keys: loaded.ssh_keys || [],
            scan: loaded.scan || { status: "idle", total: 0, done: 0 },
            webdav_locks: loaded.webdav_locks || {},
            s3_multipart_uploads: loaded.s3_multipart_uploads || {},
            sharings: loaded.sharings || [],
            search_nodes: loaded.search_nodes || []
          }
        };
      }
    } catch (_) {
    }
    return {
      shouldSave: true,
      state: defaultState(now)
    };
  };
  const createTaskHandlers = ({
    parseJson,
    queryValue,
    taskStore
  }) => {
    const map = {};
    const parseTaskRequest = async (request) => {
      const req = await parseJson(request);
      return {
        req,
        tid: queryValue(request, "tid") || req.tid || req.id || ""
      };
    };
    const taskId = async (request) => (await parseTaskRequest(request)).tid;
    const targeted = (type, callback) => async (request) => {
      const tid = await taskId(request);
      const task = taskStore.getTask(type, tid);
      if (!task) return jsonResponse(failure("task not found", 404));
      await callback(task, tid);
      return jsonResponse(success());
    };
    const batch = (type, callback) => async (request) => {
      const req = await parseJson(request);
      if (!Array.isArray(req)) return jsonResponse(failure("invalid request format", 400));
      const tids = req;
      const errors = {};
      for (const tid of tids) {
        if (!taskStore.getTask(type, tid)) {
          errors[tid] = "task not found";
          continue;
        }
        await callback(String(tid));
      }
      return jsonResponse(success(errors));
    };
    for (const type of TASK_TYPES) {
      map[`GET /api/task/${type}/undone`] = async () => jsonResponse(success(taskStore.listTasks(type, false)));
      map[`GET /api/task/${type}/done`] = async () => jsonResponse(success(taskStore.listTasks(type, true)));
      const infoHandler = async (request) => {
        const task = taskStore.getTask(type, await taskId(request));
        return task ? jsonResponse(success(task)) : jsonResponse(failure("task not found", 404));
      };
      map[`POST /api/task/${type}/info`] = infoHandler;
      map[`GET /api/task/${type}/info`] = infoHandler;
      map[`POST /api/task/${type}/retry`] = targeted(type, async (_, tid) => taskStore.retryTask(type, tid));
      map[`POST /api/task/${type}/retry_failed`] = async () => {
        await taskStore.retryFailed(type);
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/clear_done`] = async () => {
        await taskStore.clearDone(type);
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/clear_succeeded`] = async () => {
        await taskStore.clearSucceeded(type);
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/cancel`] = targeted(type, async (_, tid) => taskStore.markCanceled(type, tid));
      map[`POST /api/task/${type}/delete`] = targeted(type, async (_, tid) => taskStore.removeTask(type, tid));
      map[`POST /api/task/${type}/cancel_some`] = batch(type, async (tid) => taskStore.markCanceled(type, tid));
      map[`POST /api/task/${type}/delete_some`] = batch(type, async (tid) => taskStore.removeTask(type, tid));
      map[`POST /api/task/${type}/retry_some`] = batch(type, async (tid) => taskStore.retryTask(type, tid));
    }
    return map;
  };
  const normalizeMeta = (input, id) => ({
    id: Number(input.id || input.ID || id || 0),
    path: normalizePath(input.path || input.Path || "/"),
    read_users: Array.isArray(input.read_users) ? input.read_users : [],
    read_users_sub: !!input.read_users_sub,
    write_users: Array.isArray(input.write_users) ? input.write_users : [],
    write_users_sub: !!input.write_users_sub,
    password: String(input.password || ""),
    p_sub: !!input.p_sub,
    write: !!input.write,
    w_sub: !!input.w_sub,
    hide: String(input.hide || ""),
    h_sub: !!input.h_sub,
    readme: String(input.readme || ""),
    r_sub: !!input.r_sub,
    header: String(input.header || ""),
    header_sub: !!input.header_sub
  });
  const metaCoversPath = (metaPath, path, includeSub) => {
    const meta = normalizePath(metaPath);
    const target = normalizePath(path);
    if (meta === target) return true;
    return !!includeSub && target.startsWith(meta === "/" ? "/" : meta + "/");
  };
  const nearestMeta = (state, path) => {
    const target = normalizePath(path);
    return (state.metas || []).filter((meta) => metaCoversPath(meta.path, target, true)).sort((a, b) => b.path.length - a.path.length)[0] || null;
  };
  const validateHideRules = (hide) => {
    for (const line of String(hide || "").split(/\r?\n/)) {
      if (!line.trim()) continue;
    }
  };
  const isHiddenByMeta = (meta, path, name) => {
    if (!meta || !meta.hide || !metaCoversPath(meta.path, path, meta.h_sub)) return false;
    for (const line of String(meta.hide).split(/\r?\n/)) {
      if (!line.trim()) continue;
      try {
        const pattern = new RegExp(line);
        if (pattern.test(name) || pattern.test(path)) return true;
      } catch (_) {
        return false;
      }
    }
    return false;
  };
  const metaReadme = (meta, path) => meta && metaCoversPath(meta.path, path, meta.r_sub) ? meta.readme : "";
  const metaHeader = (meta, path) => meta && metaCoversPath(meta.path, path, meta.header_sub) ? meta.header : "";
  const createFsHandlers = ({
    cloneEntryTree,
    createFile: createFile2,
    driverRuntime,
    ensureDir,
    getState,
    isWorkspacePath,
    moveEntryTree,
    now,
    page,
    parseJson,
    removeEmptyDirs,
    removeEntry,
    renameEntryInDir,
    saveConfigState,
    saveState: saveState2,
    searchIndex,
    shareGet,
    shareClientIP: shareClientIP2,
    shareList,
    siyuanApiJson,
    taskStore,
    toFsGetResp,
    toObjResp,
    workspaceGet,
    workspaceList,
    workspaceRelPath
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const boolValue2 = (value, fallback = false) => {
      if (value === void 0 || value === null || value === "") return fallback;
      return value === true || value === "true" || value === 1 || value === "1";
    };
    const storageShouldProxy = (storage) => {
      var _a;
      const config = ((_a = driverInfoMap()[storage == null ? void 0 : storage.driver]) == null ? void 0 : _a.config) || {};
      return boolValue2(config.only_proxy) || boolValue2(storage == null ? void 0 : storage.web_proxy, boolValue2(config.prefer_proxy));
    };
    const proxyRawUrl = (path) => `/plugin/private/siyuan-cloud/p${normalizePath(path)}`;
    const rawUrlForStorage = (storage, path, linkUrl = "") => storageShouldProxy(storage) ? proxyRawUrl(path) : linkUrl;
    const requestMeta = (request) => (request == null ? void 0 : request.request) || (request == null ? void 0 : request.Request) || {};
    const requestHeaders2 = (request) => {
      var _a, _b;
      return ((_a = requestMeta(request)) == null ? void 0 : _a.headers) || ((_b = requestMeta(request)) == null ? void 0 : _b.Headers) || {};
    };
    const requestHeader2 = (request, name) => {
      const target = String(name || "").toLowerCase();
      for (const [key, value] of Object.entries(requestHeaders2(request))) {
        if (String(key).toLowerCase() !== target) continue;
        return Array.isArray(value) ? String(value[0] || "") : String(value || "");
      }
      return "";
    };
    const requestContentType = (request) => {
      var _a, _b;
      return requestHeader2(request, "Content-Type") || ((_a = requestMeta(request)) == null ? void 0 : _a.contentType) || ((_b = requestMeta(request)) == null ? void 0 : _b.ContentType) || "application/octet-stream";
    };
    const decodePathValue = (value) => {
      const input = String(value || "");
      if (!input) return "";
      try {
        return decodeURIComponent(input);
      } catch (_) {
        return input;
      }
    };
    const requestBodyData = (request) => {
      var _a, _b;
      const body = ((_a = requestMeta(request)) == null ? void 0 : _a.body) || ((_b = requestMeta(request)) == null ? void 0 : _b.Body) || {};
      return body.data !== void 0 ? body.data : body.Data;
    };
    const firstFormFile = (files) => {
      for (const value of Object.values(files || {})) {
        if (Array.isArray(value) && value[0]) return value[0];
      }
      return null;
    };
    const arrayBufferFromBytes = (value) => {
      if (value instanceof Uint8Array) return value;
      if (value instanceof ArrayBuffer) return new Uint8Array(value);
      if (Array.isArray(value)) return Uint8Array.from(value.map((item) => Number(item) & 255));
      if (value && typeof value === "object" && Array.isArray(value.data)) {
        return Uint8Array.from(value.data.map((item) => Number(item) & 255));
      }
      return null;
    };
    const bytesToBase642 = (bytes2) => {
      if (!bytes2 || !bytes2.length) return "";
      const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      let output = "";
      for (let index = 0; index < bytes2.length; index += 3) {
        const a = bytes2[index];
        const hasB = index + 1 < bytes2.length;
        const hasC = index + 2 < bytes2.length;
        const b = hasB ? bytes2[index + 1] : 0;
        const c = hasC ? bytes2[index + 2] : 0;
        output += chars2[a >> 2];
        output += chars2[(a & 3) << 4 | b >> 4];
        output += hasB ? chars2[(b & 15) << 2 | c >> 6] : "=";
        output += hasC ? chars2[c & 63] : "=";
      }
      return output;
    };
    const overwriteEnabled = (request, req) => {
      const header = requestHeader2(request, "Overwrite");
      if (header) return header !== "false";
      if (req.overwrite === void 0 || req.overwrite === null || req.overwrite === "") return true;
      return boolValue2(req.overwrite, true);
    };
    const uploadTargetExists = async (path) => {
      if (isWorkspacePath(path)) {
        const payload = await siyuanApiJson("/api/file/readDir", { path: workspaceRelPath(dirname(path)) });
        if (payload.code !== 0) return false;
        return (payload.data || []).some((entry) => (entry == null ? void 0 : entry.name) === basename(path));
      }
      const mount = driverRuntime.resolve(state.storages, path);
      if (mount) {
        try {
          await mount.driver.get(mount.storage, mount.relPath, { skipLink: true });
          return true;
        } catch (_) {
          return false;
        }
      }
      return !!state.entries[path];
    };
    const uploadFromRawRequest = async (request, req, fallbackName) => {
      const rawPath = req.path || req.file_path || req.name || decodePathValue(requestHeader2(request, "File-Path")) || fallbackName;
      const path = normalizePath(rawPath);
      const mime = req.mime || requestContentType(request);
      const data = requestBodyData(request);
      if (typeof data === "string") {
        return { body: data, bodyEncoding: "text", mime, path, size: data.length };
      }
      const bytes2 = arrayBufferFromBytes(data);
      if (bytes2) {
        return {
          body: bytesToBase642(bytes2),
          bodyEncoding: "base64",
          mime,
          path,
          size: bytes2.byteLength
        };
      }
      const content = req.content ?? req.data ?? "";
      return {
        body: String(content),
        bodyEncoding: "text",
        mime,
        path,
        size: String(content).length
      };
    };
    const uploadFromFormRequest = async (request, req) => {
      var _a, _b, _c, _d;
      const file = firstFormFile(req.files);
      const fileData = (file == null ? void 0 : file.data) ?? (file == null ? void 0 : file.Data);
      const bytes2 = arrayBufferFromBytes(fileData);
      const filename = (file == null ? void 0 : file.filename) || (file == null ? void 0 : file.Filename) || req.file_name || req.name || "upload.bin";
      const path = normalizePath(req.path || req.file_path || decodePathValue(requestHeader2(request, "File-Path")) || joinPath(req.dir || dirname(req.path || "/"), filename));
      const mime = ((_b = (_a = file == null ? void 0 : file.headers) == null ? void 0 : _a["Content-Type"]) == null ? void 0 : _b[0]) || ((_d = (_c = file == null ? void 0 : file.Headers) == null ? void 0 : _c["Content-Type"]) == null ? void 0 : _d[0]) || req.mime || requestContentType(request);
      if (bytes2) {
        return {
          body: bytesToBase642(bytes2),
          bodyEncoding: "base64",
          mime,
          path,
          size: bytes2.byteLength
        };
      }
      return {
        body: "",
        bodyEncoding: "text",
        mime,
        path,
        size: Number((file == null ? void 0 : file.size) || (file == null ? void 0 : file.Size) || 0)
      };
    };
    const joinPath = (dir, name) => normalizePath(`${normalizePath(dir || "/").replace(/\/+$/, "")}/${String(name).replace(/^\/+/, "")}`);
    const driverPut = async (mount, upload) => {
      await mount.driver.put(mount.storage, mount.relPath, upload.body, upload.mime, {
        bodyEncoding: upload.bodyEncoding,
        size: upload.size
      });
    };
    const sameStorageMount = (left, right) => {
      var _a, _b, _c, _d;
      return !!left && !!right && (((_a = left.storage) == null ? void 0 : _a.id) && ((_b = right.storage) == null ? void 0 : _b.id) && left.storage.id === right.storage.id || normalizePath(((_c = left.storage) == null ? void 0 : _c.mount_path) || "/") === normalizePath(((_d = right.storage) == null ? void 0 : _d.mount_path) || "/"));
    };
    const torrentNotImplemented = (operation) => ({
      operation,
      reason: "torrent parsing and CAS rapid upload are not implemented in the SiYuan kernel JavaScript port yet.",
      upstream_source: "server/handles/torrent.go + pkg/torrent/* + drivers/189pc/torrent.go",
      next: "Port a JavaScript bencode/torrent reader and 189/189PC CAS rapid-upload flow before enabling this route."
    });
    const fsTorrentPlaceholder = (operation, req = {}) => jsonResponse(failure(
      "torrent operations are not implemented in the SiYuan kernel port yet",
      501,
      {
        ...torrentNotImplemented(operation),
        name: req.path || req.file_name || req.name || "torrent"
      }
    ), 501);
    const fsTorrentRequiredError = (field2) => jsonResponse(failure(`${field2} is required`, 400), 400);
    const fsTorrentValidate = (operation, req = {}) => {
      if ((operation === "parse" || operation === "upload_parse" || operation === "rapid_upload") && !req.torrent_data)
        return fsTorrentRequiredError("torrent_data");
      if ((operation === "rapid_upload" || operation === "generate") && !req.path)
        return fsTorrentRequiredError("path");
      return null;
    };
    const shouldSkipExisting = (req) => boolValue2(req.skip_existing, false);
    const shouldMerge = (req) => boolValue2(req.merge, false);
    const shouldOverwrite = (req) => boolValue2(req.overwrite, false);
    const driverTargetIsDir = async (path) => {
      var _a;
      const mount = driverRuntime.resolve(state.storages, path);
      if (!mount) return false;
      try {
        return !!((_a = await mount.driver.get(mount.storage, mount.relPath, { skipLink: true })) == null ? void 0 : _a.is_dir);
      } catch (_) {
        return false;
      }
    };
    const extensionType = (name, isDir2) => {
      if (isDir2) return 1;
      const ext = String(name).toLowerCase().split(".").pop() || "";
      if (["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif"].includes(ext)) return 2;
      if (["mp4", "mkv", "mov", "avi", "webm", "m4v"].includes(ext)) return 3;
      if (["mp3", "flac", "wav", "ogg", "m4a"].includes(ext)) return 4;
      if (["zip", "7z", "rar", "tar", "gz", "bz2"].includes(ext)) return 5;
      if (["pdf", "epub", "txt", "md", "json", "yaml", "yml", "csv", "log"].includes(ext)) return 6;
      return 0;
    };
    const driverObjResp = (item) => ({
      name: item.name || "",
      size: Number(item.size || 0),
      is_dir: !!item.is_dir,
      modified: item.modified || (/* @__PURE__ */ new Date()).toISOString(),
      created: item.created || item.modified || (/* @__PURE__ */ new Date()).toISOString(),
      sign: item.sign || "",
      thumb: item.thumb || "",
      type: Number(item.type || extensionType(item.name, item.is_dir)),
      hashinfo: item.hashinfo || "",
      hash_info: item.hash_info || {}
    });
    const driverListResp = (data) => {
      const content = (data.content || []).map(driverObjResp);
      return {
        content,
        total: Number(data.total || content.length),
        readme: data.readme || "",
        header: data.header || "",
        write: data.write !== false,
        write_content_bypass: data.write_content_bypass !== false,
        provider: data.provider || "unknown",
        direct_upload_tools: data.direct_upload_tools || []
      };
    };
    const driverGetResp = (data, rawUrl = "") => ({
      ...driverObjResp(data),
      raw_url: rawUrl || data.raw_url || "",
      readme: data.readme || "",
      header: data.header || "",
      provider: data.provider || "unknown",
      related: (data.related || []).map(driverObjResp)
    });
    const handlers = {
      "ANY /api/fs/list": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path);
        const sharing = await shareList({ ...req, client_ip: shareClientIP2 == null ? void 0 : shareClientIP2(request), path });
        if (sharing == null ? void 0 : sharing.error) return jsonResponse(sharing.error);
        if (sharing == null ? void 0 : sharing.data) return jsonResponse(success(sharing.data));
        if (isWorkspacePath(path)) {
          const result = await workspaceList(path, req);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success(result.data));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            const data = await mount.driver.list(mount.storage, mount.relPath, req);
            return jsonResponse(success(driverListResp(data)));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver list failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        const entry = state.entries[path];
        if (!entry || !entry.is_dir) return jsonResponse(failure("directory not found", 404));
        const meta = nearestMeta(getState(), path);
        const children = entry.children.map((childPath) => state.entries[childPath]).filter(Boolean).filter((item) => !isHiddenByMeta(meta, item.path, item.name)).map(toObjResp);
        if (path === "/") {
          children.unshift(toObjResp({
            name: "@workspace",
            is_dir: true,
            size: 0,
            modified: now(),
            created: now()
          }));
          for (const mountEntry of driverRuntime.mountEntries(state.storages, now)) {
            if (!children.some((item) => item.name === mountEntry.name)) children.unshift(toObjResp(mountEntry));
          }
        }
        const content = page(children, req);
        return jsonResponse(success({
          content,
          total: children.length,
          readme: metaReadme(meta, path),
          header: metaHeader(meta, path),
          write: true,
          write_content_bypass: true,
          provider: "siyuan-storage",
          direct_upload_tools: []
        }));
      },
      "ANY /api/fs/get": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path);
        const sharing = await shareGet({ ...req, client_ip: shareClientIP2 == null ? void 0 : shareClientIP2(request), path });
        if (sharing == null ? void 0 : sharing.error) return jsonResponse(sharing.error);
        if (sharing == null ? void 0 : sharing.data) return jsonResponse(success(sharing.data));
        if (isWorkspacePath(path)) {
          const result = await workspaceGet(path);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success(result.data));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            const shouldProxy = storageShouldProxy(mount.storage);
            const data = await mount.driver.get(mount.storage, mount.relPath, { skipLink: shouldProxy });
            let rawUrl = data.raw_url || "";
            if (data && !data.is_dir && shouldProxy) {
              rawUrl = rawUrlForStorage(mount.storage, path);
            }
            return jsonResponse(success(driverGetResp(data, rawUrl)));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver get failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        const entry = state.entries[path];
        if (!entry) return jsonResponse(failure("object not found", 404));
        const meta = nearestMeta(getState(), path);
        return jsonResponse(success({
          ...toFsGetResp(entry, path),
          readme: metaReadme(meta, path),
          header: metaHeader(meta, path)
        }));
      },
      "ANY /api/fs/dirs": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path);
        if (isWorkspacePath(path)) {
          const result = await workspaceList(path, req);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success(result.data.content.filter((item) => item.is_dir).map((item) => ({
            name: item.name,
            modified: item.modified
          }))));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            const data = await mount.driver.list(mount.storage, mount.relPath, req);
            return jsonResponse(success((data.content || []).filter((item) => item.is_dir).map((item) => ({
              name: item.name,
              modified: item.modified || (/* @__PURE__ */ new Date()).toISOString()
            }))));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver dirs failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        const entry = state.entries[path];
        if (!entry || !entry.is_dir) return jsonResponse(failure("directory not found", 404));
        const dirs = entry.children.map((childPath) => state.entries[childPath]).filter((item) => item && item.is_dir).map((item) => ({ name: item.name, modified: item.modified }));
        return jsonResponse(success(dirs));
      },
      "ANY /api/fs/search": async (request) => {
        const req = await parseJson(request);
        const parent = normalizePath(req.parent || req.path || "/");
        const pageIndex = Number(req.page || 0);
        const perPage = Number(req.per_page || req.perPage || 0);
        if (!Number.isFinite(pageIndex) || pageIndex < 1) return jsonResponse(failure("page can't < 1", 400));
        if (!Number.isFinite(perPage) || perPage < 1) return jsonResponse(failure("per_page can't < 1", 400));
        const result = searchIndex.search({
          keywords: req.keywords || req.keyword || "",
          page: pageIndex,
          parent,
          per_page: perPage,
          scope: req.scope || 0
        });
        return jsonResponse(success(pageResp(result.content.map((node) => ({
          parent: node.parent,
          name: node.name,
          is_dir: node.is_dir,
          size: node.size,
          type: extensionType(node.name, node.is_dir)
        })), result.total)));
      },
      "POST /api/fs/mkdir": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path || [req.parent, req.name].filter(Boolean).join("/"));
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            await mount.driver.mkdir(mount.storage, mount.relPath);
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver mkdir failed", 502));
          }
        }
        ensureDir(dirname(path));
        ensureDir(path);
        await saveState2();
        return jsonResponse(success());
      },
      "PUT /api/fs/put": async (request) => {
        const req = await parseJson(request);
        const upload = await uploadFromRawRequest(request, req, "/untitled.txt");
        const path = upload.path;
        if (!overwriteEnabled(request, req) && await uploadTargetExists(path)) return jsonResponse(failure("file exists", 403));
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            await driverPut({ ...mount, relPath: mount.relPath }, upload);
            return jsonResponse(success({ path }));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver put failed", 502));
          }
        }
        if (isWorkspacePath(path)) {
          return jsonResponse(failure("workspace upload is blocked until /api/file/putFile multipart bridging is proven in the kernel plugin runtime", 501));
        }
        createFile2(path, upload.body, upload.mime, {
          bodyEncoding: upload.bodyEncoding,
          size: upload.size
        });
        await saveState2();
        return jsonResponse(success({ path }));
      },
      "PUT /api/fs/form": async (request) => {
        const req = await parseJson(request);
        const upload = await uploadFromFormRequest(request, req);
        const path = upload.path;
        if (!overwriteEnabled(request, req) && await uploadTargetExists(path)) return jsonResponse(failure("file exists", 403));
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            await driverPut({ ...mount, relPath: mount.relPath }, upload);
            return jsonResponse(success({ path }));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver put failed", 502));
          }
        }
        if (isWorkspacePath(path)) {
          return jsonResponse(failure("workspace upload is blocked until /api/file/putFile multipart bridging is proven in the kernel plugin runtime", 501));
        }
        createFile2(path, upload.body, upload.mime, {
          bodyEncoding: upload.bodyEncoding,
          size: upload.size
        });
        await saveState2();
        return jsonResponse(success({ path }));
      },
      "POST /api/fs/remove": async (request) => {
        const req = await parseJson(request);
        const names = Array.isArray(req.names) ? req.names : [];
        const dir = normalizePath(req.dir || req.path || "/");
        if (!names.length) return jsonResponse(failure("Empty file names", 400));
        let storageRemoved = false;
        if (isWorkspacePath(dir)) {
          for (const name of names) {
            const payload = await siyuanApiJson("/api/file/removeFile", { path: workspaceRelPath(normalizePath(dir + "/" + name)) });
            if (payload.code !== 0 && payload.code !== 404) return jsonResponse(failure(payload.msg || "removeFile failed", payload.code || 500));
          }
          return jsonResponse(success());
        }
        const mount = driverRuntime.resolve(state.storages, dir);
        if (mount) {
          try {
            for (const name of names) {
              await mount.driver.remove(mount.storage, normalizePath(mount.relPath + "/" + name));
            }
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver remove failed", 502));
          }
        }
        for (const name of names) {
          const path = normalizePath(dir + "/" + name);
          const storage = state.storages.find((item) => Number(item.id) !== 1 && normalizePath(item.mount_path || "/") === path);
          if (storage) {
            state.storages = state.storages.filter((item) => item !== storage);
            storageRemoved = true;
          } else {
            removeEntry(path);
          }
        }
        await (storageRemoved ? saveConfigState == null ? void 0 : saveConfigState() : saveState2());
        return jsonResponse(success());
      },
      "POST /api/fs/rename": async (request) => {
        const req = await parseJson(request);
        const oldPath = normalizePath(req.path);
        const newName = String(req.name || "").trim();
        if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
        if (oldPath === "/") return jsonResponse(failure("rename root folder is not allowed", 500));
        if (!boolValue2(req.overwrite, false)) {
          const dstPath = normalizePath(dirname(oldPath) + "/" + newName);
          if (dstPath !== oldPath && await uploadTargetExists(dstPath)) {
            return jsonResponse(failure(`file [${newName}] exists`, 403));
          }
        }
        const mount = driverRuntime.resolve(state.storages, oldPath);
        if (mount) {
          if (mount.relPath === "/") return jsonResponse(failure("rename root folder is not allowed", 500));
          try {
            await mount.driver.rename(mount.storage, mount.relPath, newName);
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver rename failed", 502));
          }
        }
        if (isWorkspacePath(oldPath)) {
          if (normalizePath(workspaceRelPath(oldPath)) === "/") return jsonResponse(failure("rename root folder is not allowed", 500));
          const newPath = normalizePath(dirname(oldPath) + "/" + newName);
          const payload = await siyuanApiJson("/api/file/renameFile", {
            path: workspaceRelPath(oldPath),
            newPath: workspaceRelPath(newPath)
          });
          if (payload.code !== 0) return jsonResponse(failure(payload.msg || "renameFile failed", payload.code || 500));
          return jsonResponse(success());
        }
        const entry = state.entries[oldPath];
        if (!entry) return jsonResponse(failure("object not found", 404));
        try {
          renameEntryInDir(dirname(oldPath), entry.name, newName, { overwrite: req.overwrite });
        } catch (error) {
          return jsonResponse(failure(error.message, error.message.includes("exists") ? 403 : 400));
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/move": async (request) => {
        const req = await parseJson(request);
        const names = Array.isArray(req.names) ? req.names : [];
        if (!names.length) return jsonResponse(failure("Empty file names", 400));
        const srcDir = normalizePath(req.src_dir);
        const dstDir = normalizePath(req.dst_dir);
        const srcMount = driverRuntime.resolve(state.storages, srcDir);
        const dstMount = driverRuntime.resolve(state.storages, dstDir);
        if (srcMount || dstMount) {
          if (!srcMount || !dstMount || !sameStorageMount(srcMount, dstMount) || !srcMount.driver.move) {
            return jsonResponse(failure("driver move across mount boundaries is not implemented in the SiYuan kernel port yet", 501));
          }
          for (const name of names) {
            const srcPath = normalizePath(srcDir + "/" + name);
            const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
            if (!shouldOverwrite(req) && await uploadTargetExists(dstPath)) {
              if (!shouldSkipExisting(req)) return jsonResponse(failure(`file [${name}] exists`, 403));
              continue;
            }
            await srcMount.driver.move(srcMount.storage, normalizePath(srcMount.relPath + "/" + name), dstMount.relPath);
          }
          const task2 = await taskStore.addTask("move", {
            name: `move ${names.length} item(s)`,
            status: "Move operations completed immediately"
          });
          return jsonResponse(success({ message: "Move operations completed immediately", tasks: [task2] }));
        }
        ensureDir(dstDir);
        for (const name of names) {
          const srcPath = normalizePath(srcDir + "/" + name);
          const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
          if (!state.entries[srcPath]) continue;
          if (!shouldOverwrite(req) && state.entries[dstPath]) {
            if (!shouldSkipExisting(req)) return jsonResponse(failure(`file [${name}] exists`, 403));
            continue;
          }
          if (state.entries[dstPath]) removeEntry(dstPath);
          moveEntryTree(srcPath, dstPath);
        }
        const task = await taskStore.addTask("move", {
          name: `move ${names.length} item(s)`,
          status: "Move operations completed immediately"
        });
        return jsonResponse(success({ message: "Move operations completed immediately", tasks: [task] }));
      },
      "POST /api/fs/copy": async (request) => {
        const req = await parseJson(request);
        const names = Array.isArray(req.names) ? req.names : [];
        if (!names.length) return jsonResponse(failure("Empty file names", 400));
        const srcDir = normalizePath(req.src_dir);
        const dstDir = normalizePath(req.dst_dir);
        const srcMount = driverRuntime.resolve(state.storages, srcDir);
        const dstMount = driverRuntime.resolve(state.storages, dstDir);
        if (srcMount || dstMount) {
          if (!srcMount || !dstMount || !sameStorageMount(srcMount, dstMount) || !srcMount.driver.copy) {
            return jsonResponse(failure("driver copy across mount boundaries is not implemented in the SiYuan kernel port yet", 501));
          }
          for (const name of names) {
            const srcPath = normalizePath(srcDir + "/" + name);
            const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
            if (!shouldOverwrite(req) && await uploadTargetExists(dstPath)) {
              if (!shouldSkipExisting(req)) return jsonResponse(failure(`file [${name}] exists`, 403));
              if (!shouldMerge(req) || !await driverTargetIsDir(dstPath)) continue;
            }
            await srcMount.driver.copy(srcMount.storage, normalizePath(srcMount.relPath + "/" + name), dstMount.relPath);
          }
          const task2 = await taskStore.addTask("copy", {
            name: `copy ${names.length} item(s)`,
            status: "Copy operations completed immediately"
          });
          return jsonResponse(success({ message: "Copy operations completed immediately", tasks: [task2] }));
        }
        ensureDir(dstDir);
        for (const name of names) {
          const srcPath = normalizePath(srcDir + "/" + name);
          const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
          if (!state.entries[srcPath]) continue;
          if (!shouldOverwrite(req) && state.entries[dstPath]) {
            if (!shouldSkipExisting(req)) return jsonResponse(failure(`file [${name}] exists`, 403));
            if (!shouldMerge(req) || !state.entries[dstPath].is_dir) continue;
          }
          if (state.entries[dstPath] && !shouldMerge(req)) removeEntry(dstPath);
          cloneEntryTree(srcPath, dstPath);
        }
        const task = await taskStore.addTask("copy", {
          name: `copy ${names.length} item(s)`,
          status: "Copy operations completed immediately"
        });
        return jsonResponse(success({ message: "Copy operations completed immediately", tasks: [task] }));
      },
      "POST /api/fs/batch_rename": async (request) => {
        const req = await parseJson(request);
        const srcDir = normalizePath(req.src_dir || "/");
        const renameObjects = Array.isArray(req.rename_objects) ? req.rename_objects : [];
        if (isWorkspacePath(srcDir)) {
          for (const item of renameObjects) {
            const srcName = String(item.src_name || "").trim();
            const newName = String(item.new_name || "").trim();
            if (!srcName || !newName) continue;
            if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
            const srcPath = normalizePath(srcDir + "/" + srcName);
            const newPath = normalizePath(srcDir + "/" + newName);
            const payload = await siyuanApiJson("/api/file/renameFile", {
              path: workspaceRelPath(srcPath),
              newPath: workspaceRelPath(newPath)
            });
            if (payload.code !== 0) return jsonResponse(failure(payload.msg || "renameFile failed", payload.code || 500));
          }
          return jsonResponse(success());
        }
        for (const item of renameObjects) {
          const srcName = String(item.src_name || "").trim();
          const newName = String(item.new_name || "").trim();
          if (!srcName || !newName) continue;
          try {
            renameEntryInDir(srcDir, srcName, newName, { overwrite: !!req.overwrite });
          } catch (error) {
            return jsonResponse(failure(error.message, error.message.includes("exists") ? 403 : 400));
          }
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/regex_rename": async (request) => {
        const req = await parseJson(request);
        const srcDir = normalizePath(req.src_dir || "/");
        let pattern;
        try {
          pattern = new RegExp(String(req.src_name_regex || ""));
        } catch (error) {
          return jsonResponse(failure(error.message, 400));
        }
        const replacement = String(req.new_name_regex || "");
        if (isWorkspacePath(srcDir)) {
          const result = await workspaceList(srcDir, { page: 1, per_page: 1e5 });
          if (result.error) return jsonResponse(result.error);
          for (const file of result.data.content || []) {
            if (!pattern.test(file.name)) continue;
            pattern.lastIndex = 0;
            const newName = file.name.replace(pattern, replacement);
            if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
            const payload = await siyuanApiJson("/api/file/renameFile", {
              path: workspaceRelPath(normalizePath(srcDir + "/" + file.name)),
              newPath: workspaceRelPath(normalizePath(srcDir + "/" + newName))
            });
            if (payload.code !== 0) return jsonResponse(failure(payload.msg || "renameFile failed", payload.code || 500));
          }
          return jsonResponse(success());
        }
        const dir = state.entries[srcDir];
        if (!dir || !dir.is_dir) return jsonResponse(failure("directory not found", 404));
        for (const childPath of [...dir.children || []]) {
          const entry = state.entries[childPath];
          if (!entry || !pattern.test(entry.name)) continue;
          pattern.lastIndex = 0;
          const newName = entry.name.replace(pattern, replacement);
          try {
            renameEntryInDir(srcDir, entry.name, newName, { overwrite: !!req.overwrite });
          } catch (error) {
            return jsonResponse(failure(error.message, error.message.includes("exists") ? 403 : 400));
          }
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/recursive_move": async (request) => {
        const req = await parseJson(request);
        const srcDir = normalizePath(req.src_dir || "/");
        const dstDir = normalizePath(req.dst_dir || "/");
        const conflictPolicy = String(req.conflict_policy || "skip").toLowerCase();
        if (isWorkspacePath(srcDir) || isWorkspacePath(dstDir)) {
          return jsonResponse(failure("recursive move for /@workspace is not available until workspace upload/move is completed", 501));
        }
        const src = state.entries[srcDir];
        if (!src || !src.is_dir) return jsonResponse(failure("source directory not found", 404));
        ensureDir(dstDir);
        const files = Object.values(state.entries).filter((entry) => entry.path !== srcDir && entry.path.startsWith(srcDir + "/") && !entry.is_dir).sort((a, b) => a.path.localeCompare(b.path));
        let count = 0;
        for (const file of files) {
          const dstPath = normalizePath(dstDir + "/" + file.name);
          if (dirname(file.path) === dstDir) continue;
          if (state.entries[dstPath]) {
            if (conflictPolicy === "cancel") return jsonResponse(failure(`file [${file.name}] exists`, 403));
            if (conflictPolicy === "skip") continue;
            removeEntry(dstPath);
          }
          moveEntryTree(file.path, dstPath);
          count += 1;
        }
        await saveState2();
        return jsonResponse(successWithMessage(`Successfully moved ${count} ${count === 1 ? "file" : "files"}`));
      },
      "POST /api/fs/remove_empty_directory": async (request) => {
        const req = await parseJson(request);
        removeEmptyDirs(normalizePath(req.src_dir || "/"));
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/link": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path);
        if (isWorkspacePath(path)) {
          const result = await workspaceGet(path);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success({ url: "/plugin/private/siyuan-cloud/d" + path }));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount && mount.driver.read) {
          try {
            const data = await mount.driver.read(mount.storage, mount.relPath, {});
            const link = linkFromDriverData(data);
            return jsonResponse(success({
              url: link.url,
              header: link.header,
              method: link.method,
              content_length: link.content_length,
              raw_url: rawUrlForStorage(mount.storage, path, link.url),
              provider: mount.storage.driver
            }));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver link failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        if (!state.entries[path]) return jsonResponse(failure("object not found", 404));
        return jsonResponse(success({ url: "/plugin/private/siyuan-cloud/d" + path }));
      },
      "POST /api/fs/add_offline_download": async (request) => {
        const req = await parseJson(request);
        const urls = (Array.isArray(req.urls) ? req.urls : [req.url]).map((url) => String(url || "").trim()).filter(Boolean);
        const tasks = [];
        for (const url of urls) {
          tasks.push(await taskStore.addTask("offline_download", {
            delete_policy: req.delete_policy || "",
            dst_dir_path: normalizePath(req.path || "/"),
            error: "offline download is not implemented in the SiYuan kernel port yet",
            name: url,
            status: "not implemented",
            tool: req.tool || "",
            url
          }));
        }
        return jsonResponse(failure(
          "offline download is not implemented in the SiYuan kernel port yet",
          501,
          { tasks }
        ), 501);
      },
      "POST /api/fs/get_direct_upload_info": async (request) => {
        var _a;
        const req = await parseJson(request);
        const path = normalizePath(req.path || req.file_path || "/");
        if (!overwriteEnabled(request, req) && await uploadTargetExists(path)) return jsonResponse(failure("file exists", 403));
        const mount = driverRuntime.resolve(state.storages, path);
        if ((_a = mount == null ? void 0 : mount.driver) == null ? void 0 : _a.getDirectUploadInfo) {
          try {
            const data = await mount.driver.getDirectUploadInfo(mount.storage, mount.relPath, req);
            return jsonResponse(success(data));
          } catch (error) {
            return jsonResponse(failure(error.message || "get direct upload info failed", 502));
          }
        }
        return jsonResponse(success(null));
      },
      "ANY /api/fs/other": async () => jsonResponse(success(null))
    };
    for (const operation of ["parse", "upload_parse", "rapid_upload", "generate"]) {
      handlers[`POST /api/fs/torrent/${operation}`] = async (request) => {
        const req = await parseJson(request);
        return fsTorrentValidate(operation, req) || fsTorrentPlaceholder(operation, req);
      };
    }
    return handlers;
  };
  const randomShareId = () => Math.random().toString(36).slice(2, 10);
  const validSharingID = /^[\w\u4e00-\u9fff-]+$/u;
  const shareIdOf = (share) => String((share == null ? void 0 : share.id) || "");
  const sharePwdOf = (share) => String((share == null ? void 0 : share.pwd) ?? "");
  const shareFilesOf = (share) => Array.isArray(share == null ? void 0 : share.files) ? share.files.map(normalizePath).filter(Boolean) : [];
  const accessCache = /* @__PURE__ */ new Map();
  const accessCountDelay = 30 * 60 * 1e3;
  const normalizeShare = (share = {}, now) => {
    const files = shareFilesOf(share);
    const id = shareIdOf(share) || randomShareId();
    return {
      id,
      files,
      expires: share.expires || null,
      pwd: sharePwdOf(share),
      accessed: Number(share.accessed || 0),
      max_accessed: Number(share.max_accessed || 0),
      disabled: !!share.disabled,
      remark: share.remark || "",
      readme: share.readme || "",
      header: share.header || "",
      order_by: share.order_by || "",
      order_direction: share.order_direction || "",
      extract_folder: share.extract_folder || "",
      creator: share.creator || share.creator_name || "admin",
      creator_role: Number(share.creator_role ?? 2),
      created: share.created || (now == null ? void 0 : now()) || "",
      modified: share.modified || (now == null ? void 0 : now()) || ""
    };
  };
  const shareResp = (share) => {
    const normalized = normalizeShare(share);
    return {
      ...normalized
    };
  };
  const validShare = (share, password2) => {
    const normalized = normalizeShare(share);
    if (!share || share.disabled) return false;
    if (normalized.max_accessed > 0 && normalized.accessed >= normalized.max_accessed) return false;
    if (normalized.pwd && normalized.pwd !== password2) return false;
    if (normalized.expires && !Number.isNaN(Date.parse(normalized.expires)) && Date.parse(normalized.expires) < Date.now()) return false;
    return true;
  };
  const shareNeedsPassword = ({ path, password: password2, state }) => {
    const normalized = normalizePath(path);
    const [sid] = normalized.replace(/^\/+/, "").split("/");
    if (!sid) return null;
    const source = state.sharings.find((item) => shareIdOf(item) === sid);
    if (!source) return null;
    const share = normalizeShare(source);
    if (source.disabled) return null;
    if (share.max_accessed > 0 && share.accessed >= share.max_accessed) return null;
    if (share.expires && !Number.isNaN(Date.parse(share.expires)) && Date.parse(share.expires) < Date.now()) return null;
    if (!share.pwd || share.pwd === password2) return null;
    return { sid, share: source, normalizedShare: share };
  };
  const sharePathInfo = ({ path, password: password2, state }) => {
    const normalized = normalizePath(path);
    const [sid, ...innerParts] = normalized.replace(/^\/+/, "").split("/");
    if (!sid) return null;
    const source = state.sharings.find((item) => shareIdOf(item) === sid);
    if (!validShare(source, password2)) return null;
    const share = normalizeShare(source);
    const inner = normalizePath("/" + innerParts.join("/"));
    if (share.files.length === 1 || inner !== "/") {
      const base = share.files.length === 1 ? share.files[0] : share.files.find((file) => basename(file) === inner.replace(/^\/+/, "").split("/")[0]);
      if (!base) return null;
      const rest = share.files.length === 1 ? inner : normalizePath("/" + inner.replace(/^\/+/, "").split("/").slice(1).join("/"));
      const targetPath = rest === "/" ? normalizePath(base) : normalizePath(`${base}/${rest.replace(/^\/+/, "")}`);
      return { inner, share: source, normalizedShare: share, targetPath };
    }
    return { inner, share: source, normalizedShare: share, targetPath: "/" };
  };
  const validateSharingID = (id) => {
    if (!id) return "";
    if ([...String(id)].length > 64) throw new Error("share id must be at most 64 characters");
    if (!validSharingID.test(String(id))) throw new Error("share id can only contain letters, numbers, underscores, hyphens, and CJK characters");
    return String(id);
  };
  const shareClientIP = (request) => {
    const meta = (request == null ? void 0 : request.request) || (request == null ? void 0 : request.Request) || {};
    const headers = meta.headers || meta.Headers || {};
    for (const name of ["X-Forwarded-For", "x-forwarded-for", "X-Real-IP", "x-real-ip"]) {
      const value = headers[name];
      const ip = Array.isArray(value) ? value[0] : value;
      if (ip) return String(ip).split(",")[0].trim();
    }
    return "127.0.0.1";
  };
  const countShareAccess = async ({ info, ip, saveState: saveState2 }) => {
    if (!(info == null ? void 0 : info.share)) return;
    const key = `${shareIdOf(info.share)}:${ip || "127.0.0.1"}`;
    const expires = accessCache.get(key);
    if (expires && expires > Date.now()) return;
    accessCache.set(key, Date.now() + accessCountDelay);
    info.share.accessed = Number(info.share.accessed || 0) + 1;
    await (saveState2 == null ? void 0 : saveState2());
  };
  const createShareReader = ({
    driverRuntime,
    getState,
    isWorkspacePath,
    page,
    toFsGetResp,
    toObjResp,
    workspaceGet,
    workspaceList,
    saveState: saveState2
  }) => {
    const extensionType = (name, isDir2) => {
      if (isDir2) return 1;
      const ext = String(name).toLowerCase().split(".").pop() || "";
      if (["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif"].includes(ext)) return 2;
      if (["mp4", "mkv", "mov", "avi", "webm", "m4v"].includes(ext)) return 3;
      if (["mp3", "flac", "wav", "ogg", "m4a"].includes(ext)) return 4;
      if (["zip", "7z", "rar", "tar", "gz", "bz2"].includes(ext)) return 5;
      if (["pdf", "epub", "txt", "md", "json", "yaml", "yml", "csv", "log"].includes(ext)) return 6;
      return 0;
    };
    const driverObjResp = (item) => ({
      name: item.name || "",
      size: Number(item.size || 0),
      is_dir: !!item.is_dir,
      modified: item.modified || (/* @__PURE__ */ new Date()).toISOString(),
      created: item.created || item.modified || (/* @__PURE__ */ new Date()).toISOString(),
      sign: item.sign || "",
      thumb: item.thumb || "",
      type: Number(item.type || extensionType(item.name, item.is_dir)),
      hashinfo: item.hashinfo || "",
      hash_info: item.hash_info || {}
    });
    const driverListResp = (data) => {
      const content = (data.content || []).map(driverObjResp);
      return {
        content,
        total: Number(data.total || content.length),
        readme: data.readme || "",
        header: data.header || "",
        write: false,
        write_content_bypass: false,
        provider: data.provider || "unknown",
        direct_upload_tools: data.direct_upload_tools || []
      };
    };
    const objForPath = async (state, path) => {
      if (isWorkspacePath(path)) {
        const result = await workspaceGet(path);
        return result.error ? null : result.data;
      }
      const mount = driverRuntime == null ? void 0 : driverRuntime.resolve(state.storages, path);
      if (mount) {
        try {
          return driverObjResp(await mount.driver.get(mount.storage, mount.relPath, { skipLink: true }));
        } catch (_) {
          return null;
        }
      }
      const entry = state.entries[path];
      return entry ? toObjResp(entry) : null;
    };
    const shareList = async (req) => {
      const state = getState();
      const info = sharePathInfo({ path: req.path, password: req.password || req.pwd, state });
      if (!info) return null;
      await countShareAccess({ info, ip: req.client_ip, saveState: saveState2 });
      if (info.normalizedShare.files.length > 1 && info.inner === "/") {
        const content = [];
        for (const file of info.normalizedShare.files) {
          const obj = await objForPath(state, file);
          if (obj) content.push({ ...obj, name: basename(file) });
        }
        return {
          data: {
            content: page(content, req),
            total: content.length,
            readme: info.normalizedShare.readme || "",
            header: info.normalizedShare.header || "",
            write: false,
            write_content_bypass: false,
            provider: "unknown",
            direct_upload_tools: []
          }
        };
      }
      if (isWorkspacePath(info.targetPath)) {
        const result = await workspaceList(info.targetPath, req);
        if (result.error) return { error: result.error };
        return {
          data: {
            ...result.data,
            readme: info.normalizedShare.readme || "",
            header: info.normalizedShare.header || "",
            write: false
          }
        };
      }
      const mount = driverRuntime == null ? void 0 : driverRuntime.resolve(state.storages, info.targetPath);
      if (mount) {
        try {
          const data = await mount.driver.list(mount.storage, mount.relPath, req);
          return {
            data: {
              ...driverListResp(data),
              readme: info.normalizedShare.readme || data.readme || "",
              header: info.normalizedShare.header || data.header || ""
            }
          };
        } catch (error) {
          return { error: failure(error.message || "driver list failed", 502) };
        }
      }
      const entry = state.entries[info.targetPath];
      if (!entry) return { error: failure("object not found", 404) };
      const children = entry.is_dir ? (entry.children || []).map((childPath) => state.entries[childPath]).filter(Boolean).map(toObjResp) : [toObjResp(entry)];
      return {
        data: {
          content: page(children, req),
          total: children.length,
          readme: info.normalizedShare.readme || "",
          header: info.normalizedShare.header || "",
          write: false,
          write_content_bypass: false,
          provider: "unknown",
          direct_upload_tools: []
        }
      };
    };
    const shareGet = async (req) => {
      const state = getState();
      const info = sharePathInfo({ path: req.path, password: req.password || req.pwd, state });
      if (!info) return null;
      await countShareAccess({ info, ip: req.client_ip, saveState: saveState2 });
      if (info.normalizedShare.files.length > 1 && info.inner === "/") {
        return {
          data: {
            name: shareIdOf(info.share),
            size: 0,
            is_dir: true,
            modified: "",
            created: "",
            sign: "",
            thumb: "",
            type: 1,
            raw_url: "",
            readme: info.normalizedShare.readme || "",
            header: info.normalizedShare.header || "",
            provider: "unknown",
            related: []
          }
        };
      }
      if (isWorkspacePath(info.targetPath)) {
        const result = await workspaceGet(info.targetPath);
        if (result.error) return { error: result.error };
        return {
          data: {
            ...result.data,
            raw_url: result.data.is_dir ? "" : `/plugin/private/siyuan-cloud/sd/${shareIdOf(info.share)}${info.inner}${info.normalizedShare.pwd ? `?pwd=${info.normalizedShare.pwd}` : ""}`,
            readme: info.normalizedShare.readme || "",
            header: info.normalizedShare.header || "",
            provider: "unknown"
          }
        };
      }
      const mount = driverRuntime == null ? void 0 : driverRuntime.resolve(state.storages, info.targetPath);
      if (mount) {
        try {
          const data = await mount.driver.get(mount.storage, mount.relPath, { skipLink: true });
          return {
            data: {
              ...driverObjResp(data),
              raw_url: data.is_dir ? "" : `/plugin/private/siyuan-cloud/sd/${shareIdOf(info.share)}${info.inner}${info.normalizedShare.pwd ? `?pwd=${info.normalizedShare.pwd}` : ""}`,
              readme: info.normalizedShare.readme || "",
              header: info.normalizedShare.header || "",
              provider: data.provider || mount.storage.driver || "unknown",
              related: []
            }
          };
        } catch (error) {
          return { error: failure(error.message || "driver get failed", 502) };
        }
      }
      const entry = state.entries[info.targetPath];
      if (!entry) return { error: failure("object not found", 404) };
      return {
        data: {
          ...toFsGetResp(entry, info.targetPath),
          raw_url: entry.is_dir ? "" : `/plugin/private/siyuan-cloud/sd/${shareIdOf(info.share)}${info.inner}${info.normalizedShare.pwd ? `?pwd=${info.normalizedShare.pwd}` : ""}`,
          readme: info.normalizedShare.readme || "",
          header: info.normalizedShare.header || "",
          provider: "unknown"
        }
      };
    };
    return { shareGet, shareList };
  };
  const createShareHandlers = ({
    driverRuntime,
    getState,
    isWorkspacePath,
    now,
    page,
    parseJson,
    queryValue,
    saveState: saveState2,
    workspaceGet
  }) => ({
    "ANY /api/share/list": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      state.sharings = state.sharings.map((share) => normalizeShare(share, now));
      const content = page(state.sharings.map(shareResp), req);
      return jsonResponse(success(pageResp(content, state.sharings.length)));
    },
    "GET /api/share/get": async (request) => {
      const state = getState();
      const id = queryValue(request, "id");
      const share = state.sharings.find((item) => shareIdOf(item) === id);
      if (!share) return jsonResponse(failure("sharing not found", 404));
      return jsonResponse(success(shareResp(share)));
    },
    "POST /api/share/create": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      let customId = "";
      try {
        customId = validateSharingID(req.id || "");
      } catch (error) {
        return jsonResponse(failure(error.message, 400));
      }
      const files = (Array.isArray(req.files) ? req.files : []).map(normalizePath).filter(Boolean);
      if (!files.length) return jsonResponse(failure("must add at least 1 object", 400));
      const id = customId || randomShareId();
      if (state.sharings.some((item) => shareIdOf(item) === id)) return jsonResponse(failure("UNIQUE constraint failed: sharings.id", 500));
      const share = normalizeShare({
        id,
        files,
        pwd: req.pwd ?? "",
        expires: req.expires || "",
        accessed: req.accessed || 0,
        max_accessed: req.max_accessed || 0,
        disabled: !!req.disabled,
        remark: req.remark || "",
        readme: req.readme || "",
        header: req.header || "",
        order_by: req.order_by || "",
        order_direction: req.order_direction || "",
        extract_folder: req.extract_folder || "",
        created: now(),
        modified: now()
      }, now);
      state.sharings.push(share);
      await saveState2();
      return jsonResponse(success(shareResp(share)));
    },
    "POST /api/share/update": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const share = state.sharings.find((item) => shareIdOf(item) === String(req.id || ""));
      if (!share) return jsonResponse(failure("sharing not found", 404));
      const files = Array.isArray(req.files) && req.files.length ? req.files.map(normalizePath) : shareFilesOf(share);
      if (!files.length) return jsonResponse(failure("must add at least 1 object", 400));
      Object.assign(share, {
        files,
        pwd: req.pwd ?? sharePwdOf(share),
        expires: req.expires ?? share.expires,
        accessed: Number(req.accessed ?? share.accessed ?? 0),
        max_accessed: Number(req.max_accessed ?? share.max_accessed ?? 0),
        disabled: req.disabled ?? share.disabled,
        remark: req.remark ?? share.remark,
        readme: req.readme ?? share.readme,
        header: req.header ?? share.header,
        order_by: req.order_by ?? share.order_by,
        order_direction: req.order_direction ?? share.order_direction,
        extract_folder: req.extract_folder ?? share.extract_folder,
        modified: now()
      });
      if (req.new_id && req.new_id !== shareIdOf(share)) {
        let candidateId = "";
        try {
          candidateId = validateSharingID(req.new_id);
        } catch (error) {
          return jsonResponse(failure(error.message, 400));
        }
        if (state.sharings.some((item) => item !== share && shareIdOf(item) === candidateId)) {
          return jsonResponse(failure("UNIQUE constraint failed: sharings.id", 500));
        }
        share.id = candidateId;
      }
      await saveState2();
      return jsonResponse(success(shareResp(share)));
    },
    "POST /api/share/delete": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const queryId = queryValue(request, "id");
      const ids = Array.isArray(req.ids) ? req.ids.map(String) : [String(queryId || req.id || "")];
      if (!ids.some((id) => state.sharings.some((item) => shareIdOf(item) === id))) {
        return jsonResponse(failure("sharing not found", 404));
      }
      state.sharings = state.sharings.filter((item) => !ids.includes(shareIdOf(item)));
      await saveState2();
      return jsonResponse(success());
    },
    "POST /api/share/enable": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const share = state.sharings.find((item) => shareIdOf(item) === String(queryValue(request, "id") || req.id || ""));
      if (!share) return jsonResponse(failure("sharing not found", 404));
      share.disabled = false;
      share.modified = now();
      await saveState2();
      return jsonResponse(success());
    },
    "POST /api/share/disable": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const share = state.sharings.find((item) => shareIdOf(item) === String(queryValue(request, "id") || req.id || ""));
      if (!share) return jsonResponse(failure("sharing not found", 404));
      share.disabled = true;
      share.modified = now();
      await saveState2();
      return jsonResponse(success());
    }
  });
  const createAdminHandlers = ({
    driverRuntime,
    getState,
    isWorkspacePath,
    listSettings,
    now,
    pageSlice,
    parseJson,
    queryValue,
    reloadConfigState,
    saveState: saveState2,
    saveToolSettings,
    settingItem,
    storageResp,
    workspaceGet
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const refreshConfig = async () => {
      await (reloadConfigState == null ? void 0 : reloadConfigState());
    };
    const storageAddition = (reqAddition, currentAddition = "{}") => {
      if (typeof reqAddition === "string") return reqAddition;
      if (reqAddition !== void 0) return JSON.stringify(reqAddition || {});
      return currentAddition || "{}";
    };
    const exportConfig = () => ({
      version: 1,
      exported_at: (/* @__PURE__ */ new Date()).toISOString(),
      source: "siyuan-cloud",
      settings: { ...state.settings },
      users: state.users.map((user) => ({ ...user })),
      storages: state.storages.map((storage) => ({ ...storage })),
      metas: (state.metas || []).map((meta) => ({ ...meta })),
      sharings: (state.sharings || []).map((share) => ({ ...share }))
    });
    const asArray = (value, fallback = []) => Array.isArray(value) ? value : fallback;
    const boolValue2 = (value, fallback = false) => {
      if (value === void 0 || value === null || value === "") return fallback;
      return value === true || value === "true" || value === 1 || value === "1";
    };
    const parseAddition2 = (value) => {
      if (!value) return {};
      if (typeof value === "object") return value;
      try {
        return JSON.parse(String(value || "{}"));
      } catch (_) {
        return {};
      }
    };
    const driverConfig = (driver) => {
      var _a;
      return ((_a = driverInfoMap()[driver]) == null ? void 0 : _a.config) || {};
    };
    const verifyDataFromError = (error, driver, addition) => {
      var _a, _b, _c, _d, _e;
      const message = (error == null ? void 0 : error.message) || "driver test failed";
      if (error == null ? void 0 : error.verify) {
        return {
          driver,
          addition: error.addition || addition,
          verify: error.verify
        };
      }
      const html = String(((_a = message.match(/need verify:\s*([\s\S]*)/i)) == null ? void 0 : _a[1]) || "");
      const qrSrc = ((_b = html.match(/<img[^>]+src=["']([^"']+)["']/i)) == null ? void 0 : _b[1]) || "";
      const qrText = ((_c = html.match(/<a[^>]+href=["']([^"']+)["']/i)) == null ? void 0 : _c[1]) || "";
      const qrData = ((_d = qrSrc.match(/base64,([^"')\s<]+)/i)) == null ? void 0 : _d[1]) || ((_e = html.match(/base64,([^"')\s<]+)/i)) == null ? void 0 : _e[1]) || "";
      return {
        driver,
        addition,
        verify: html ? {
          html,
          qr_data: qrData,
          qr_src: qrSrc,
          qr_text: qrText,
          type: "qrcode"
        } : null
      };
    };
    const proxyDefaults = (driver, source = {}) => {
      const config = driverConfig(driver);
      const addition = parseAddition2(source.addition);
      const quarkWebProxy = driver === "Quark" && !boolValue2(addition.use_transcoding_address);
      const preferProxy2 = boolValue2(config.prefer_proxy) || quarkWebProxy;
      return {
        web_proxy: boolValue2(source.web_proxy, preferProxy2),
        webdav_policy: source.webdav_policy || (preferProxy2 ? "native_proxy" : "302_redirect"),
        proxy_range: boolValue2(source.proxy_range),
        down_proxy_url: source.down_proxy_url || "",
        disable_proxy_sign: boolValue2(source.disable_proxy_sign)
      };
    };
    const normalizeStorageForImport = (storage, index) => {
      const driver = storage.driver || "SiYuanKernel";
      return {
        id: Number(storage.id || index + 1),
        mount_path: normalizePath(storage.mount_path || storage.mountPath || "/"),
        order: Number(storage.order ?? 0),
        driver,
        cache_expiration: Number(storage.cache_expiration ?? 30),
        custom_cache_policies: storage.custom_cache_policies || "",
        status: storage.status || "work",
        addition: storageAddition(storage.addition),
        remark: storage.remark || "",
        modified: Number(storage.modified || now()),
        disabled: !!storage.disabled,
        disable_index: boolValue2(storage.disable_index),
        ...proxyDefaults(driver, storage)
      };
    };
    const nextUserId = () => Math.max(0, ...state.users.map((item) => Number(item.id || 0))) + 1;
    const userById = (id) => state.users.find((item) => Number(item.id) === Number(id));
    const userList = () => state.users.map(sanitizeUser);
    return {
      "GET /api/admin/user/list": async (request) => {
        await refreshConfig();
        return jsonResponse(success(pageSlice(userList(), request)));
      },
      "GET /api/admin/user/get": async (request) => {
        await refreshConfig();
        const id = Number(queryValue(request, "id") || 1);
        const user = userById(id);
        if (!user) return jsonResponse(failure("user not found", 404));
        return jsonResponse(success(sanitizeUser(user)));
      },
      "POST /api/admin/user/update": async (request) => {
        const req = await parseJson(request);
        const index = state.users.findIndex((item) => item.id === Number(req.id));
        if (index < 0) return jsonResponse(failure("user not found", 404));
        const current = state.users[index];
        const role = Number(req.role ?? current.role);
        if (role !== Number(current.role)) return jsonResponse(failure("role can not be changed", 400));
        if (req.disabled && current.role === USER_ROLE.ADMIN) return jsonResponse(failure("admin user can not be disabled", 400));
        const next = normalizeUser({
          ...current,
          ...req,
          id: current.id,
          role: current.role,
          password: req.password ? req.password : current.password,
          otp_secret: req.otp_secret || current.otp_secret || ""
        }, index);
        state.users[index] = next;
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/user/create": async (request) => {
        const req = await parseJson(request);
        if (!req.username) return jsonResponse(failure("username is required", 400));
        if (state.users.some((item) => item.username === req.username)) return jsonResponse(failure("user already exists", 409));
        const role = Number(req.role ?? USER_ROLE.GENERAL);
        if (role === USER_ROLE.ADMIN || role === USER_ROLE.GUEST) return jsonResponse(failure("admin or guest user can not be created", 400));
        const user = normalizeUser({
          ...req,
          id: nextUserId(),
          role: USER_ROLE.GENERAL,
          password: req.password || "",
          base_path: req.base_path || "/",
          permission: Number(req.permission ?? 0)
        }, state.users.length);
        state.users.push(user);
        await saveState2();
        return jsonResponse(success(sanitizeUser(user)));
      },
      "POST /api/admin/user/delete": async (request) => {
        const req = await parseJson(request);
        const id = Number(queryValue(request, "id") || req.id);
        const user = userById(id);
        if (!user) return jsonResponse(failure("user not found", 404));
        if (user.role === USER_ROLE.ADMIN || user.role === USER_ROLE.GUEST) return jsonResponse(failure("admin or guest user can not be deleted", 400));
        state.users = state.users.filter((item) => item.id !== id);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/user/cancel_2fa": async (request) => {
        const req = await parseJson(request);
        const user = state.users.find((item) => item.id === Number(req.id));
        if (!user) return jsonResponse(failure("user not found", 404));
        user.otp = false;
        user.otp_secret = "";
        await saveState2();
        return jsonResponse(success());
      },
      "GET /api/admin/storage/list": async (request) => {
        await refreshConfig();
        return jsonResponse(success(pageSlice(state.storages.map(storageResp), request)));
      },
      "GET /api/admin/storage/get": async (request) => {
        await refreshConfig();
        const id = Number(queryValue(request, "id") || 1);
        return jsonResponse(success(storageResp(state.storages.find((item) => item.id === id) || state.storages[0])));
      },
      "POST /api/admin/storage/create": async (request) => {
        const req = await parseJson(request);
        const mountPath = normalizePath(req.mount_path || req.mountPath || "");
        const existing = mountPath && state.storages.find((item) => item.mount_path === mountPath);
        if (existing) {
          const driver2 = req.driver || existing.driver || "SiYuanKernel";
          Object.assign(existing, {
            order: Number(req.order ?? existing.order ?? 0),
            driver: driver2,
            cache_expiration: Number(req.cache_expiration ?? existing.cache_expiration ?? 30),
            custom_cache_policies: req.custom_cache_policies ?? existing.custom_cache_policies ?? "",
            status: req.status || existing.status || "work",
            addition: storageAddition(req.addition, existing.addition),
            remark: req.remark ?? existing.remark ?? "",
            modified: now(),
            disabled: !!req.disabled,
            disable_index: boolValue2(req.disable_index, existing.disable_index),
            ...proxyDefaults(driver2, { ...existing, ...req })
          });
          await saveState2();
          return jsonResponse(success({ id: existing.id, updated: true }));
        }
        const id = Math.max(0, ...state.storages.map((item) => item.id || 0)) + 1;
        const driver = req.driver || "SiYuanKernel";
        state.storages.push({
          id,
          mount_path: mountPath || normalizePath("/mount-" + id),
          order: Number(req.order || 0),
          driver,
          cache_expiration: Number(req.cache_expiration ?? 30),
          custom_cache_policies: req.custom_cache_policies || "",
          status: req.status || "work",
          addition: storageAddition(req.addition),
          remark: req.remark || "",
          modified: now(),
          disabled: !!req.disabled,
          disable_index: boolValue2(req.disable_index),
          ...proxyDefaults(driver, req)
        });
        await saveState2();
        return jsonResponse(success({ id }));
      },
      "POST /api/admin/storage/update": async (request) => {
        const req = await parseJson(request);
        const storage = state.storages.find((item) => item.id === Number(req.id));
        if (!storage) return jsonResponse(failure("storage not found", 404));
        Object.assign(storage, {
          ...req,
          mount_path: req.mount_path ? normalizePath(req.mount_path) : storage.mount_path,
          addition: storageAddition(req.addition, storage.addition),
          cache_expiration: Number(req.cache_expiration ?? storage.cache_expiration ?? 30),
          disabled: !!req.disabled,
          disable_index: boolValue2(req.disable_index, storage.disable_index),
          modified: now(),
          ...proxyDefaults(req.driver || storage.driver, { ...storage, ...req })
        });
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/delete": async (request) => {
        const req = await parseJson(request);
        const id = Number(req.id);
        if (id === 1) return jsonResponse(failure("root storage cannot be deleted", 403));
        state.storages = state.storages.filter((item) => item.id !== id);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/enable": async (request) => {
        const req = await parseJson(request);
        const storage = state.storages.find((item) => item.id === Number(req.id));
        if (!storage) return jsonResponse(failure("storage not found", 404));
        storage.disabled = false;
        storage.status = "work";
        storage.modified = now();
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/disable": async (request) => {
        const req = await parseJson(request);
        const storage = state.storages.find((item) => item.id === Number(req.id));
        if (!storage) return jsonResponse(failure("storage not found", 404));
        storage.disabled = true;
        storage.status = "disabled";
        storage.modified = now();
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/load_all": async () => jsonResponse(success()),
      "GET /api/admin/config/export": async () => jsonResponse(success(exportConfig())),
      "POST /api/admin/config/import": async (request) => {
        const req = await parseJson(request);
        const payload = (req == null ? void 0 : req.config) || req;
        const mode = (req == null ? void 0 : req.mode) || "replace";
        if (!payload || typeof payload !== "object") return jsonResponse(failure("config is required", 400));
        if (payload.settings && typeof payload.settings === "object") {
          state.settings = mode === "merge" ? { ...state.settings, ...payload.settings } : { ...defaultSettings(), ...payload.settings };
        }
        if (payload.users) {
          const importedUsers = asArray(payload.users).map(normalizeUser);
          state.users = importedUsers.length ? importedUsers : state.users;
        }
        if (payload.storages) {
          const importedStorages = asArray(payload.storages).map(normalizeStorageForImport);
          if (!importedStorages.some((item) => item.mount_path === "/")) {
            importedStorages.unshift(normalizeStorageForImport({ id: 1, mount_path: "/", driver: "SiYuanKernel", addition: "{}" }, 0));
          }
          state.storages = importedStorages;
        }
        if (payload.metas) state.metas = asArray(payload.metas).map((meta, index) => ({ ...meta, id: Number(meta.id || index + 1) }));
        if (payload.sharings) state.sharings = asArray(payload.sharings).map((share) => normalizeShare(share, now));
        await saveState2();
        return jsonResponse(success({
          users: state.users.length,
          storages: state.storages.length,
          metas: state.metas.length,
          sharings: state.sharings.length
        }));
      },
      "GET /api/admin/driver/names": async () => jsonResponse(success(driverNames())),
      "GET /api/admin/driver/list": async () => jsonResponse(success(driverInfoMap())),
      "GET /api/admin/driver/info": async (request) => {
        const driver = queryValue(request, "driver") || "SiYuanKernel";
        const info = driverInfoMap()[driver];
        if (!info) return jsonResponse(failure(`driver [${driver}] not found`, 404));
        return jsonResponse(success(info));
      },
      "POST /api/admin/driver/test": async (request) => {
        var _a, _b;
        const req = await parseJson(request);
        const driver = req.driver || "SiYuanKernel";
        let addition;
        try {
          addition = typeof req.addition === "string" ? JSON.parse(req.addition || "{}") : req.addition || {};
        } catch (error) {
          return jsonResponse(failure(error.message || "invalid addition JSON", 400));
        }
        if (!((_a = driverRuntime == null ? void 0 : driverRuntime.drivers) == null ? void 0 : _a[driver])) return jsonResponse(failure(`driver [${driver}] not found`, 404));
        if (!driverRuntime.drivers[driver].test) return jsonResponse(failure(`driver [${driver}] does not expose a test method yet`, 501));
        try {
          if (((_b = req.verify) == null ? void 0 : _b.type) === "sms") {
            if (!driverRuntime.drivers[driver].verify) return jsonResponse(failure(`driver [${driver}] does not expose a verify method yet`, 501));
            return jsonResponse(success(await driverRuntime.drivers[driver].verify({
              addition_json: addition,
              driver,
              mount_path: "/",
              settings: state.settings || {}
            }, req.verify)));
          }
          return jsonResponse(success(await driverRuntime.test(driver, addition, req.verify)));
        } catch (error) {
          return jsonResponse(failure(error.message || "driver test failed", 502, verifyDataFromError(error, driver, addition)));
        }
      },
      "GET /api/admin/setting/get": async (request) => {
        const key = queryValue(request, "key");
        const keys = queryValue(request, "keys");
        if (key) return jsonResponse(success(settingItem(key, state.settings[key] || "")));
        return jsonResponse(success(keys.split(",").filter(Boolean).map((item, index) => settingItem(item, state.settings[item] || "", index))));
      },
      "GET /api/admin/setting/list": async (request) => jsonResponse(success(listSettings(request))),
      "POST /api/admin/setting/default": async (request) => jsonResponse(success(listSettings(request, defaultSettings()))),
      "POST /api/admin/setting/save": async (request) => {
        const req = await parseJson(request);
        const items = Array.isArray(req) ? req : [req];
        for (const item of items) {
          if (item && item.key) state.settings[item.key] = String(item.value ?? "");
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/setting/delete": async (request) => {
        const key = queryValue(request, "key") || (await parseJson(request)).key;
        if (key) delete state.settings[key];
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/setting/reset_token": async () => {
        state.settings.token = "siyuan-cloud-token-" + Math.random().toString(36).slice(2);
        await saveState2();
        return jsonResponse(success(state.settings.token));
      },
      "POST /api/admin/setting/set_aria2": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { aria2_uri: "uri", aria2_secret: "secret" }, "siyuan-cloud-aria2-placeholder");
      },
      "POST /api/admin/setting/set_qbit": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { qbittorrent_url: "url", qbittorrent_seedtime: "seedtime" });
      },
      "POST /api/admin/setting/set_transmission": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { transmission_uri: "uri", transmission_seedtime: "seedtime" });
      },
      "POST /api/admin/setting/set_115": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { "115_temp_dir": "temp_dir" });
      },
      "POST /api/admin/setting/set_115_open": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { "115_open_temp_dir": "temp_dir" });
      },
      "POST /api/admin/setting/set_123_pan": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { "123_temp_dir": "temp_dir" });
      },
      "POST /api/admin/setting/set_123_open": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { "123_open_temp_dir": "temp_dir", "123_open_callback_url": "callback_url" });
      },
      "POST /api/admin/setting/set_pikpak": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { pikpak_temp_dir: "temp_dir" });
      },
      "POST /api/admin/setting/set_thunder": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { thunder_temp_dir: "temp_dir" });
      },
      "POST /api/admin/setting/set_thunderx": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { thunderx_temp_dir: "temp_dir" });
      },
      "POST /api/admin/setting/set_thunder_browser": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { thunder_browser_temp_dir: "temp_dir" });
      }
    };
  };
  const tokenResp = (user) => ({ token: `siyuan-cloud-port:${(user == null ? void 0 : user.id) || 1}`, username: (user == null ? void 0 : user.username) || "admin" });
  const createAuthHandlers = ({
    getState,
    parseJson,
    saveState: saveState2
  }) => ({
    "POST /api/auth/login": async (request) => {
      const req = await parseJson(request);
      const user = getState().users.find((item) => item.username === req.username);
      if (!user || user.disabled) return jsonResponse(failure("Invalid username or password", 401));
      if (user.password && req.password !== user.password) return jsonResponse(failure("Invalid username or password", 401));
      return jsonResponse(success(tokenResp(user)));
    },
    "POST /api/auth/login/hash": async (request) => {
      const req = await parseJson(request);
      const user = getState().users.find((item) => item.username === req.username);
      if (!user || user.disabled) return jsonResponse(failure("Invalid username or password", 401));
      return jsonResponse(success(tokenResp(user)));
    },
    "POST /api/auth/login/ldap": async () => jsonResponse(failure("LDAP login is not implemented in the SiYuan kernel runtime", 501, {
      upstream: "OpenList server/handles/ldap_login.go",
      reason: "The JavaScript kernel plugin runtime has no LDAP server bind/search implementation yet."
    })),
    "GET /api/auth/logout": async () => jsonResponse(success()),
    "POST /api/auth/logout": async () => jsonResponse(success()),
    "GET /api/me": async () => {
      const user = getState().users.find((item) => item.role === USER_ROLE.ADMIN) || getState().users[0];
      return jsonResponse(success(sanitizeUser(user)));
    },
    "POST /api/me/update": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const index = state.users.findIndex((item) => item.role === USER_ROLE.ADMIN);
      const current = state.users[index >= 0 ? index : 0];
      if (!current || current.role === USER_ROLE.GUEST) return jsonResponse(failure("Guest user can not update profile", 403));
      state.users[index >= 0 ? index : 0] = {
        ...current,
        username: req.username || current.username,
        password: req.password || current.password,
        sso_id: req.sso_id || current.sso_id || ""
      };
      await saveState2();
      return jsonResponse(success());
    }
  });
  const notImplemented = (name) => jsonResponse(failure(`${name} is not implemented in the SiYuan kernel port yet`, 501));
  const createCompatHandlers = () => ({
    "GET /api/auth/sso": async () => notImplemented("sso login"),
    "GET /api/auth/sso_callback": async () => notImplemented("sso callback"),
    "GET /api/auth/get_sso_id": async () => notImplemented("sso id lookup"),
    "GET /api/auth/sso_get_token": async () => notImplemented("sso token lookup"),
    "GET /api/authn/webauthn_begin_login": async () => notImplemented("webauthn login"),
    "POST /api/authn/webauthn_finish_login": async () => notImplemented("webauthn login"),
    "GET /api/authn/webauthn_begin_registration": async () => notImplemented("webauthn registration"),
    "POST /api/authn/webauthn_finish_registration": async () => notImplemented("webauthn registration"),
    "POST /api/authn/delete_authn": async () => jsonResponse(success()),
    "GET /api/authn/getcredentials": async () => jsonResponse(success([])),
    "POST /api/admin/user/del_cache": async () => jsonResponse(success())
  });
  const createIndexHandlers = ({
    parseJson,
    searchIndex
  }) => {
    return {
      "POST /api/admin/index/build": async () => {
        await searchIndex.clear();
        await searchIndex.build({ clearFirst: true, count: true, paths: ["/"] });
        return jsonResponse(success());
      },
      "POST /api/admin/index/update": async (request) => {
        const req = await parseJson(request);
        const paths = Array.isArray(req.paths) && req.paths.length ? req.paths : ["/"];
        await searchIndex.build({ clearFirst: false, count: false, maxDepth: req.max_depth, paths });
        return jsonResponse(success());
      },
      "POST /api/admin/index/stop": async () => jsonResponse(failure("index is not running", 400)),
      "POST /api/admin/index/clear": async () => {
        await searchIndex.clear();
        await searchIndex.writeProgress({
          error: "",
          is_done: true,
          last_done_time: null,
          obj_count: 0
        });
        return jsonResponse(success());
      },
      "GET /api/admin/index/progress": async () => {
        return jsonResponse(success(searchIndex.getProgress()));
      }
    };
  };
  const createMetaHandlers = ({
    getState,
    pageSlice,
    parseJson,
    queryValue,
    saveState: saveState2
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const nextId = () => Math.max(0, ...(state.metas || []).map((item) => item.id || 0)) + 1;
    return {
      "GET /api/admin/meta/list": async (request) => {
        state.metas = state.metas || [];
        return jsonResponse(success(pageSlice([...state.metas].sort((a, b) => a.id - b.id), request)));
      },
      "GET /api/admin/meta/get": async (request) => {
        const id = Number(queryValue(request, "id"));
        const meta = (state.metas || []).find((item) => item.id === id);
        return meta ? jsonResponse(success(meta)) : jsonResponse(failure("meta not found", 404));
      },
      "POST /api/admin/meta/create": async (request) => {
        const req = await parseJson(request);
        try {
          validateHideRules(req.hide);
        } catch (error) {
          return jsonResponse(failure(`${req.hide || ""} is illegal: ${error.message}`, 400));
        }
        state.metas = state.metas || [];
        const meta = normalizeMeta(req, nextId());
        if (state.metas.some((item) => item.path === meta.path)) return jsonResponse(failure("meta path already exists", 409));
        state.metas.push(meta);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/meta/update": async (request) => {
        const req = await parseJson(request);
        try {
          validateHideRules(req.hide);
        } catch (error) {
          return jsonResponse(failure(`${req.hide || ""} is illegal: ${error.message}`, 400));
        }
        state.metas = state.metas || [];
        const index = state.metas.findIndex((item) => item.id === Number(req.id));
        if (index < 0) return jsonResponse(failure("meta not found", 404));
        state.metas[index] = normalizeMeta({ ...state.metas[index], ...req }, state.metas[index].id);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/meta/delete": async (request) => {
        const req = await parseJson(request);
        const id = Number(queryValue(request, "id") || req.id);
        state.metas = (state.metas || []).filter((item) => item.id !== id);
        await saveState2();
        return jsonResponse(success());
      }
    };
  };
  const createMessageHandlers = ({
    getState,
    now,
    parseJson,
    saveState: saveState2
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    return {
      "POST /api/admin/message/get": async () => {
        state.messages = state.messages || [];
        return jsonResponse(success(pageResp([...state.messages].reverse(), state.messages.length)));
      },
      "POST /api/admin/message/send": async (request) => {
        const req = await parseJson(request);
        state.messages = state.messages || [];
        state.messages.push({
          id: `message-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
          title: req.title || req.Title || "",
          content: req.content || req.message || req.Message || "",
          type: req.type || "info",
          created: now()
        });
        await saveState2();
        return jsonResponse(success());
      }
    };
  };
  const createScanHandlers = ({
    getState,
    now,
    saveState: saveState2
  }) => {
    const setScan = async (scan) => {
      getState().scan = {
        updated: now(),
        ...scan
      };
      await saveState2();
      return jsonResponse(success());
    };
    return {
      "POST /api/admin/scan/start": async () => setScan({ status: "done", total: 1, done: 1 }),
      "POST /api/admin/scan/stop": async () => setScan({ status: "idle", total: 0, done: 0 }),
      "GET /api/admin/scan/progress": async () => jsonResponse(success(getState().scan || { status: "idle", total: 0, done: 0 }))
    };
  };
  const createSecurityHandlers = ({
    getState,
    now,
    parseJson,
    queryValue,
    saveState: saveState2
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const publicKeysForUser = (userId) => (state.ssh_keys || []).filter((item) => item.user_id === userId);
    const addKey = async (request, userId) => {
      const req = await parseJson(request);
      state.ssh_keys = state.ssh_keys || [];
      const id = Math.max(0, ...state.ssh_keys.map((item) => item.id || 0)) + 1;
      state.ssh_keys.push({
        id,
        user_id: Number(req.user_id || userId),
        title: req.title || req.name || `key-${id}`,
        key: req.key || req.public_key || "",
        created: now()
      });
      await saveState2();
      return jsonResponse(success({ id }));
    };
    const deleteKey = async (request, userId) => {
      const req = await parseJson(request);
      const id = Number(queryValue(request, "id") || req.id);
      state.ssh_keys = (state.ssh_keys || []).filter((item) => item.id !== id || userId && item.user_id !== userId);
      await saveState2();
      return jsonResponse(success());
    };
    return {
      "GET /api/me/sshkey/list": async () => jsonResponse(success(publicKeysForUser(1))),
      "POST /api/me/sshkey/add": async (request) => addKey(request, 1),
      "POST /api/me/sshkey/delete": async (request) => deleteKey(request, 1),
      "GET /api/admin/user/sshkey/list": async (request) => {
        const userId = Number(queryValue(request, "user_id") || queryValue(request, "id") || 1);
        return jsonResponse(success(publicKeysForUser(userId)));
      },
      "POST /api/admin/user/sshkey/delete": async (request) => deleteKey(request, 0),
      "POST /api/auth/2fa/generate": async () => {
        const user = state.users[0];
        if (!user) return jsonResponse(failure("user not found", 404));
        user.otp_secret = `siyuan-cloud-${Math.random().toString(36).slice(2, 12)}`;
        await saveState2();
        return jsonResponse(success({
          otp_secret: user.otp_secret,
          qr: ""
        }));
      },
      "POST /api/auth/2fa/verify": async () => {
        const user = state.users[0];
        if (!user) return jsonResponse(failure("user not found", 404));
        user.otp = true;
        await saveState2();
        return jsonResponse(success());
      }
    };
  };
  const acceptedArchiveExtensions = () => [
    ".7z",
    ".7z.001",
    ".br",
    ".bz2",
    ".gz",
    ".iso",
    ".lz",
    ".lz4",
    ".mz",
    ".part1.rar",
    ".rar",
    ".s2",
    ".sz",
    ".tar",
    ".tbz2",
    ".tgz",
    ".tlz",
    ".tlz4",
    ".txz",
    ".tzst",
    ".xz",
    ".zip",
    ".zip.001",
    ".zst",
    ".zz"
  ];
  const archiveNotImplemented = (operation) => ({
    operation,
    reason: "SiYuan kernel JavaScript runtime has no archive reader wired yet.",
    upstream_source: "server/handles/archive.go + internal/op/archive.go + internal/archive/*",
    next: "Port a JS archive reader or expose a kernel-side archive primitive before enabling this route."
  });
  const sharingArchiveNotImplemented = (operation) => ({
    operation,
    reason: "SiYuan kernel JavaScript runtime has no sharing archive reader wired yet.",
    upstream_source: "server/handles/sharing.go + internal/sharing/archive.go",
    next: "Port OpenList sharing archive preview/extract before enabling this route."
  });
  const parseArchiveRequest = async (request, parseJson) => {
    if (request.method === "GET" || request.method === "HEAD")
      return Object.fromEntries(new URL(request.url).searchParams.entries());
    return parseJson(request);
  };
  const isSharingArchivePath = (path) => typeof path === "string" && path.startsWith("/@s");
  const createArchiveHandlers = ({ parseJson, taskStore }) => ({
    "ANY /api/fs/archive/meta": async (request) => {
      const req = await parseArchiveRequest(request, parseJson);
      const data = isSharingArchivePath(req.path) ? sharingArchiveNotImplemented("share_meta") : archiveNotImplemented("meta");
      return jsonResponse(failure(
        "archive preview is not implemented in the SiYuan kernel port yet",
        501,
        data
      ), 501);
    },
    "ANY /api/fs/archive/list": async (request) => {
      const req = await parseArchiveRequest(request, parseJson);
      const data = isSharingArchivePath(req.path) ? sharingArchiveNotImplemented("share_list") : archiveNotImplemented("list");
      return jsonResponse(failure(
        "archive preview is not implemented in the SiYuan kernel port yet",
        501,
        data
      ), 501);
    },
    "POST /api/fs/archive/decompress": async (request) => {
      const req = await parseJson(request);
      const task = await taskStore.addTask("decompress", {
        error: "archive decompress is not implemented in the SiYuan kernel port yet",
        name: req.src_path || req.path || "archive decompress",
        status: "not implemented"
      });
      return jsonResponse(failure(
        "archive decompress is not implemented in the SiYuan kernel port yet",
        501,
        { ...archiveNotImplemented("decompress"), task }
      ), 501);
    }
  });
  const createPublicHandlers = ({
    getState,
    handlersRef,
    settingItem
  }) => {
    const publicSettings = () => {
      const result = {};
      for (const [key, value] of Object.entries(getState().settings)) {
        const item = settingItem(key, value, 0);
        if (item.flag !== SETTING_FLAG.PRIVATE) result[key] = item.value;
      }
      result.version = OPENLIST_VERSION;
      return result;
    };
    const routeEntries = () => Object.keys(handlersRef ? handlersRef() : {}).sort().map((route) => {
      const [method, ...pathParts] = route.split(" ");
      const path = pathParts.join(" ");
      return {
        method,
        path,
        url: path.startsWith("/api") ? `/plugin/private/siyuan-cloud${path}` : path
      };
    });
    const apiIndex = () => ({
      name: "Siyuan Cloud",
      upstream: "OpenList",
      version: OPENLIST_VERSION,
      base_url: "/plugin/private/siyuan-cloud",
      api_base: "/plugin/private/siyuan-cloud/api",
      envelope: { code: 200, message: "success", data: null },
      routes: routeEntries(),
      endpoints: {
        api: "/plugin/private/siyuan-cloud/api",
        download: "/plugin/private/siyuan-cloud/d/{path}",
        proxy: "/plugin/private/siyuan-cloud/p/{path}",
        webdav: "/plugin/private/siyuan-cloud/dav",
        s3: "/plugin/private/siyuan-cloud/s3",
        share_download: "/plugin/private/siyuan-cloud/sd/{id}/{path}"
      },
      capabilities: [
        "openlist.http-api",
        "openlist.fs",
        "openlist.search.local-index",
        "openlist.admin",
        "openlist.public",
        "openlist.share",
        "openlist.share.multi-file",
        "openlist.task",
        "openlist.task.manager-shape",
        "openlist.webdav",
        "openlist.s3",
        "openlist.fs.torrent.placeholder"
      ],
      notes: [
        "Use this plugin private route as an OpenList-compatible base URL.",
        "Route names, request fields, response envelope, /d, /p, /dav, and /s3 follow OpenList-compatible boundaries where implemented.",
        "Unsupported OpenList capabilities return structured compatibility placeholders instead of silent behavior changes."
      ]
    });
    return {
      "ANY /api/public/api": async () => jsonResponse(success(apiIndex())),
      "ANY /api/public/routes": async () => jsonResponse(success(apiIndex())),
      "ANY /api/public/settings": async () => jsonResponse(success(publicSettings())),
      "ANY /api/public/offline_download_tools": async () => jsonResponse(success([])),
      "ANY /api/public/archive_extensions": async () => jsonResponse(success(acceptedArchiveExtensions()))
    };
  };
  const ADAPTERS = [
    "siyuan-storage",
    "siyuan-workspace",
    "openlist",
    "alist_v3",
    "webdav",
    "s3",
    "115_cloud",
    "onedrive",
    "123pan",
    "baidu_netdisk",
    "aliyundrive_open",
    "189cloud",
    "189cloud_pc",
    "189cloud_tv",
    "quark",
    "uc",
    "quark_open",
    "quark_tv",
    "uc_tv"
  ];
  const STAGES = [
    ["kernel", "done"],
    ["auth", "done"],
    ["fs", "done"],
    ["search-index", "active"],
    ["torrent", "active"],
    ["streaming-proxy", "done"],
    ["admin", "done"],
    ["meta", "done"],
    ["security", "active"],
    ["share", "done"],
    ["task", "active"],
    ["real-adapter", "active"],
    ["webdav", "active"],
    ["s3", "active"]
  ];
  const getSyncInfo = async (client) => {
    let syncignore = "";
    try {
      const response = await client.fetch("/api/file/getFile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: ".siyuan/syncignore" })
      });
      if (response.ok) syncignore = await response.text();
    } catch (_) {
      syncignore = "";
    }
    const lines = syncignore.replace(/\r\n/g, "\n").split("\n").map((line) => line.trim()).filter((line) => line && !line.startsWith("#"));
    const storageBase = "/storage/petal/siyuan-cloud";
    const configPath = `${storageBase}/${CONFIG_FILE}`;
    const runtimePath = `${storageBase}/${RUNTIME_FILE}`;
    const searchIndexPath = `${storageBase}/${SEARCH_INDEX_FILE}`;
    const ignored = lines.some((line) => line === "/storage/petal/**/*" || line === "/storage/petal/**" || line === "/storage/petal/siyuan-cloud/**/*" || line === "/storage/petal/siyuan-cloud/**" || line === configPath || line === runtimePath || line === searchIndexPath);
    return {
      persistent: true,
      syncable_by_default: true,
      ignored_by_syncignore: ignored,
      state_file: configPath,
      config_file: configPath,
      runtime_file: runtimePath,
      search_index_file: searchIndexPath,
      source: "kernel/plugin/plugin.go + kernel/model/repository.go + kernel/model/sync.go"
    };
  };
  const createStatusPayload = async ({
    client,
    getState,
    handlersRef
  }) => {
    const state = getState();
    const handlers = handlersRef();
    return {
      ok: true,
      version: OPENLIST_VERSION,
      users: state.users.length,
      entries: Object.keys(state.entries).length,
      storages: state.storages.length,
      sharings: state.sharings.length,
      adapters: [...ADAPTERS],
      storage: await getSyncInfo(client),
      routes: Object.keys(handlers).sort(),
      stages: STAGES.map(([key, status]) => ({ key, status }))
    };
  };
  const createStatusHandlers = ({
    client,
    getState,
    handlersRef
  }) => {
    return {
      "GET /ping": async () => textResponse("pong"),
      "ANY /ping": async () => textResponse("pong"),
      "GET /siyuan-cloud/status": async () => jsonResponse(success(await createStatusPayload({ client, getState, handlersRef })))
    };
  };
  const ORIGIN_IGNORE_HEADERS = /* @__PURE__ */ new Set([
    "authorization",
    "cookie",
    "connection",
    "host",
    "proxy-authorization",
    "proxy-connection",
    "referer",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade"
  ]);
  const HOP_BY_HOP_HEADERS = /* @__PURE__ */ new Set([
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "proxy-connection",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade"
  ]);
  const connectionHeaders = (headers = {}) => {
    const result = /* @__PURE__ */ new Set();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== "connection") continue;
      const values = Array.isArray(value) ? value : [value];
      for (const item of values) {
        for (const part of String(item || "").split(",")) {
          const name = part.trim().toLowerCase();
          if (name) result.add(name);
        }
      }
    }
    return result;
  };
  const headerValues = (value) => Array.isArray(value) ? value.map(String) : [String(value)];
  const setHeader = (headers, key, value) => {
    const lower = String(key).toLowerCase();
    for (const existing of Object.keys(headers)) {
      if (existing.toLowerCase() === lower) delete headers[existing];
    }
    headers[key] = headerValues(value);
  };
  const processHeader = (origin = {}, override = {}) => {
    const result = {};
    const originConnectionHeaders = connectionHeaders(origin);
    for (const [key, value] of Object.entries(origin || {})) {
      const lower = String(key).toLowerCase();
      if (ORIGIN_IGNORE_HEADERS.has(lower) || originConnectionHeaders.has(lower)) continue;
      setHeader(result, key, value);
    }
    const overrideConnectionHeaders = connectionHeaders(override);
    for (const [key, value] of Object.entries(override || {})) {
      if (value === void 0 || value === null || value === "") continue;
      const lower = String(key).toLowerCase();
      if (HOP_BY_HOP_HEADERS.has(lower) || overrideConnectionHeaders.has(lower)) continue;
      setHeader(result, key, value);
    }
    return result;
  };
  const requestHeader = (request) => {
    const requestMeta = (request == null ? void 0 : request.request) || (request == null ? void 0 : request.Request) || {};
    return requestMeta.headers || requestMeta.Headers || {};
  };
  const proxy = (_ctx, link, file, _proxyRange) => {
    return proxyResponse(link.url, processHeader((file == null ? void 0 : file.request_header) || {}, link.header), link.method || "GET");
  };
  const proxyReadOptions = (request) => {
    return {
      headers: {},
      proxyHeaders: {},
      requestHeaders: requestHeader(request)
    };
  };
  const privateBase = "/plugin/private/siyuan-cloud";
  const escapeHtml = (value) => String(value || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const htmlResponse = (html) => rawResponse(html, 200, "text/html; charset=utf-8");
  const shareText = (request) => {
    const meta = (request == null ? void 0 : request.request) || (request == null ? void 0 : request.Request) || {};
    const headers = meta.headers || meta.Headers || {};
    const zh = String(headers["accept-language"] || headers["Accept-Language"] || "").toLowerCase().includes("zh");
    const keys = "download notFound notFoundMessage open password passwordTitle retry tryAgain verified wrongPassword".split(" ");
    const values = zh ? ["下载", "分享不存在", "分享不存在或不可用。", "打开", "密码", "请输入分享密码", "重试", "密码错误，请重试。", "已验证", "密码错误"] : ["Download", "Share not found", "The share does not exist or is unavailable.", "Open", "Password", "Share password", "Retry", "Password is incorrect. Please try again.", "Access verified", "Password is incorrect"];
    return Object.fromEntries(keys.map((key, index) => [key, values[index]]));
  };
  const shareShell = (body) => htmlResponse(`<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Siyuan Cloud Share</title>
  <style>
    body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f6f6f7;color:#202124;font:14px/1.5 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
    main{width:min(760px,calc(100vw - 32px));display:grid;gap:12px}
    h1{margin:0;font-size:18px;font-weight:600}
    form{display:grid;gap:10px}
    input{height:36px;padding:0 10px;border:1px solid #d0d0d0;border-radius:6px;background:#fff;font:inherit}
    a,button{height:36px;display:inline-grid;place-items:center;padding:0 14px;border:0;border-radius:6px;background:#3575f0;color:#fff;font:inherit;text-decoration:none;cursor:pointer}
    p{margin:0;color:#5f6368}
    .error{color:#d23f31}
  </style>
</head>
<body><main>${body}</main></body>
</html>`);
  const sharePasswordPage = ({ action, message, text: text2, title }) => shareShell(`<h1>${escapeHtml(title || text2.passwordTitle)}</h1>
  ${message ? `<p class="error" role="alert">${escapeHtml(message)}</p>` : ""}
  <form method="get" action="${escapeHtml(privateBase + action)}" onsubmit="document.querySelector('.error')?.remove()">
    <input name="pwd" type="password" autofocus autocomplete="current-password" placeholder="${escapeHtml(text2.password)}">
    <button type="submit">${message ? escapeHtml(text2.retry) : escapeHtml(text2.open)}</button>
  </form>`);
  const sharePreviewPage = ({ info, path, pwd, text: text2 }) => {
    const name = basename(info.targetPath) || basename(path) || info.normalizedShare.id;
    const query = `download=1${pwd ? `&pwd=${encodeURIComponent(pwd)}` : ""}`;
    const url = `${privateBase}${path}?${query}`;
    return shareShell(`<h1>${escapeHtml(name)}</h1><p>${escapeHtml(text2.verified)}</p><a href="${escapeHtml(url)}">${escapeHtml(text2.download)}</a>`);
  };
  const createRouter = ({
    getState,
    handleWebDav,
    handleS3,
    handlers,
    isWorkspacePath,
    pick,
    queryValue,
    readFileResponse: externalReadFileResponse,
    requestPath,
    saveState: saveState2,
    warn,
    workspaceReadText
  }) => {
    const fallbackReadFileResponse = async (filePath) => {
      const state = getState();
      if (isWorkspacePath(filePath)) {
        const file = await workspaceReadText(filePath);
        if (!file.ok) return textResponse(file.text || "not found", file.status || 404);
        return textResponse(file.text, 200, file.contentType);
      }
      const entry = state.entries[filePath];
      if (!entry || entry.is_dir) return textResponse("not found", 404);
      return textResponse(entry.content || "", 200, entry.mime || "application/octet-stream");
    };
    const readFileResponse = externalReadFileResponse || fallbackReadFileResponse;
    const dispatch = async (request) => {
      const requestMeta = pick(request, "request", "Request");
      const method = String(pick(requestMeta, "method", "Method") || "GET").toUpperCase();
      const path = requestPath(request);
      const key = method + " " + path;
      const anyKey = "ANY " + path;
      const handler = handlers[key] || handlers[anyKey];
      if (handler) return handler(request);
      if (path === "/" || path === "/@manage") {
        return jsonResponse(success({
          name: "Siyuan Cloud",
          version: OPENLIST_VERSION,
          message: "OpenList compatibility layer is running.",
          private_base: privateBase,
          routes: Object.keys(handlers).sort()
        }));
      }
      if (path === "/dav" || path.startsWith("/dav/")) {
        return handleWebDav(request);
      }
      if (path === "/s3" || path.startsWith("/s3/")) {
        return handleS3(request);
      }
      if (path.startsWith("/sd/")) {
        const sharePath = normalizePath(path.replace(/^\/sd/, ""));
        const pwd = queryValue(request, "pwd");
        const state = getState();
        const info = sharePathInfo({ path: sharePath, password: pwd, state });
        const needsPassword = shareNeedsPassword({ path: sharePath, password: pwd, state });
        const text2 = shareText(request);
        if (!info && needsPassword) return sharePasswordPage({ action: path, message: pwd ? text2.tryAgain : "", text: text2 });
        if (!info) return sharePasswordPage({ action: path, message: text2.notFoundMessage, text: text2, title: text2.notFound });
        await countShareAccess({ info, ip: shareClientIP(request), saveState: saveState2 });
        return queryValue(request, "download") ? readFileResponse(info.targetPath, request) : sharePreviewPage({ info, path, pwd, text: text2 });
      }
      if (path.startsWith("/d/") || path.startsWith("/p/")) {
        return readFileResponse(normalizePath(path.replace(/^\/[dp]/, "")), request);
      }
      if (path === "/sad" || path.startsWith("/sad/")) {
        return textResponse("sharing archive extract is not implemented in the SiYuan kernel port yet", 501);
      }
      if (path.startsWith("/ad/") || path.startsWith("/ap/") || path.startsWith("/ae/")) {
        return textResponse("archive download is not implemented in the SiYuan kernel port yet", 501);
      }
      return jsonResponse(failure("route not implemented: " + key, 404), 404);
    };
    return async (request) => {
      try {
        return await dispatch(request);
      } catch (error) {
        await warn("request failed", String(error && error.stack || error));
        return jsonResponse(failure(String(error && error.message || error), 500), 500);
      }
    };
  };
  const DEFAULT_BUCKET = "siyuan-cloud";
  const escapeXml$1 = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const xmlResponse = (xml, statusCode = 200) => textResponse(xml, statusCode, "application/xml; charset=utf-8");
  const s3PathParts = (path) => {
    const clean = path.replace(/^\/s3\/?/, "").replace(/^\/+/, "");
    const [bucket, ...objectParts] = clean.split("/").filter(Boolean);
    return {
      bucket: bucket || "",
      object: objectParts.join("/")
    };
  };
  const requestBodyText = async (requestMeta) => {
    const body = requestMeta.body || requestMeta.Body || {};
    if (body.data !== void 0 && body.data !== null) {
      if (typeof body.data === "string") return body.data;
      if (typeof body.data.text === "function") return body.data.text();
      if (body.data instanceof ArrayBuffer) return String.fromCharCode(...new Uint8Array(body.data));
      if (typeof body.data === "object") return JSON.stringify(body.data);
    }
    if (body.string && Array.isArray(body.string.values)) return body.string.values.join("");
    return "";
  };
  const headerValue = (requestMeta, name) => {
    const headers = requestMeta.headers || requestMeta.Headers || {};
    const lower = name.toLowerCase();
    for (const [key, value] of Object.entries(headers)) {
      if (String(key).toLowerCase() !== lower) continue;
      if (Array.isArray(value)) return value[0] || "";
      return String(value || "");
    }
    return "";
  };
  const objectPath = (object) => normalizePath("/" + object);
  const listBucketsXml = () => xmlResponse([
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<ListAllMyBucketsResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
    `<Owner><ID>siyuan-cloud</ID><DisplayName>Siyuan Cloud</DisplayName></Owner>`,
    `<Buckets><Bucket><Name>${DEFAULT_BUCKET}</Name><CreationDate>${(/* @__PURE__ */ new Date()).toISOString()}</CreationDate></Bucket></Buckets>`,
    `</ListAllMyBucketsResult>`
  ].join(""));
  const errorXml = (code, message, statusCode) => xmlResponse([
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<Error><Code>${escapeXml$1(code)}</Code><Message>${escapeXml$1(message)}</Message></Error>`
  ].join(""), statusCode);
  const createS3Server = ({
    cloneEntryTree,
    createFile: createFile2,
    ensureDir,
    getState,
    removeEntry,
    requestPath,
    saveState: saveState2
  }) => {
    const listBucketXml = (bucket, options) => {
      const state = getState();
      const normalizedPrefix = String(options.prefix || "").replace(/^\/+/, "");
      const delimiter = options.delimiter || "";
      const maxKeys = Math.max(1, Number(options.maxKeys));
      const allObjects = Object.values(state.entries).filter((entry) => entry.path !== "/" && !entry.is_dir).map((entry) => ({
        key: entry.path.replace(/^\//, ""),
        entry
      })).filter((item) => !normalizedPrefix || item.key.startsWith(normalizedPrefix)).sort((a, b) => a.key.localeCompare(b.key));
      const commonPrefixes = /* @__PURE__ */ new Set();
      const contents = [];
      for (const item of allObjects) {
        const rest = item.key.slice(normalizedPrefix.length);
        if (delimiter && rest.includes(delimiter)) {
          commonPrefixes.add(normalizedPrefix + rest.slice(0, rest.indexOf(delimiter) + delimiter.length));
          continue;
        }
        contents.push(item);
      }
      const contentXml = contents.slice(0, maxKeys).map(({ key, entry }) => [
        `<Contents>`,
        `<Key>${escapeXml$1(key)}</Key>`,
        `<LastModified>${escapeXml$1(entry.modified || (/* @__PURE__ */ new Date()).toISOString())}</LastModified>`,
        `<ETag>"${escapeXml$1(String(entry.size || 0))}"</ETag>`,
        `<Size>${Number(entry.size || 0)}</Size>`,
        `<StorageClass>STANDARD</StorageClass>`,
        `</Contents>`
      ].join("")).join("");
      const prefixXml = [...commonPrefixes].sort((a, b) => a.localeCompare(b)).slice(0, maxKeys).map((prefix) => `<CommonPrefixes><Prefix>${escapeXml$1(prefix)}</Prefix></CommonPrefixes>`).join("");
      return xmlResponse([
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<ListBucketResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
        `<Name>${escapeXml$1(bucket)}</Name>`,
        `<Prefix>${escapeXml$1(normalizedPrefix)}</Prefix>`,
        `<Delimiter>${escapeXml$1(delimiter)}</Delimiter>`,
        `<Marker></Marker><MaxKeys>${maxKeys}</MaxKeys><IsTruncated>false</IsTruncated>`,
        contentXml,
        prefixXml,
        `</ListBucketResult>`
      ].join(""));
    };
    const objectResponse = (entry, headOnly = false) => {
      const response = textResponse(headOnly ? "" : entry.content || "", 200, entry.mime || "application/octet-stream");
      response.headers["Content-Length"] = [String(entry.size || 0)];
      response.headers.ETag = [`"${entry.size || 0}"`];
      response.headers["Last-Modified"] = [new Date(entry.modified || Date.now()).toUTCString()];
      return response;
    };
    const copySource = (requestMeta) => {
      const raw = decodeURIComponent(headerValue(requestMeta, "x-amz-copy-source").replace(/^\/+/, ""));
      if (!raw) return null;
      const [bucket, ...objectParts] = raw.split("/");
      if (bucket !== DEFAULT_BUCKET) return null;
      return objectPath(objectParts.join("/"));
    };
    const copyResultXml = () => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<CopyObjectResult>`,
      `<LastModified>${(/* @__PURE__ */ new Date()).toISOString()}</LastModified>`,
      `<ETag>"0"</ETag>`,
      `</CopyObjectResult>`
    ].join(""));
    const multiDeleteXml = (objects) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<DeleteResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      ...objects.map((key) => `<Deleted><Key>${escapeXml$1(key)}</Key></Deleted>`),
      `</DeleteResult>`
    ].join(""));
    const parseDeleteObjects = async (requestMeta) => {
      const text2 = await requestBodyText(requestMeta);
      return [...text2.matchAll(/<Key>([^<]+)<\/Key>/g)].map((match) => match[1]);
    };
    const ensureMultipartState = () => {
      const state = getState();
      state.s3_multipart_uploads = state.s3_multipart_uploads || {};
      return state.s3_multipart_uploads;
    };
    const initiateMultipartXml = (bucket, object, uploadId) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<InitiateMultipartUploadResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      `<Bucket>${escapeXml$1(bucket)}</Bucket><Key>${escapeXml$1(object)}</Key><UploadId>${escapeXml$1(uploadId)}</UploadId>`,
      `</InitiateMultipartUploadResult>`
    ].join(""));
    const completeMultipartXml = (bucket, object, entry) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<CompleteMultipartUploadResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      `<Location>/s3/${escapeXml$1(bucket)}/${escapeXml$1(object)}</Location>`,
      `<Bucket>${escapeXml$1(bucket)}</Bucket><Key>${escapeXml$1(object)}</Key><ETag>"${escapeXml$1(String((entry == null ? void 0 : entry.size) || 0))}"</ETag>`,
      `</CompleteMultipartUploadResult>`
    ].join(""));
    const listMultipartXml = (bucket, object, uploadId, upload) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<ListPartsResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      `<Bucket>${escapeXml$1(bucket)}</Bucket><Key>${escapeXml$1(object)}</Key><UploadId>${escapeXml$1(uploadId)}</UploadId>`,
      ...Object.entries((upload == null ? void 0 : upload.parts) || {}).sort(([a], [b]) => Number(a) - Number(b)).map(([partNumber, part]) => `<Part><PartNumber>${Number(partNumber)}</PartNumber><ETag>"${part.size}"</ETag><Size>${part.size}</Size></Part>`),
      `</ListPartsResult>`
    ].join(""));
    const listMultipartUploadsXml = (bucket, uploads, options = {}) => {
      const prefix = String(options.prefix || "").replace(/^\/+/, "");
      const uploadXml = Object.entries(uploads).filter(([, upload]) => upload.bucket === bucket && (!prefix || upload.object.startsWith(prefix))).sort(([, a], [, b]) => String(a.object).localeCompare(String(b.object))).map(([uploadId, upload]) => [
        `<Upload>`,
        `<Key>${escapeXml$1(upload.object)}</Key>`,
        `<UploadId>${escapeXml$1(uploadId)}</UploadId>`,
        `<Initiator><ID>siyuan-cloud</ID><DisplayName>Siyuan Cloud</DisplayName></Initiator>`,
        `<Owner><ID>siyuan-cloud</ID><DisplayName>Siyuan Cloud</DisplayName></Owner>`,
        `<StorageClass>STANDARD</StorageClass>`,
        `<Initiated>${escapeXml$1(upload.started || (/* @__PURE__ */ new Date()).toISOString())}</Initiated>`,
        `</Upload>`
      ].join("")).join("");
      return xmlResponse([
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<ListMultipartUploadsResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
        `<Bucket>${escapeXml$1(bucket)}</Bucket>`,
        `<KeyMarker></KeyMarker><UploadIdMarker></UploadIdMarker>`,
        `<NextKeyMarker></NextKeyMarker><NextUploadIdMarker></NextUploadIdMarker>`,
        `<Prefix>${escapeXml$1(prefix)}</Prefix><Delimiter></Delimiter>`,
        `<MaxUploads>1000</MaxUploads><IsTruncated>false</IsTruncated>`,
        uploadXml,
        `</ListMultipartUploadsResult>`
      ].join(""));
    };
    return async (request) => {
      var _a;
      const requestMeta = request.request || request.Request || {};
      const method = String(requestMeta.method || requestMeta.Method || "GET").toUpperCase();
      const path = requestPath(request);
      const { bucket, object } = s3PathParts(path);
      if (method === "OPTIONS") {
        const response = textResponse("", 204);
        response.headers.Allow = ["OPTIONS, GET, HEAD, PUT, DELETE"];
        return response;
      }
      if (!bucket) {
        if (method === "GET" || method === "HEAD") return listBucketsXml();
        return errorXml("MethodNotAllowed", "method not allowed", 405);
      }
      if (bucket !== DEFAULT_BUCKET) return errorXml("NoSuchBucket", "bucket does not exist", 404);
      if (!object) {
        if (method === "POST") {
          const requestUrl2 = request.url || request.URL || {};
          const query2 = requestUrl2.query || requestUrl2.Query || "";
          if (new URLSearchParams(query2).has("delete")) {
            const objects = await parseDeleteObjects(requestMeta);
            for (const key of objects) removeEntry(objectPath(key));
            await saveState2();
            return multiDeleteXml(objects);
          }
        }
        if (method === "GET" || method === "HEAD") {
          const requestUrl2 = request.url || request.URL || {};
          const query2 = requestUrl2.query || requestUrl2.Query || "";
          const params2 = new URLSearchParams(query2);
          if (params2.has("uploads")) {
            return listMultipartUploadsXml(bucket, ensureMultipartState(), {
              prefix: params2.get("prefix") || ""
            });
          }
          return listBucketXml(bucket, {
            delimiter: params2.get("delimiter") || "",
            maxKeys: params2.get("max-keys") || params2.get("maxKeys") || 1e3,
            prefix: params2.get("prefix") || ""
          });
        }
        if (method === "PUT") return textResponse("", 200);
        if (method === "DELETE") return textResponse("", 204);
        return errorXml("MethodNotAllowed", "method not allowed", 405);
      }
      const fsPath = objectPath(object);
      const state = getState();
      const entry = state.entries[fsPath];
      const requestUrl = request.url || request.URL || {};
      const query = requestUrl.query || requestUrl.Query || "";
      const params = new URLSearchParams(query);
      if (method === "GET" || method === "HEAD") {
        if (params.has("uploadId")) {
          const uploadId = params.get("uploadId");
          const upload = ensureMultipartState()[uploadId];
          if (!upload) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
          return listMultipartXml(bucket, object, params.get("uploadId"), upload);
        }
        if (!entry || entry.is_dir) return errorXml("NoSuchKey", "object does not exist", 404);
        return objectResponse(entry, method === "HEAD");
      }
      if (method === "POST" && params.has("uploads")) {
        const uploadId = `upload-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
        ensureMultipartState()[uploadId] = { bucket, object, parts: {}, started: (/* @__PURE__ */ new Date()).toISOString() };
        await saveState2();
        return initiateMultipartXml(bucket, object, uploadId);
      }
      if (method === "POST" && params.has("uploadId")) {
        const uploadId = params.get("uploadId");
        const uploads = ensureMultipartState();
        const upload = uploads[uploadId];
        if (!upload) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
        const content = Object.entries(upload.parts || {}).sort(([a], [b]) => Number(a) - Number(b)).map(([, part]) => part.content || "").join("");
        ensureDir(dirname(fsPath));
        createFile2(fsPath, content, "application/octet-stream");
        delete uploads[uploadId];
        await saveState2();
        return completeMultipartXml(bucket, object, getState().entries[fsPath]);
      }
      if (method === "PUT") {
        if (params.has("uploadId") && params.has("partNumber")) {
          const upload = ensureMultipartState()[params.get("uploadId")];
          if (!upload) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
          const content = await requestBodyText(requestMeta);
          upload.parts[String(params.get("partNumber"))] = {
            content,
            size: content.length
          };
          await saveState2();
          const response2 = textResponse("", 200);
          response2.headers.ETag = [`"${content.length}"`];
          return response2;
        }
        const srcPath = copySource(requestMeta);
        if (srcPath) {
          if (!state.entries[srcPath]) return errorXml("NoSuchKey", "copy source does not exist", 404);
          ensureDir(dirname(fsPath));
          cloneEntryTree(srcPath, fsPath);
          await saveState2();
          return copyResultXml();
        }
        const isDir2 = object.endsWith("/");
        if (isDir2) {
          ensureDir(fsPath);
        } else {
          ensureDir(dirname(fsPath));
          createFile2(fsPath, await requestBodyText(requestMeta), headerValue(requestMeta, "Content-Type") || "application/octet-stream");
        }
        await saveState2();
        const response = textResponse("", 200);
        response.headers.ETag = [`"${((_a = getState().entries[fsPath]) == null ? void 0 : _a.size) || 0}"`];
        return response;
      }
      if (method === "DELETE") {
        if (params.has("uploadId")) {
          const uploadId = params.get("uploadId");
          const uploads = ensureMultipartState();
          if (!uploads[uploadId]) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
          delete uploads[uploadId];
          await saveState2();
          return textResponse("", 204);
        }
        removeEntry(fsPath);
        await saveState2();
        return textResponse("", 204);
      }
      return errorXml("MethodNotAllowed", "method not allowed", 405);
    };
  };
  const escapeXml = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const webdavPath = (path) => normalizePath(path.replace(/^\/dav\/?/, "/"));
  const propResponse = ({ href, item }) => {
    const collection = item.is_dir ? "<D:resourcetype><D:collection/></D:resourcetype>" : "<D:resourcetype/>";
    const length = item.is_dir ? "" : `<D:getcontentlength>${Number(item.size || 0)}</D:getcontentlength>`;
    return [
      "<D:response>",
      `<D:href>${escapeXml(href)}</D:href>`,
      "<D:propstat><D:prop>",
      `<D:displayname>${escapeXml(item.name || "")}</D:displayname>`,
      collection,
      length,
      `<D:getlastmodified>${escapeXml(new Date(item.modified || Date.now()).toUTCString())}</D:getlastmodified>`,
      "</D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat>",
      "</D:response>"
    ].join("");
  };
  const createWebDavServer = ({
    getState,
    cloneEntryTree,
    createFile: createFile2,
    ensureDir,
    isWorkspacePath,
    moveEntryTree,
    readFileResponse,
    removeEntry,
    requestPath,
    saveState: saveState2,
    toObjResp,
    workspaceGet,
    workspaceList
  }) => {
    const listVirtual = (path) => {
      const state = getState();
      const entry = state.entries[path];
      if (!entry || !entry.is_dir) return null;
      const items = entry.children.map((childPath) => state.entries[childPath]).filter(Boolean);
      if (path === "/") {
        items.unshift({
          name: "@workspace",
          is_dir: true,
          size: 0,
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      return { entry, items };
    };
    const getVirtual = (path) => {
      const state = getState();
      if (path === "/") {
        return { name: "", is_dir: true, size: 0, modified: (/* @__PURE__ */ new Date()).toISOString() };
      }
      return state.entries[path] || null;
    };
    const propfind = async (request, path) => {
      var _a, _b;
      const fsPath = webdavPath(path);
      let current;
      let children = [];
      if (isWorkspacePath(fsPath)) {
        const got = await workspaceGet(fsPath);
        if (got.error) return textResponse("", got.error.code || 404);
        current = got.data;
        if (current.is_dir) {
          const listed = await workspaceList(fsPath, { page: 1, per_page: 1e5 });
          if (!listed.error) children = listed.data.content || [];
        }
      } else {
        current = getVirtual(fsPath);
        const listed = listVirtual(fsPath);
        if (listed) children = listed.items.map(toObjResp);
      }
      if (!current) return textResponse("", 404);
      const hrefBase = "/dav" + (fsPath === "/" ? "/" : fsPath);
      const responses = [propResponse({ href: hrefBase, item: current })];
      const depth = String(((_a = request.headers) == null ? void 0 : _a.depth) || ((_b = request.headers) == null ? void 0 : _b.Depth) || "1");
      if (current.is_dir && depth !== "0") {
        for (const child of children) {
          responses.push(propResponse({
            href: normalizePath(hrefBase + "/" + child.name) + (child.is_dir ? "/" : ""),
            item: child
          }));
        }
      }
      return textResponse(`<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:">${responses.join("")}</D:multistatus>`, 207, "application/xml; charset=utf-8");
    };
    const requestBodyText2 = async (requestMeta) => {
      const body = requestMeta.body || requestMeta.Body || {};
      if (body.data !== void 0 && body.data !== null) {
        if (typeof body.data === "string") return body.data;
        if (typeof body.data.text === "function") return body.data.text();
        if (body.data instanceof ArrayBuffer) return String.fromCharCode(...new Uint8Array(body.data));
        if (typeof body.data === "object") return JSON.stringify(body.data);
      }
      if (body.string && Array.isArray(body.string.values)) return body.string.values.join("");
      return "";
    };
    const headerValue2 = (requestMeta, name) => {
      const headers = requestMeta.headers || requestMeta.Headers || {};
      const lower = name.toLowerCase();
      for (const [key, value] of Object.entries(headers)) {
        if (String(key).toLowerCase() !== lower) continue;
        if (Array.isArray(value)) return value[0] || "";
        return String(value || "");
      }
      return "";
    };
    const destinationPath = (requestMeta) => {
      const raw = headerValue2(requestMeta, "Destination");
      if (!raw) return "";
      try {
        const parsed = new URL(raw);
        return webdavPath(parsed.pathname.replace(/^\/plugin\/private\/[^/]+/, ""));
      } catch (_) {
        return webdavPath(raw.replace(/^\/plugin\/private\/[^/]+/, ""));
      }
    };
    const rejectWorkspaceWrite = (fsPath) => {
      if (!isWorkspacePath(fsPath)) return null;
      return textResponse("WebDAV write operations for /@workspace are disabled until SiYuan upload/move support is proven", 501);
    };
    const lockToken = () => `opaquelocktoken:siyuan-cloud-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    const lockResponse = (token) => textResponse([
      `<?xml version="1.0" encoding="utf-8"?>`,
      `<D:prop xmlns:D="DAV:"><D:lockdiscovery><D:activelock>`,
      `<D:locktype><D:write/></D:locktype><D:lockscope><D:exclusive/></D:lockscope>`,
      `<D:depth>infinity</D:depth><D:timeout>Second-3600</D:timeout>`,
      `<D:locktoken><D:href>${escapeXml(token)}</D:href></D:locktoken>`,
      `</D:activelock></D:lockdiscovery></D:prop>`
    ].join(""), 200, "application/xml; charset=utf-8");
    return async (request) => {
      const requestMeta = request.request || request.Request || {};
      const method = String(requestMeta.method || requestMeta.Method || "GET").toUpperCase();
      const path = requestPath(request);
      if (method === "OPTIONS") {
        return {
          ...textResponse("", 204),
          headers: {
            Allow: ["OPTIONS, GET, HEAD, PROPFIND, MKCOL, PUT, DELETE, COPY, MOVE, LOCK, UNLOCK, PROPPATCH"],
            DAV: ["1, 2"]
          }
        };
      }
      if (method === "PROPFIND") return propfind(requestMeta, path);
      if (method === "GET" || method === "HEAD") return readFileResponse(webdavPath(path), request);
      if (method === "MKCOL") {
        const fsPath = webdavPath(path);
        const rejected = rejectWorkspaceWrite(fsPath);
        if (rejected) return rejected;
        ensureDir(fsPath);
        await saveState2();
        return textResponse("", 201);
      }
      if (method === "PUT") {
        const fsPath = webdavPath(path);
        const rejected = rejectWorkspaceWrite(fsPath);
        if (rejected) return rejected;
        createFile2(fsPath, await requestBodyText2(requestMeta), headerValue2(requestMeta, "Content-Type"));
        await saveState2();
        return textResponse("", 201);
      }
      if (method === "DELETE") {
        const fsPath = webdavPath(path);
        const rejected = rejectWorkspaceWrite(fsPath);
        if (rejected) return rejected;
        removeEntry(fsPath);
        await saveState2();
        return textResponse("", 204);
      }
      if (method === "COPY" || method === "MOVE") {
        const srcPath = webdavPath(path);
        const dstPath = destinationPath(requestMeta);
        const rejected = rejectWorkspaceWrite(srcPath) || rejectWorkspaceWrite(dstPath);
        if (rejected) return rejected;
        if (!dstPath) return textResponse("missing Destination header", 400);
        if (method === "COPY") cloneEntryTree(srcPath, dstPath);
        if (method === "MOVE") moveEntryTree(srcPath, dstPath);
        await saveState2();
        return textResponse("", 201);
      }
      if (method === "LOCK") {
        const fsPath = webdavPath(path);
        const token = lockToken();
        const state = getState();
        state.webdav_locks = state.webdav_locks || {};
        state.webdav_locks[token] = { path: fsPath, created: (/* @__PURE__ */ new Date()).toISOString() };
        await saveState2();
        const response = lockResponse(token);
        response.headers["Lock-Token"] = [`<${token}>`];
        return response;
      }
      if (method === "UNLOCK") {
        const state = getState();
        const token = headerValue2(requestMeta, "Lock-Token").replace(/[<>]/g, "");
        if (state.webdav_locks && token) delete state.webdav_locks[token];
        await saveState2();
        return textResponse("", 204);
      }
      if (method === "PROPPATCH") {
        return textResponse(`<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:"/>`, 207, "application/xml; charset=utf-8");
      }
      return textResponse("method not allowed", 405);
    };
  };
  (function() {
    const now = () => (/* @__PURE__ */ new Date()).toISOString();
    let state = defaultState(now);
    const {
      cloneEntryTree,
      createFile: createFile2,
      ensureDir,
      moveEntryTree,
      removeEmptyDirs,
      removeEntry,
      renameEntryInDir
    } = createVirtualFs({
      getState: () => state,
      now
    });
    const log = (...args) => siyuan.logger.info("[siyuan-cloud]", ...args);
    const warn = (...args) => siyuan.logger.warn("[siyuan-cloud]", ...args);
    const pick = (value, lowerName, upperName) => {
      if (!value) return void 0;
      if (value[lowerName] !== void 0) return value[lowerName];
      if (value[upperName] !== void 0) return value[upperName];
      return void 0;
    };
    const extensionType = (name, isDir2) => {
      if (isDir2) return 1;
      const ext = String(name).toLowerCase().split(".").pop() || "";
      if (["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif"].includes(ext)) return 2;
      if (["mp4", "mkv", "mov", "avi", "webm", "m4v"].includes(ext)) return 3;
      if (["mp3", "flac", "wav", "ogg", "m4a"].includes(ext)) return 4;
      if (["zip", "7z", "rar", "tar", "gz", "bz2"].includes(ext)) return 5;
      if (["pdf", "epub", "txt", "md", "json", "yaml", "yml", "csv", "log"].includes(ext)) return 6;
      return 0;
    };
    const toObjResp = (entry) => ({
      name: entry.name,
      size: entry.size || 0,
      is_dir: !!entry.is_dir,
      modified: entry.modified,
      created: entry.created || entry.modified,
      sign: "",
      thumb: "",
      type: extensionType(entry.name, entry.is_dir),
      hashinfo: "",
      hash_info: {}
    });
    const toFsGetResp = (entry, path) => ({
      ...toObjResp(entry),
      raw_url: entry.is_dir ? "" : "/plugin/private/siyuan-cloud/d" + normalizePath(path),
      readme: "",
      header: "",
      provider: "siyuan-storage",
      related: relatedEntries(path, entry).map(toObjResp)
    });
    const page = (items, req) => {
      const pageIndex = Math.max(1, Number(req.page || req.Page || 1));
      const perPage = Math.max(1, Number(req.per_page || req.perPage || req.PerPage || items.length || 1));
      const start = (pageIndex - 1) * perPage;
      return items.slice(start, start + perPage);
    };
    const {
      isWorkspacePath,
      siyuanApiJson,
      workspaceGet,
      workspaceList,
      workspaceReadText,
      workspaceRelPath
    } = createWorkspaceAdapter({
      client: siyuan.client,
      extensionType,
      failure,
      now,
      page,
      toObjResp
    });
    const relatedEntries = (path, entry) => {
      if (!entry || entry.is_dir) return [];
      const parent = state.entries[dirname(path)];
      if (!parent || !parent.children) return [];
      const stem = entry.name.replace(/\.[^.]+$/, "");
      return parent.children.map((childPath) => state.entries[childPath]).filter((item) => item && !item.is_dir && item.name !== entry.name && item.name.startsWith(stem));
    };
    const parseJson = async (request) => {
      const requestMeta = pick(request, "request", "Request");
      const body = pick(requestMeta, "body", "Body");
      if (!body) return {};
      if (body.data !== void 0 && body.data !== null) {
        if (typeof body.data === "object") {
          if (typeof body.data.json === "function") {
            try {
              return await body.data.json();
            } catch (_) {
            }
          }
          if (typeof body.data.text === "function") {
            const text2 = await body.data.text();
            if (!text2 || !String(text2).trim()) return {};
            try {
              return JSON.parse(text2);
            } catch (_) {
              return { content: text2 };
            }
          }
          return body.data;
        }
        if (typeof body.data === "string" && body.data.trim()) {
          try {
            return JSON.parse(body.data);
          } catch (_) {
            return { content: body.data };
          }
        }
      }
      if (body.form && typeof body.form === "object") {
        const values = body.form.values || body.form.Value || {};
        const files = body.form.files || body.form.File || {};
        const flattened = {};
        for (const key of Object.keys(values)) {
          const value = values[key];
          flattened[key] = Array.isArray(value) && value.length === 1 ? value[0] : value;
        }
        flattened.files = files;
        return flattened;
      }
      if (body.string && Array.isArray(body.string.values)) return { content: body.string.values.join("") };
      return {};
    };
    const queryValue = (request, key) => {
      const url = pick(request, "url", "URL");
      const queryMap = pick(url, "query", "Query");
      if (queryMap && typeof queryMap === "object") {
        const value = queryMap[key];
        return Array.isArray(value) ? String(value[0] || "") : String(value || "");
      }
      const query = queryMap || pick(url, "rawQuery", "RawQuery") || pick(url, "search", "Search") || "";
      const params = new URLSearchParams(query);
      return params.get(key) || "";
    };
    const decodePath = (path) => {
      try {
        return decodeURIComponent(path);
      } catch (_) {
        return path;
      }
    };
    const requestPath = (request) => {
      const context = pick(request, "context", "Context");
      const url = pick(request, "url", "URL");
      const fromContext = pick(context, "path", "Path");
      const fromUrl = pick(url, "path", "Path");
      const raw = fromContext || fromUrl || "/";
      return decodePath(raw.replace(/^\/plugin\/private\/[^/]+/, "") || "/");
    };
    const rawForwardHeaders = (headers = {}) => {
      const result = {};
      for (const [key, value] of Object.entries(headers || {})) {
        const normalized = String(key).toLowerCase();
        if (["accept-ranges", "content-range", "content-length", "etag", "last-modified", "cache-control"].includes(normalized)) {
          result[key] = Array.isArray(value) ? value.map(String) : [String(value)];
        }
      }
      return result;
    };
    const fileMime = (path) => {
      const ext = String(path || "").split(".").pop().toLowerCase();
      const types = {
        mp4: "video/mp4",
        m4v: "video/mp4",
        webm: "video/webm",
        mkv: "video/x-matroska",
        mov: "video/quicktime",
        mp3: "audio/mpeg",
        m4a: "audio/mp4",
        flac: "audio/flac",
        wav: "audio/wav",
        ogg: "audio/ogg"
      };
      return types[ext] || "application/octet-stream";
    };
    const saveState$1 = async (domains) => {
      await saveState(siyuan.storage, state, domains);
    };
    const saveConfigState = async () => saveState$1("config");
    const saveRuntimeState = async () => saveState$1("runtime");
    const saveSearchState = async () => saveState$1("search");
    const saveStorageAddition = async (storage, addition) => {
      const target = state.storages.find((item) => item.id === storage.id) || state.storages.find((item) => item.mount_path === storage.mount_path);
      if (!target) return;
      target.addition = JSON.stringify(addition || {});
      target.modified = now();
      await saveConfigState();
    };
    const driverRuntime = createDriverRuntime({
      client: siyuan.client,
      getSettings: () => state.settings,
      saveStorageAddition
    });
    const searchFs = {
      async get(path) {
        const normalized = normalizePath(path);
        if (normalized === "/") return { name: "", is_dir: true, size: 0 };
        if (isWorkspacePath(normalized)) {
          const result = await workspaceGet(normalized);
          if (result.error) return null;
          return result.data;
        }
        const mount = driverRuntime.resolve(state.storages, normalized);
        if (mount) {
          return mount.driver.get(mount.storage, mount.relPath, { skipLink: true });
        }
        const entry = state.entries[normalized];
        if (entry) return toObjResp(entry);
        const mountName = normalized === "/" ? "" : normalized.split("/").filter(Boolean)[0];
        if (normalized !== "/" && state.storages.some((storage) => !storage.disabled && normalizePath(storage.mount_path || "/").split("/").filter(Boolean)[0] === mountName)) {
          return { name: basename(normalized), is_dir: true, size: 0 };
        }
        return null;
      },
      async list(path) {
        const normalized = normalizePath(path);
        if (isWorkspacePath(normalized)) {
          const result = await workspaceList(normalized, { page: 1, per_page: 1e5 });
          if (result.error) return [];
          return result.data.content || [];
        }
        const mount = driverRuntime.resolve(state.storages, normalized);
        if (mount) {
          const data = await mount.driver.list(mount.storage, mount.relPath, { page: 1, per_page: 1e5 });
          return data.content || [];
        }
        const entry = state.entries[normalized];
        const children = (entry == null ? void 0 : entry.is_dir) ? (entry.children || []).map((childPath) => state.entries[childPath]).filter(Boolean).map(toObjResp) : [];
        if (normalized === "/") {
          children.unshift({ name: "@workspace", is_dir: true, size: 0 });
          for (const mountEntry of driverRuntime.mountEntries(state.storages, now)) {
            if (!children.some((item) => item.name === mountEntry.name)) children.unshift(toObjResp(mountEntry));
          }
        }
        return children;
      }
    };
    const searchIndex = createSearchIndex({
      getObj: searchFs.get,
      getState: () => state,
      isIndexDisabled: (path) => {
        const normalized = normalizePath(path);
        return state.storages.some((storage) => {
          const mountPath = normalizePath(storage.mount_path || "/");
          return !!storage.disable_index && normalized !== "/" && (normalized === mountPath || normalized.startsWith(`${mountPath}/`));
        });
      },
      listObjs: searchFs.list,
      now,
      saveState: saveSearchState
    });
    const loadState$1 = async () => {
      var _a;
      const loaded = await loadState({ now, storage: siyuan.storage });
      state = loaded.state;
      let userChanged = false;
      try {
        const conf = await siyuanApiJson("/api/system/getConf", {});
        userChanged = syncDefaultUserWithSiyuan(state, accountFromSiyuanConf(((_a = conf == null ? void 0 : conf.data) == null ? void 0 : _a.conf) || (conf == null ? void 0 : conf.data) || conf));
      } catch (error) {
        warn("failed to sync SiYuan account user", (error == null ? void 0 : error.message) || String(error));
      }
      if (loaded.shouldSave) {
        await saveState$1();
      } else if (userChanged) {
        await saveConfigState();
      }
      ensureDir("/");
      ensureSearchState(state);
    };
    const reloadConfigState = async () => {
      const config = await loadConfigState({ storage: siyuan.storage });
      if (!config) return false;
      Object.assign(state, config);
      ensureDir("/");
      ensureSearchState(state);
      return true;
    };
    const settingItem = (key, value, index) => {
      const meta = settingMeta[key] || {};
      return {
        key,
        value: String(value ?? ""),
        help: meta.help || "",
        type: meta.type || "string",
        options: meta.options || "",
        group: meta.group ?? SETTING_GROUP.SINGLE,
        flag: meta.flag ?? SETTING_FLAG.PUBLIC,
        index: index || 0
      };
    };
    const requestedGroups = (request) => {
      const raw = queryValue(request, "groups") || queryValue(request, "group");
      if (!raw) return null;
      const groups = raw.split(",").map((item) => Number(item.trim())).filter((item) => Number.isFinite(item));
      return groups.length ? groups : null;
    };
    const listSettings = (request, source) => {
      const groups = request ? requestedGroups(request) : null;
      return Object.entries(source || state.settings).map(([key, value], index) => settingItem(key, value, index)).filter((item) => !groups || groups.includes(item.group));
    };
    const saveToolSettings = async (req, keyMap, responseValue) => {
      for (const [settingKey, reqKey] of Object.entries(keyMap)) {
        state.settings[settingKey] = String(req[reqKey] ?? "");
      }
      await saveConfigState();
      return jsonResponse(success(responseValue === void 0 ? "ok" : responseValue));
    };
    const pageSlice = (items, request) => {
      const pageIndex = Math.max(1, Number(queryValue(request, "page") || 1));
      const perPage = Math.max(1, Number(queryValue(request, "per_page") || queryValue(request, "perPage") || items.length || 1));
      const start = (pageIndex - 1) * perPage;
      return pageResp(items.slice(start, start + perPage), items.length);
    };
    const storageResp = (storage) => ({
      ...storage,
      mount_details: storage.mount_details || {
        total_space: 0,
        used_space: 0,
        free_space: 0
      }
    });
    const { shareGet, shareList } = createShareReader({
      driverRuntime,
      getState: () => state,
      isWorkspacePath,
      page,
      saveState: saveConfigState,
      toFsGetResp,
      toObjResp,
      workspaceGet,
      workspaceList
    });
    const taskStore = createTaskStore({
      getState: () => state,
      now,
      saveState: saveRuntimeState
    });
    const readFileResponse = async (filePath, request) => {
      if (isWorkspacePath(filePath)) {
        const file = await workspaceReadText(filePath);
        if (!file.ok) return textResponse(file.text || "not found", file.status || 404);
        return textResponse(file.text, 200, file.contentType);
      }
      const mount = driverRuntime.resolve(state.storages, filePath);
      if (mount && mount.driver.read) {
        try {
          const options = proxyReadOptions(request, filePath);
          const data = await mount.driver.read(mount.storage, mount.relPath, options);
          if (data.link) {
            const link = linkFromDriverData(data);
            return proxy(null, link, { request_header: options.requestHeaders }, !!mount.storage.proxy_range);
          }
          if (String(data.bodyEncoding || "").startsWith("base64")) {
            const headers = rawForwardHeaders(data.headers);
            if (!headers["Accept-Ranges"] && !headers["accept-ranges"]) headers["Accept-Ranges"] = ["bytes"];
            return rawResponse(
              base64ToArrayBuffer(data.body || ""),
              data.status || 200,
              data.contentType || fileMime(filePath),
              headers
            );
          }
          return textResponse(data.body || "", data.status || 200, data.contentType || "application/octet-stream");
        } catch (error) {
          return textResponse(error.message || "driver read failed", 502);
        }
      }
      const entry = state.entries[filePath];
      if (!entry || entry.is_dir) return textResponse("not found", 404);
      if (String(entry.body_encoding || "").startsWith("base64")) {
        return rawResponse(
          base64ToArrayBuffer(entry.content || ""),
          200,
          entry.mime || "application/octet-stream"
        );
      }
      return textResponse(entry.content || "", 200, entry.mime || "application/octet-stream");
    };
    const handleWebDav = createWebDavServer({
      cloneEntryTree,
      createFile: createFile2,
      ensureDir,
      getState: () => state,
      isWorkspacePath,
      moveEntryTree,
      readFileResponse,
      removeEntry,
      requestPath,
      saveState: saveRuntimeState,
      toObjResp,
      workspaceGet,
      workspaceList
    });
    const handleS3 = createS3Server({
      cloneEntryTree,
      createFile: createFile2,
      ensureDir,
      getState: () => state,
      removeEntry,
      requestPath,
      saveState: saveRuntimeState
    });
    let handlers = {};
    handlers = {
      ...createStatusHandlers({
        client: siyuan.client,
        getState: () => state,
        handlersRef: () => handlers
      }),
      ...createTaskHandlers({
        parseJson,
        queryValue,
        taskStore
      }),
      ...createAuthHandlers({
        getState: () => state,
        parseJson,
        saveState: saveConfigState
      }),
      ...createCompatHandlers(),
      ...createMetaHandlers({
        getState: () => state,
        pageSlice,
        parseJson,
        queryValue,
        saveState: saveConfigState
      }),
      ...createMessageHandlers({
        getState: () => state,
        now,
        parseJson,
        saveState: saveRuntimeState
      }),
      ...createIndexHandlers({
        parseJson,
        searchIndex
      }),
      ...createScanHandlers({
        getState: () => state,
        now,
        saveState: saveRuntimeState
      }),
      ...createSecurityHandlers({
        getState: () => state,
        now,
        parseJson,
        queryValue,
        saveState: saveConfigState
      }),
      ...createPublicHandlers({
        getState: () => state,
        handlersRef: () => handlers,
        settingItem
      }),
      ...createAdminHandlers({
        driverRuntime,
        getState: () => state,
        isWorkspacePath,
        listSettings,
        now,
        pageSlice,
        parseJson,
        queryValue,
        reloadConfigState,
        saveState: saveConfigState,
        saveToolSettings,
        settingItem,
        storageResp,
        workspaceGet
      }),
      ...createFsHandlers({
        cloneEntryTree,
        createFile: createFile2,
        driverRuntime,
        ensureDir,
        getState: () => state,
        isWorkspacePath,
        moveEntryTree,
        now,
        page,
        parseJson,
        removeEmptyDirs,
        removeEntry,
        renameEntryInDir,
        saveConfigState,
        saveState: saveRuntimeState,
        searchIndex,
        shareGet,
        shareClientIP,
        shareList,
        siyuanApiJson,
        taskStore,
        toFsGetResp,
        toObjResp,
        workspaceGet,
        workspaceList,
        workspaceRelPath
      }),
      ...createArchiveHandlers({
        parseJson,
        taskStore
      }),
      ...createShareHandlers({
        driverRuntime,
        getState: () => state,
        isWorkspacePath,
        now,
        page,
        parseJson,
        queryValue,
        saveState: saveConfigState,
        workspaceGet
      })
    };
    const route = createRouter({
      getState: () => state,
      handleS3,
      handleWebDav,
      handlers,
      isWorkspacePath,
      pick,
      queryValue,
      readFileResponse,
      requestPath,
      saveState: saveConfigState,
      warn,
      workspaceReadText
    });
    siyuan.plugin.lifecycle.onload = async () => {
      await loadState$1();
      await siyuan.rpc.bind("siyuan-cloud.status", async () => createStatusPayload({
        client: siyuan.client,
        getState: () => state,
        handlersRef: () => handlers
      }), "Return Siyuan Cloud compatibility runtime status.");
      await log("kernel plugin loaded", OPENLIST_VERSION);
    };
    siyuan.plugin.lifecycle.onunload = async () => {
      await saveState$1(["config", "runtime", "search"]);
      await log("kernel plugin unloaded");
    };
    siyuan.server.private.http.handler = async (request) => {
      return route(request);
    };
  })();
})();
