(function() {
  "use strict";
  const OPENLIST_VERSION = "siyuan-cloud-port-0.3.0";
  const STATE_FILE = "siyuan-cloud/state.json";
  const TASK_TYPES = [
    "copy",
    "move",
    "upload",
    "offline_download",
    "offline_download_transfer",
    "aria2_down",
    "aria2_transfer",
    "qbit_down",
    "qbit_transfer",
    "decompress",
    "decompress_upload"
  ];
  const success = (data) => ({
    code: 200,
    message: "success",
    data: data === void 0 ? null : data
  });
  const successWithMessage = (message, data) => ({
    code: 200,
    message: message || "success",
    data: data === void 0 ? null : data
  });
  const failure = (message, code, data) => ({
    code: code || 500,
    message: message || "error",
    data: data === void 0 ? null : data
  });
  const jsonResponse = (payload, statusCode) => ({
    statusCode: statusCode || 200,
    headers: {
      "Content-Type": ["application/json; charset=utf-8"],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
    },
    body: {
      data: {
        type: "JSON",
        data: payload
      }
    }
  });
  const textResponse = (text2, statusCode, contentType) => ({
    statusCode: statusCode || 200,
    headers: {
      "Content-Type": [contentType || "text/plain; charset=utf-8"],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
    },
    body: {
      string: {
        format: "%s",
        values: [text2]
      }
    }
  });
  const rawResponse = (data, statusCode, contentType, extraHeaders = {}) => ({
    statusCode: statusCode || 200,
    headers: {
      "Content-Type": [contentType || "application/octet-stream"],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION],
      ...extraHeaders
    },
    body: {
      raw: {
        contentType: contentType || "application/octet-stream",
        data
      }
    }
  });
  const redirectResponse = (location, statusCode = 302) => ({
    statusCode,
    headers: {
      Location: [location],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
    },
    body: {
      redirect: {
        location
      }
    }
  });
  const proxyResponse = (url, headers = {}, method = "GET") => {
    const normalizedHeaders = {};
    for (const [key, value] of Object.entries(headers || {})) {
      if (value === void 0 || value === null || value === "") continue;
      normalizedHeaders[key] = Array.isArray(value) ? value.map(String) : [String(value)];
    }
    return {
      statusCode: 200,
      headers: {
        "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
      },
      body: {
        proxy: {
          url,
          method,
          headers: normalizedHeaders
        }
      }
    };
  };
  const base64ToArrayBuffer = (value) => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "").replace(/-/g, "+").replace(/_/g, "/");
    const bytes2 = [];
    for (let i = 0; i < clean.length; i += 4) {
      const a = chars.indexOf(clean[i]);
      const b = chars.indexOf(clean[i + 1]);
      const c = clean[i + 2] === "=" ? -1 : chars.indexOf(clean[i + 2]);
      const d = clean[i + 3] === "=" ? -1 : chars.indexOf(clean[i + 3]);
      if (a < 0 || b < 0) continue;
      bytes2.push(a << 2 | b >> 4);
      if (c >= 0) bytes2.push((b & 15) << 4 | c >> 2);
      if (d >= 0) bytes2.push((c & 3) << 6 | d);
    }
    return new Uint8Array(bytes2).buffer;
  };
  const pageResp = (content, total) => ({
    content,
    total: total === void 0 ? content.length : total
  });
  const normalizePath = (input) => {
    let value = typeof input === "string" && input.trim() ? input.trim() : "/";
    if (!value.startsWith("/")) value = "/" + value;
    value = value.replace(/\\/g, "/").replace(/\/+/g, "/");
    const parts = [];
    for (const part of value.split("/")) {
      if (!part || part === ".") continue;
      if (part === "..") continue;
      parts.push(part);
    }
    return "/" + parts.join("/");
  };
  const dirname = (path) => {
    const normalized = normalizePath(path);
    if (normalized === "/") return "/";
    const index = normalized.lastIndexOf("/");
    return index <= 0 ? "/" : normalized.slice(0, index);
  };
  const basename = (path) => {
    const normalized = normalizePath(path);
    if (normalized === "/") return "";
    return normalized.slice(normalized.lastIndexOf("/") + 1);
  };
  const isSafeRelativeName = (name) => {
    const value = String(name || "").trim();
    return !!value && !/[\\/]/.test(value) && value !== "." && value !== "..";
  };
  const linkFromDriverData = (data = {}) => {
    const link = data.link || data.Link || {};
    const url = link.url || link.URL || data.proxy_url || data.proxyUrl || data.redirect_url || data.redirectUrl || "";
    const header = link.header || link.Header || data.proxy_headers || data.proxyHeaders || data.headers || {};
    return {
      url,
      header,
      method: link.method || link.Method || data.proxy_method || data.proxyMethod || "GET",
      content_length: Number(link.content_length || link.ContentLength || data.content_length || data.contentLength || 0),
      concurrency: Number(link.concurrency || link.Concurrency || data.concurrency || 0),
      part_size: Number(link.part_size || link.PartSize || data.part_size || data.partSize || 0),
      range_reader: link.range_reader || link.RangeReader || null
    };
  };
  const SETTING_GROUP = {
    SINGLE: 0,
    SITE: 1,
    STYLE: 2,
    PREVIEW: 3,
    GLOBAL: 4,
    OFFLINE_DOWNLOAD: 5,
    INDEX: 6,
    SSO: 7,
    LDAP: 8,
    S3: 9,
    FTP: 10,
    TRAFFIC: 11
  };
  const SETTING_FLAG = {
    PUBLIC: 0,
    PRIVATE: 1,
    READONLY: 2
  };
  const field = (name, type = "string", defaultValue = "", options = "", required = false, help = "") => ({
    name,
    type,
    default: String(defaultValue ?? ""),
    options: Array.isArray(options) ? options.join(",") : options,
    required,
    help
  });
  const unsupported = (name, extra = [], common = [rootPath("/")]) => ({
    common,
    additional: extra,
    config: {
      name,
      local_sort: true,
      only_proxy: true,
      no_cache: false,
      no_upload: true,
      need_ms: false,
      default_root: "/",
      alert: "warning",
      only_indices: false,
      prefer_proxy: true,
      status: "metadata-only",
      note: "Driver metadata is copied for mount creation. Runtime behavior is still being ported to the SiYuan kernel JS environment."
    }
  });
  const supported = (name, extra = [], common) => {
    const info = unsupported(name, extra, common);
    info.config.status = "ported";
    info.config.note = "Runtime behavior is wired through SiYuan /api/network/forwardProxy in the kernel plugin.";
    info.config.no_upload = false;
    info.config.only_proxy = false;
    info.config.prefer_proxy = false;
    return info;
  };
  const preferProxy = (info) => {
    info.config.prefer_proxy = true;
    return info;
  };
  const text = (name, required = false, help = "") => field(name, "string", "", "", required, help);
  const password = (name, required = false, help = "") => field(name, "password", "", "", required, help);
  const bool = (name, defaultValue = false, help = "") => field(name, "bool", defaultValue, "", false, help);
  const number = (name, defaultValue = "", required = false, help = "") => field(name, "number", defaultValue, "", required, help);
  const float = (name, defaultValue = "", required = false, help = "") => field(name, "float", defaultValue, "", required, help);
  const select = (name, options, defaultValue = "", required = false, help = "") => field(name, "select", defaultValue, options, required, help);
  const rootPath = (defaultValue = "/") => field("root_folder_path", "string", defaultValue, "", false, "OpenList root folder path.");
  const rootId$1 = (defaultValue = "") => field("root_folder_id", "string", defaultValue, "", false, defaultValue ? `OpenList default root: ${defaultValue}` : "");
  const metadataOnlyNames = [
    "139Yun",
    "Alias",
    "AutoIndex",
    "Azure Blob Storage",
    "BaiduPhoto",
    "CNB Releases",
    "ChaoXingGroupDrive",
    "Chunk",
    "Cloudreve V4",
    "Crypt",
    "Degoo",
    "Doubao",
    "DoubaoNew",
    "DoubaoShare",
    "FTP",
    "FebBox",
    "FeijiPan",
    "GitHub API",
    "GitHub Releases",
    "HalalCloud",
    "HalalCloudOpen",
    "ILanZou",
    "IPFS API",
    "KodBox",
    "LenovoNasShare",
    "Local",
    "MediaFire",
    "MediaTrack",
    "Mega_nz",
    "Misskey",
    "MoPan",
    "NeteaseMusic",
    "OpenListShare",
    "PikPakShare",
    "ProtonDrive",
    "QuarkOpen",
    "QuarkTV",
    "Seafile",
    "Strm",
    "Teambition",
    "Teldrive",
    "Template",
    "Terabox",
    "ThunderBrowser",
    "ThunderBrowserExpert",
    "ThunderExpert",
    "ThunderX",
    "ThunderXExpert",
    "UC",
    "UCTV",
    "UrlTree",
    "WeiYun",
    "WoPan",
    "WPS",
    "YandexDisk"
  ];
  const withAliases = (map) => ({
    ...map,
    "115": map["115 Cloud"],
    "115Open": map["115 Open"],
    "115Share": map["115 Share"],
    "123": map["123Pan"],
    "123Open": map["123 Open"],
    "123Share": map["123PanShare"],
    "AliyunDrive": map.Aliyundrive,
    "AliyunDriveOpen": map.AliyundriveOpen,
    "AliyunDriveShare": map.AliyundriveShare,
    "OneDrive": map.Onedrive
  });
  const driverNameOrder = [
    "SiYuanKernel",
    "SiYuanWorkspace",
    "WebDav",
    "OpenList",
    "AListV3",
    "AList V3",
    "S3",
    "Doge",
    "115 Cloud",
    "115 Open",
    "115 Share",
    "123Pan",
    "123 Open",
    "123PanShare",
    "123PanLink",
    "189Cloud",
    "189CloudPC",
    "189CloudTV",
    "Aliyundrive",
    "AliyundriveOpen",
    "AliyundriveShare",
    "BaiduNetdisk",
    "Cloudreve",
    "Dropbox",
    "GoogleDrive",
    "GooglePhoto",
    "Lanzou",
    "Onedrive",
    "OnedriveAPP",
    "Onedrive Sharelink",
    "PikPak",
    "Quark",
    "SFTP",
    "SMB",
    "Thunder",
    "URLTree",
    "USS",
    "Virtual"
  ];
  const buildDriverInfoMap = () => withAliases({
    ...Object.fromEntries(metadataOnlyNames.map((name) => [name, unsupported(name)])),
    SiYuanKernel: {
      common: [field("root_folder_path", "string", "/", "", false, "Virtual OpenList root inside siyuan.storage.")],
      additional: [],
      config: {
        name: "SiYuanKernel",
        local_sort: true,
        only_proxy: false,
        no_cache: true,
        no_upload: false,
        need_ms: false,
        default_root: "/",
        alert: "success",
        only_indices: false,
        prefer_proxy: false,
        status: "ported",
        note: "Virtual OpenList storage backed by SiYuan kernel plugin storage."
      }
    },
    SiYuanWorkspace: {
      common: [field("root_folder_path", "string", "/@workspace", "", false, "SiYuan workspace files exposed through /api/file.")],
      additional: [],
      config: {
        name: "SiYuanWorkspace",
        local_sort: true,
        only_proxy: true,
        no_cache: true,
        no_upload: true,
        need_ms: false,
        default_root: "/@workspace",
        alert: "warning",
        only_indices: false,
        prefer_proxy: true,
        status: "ported",
        note: "Read/list/remove/rename are wired through SiYuan /api/file. Upload is still guarded."
      }
    },
    WebDav: supported("WebDav", [
      select("vendor", ["sharepoint", "other"], "other"),
      text("address", true),
      text("username", true),
      password("password", true),
      bool("tls_insecure_skip_verify", false)
    ]),
    OpenList: supported("OpenList", [
      text("url", true),
      password("meta_password"),
      text("username"),
      password("password"),
      password("token"),
      bool("pass_ip_to_upsteam", true),
      bool("pass_ua_to_upsteam", true),
      bool("forward_archive_requests", true),
      bool("pass_refresh_flag_to_upsteam", false)
    ]),
    AListV3: supported("AListV3", [
      text("url", true),
      text("username"),
      password("password"),
      password("token")
    ]),
    "AList V3": supported("AList V3", [
      text("url", true),
      text("username"),
      password("password"),
      password("token")
    ]),
    S3: supported("S3", [
      text("bucket", true),
      text("endpoint", true),
      text("region"),
      text("access_key_id", true),
      password("secret_access_key", true),
      password("session_token"),
      text("custom_host"),
      bool("force_path_style", false),
      select("list_object_version", ["v1", "v2"], "v1"),
      bool("enable_direct_upload", false)
    ]),
    Doge: supported("Doge", [
      text("bucket", true),
      text("endpoint", true),
      text("region"),
      text("access_key_id", true),
      password("secret_access_key", true),
      password("session_token"),
      bool("force_path_style", false)
    ]),
    "115 Cloud": unsupported("115 Cloud", [
      rootId$1("0"),
      password("cookie", true),
      text("qrcode_token"),
      select("qrcode_source", ["web", "android", "ios", "tv", "alipaymini", "wechatmini", "qandroid"], "linux"),
      number("page_size", 1e3),
      float("limit_rate", 2)
    ]),
    "115 Open": unsupported("115 Open", [
      rootId$1(),
      select("order_by", ["file_name", "file_size", "user_utime", "file_type"]),
      select("order_direction", ["asc", "desc"]),
      float("limit_rate", 1),
      number("page_size", 200),
      password("access_token", true),
      password("refresh_token", true)
    ]),
    "115 Share": unsupported("115 Share", [text("share_code", true), password("receive_code"), rootId$1()]),
    "123Pan": supported("123Pan", [
      rootId$1("0"),
      text("username", true),
      password("password", true),
      password("access_token"),
      number("UploadThread", 3),
      field("platform", "string", "web")
    ]),
    "123 Open": unsupported("123 Open", [
      rootId$1(),
      text("ClientID"),
      password("ClientSecret"),
      password("AccessToken"),
      password("RefreshToken"),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/123cloud/renewapi"),
      number("UploadThread", 3),
      bool("DirectLink", false),
      password("DirectLinkPrivateKey"),
      number("DirectLinkValidDuration", 30)
    ]),
    "123PanShare": unsupported("123PanShare", [text("share_key", true), password("share_pwd"), rootId$1()]),
    "123PanLink": unsupported("123PanLink", [text("url", true)]),
    "189Cloud": unsupported("189Cloud", [rootId$1("-11"), text("username", true), password("password", true), password("cookie")]),
    "189CloudPC": unsupported("189CloudPC", [rootId$1("-11"), text("username", true), password("password", true), password("cookie")]),
    "189CloudTV": unsupported("189CloudTV", [rootId$1("-11"), text("username", true), password("password", true), password("cookie")]),
    Aliyundrive: unsupported("Aliyundrive", [
      rootId$1("root"),
      password("refresh_token", true),
      select("order_by", ["name", "size", "updated_at", "created_at"]),
      select("order_direction", ["ASC", "DESC"]),
      bool("rapid_upload", false),
      bool("internal_upload", false)
    ]),
    AliyundriveOpen: unsupported("AliyundriveOpen", [
      select("drive_type", ["default", "resource", "backup"], "resource"),
      rootId$1(),
      password("refresh_token", true),
      select("order_by", ["name", "size", "updated_at", "created_at"]),
      select("order_direction", ["ASC", "DESC"]),
      bool("use_online_api", true),
      select("alipan_type", ["default", "alipanTV"], "default", true),
      field("api_url_address", "string", "https://api.oplist.org/alicloud/renewapi"),
      text("client_id"),
      password("client_secret"),
      select("remove_way", ["trash", "delete"], "trash", true),
      bool("rapid_upload", false),
      bool("internal_upload", false),
      select("livp_download_format", ["jpeg", "mov"], "jpeg"),
      password("access_token")
    ]),
    AliyundriveShare: unsupported("AliyundriveShare", [
      rootId$1(),
      password("refresh_token", true),
      text("share_id", true),
      password("share_pwd"),
      select("order_by", ["name", "size", "updated_at", "created_at"]),
      select("order_direction", ["ASC", "DESC"])
    ]),
    BaiduNetdisk: preferProxy(supported("BaiduNetdisk", [
      rootPath("/"),
      select("order_by", ["name", "time", "size"], "name"),
      select("order_direction", ["asc", "desc"], "asc"),
      select("download_api", ["official", "crack", "crack_video"], "official"),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/baiduyun/renewapi"),
      text("client_id"),
      password("client_secret"),
      field("custom_crack_ua", "string", "netdisk", "", true),
      password("access_token"),
      password("refresh_token", true),
      number("upload_thread", 3),
      number("upload_timeout", 60),
      field("upload_api", "string", "https://d.pcs.baidu.com"),
      bool("use_dynamic_upload_api", true),
      number("custom_upload_part_size", 0),
      bool("low_bandwith_upload_mode", false),
      bool("only_list_video_file", false)
    ])),
    Cloudreve: unsupported("Cloudreve", [text("address", true), text("username"), password("password"), password("token")]),
    Dropbox: unsupported("Dropbox", [password("refresh_token", true), text("client_id"), password("client_secret")]),
    GoogleDrive: unsupported("GoogleDrive", [
      rootId$1(),
      password("refresh_token", true),
      text("order_by", false, "such as: folder,name,modifiedTime"),
      select("order_direction", ["asc", "desc"]),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/googleui/renewapi"),
      text("client_id"),
      password("client_secret"),
      number("chunk_size", 5),
      bool("disable_disk_usage", false)
    ]),
    GooglePhoto: unsupported("GooglePhoto", [
      rootId$1(),
      password("refresh_token", true),
      field("client_id", "string", "202264815644.apps.googleusercontent.com", "", true),
      field("client_secret", "password", "X4Z3ca8xfWDb1Voo-F9a7ZxJ", "", true),
      bool("show_archive", false)
    ]),
    Lanzou: unsupported("Lanzou", [password("cookie", true)]),
    Onedrive: supported("Onedrive", [
      rootPath("/"),
      select("region", ["global", "cn", "us", "de"], "global", true),
      bool("is_sharepoint", false),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/onedrive/renewapi"),
      text("client_id"),
      password("client_secret"),
      field("redirect_uri", "string", "https://api.oplist.org/onedrive/callback", "", true),
      password("refresh_token", true),
      text("site_id"),
      number("chunk_size", 5),
      text("custom_host"),
      bool("disable_disk_usage", false),
      bool("enable_direct_upload", false)
    ]),
    OnedriveAPP: unsupported("OnedriveAPP", [
      rootPath("/"),
      select("region", ["global", "cn", "us", "de"], "global", true),
      text("client_id", true),
      password("client_secret", true),
      text("tenant_id"),
      text("email"),
      number("chunk_size", 5),
      text("custom_host"),
      bool("disable_disk_usage", false),
      bool("enable_direct_upload", false)
    ]),
    "Onedrive Sharelink": unsupported("Onedrive Sharelink", [text("share_url", true), rootPath("/")]),
    PikPak: unsupported("PikPak", [text("username", true), password("password", true)]),
    Quark: unsupported("Quark", [password("cookie", true)]),
    SFTP: unsupported("SFTP", [text("address", true), text("username", true), password("password"), password("private_key")]),
    SMB: unsupported("SMB", [text("address", true), text("username"), password("password"), text("share_name")]),
    Thunder: unsupported("Thunder", [text("username"), password("password"), password("refresh_token")]),
    URLTree: unsupported("URLTree", [text("url", true)]),
    USS: unsupported("USS", [text("bucket", true), text("endpoint", true), text("operator", true), password("password", true)]),
    Virtual: unsupported("Virtual", [])
  });
  const driverInfoMap = () => buildDriverInfoMap();
  const driverNames = () => {
    const map = driverInfoMap();
    return [
      ...driverNameOrder.filter((name) => map[name]),
      ...Object.keys(map).filter((name) => !driverNameOrder.includes(name))
    ];
  };
  const encodePayload = (payload) => {
    if (payload === void 0 || payload === null) return "";
    return typeof payload === "string" ? payload : JSON.stringify(payload);
  };
  const proxyPayload = (body, contentType) => {
    if (body === void 0 || body === null) return { payload: "", payloadEncoding: "text" };
    if (typeof body !== "string" && String(contentType || "").includes("application/json")) {
      return { payload: body, payloadEncoding: "json" };
    }
    return { payload: encodePayload(body), payloadEncoding: "text" };
  };
  const forwardProxy = async (client, url, {
    body,
    allowErrorStatus = false,
    contentType = "application/json",
    headers = {},
    method = "GET",
    responseEncoding = "text",
    timeout = 3e4
  } = {}) => {
    const encoded = proxyPayload(body, contentType);
    const headerPairs = Object.entries(headers).filter(([, value]) => value !== void 0 && value !== null && value !== "").map(([key, value]) => ({ [key]: String(value) }));
    const response = await client.fetch("/api/network/forwardProxy", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        url,
        method,
        headers: headerPairs,
        contentType,
        payload: encoded.payload,
        payloadEncoding: encoded.payloadEncoding,
        responseEncoding,
        timeout
      })
    });
    const payload = await response.json();
    if (payload.code !== 0) throw new Error(payload.msg || "forwardProxy failed");
    const data = payload.data || {};
    if (!allowErrorStatus && data.status >= 400) throw new Error(`HTTP ${data.status}: ${String(data.body || "").slice(0, 300)}`);
    return data;
  };
  const remoteJson = async (client, url, options) => {
    const data = await forwardProxy(client, url, options);
    try {
      return JSON.parse(data.body || "{}");
    } catch (error) {
      throw new Error(`invalid JSON response from ${url}: ${error.message}`);
    }
  };
  const basicAuth = (username, password2) => {
    if (!username && !password2) return "";
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const input = unescape(encodeURIComponent(`${username || ""}:${password2 || ""}`));
    let output = "";
    for (let i = 0; i < input.length; i += 3) {
      const a = input.charCodeAt(i);
      const b = input.charCodeAt(i + 1);
      const c = input.charCodeAt(i + 2);
      output += chars[a >> 2];
      output += chars[(a & 3) << 4 | (Number.isNaN(b) ? 0 : b >> 4)];
      output += Number.isNaN(b) ? "=" : chars[(b & 15) << 2 | (Number.isNaN(c) ? 0 : c >> 6)];
      output += Number.isNaN(c) ? "=" : chars[c & 63];
    }
    return `Basic ${output}`;
  };
  const joinUrl = (base, path) => {
    const trimmed = String(base || "").replace(/\/+$/, "");
    const encoded = String(path || "/").split("/").filter(Boolean).map((part) => encodeURIComponent(part)).join("/");
    return encoded ? `${trimmed}/${encoded}` : `${trimmed}/`;
  };
  const B_API = "https://www.123pan.com/b/api";
  const LOGIN_API = "https://login.123pan.com/api";
  const SIGN_IN = LOGIN_API + "/user/sign_in";
  const USER_INFO = B_API + "/user/info";
  const FILE_LIST = B_API + "/file/list/new";
  const DOWNLOAD_INFO = B_API + "/file/download_info";
  const MKDIR = B_API + "/file/upload_request";
  const MOVE = B_API + "/file/mod_pid";
  const RENAME = B_API + "/file/rename";
  const TRASH = B_API + "/file/trash";
  const crcTable = (() => {
    const table = [];
    for (let i = 0; i < 256; i += 1) {
      let c = i;
      for (let j = 0; j < 8; j += 1) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
      table[i] = c >>> 0;
    }
    return table;
  })();
  const crc32 = (value) => {
    let crc = 4294967295;
    const input = unescape(encodeURIComponent(String(value || "")));
    for (let i = 0; i < input.length; i += 1) {
      crc = crc >>> 8 ^ crcTable[(crc ^ input.charCodeAt(i)) & 255];
    }
    return ((crc ^ 4294967295) >>> 0).toString();
  };
  const pad = (value) => String(value).padStart(2, "0");
  const signPath = (path, os = "web", version = "3") => {
    const table = ["a", "d", "e", "f", "g", "h", "l", "m", "y", "i", "j", "n", "o", "p", "k", "q", "r", "s", "t", "u", "b", "c", "v", "w", "s", "z"];
    const random = String(Math.round(1e7 * Math.random()));
    const now = new Date(Date.now() + 8 * 3600 * 1e3);
    const timestamp = String(Math.floor(now.getTime() / 1e3));
    const nowStr = `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}${pad(now.getUTCHours())}${pad(now.getUTCMinutes())}`;
    const encodedTime = nowStr.split("").map((char) => table[Number(char)]).join("");
    const timeSign = crc32(encodedTime);
    const data = [timestamp, random, path, os, version, timeSign].join("|");
    const dataSign = crc32(data);
    return [timeSign, [timestamp, random, dataSign].join("-")];
  };
  const signedApi = (rawUrl) => {
    const url = new URL(rawUrl);
    const [key, value] = signPath(url.pathname, "web", "3");
    url.searchParams.append(key, value);
    return url.toString();
  };
  const isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || ""));
  const cleanUsername = (value) => String(value || "").trim().replace(/[\s-]/g, "");
  const decodeBase64 = (value) => {
    const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    let output = "";
    let buffer = 0;
    let bits = 0;
    for (const char of String(value || "")) {
      if (char === "=") break;
      const index = chars.indexOf(char);
      if (index < 0) continue;
      buffer = buffer << 6 | index;
      bits += 6;
      if (bits >= 8) {
        bits -= 8;
        output += String.fromCharCode(buffer >> bits & 255);
      }
    }
    try {
      return decodeURIComponent(escape(output));
    } catch (_) {
      return output;
    }
  };
  const platform = (addition) => addition.platform || addition.Platform || "web";
  const headersFor$1 = (addition, token = addition.access_token || addition.AccessToken || "") => ({
    origin: "https://www.123pan.com",
    referer: "https://www.123pan.com/",
    authorization: token ? `Bearer ${token}` : "",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) siyuan-cloud-client",
    platform: platform(addition),
    "app-version": "3"
  });
  const check123 = (payload) => {
    const code = Number((payload == null ? void 0 : payload.code) ?? 0);
    if (code !== 0) throw new Error((payload == null ? void 0 : payload.message) || `123Pan code ${code}`);
    return payload;
  };
  const login$1 = async (client, addition) => {
    var _a;
    const username = addition.username || addition.Username || "";
    const passport = cleanUsername(username);
    const password2 = addition.password || addition.Password || "";
    const body = isEmail(username) ? { mail: String(username).trim(), password: password2, type: 2 } : { passport, password: password2, remember: true };
    const payload = await remoteJson(client, SIGN_IN, {
      body,
      headers: {
        origin: "https://www.123pan.com",
        referer: "https://www.123pan.com/",
        "user-agent": "Dart/2.19(dart:io)-siyuan-cloud",
        platform: "web",
        "app-version": "3"
      },
      method: "POST"
    });
    if (Number(payload == null ? void 0 : payload.code) !== 200) throw new Error((payload == null ? void 0 : payload.message) || "123Pan login failed");
    addition.access_token = ((_a = payload == null ? void 0 : payload.data) == null ? void 0 : _a.token) || "";
    return addition.access_token;
  };
  const request123 = async (client, storage, url, {
    body,
    method = "GET",
    query,
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    if (!addition.access_token && !addition.AccessToken) await login$1(client, addition);
    const api = new URL(url);
    for (const [key, value] of Object.entries(query || {})) api.searchParams.set(key, String(value));
    const payload = await remoteJson(client, signedApi(api.toString()), {
      allowErrorStatus: true,
      body,
      headers: headersFor$1(addition),
      method
    });
    if (Number(payload == null ? void 0 : payload.code) === 401 && retry) {
      await login$1(client, addition);
      return request123(client, storage, url, { body, method, query, retry: false });
    }
    return check123(payload);
  };
  const parseTime = (value) => {
    const date = value ? new Date(value) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const idOf = (file) => String((file == null ? void 0 : file.FileId) ?? (file == null ? void 0 : file.fileId) ?? (file == null ? void 0 : file.id) ?? "");
  const fileNameOf$1 = (file) => (file == null ? void 0 : file.FileName) || (file == null ? void 0 : file.fileName) || (file == null ? void 0 : file.name) || "";
  const isDir$1 = (file) => Number((file == null ? void 0 : file.Type) ?? (file == null ? void 0 : file.type) ?? 0) === 1;
  const thumbOf = (file) => {
    const raw = (file == null ? void 0 : file.DownloadUrl) || (file == null ? void 0 : file.downloadUrl) || "";
    if (!raw) return "";
    try {
      const url = new URL(raw);
      url.pathname = url.pathname.replace(/_24_24$/, "") + "_70_70";
      url.searchParams.set("w", "70");
      url.searchParams.set("h", "70");
      if (!url.searchParams.has("type")) url.searchParams.set("type", basename(fileNameOf$1(file)).replace(/^\./, ""));
      if (!url.searchParams.has("trade_key")) url.searchParams.set("trade_key", "123pan-thumbnail");
      return url.toString();
    } catch (_) {
      return "";
    }
  };
  const objFromFile = (file, relPath, storage) => {
    const dir = isDir$1(file);
    return {
      name: fileNameOf$1(file),
      path: normalizePath(relPath),
      is_dir: dir,
      size: Number((file == null ? void 0 : file.Size) ?? (file == null ? void 0 : file.size) ?? 0),
      modified: parseTime((file == null ? void 0 : file.UpdateAt) || (file == null ? void 0 : file.updateAt)),
      created: parseTime((file == null ? void 0 : file.UpdateAt) || (file == null ? void 0 : file.updateAt)),
      sign: "",
      thumb: thumbOf(file),
      type: dir ? 1 : 0,
      hashinfo: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) || "",
      hash_info: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) ? { md5: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) } : {},
      id: idOf(file),
      raw_url: dir ? "" : `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
      provider: "123Pan",
      file
    };
  };
  const rootId = (addition) => String(addition.root_folder_id || addition.RootFolderID || "0");
  const listByParentId = async (client, storage, parentId, parentName) => {
    let page = 1;
    let total = 0;
    const result = [];
    for (; ; ) {
      const payload = await request123(client, storage, FILE_LIST, {
        method: "GET",
        query: {
          driveId: "0",
          limit: "100",
          next: "0",
          orderBy: "file_id",
          orderDirection: "desc",
          parentFileId: parentId,
          trashed: "false",
          SearchData: "",
          Page: page,
          OnlyLookAbnormalFile: "0",
          event: "homeListFile",
          operateType: "4",
          inDirectSpace: "false"
        }
      });
      const data = payload.data || {};
      const list = data.InfoList || data.infoList || [];
      result.push(...list);
      total = Number(data.Total || data.total || total);
      page += 1;
      if (!list.length || String(data.Next ?? data.next) === "-1") break;
    }
    if (total && result.length !== total) {
      result.warning = `incorrect file count from remote at ${parentName}: expected ${total}, got ${result.length}`;
    }
    return result;
  };
  const resolveFile$1 = async (client, storage, relPath) => {
    const current = normalizePath(relPath || "/");
    if (current === "/") return { id: rootId(storage.addition_json), name: "root", path: "/", isRoot: true };
    let parentId = rootId(storage.addition_json);
    let parentPath = "/";
    let found = null;
    for (const part of current.split("/").filter(Boolean)) {
      const files = await listByParentId(client, storage, parentId, parentPath);
      found = files.find((file) => fileNameOf$1(file) === part);
      if (!found) throw new Error(`object not found: ${current}`);
      parentId = idOf(found);
      parentPath = normalizePath(parentPath + "/" + part);
    }
    return { file: found, id: idOf(found), name: fileNameOf$1(found), path: current };
  };
  const downloadUrlFor = async (client, storage, file) => {
    var _a, _b, _c, _d;
    const payload = await request123(client, storage, DOWNLOAD_INFO, {
      body: {
        driveId: 0,
        etag: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) || "",
        fileId: Number(idOf(file)),
        fileName: fileNameOf$1(file),
        s3keyFlag: (file == null ? void 0 : file.S3KeyFlag) || (file == null ? void 0 : file.s3KeyFlag) || "",
        size: Number((file == null ? void 0 : file.Size) ?? (file == null ? void 0 : file.size) ?? 0),
        type: Number((file == null ? void 0 : file.Type) ?? (file == null ? void 0 : file.type) ?? 0)
      },
      method: "POST"
    });
    const raw = ((_a = payload == null ? void 0 : payload.data) == null ? void 0 : _a.DownloadUrl) || ((_b = payload == null ? void 0 : payload.data) == null ? void 0 : _b.downloadUrl) || "";
    if (!raw) throw new Error("get download url failed");
    let candidate = raw;
    try {
      const url = new URL(raw);
      const params = url.searchParams.get("params");
      candidate = params ? decodeBase64(params) : url.toString();
    } catch (_) {
      candidate = raw;
    }
    try {
      const resolved = await forwardProxy(client, candidate, {
        allowErrorStatus: true,
        contentType: "application/json",
        headers: { Referer: "https://www.123pan.com/" },
        method: "GET",
        responseEncoding: "text"
      });
      const data = JSON.parse(resolved.body || "{}");
      return ((_c = data == null ? void 0 : data.data) == null ? void 0 : _c.redirect_url) || ((_d = data == null ? void 0 : data.data) == null ? void 0 : _d.redirectUrl) || candidate;
    } catch (_) {
      return candidate;
    }
  };
  const create123PanDriver = ({ client }) => ({
    async list(storage, relPath) {
      const target = await resolveFile$1(client, storage, relPath);
      const files = await listByParentId(client, storage, target.id, target.name);
      const content = files.map((file) => objFromFile(file, normalizePath(relPath + "/" + fileNameOf$1(file)), storage));
      return {
        content,
        total: content.length,
        readme: "",
        header: files.warning || "",
        write: true,
        provider: "123Pan",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath) {
      const target = await resolveFile$1(client, storage, relPath);
      if (target.isRoot) {
        return {
          name: "root",
          path: "/",
          is_dir: true,
          size: 0,
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString(),
          provider: "123Pan",
          related: []
        };
      }
      const obj = objFromFile(target.file, relPath, storage);
      if (!obj.is_dir) {
        obj.raw_url = await downloadUrlFor(client, storage, target.file);
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath) {
      const target = await resolveFile$1(client, storage, relPath);
      if (target.isRoot || isDir$1(target.file)) throw new Error("not file");
      const url = await downloadUrlFor(client, storage, target.file);
      return forwardProxy(client, url, {
        headers: {
          Referer: `${new URL(url).protocol}//${new URL(url).host}/`
        },
        method: "GET",
        responseEncoding: "base64"
      });
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$1(client, storage, dirname(relPath));
      await request123(client, storage, MKDIR, {
        body: {
          driveId: 0,
          etag: "",
          fileName: basename(relPath),
          parentFileId: parent.id,
          size: 0,
          type: 1
        },
        method: "POST"
      });
    },
    async remove(storage, relPath) {
      const target = await resolveFile$1(client, storage, relPath);
      if (target.isRoot) throw new Error("root cannot be removed");
      await request123(client, storage, TRASH, {
        body: {
          driveId: 0,
          operation: true,
          fileTrashInfoList: [target.file]
        },
        method: "POST"
      });
    },
    async rename(storage, relPath, newName) {
      const target = await resolveFile$1(client, storage, relPath);
      if (target.isRoot) throw new Error("root cannot be renamed");
      await request123(client, storage, RENAME, {
        body: {
          driveId: 0,
          fileId: Number(target.id),
          fileName: newName
        },
        method: "POST"
      });
    },
    async move(storage, relPath, dstRelPath) {
      const target = await resolveFile$1(client, storage, relPath);
      const dst = await resolveFile$1(client, storage, dstRelPath);
      await request123(client, storage, MOVE, {
        body: {
          fileIdList: [{ FileId: target.id }],
          parentFileId: dst.id
        },
        method: "POST"
      });
    },
    async put() {
      throw new Error("123Pan upload is not implemented in the SiYuan kernel port yet; OpenList upload_request/S3 upload_complete flow is the next migration step.");
    },
    async test(storage) {
      const payload = await request123(client, storage, USER_INFO, {
        method: "GET"
      });
      const data = payload.data || {};
      return {
        ok: true,
        addition: storage.addition_json,
        user: {
          uid: data.UID || data.uid || 0,
          nickname: data.Nickname || data.nickname || "",
          space_used: data.SpaceUsed || data.spaceUsed || 0,
          space_permanent: data.SpacePermanent || data.spacePermanent || 0,
          space_temp: data.SpaceTemp || data.spaceTemp || 0,
          file_count: data.FileCount || data.fileCount || 0
        }
      };
    }
  });
  const API = "https://pan.baidu.com/rest/2.0";
  const OPEN_API = "https://openapi.baidu.com/oauth/2.0/token";
  const DEFAULT_RENEW_API = "https://api.oplist.org/baiduyun/renewapi";
  const LIST_CACHE_TTL = 5 * 60 * 1e3;
  const FILE_CACHE_TTL = 5 * 60 * 1e3;
  const LINK_CACHE_TTL = 10 * 60 * 1e3;
  const baiduCache = /* @__PURE__ */ new Map();
  const storageKey = (storage) => String((storage == null ? void 0 : storage.id) || (storage == null ? void 0 : storage.mount_path) || (storage == null ? void 0 : storage.mount_path_hash) || "default");
  const cacheKey = (storage, type, key) => `${storageKey(storage)}:${type}:${key}`;
  const getCache = (key) => {
    const hit = baiduCache.get(key);
    if (!hit) return void 0;
    if (hit.expires <= Date.now()) {
      baiduCache.delete(key);
      return void 0;
    }
    return hit.value;
  };
  const setCache = (key, value, ttl) => {
    baiduCache.set(key, { expires: Date.now() + ttl, value });
    if (baiduCache.size > 512) {
      for (const cacheKeyValue of baiduCache.keys()) {
        baiduCache.delete(cacheKeyValue);
        if (baiduCache.size <= 384) break;
      }
    }
    return value;
  };
  const invalidateStorageCache = (storage) => {
    const prefix = `${storageKey(storage)}:`;
    for (const key of baiduCache.keys()) {
      if (key.startsWith(prefix)) baiduCache.delete(key);
    }
  };
  const boolValue$1 = (value, fallback = false) => {
    if (value === void 0 || value === null || value === "") return fallback;
    return value === true || value === "true";
  };
  const rootedPath$1 = (addition, relPath) => {
    const root = normalizePath(addition.root_folder_path || addition.RootFolderPath || "/");
    return normalizePath(root + "/" + normalizePath(relPath || "/"));
  };
  const baiduTime = (value) => {
    const date = Number(value || 0) ? new Date(Number(value) * 1e3) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const checkBaidu = (payload) => {
    const errno = Number((payload == null ? void 0 : payload.errno) || (payload == null ? void 0 : payload.error_code) || 0);
    if (errno && errno !== 31023) throw new Error((payload == null ? void 0 : payload.errmsg) || (payload == null ? void 0 : payload.error_msg) || `baidu errno: ${errno}`);
    return payload;
  };
  const persistAddition = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const refreshToken$1 = async (client, storage) => {
    const addition = storage.addition_json || storage;
    const refreshTokenValue = addition.refresh_token || addition.RefreshToken || "";
    if (!refreshTokenValue) throw new Error("empty refresh_token");
    const useOnlineApi = boolValue$1(addition.use_online_api ?? addition.UseOnlineAPI, true);
    if (useOnlineApi) {
      const url2 = new URL(addition.api_url_address || addition.APIAddress || DEFAULT_RENEW_API);
      url2.searchParams.set("refresh_ui", refreshTokenValue);
      url2.searchParams.set("server_use", "true");
      url2.searchParams.set("driver_txt", "baiduyun_go");
      const resp2 = await remoteJson(client, url2.toString(), { method: "GET" });
      if (!resp2.refresh_token || !resp2.access_token) throw new Error(resp2.text || "empty token returned from official API");
      addition.access_token = resp2.access_token;
      addition.refresh_token = resp2.refresh_token;
      await persistAddition(storage);
      return addition;
    }
    if (!addition.client_id || !addition.client_secret) throw new Error("empty ClientID or ClientSecret");
    const url = new URL(OPEN_API);
    url.searchParams.set("grant_type", "refresh_token");
    url.searchParams.set("refresh_token", refreshTokenValue);
    url.searchParams.set("client_id", addition.client_id);
    url.searchParams.set("client_secret", addition.client_secret);
    const resp = await remoteJson(client, url.toString(), { method: "GET" });
    if (resp.error) throw new Error(`${resp.error}: ${resp.error_description || ""}`.trim());
    if (!resp.refresh_token || !resp.access_token) throw new Error("empty token returned from official API");
    addition.access_token = resp.access_token;
    addition.refresh_token = resp.refresh_token;
    await persistAddition(storage);
    return addition;
  };
  const ensureAccessToken = async (client, storage) => {
    const addition = storage.addition_json || storage;
    if (addition.access_token || addition.AccessToken) return;
    await refreshToken$1(client, storage);
  };
  const requestBaidu = async (client, storage, url, {
    allowErrorStatus = false,
    body,
    contentType = "application/json",
    method = "GET",
    query = {},
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    await ensureAccessToken(client, storage);
    const target = new URL(url);
    target.searchParams.set("access_token", addition.access_token || addition.AccessToken || "");
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const resp = await remoteJson(client, target.toString(), {
      allowErrorStatus,
      body,
      contentType,
      method
    });
    const errno = Number((resp == null ? void 0 : resp.errno) || (resp == null ? void 0 : resp.error_code) || 0);
    if ((errno === 111 || errno === -6) && retry) {
      await refreshToken$1(client, storage);
      return requestBaidu(client, storage, url, { allowErrorStatus, body, contentType, method, query, retry: false });
    }
    return checkBaidu(resp);
  };
  const get = (client, storage, pathname, query, retry) => requestBaidu(client, storage, `${API}${pathname}`, { method: "GET", query, retry });
  const postForm = (client, storage, pathname, query, form) => requestBaidu(client, storage, `${API}${pathname}`, {
    body: new URLSearchParams(form).toString(),
    contentType: "application/x-www-form-urlencoded",
    method: "POST",
    query
  });
  const fileNameOf = (file) => (file == null ? void 0 : file.server_filename) || (file == null ? void 0 : file.name) || basename((file == null ? void 0 : file.path) || "");
  const isDir = (file) => Number((file == null ? void 0 : file.isdir) || 0) === 1;
  const fileToObj$1 = (file, relPath, storage) => {
    var _a;
    const actualPath = (file == null ? void 0 : file.path) || rootedPath$1(storage.addition_json, relPath);
    const dir = isDir(file);
    return {
      name: fileNameOf(file),
      path: normalizePath(relPath),
      is_dir: dir,
      size: Number((file == null ? void 0 : file.size) || 0),
      modified: baiduTime((file == null ? void 0 : file.server_mtime) || (file == null ? void 0 : file.mtime)),
      created: baiduTime((file == null ? void 0 : file.server_ctime) || (file == null ? void 0 : file.ctime)),
      sign: "",
      thumb: ((_a = file == null ? void 0 : file.thumbs) == null ? void 0 : _a.url3) || "",
      type: dir ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: String((file == null ? void 0 : file.fs_id) || (file == null ? void 0 : file.id) || ""),
      raw_url: dir ? "" : `/plugin/private/siyuan-cloud/p${normalizePath(storage.mount_path + "/" + relPath)}`,
      provider: "BaiduNetdisk",
      file: { ...file, path: actualPath }
    };
  };
  const listFiles = async (client, storage, relPath) => {
    const cleanRelPath = normalizePath(relPath || "/");
    const cached = getCache(cacheKey(storage, "list", cleanRelPath));
    if (cached) return cached;
    const addition = storage.addition_json;
    const dir = rootedPath$1(addition, cleanRelPath);
    const result = [];
    for (let start = 0; ; start += 1e3) {
      const query = {
        method: "list",
        dir,
        web: "web",
        start,
        limit: 1e3
      };
      if (addition.order_by) {
        query.order = addition.order_by;
        if (addition.order_direction === "desc") query.desc = "1";
      }
      const payload = await get(client, storage, "/xpan/file", {
        ...query
      });
      const list = payload.list || [];
      for (const file of list) {
        if (!boolValue$1(addition.only_list_video_file) || file.isdir === 1 || file.category === 1) result.push(file);
      }
      if (list.length < 1e3) break;
    }
    return setCache(cacheKey(storage, "list", cleanRelPath), result, LIST_CACHE_TTL);
  };
  const resolveFile = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    if (clean === "/") return { isRoot: true, id: "", name: "root", path: "/" };
    const cached = getCache(cacheKey(storage, "file", clean));
    if (cached) return cached;
    const parent = dirname(clean);
    const name = basename(clean);
    const files = await listFiles(client, storage, parent);
    const file = files.find((entry) => fileNameOf(entry) === name);
    if (!file) throw new Error(`object not found: ${clean}`);
    return setCache(cacheKey(storage, "file", clean), { file, id: String(file.fs_id || ""), name: fileNameOf(file), path: clean }, FILE_CACHE_TTL);
  };
  const headerValue$1 = (headers = {}, name) => {
    const lower = String(name || "").toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== lower) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const resolveHeadLocation = async (client, url, headers) => {
    try {
      const resp = await forwardProxy(client, url, {
        allowErrorStatus: true,
        contentType: "application/octet-stream",
        headers,
        method: "HEAD",
        responseEncoding: "text",
        timeout: 3e4
      });
      return headerValue$1(resp.headers, "Location") || headerValue$1(resp.headers, "location");
    } catch (_) {
      return "";
    }
  };
  const linkOfficial = async (client, storage, file) => {
    var _a, _b;
    const payload = await get(client, storage, "/xpan/multimedia", {
      method: "filemetas",
      fsids: `[${file.fs_id || file.id}]`,
      dlink: "1"
    });
    const dlink = ((_b = (_a = payload == null ? void 0 : payload.list) == null ? void 0 : _a[0]) == null ? void 0 : _b.dlink) || "";
    if (!dlink) throw new Error("get baidu dlink failed");
    const headers = { "User-Agent": "pan.baidu.com" };
    const url = `${dlink}&access_token=${encodeURIComponent(storage.addition_json.access_token || "")}`;
    const location = await resolveHeadLocation(client, url, headers);
    return {
      headers,
      url: location || url
    };
  };
  const linkCrack = async (client, storage, file) => {
    var _a, _b;
    const payload = await requestBaidu(client, storage, "https://pan.baidu.com/api/filemetas", {
      method: "GET",
      query: {
        target: `["${file.path}"]`,
        dlink: "1",
        web: "5",
        origin: "dlna"
      }
    });
    const url = ((_b = (_a = payload == null ? void 0 : payload.info) == null ? void 0 : _a[0]) == null ? void 0 : _b.dlink) || "";
    if (!url) throw new Error("get baidu crack dlink failed");
    return {
      headers: { "User-Agent": storage.addition_json.custom_crack_ua || "netdisk" },
      url
    };
  };
  const linkCrackVideo = async (client, storage, file) => {
    var _a, _b, _c;
    const payload = await requestBaidu(client, storage, "https://pan.baidu.com/api/mediainfo", {
      allowErrorStatus: true,
      method: "GET",
      query: {
        type: "VideoURL",
        path: file.path,
        fs_id: file.fs_id || file.id,
        devuid: "0%1",
        clienttype: "1",
        channel: "android_15_25010PN30C_bd-netdisk_1523a",
        nom3u8: "1",
        dlink: "1",
        media: "1",
        origin: "dlna"
      }
    });
    const url = ((_a = payload == null ? void 0 : payload.info) == null ? void 0 : _a.dlink) || ((_c = (_b = payload == null ? void 0 : payload.info) == null ? void 0 : _b[0]) == null ? void 0 : _c.dlink) || "";
    if (!url) throw new Error("get baidu video dlink failed");
    return {
      headers: { "User-Agent": storage.addition_json.custom_crack_ua || "netdisk" },
      url
    };
  };
  const linkFor = async (client, storage, file) => {
    const key = cacheKey(storage, "link", [
      storage.addition_json.download_api || "official",
      file.fs_id || file.id || "",
      file.size || "",
      file.server_mtime || file.mtime || ""
    ].join(":"));
    const cached = getCache(key);
    if (cached) return cached;
    let link;
    switch (storage.addition_json.download_api || "official") {
      case "crack":
        link = await linkCrack(client, storage, file);
        break;
      case "crack_video":
        link = await linkCrackVideo(client, storage, file);
        break;
      default:
        link = await linkOfficial(client, storage, file);
    }
    return setCache(key, link, LINK_CACHE_TTL);
  };
  const manage = (client, storage, opera, filelist) => postForm(client, storage, "/xpan/file", {
    method: "filemanager",
    opera
  }, {
    async: "0",
    filelist: JSON.stringify(filelist),
    ondup: "fail"
  });
  const createBaiduNetdiskDriver = ({ client }) => ({
    async test(storage) {
      await ensureAccessToken(client, storage);
      await get(client, storage, "/xpan/nas", { method: "uinfo" });
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const content = (await listFiles(client, storage, relPath)).map((file) => fileToObj$1(file, normalizePath(relPath + "/" + fileNameOf(file)), storage));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "BaiduNetdisk",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const target = await resolveFile(client, storage, relPath);
      if (target.isRoot) {
        return {
          name: "root",
          path: "/",
          is_dir: true,
          size: 0,
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString(),
          provider: "BaiduNetdisk",
          related: []
        };
      }
      const obj = fileToObj$1(target.file, relPath, storage);
      if (!obj.is_dir && !options.skipLink) {
        const link = await linkFor(client, storage, target.file);
        obj.raw_url = link.url;
        obj.url = link.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      var _a;
      const target = await resolveFile(client, storage, relPath);
      if (target.isRoot || isDir(target.file)) throw new Error("not file");
      const link = await linkFor(client, storage, target.file);
      if (link.body !== void 0) {
        return {
          body: link.body,
          contentType: link.contentType || "application/vnd.apple.mpegurl",
          headers: link.headers || {},
          media_type: link.media_type || "m3u8",
          status: 200
        };
      }
      const header = { ...link.headers, ...options.proxyHeaders || options.headers || {} };
      return {
        link: {
          url: link.url,
          header,
          content_length: Number(((_a = target.file) == null ? void 0 : _a.size) || 0)
        },
        proxy_url: link.url,
        proxy_headers: header,
        proxy_method: "GET"
      };
    },
    async mkdir(storage, relPath) {
      await postForm(client, storage, "/xpan/file", { method: "create" }, {
        path: rootedPath$1(storage.addition_json, relPath),
        size: "0",
        isdir: "1",
        rtype: "3"
      });
      invalidateStorageCache(storage);
    },
    async remove(storage, relPath) {
      const target = await resolveFile(client, storage, relPath);
      await manage(client, storage, "delete", [target.file.path]);
      invalidateStorageCache(storage);
    },
    async rename(storage, relPath, newName) {
      const target = await resolveFile(client, storage, relPath);
      await manage(client, storage, "rename", [{ path: target.file.path, newname: newName }]);
      invalidateStorageCache(storage);
    },
    async put() {
      throw new Error("BaiduNetdisk upload is not implemented in the SiYuan kernel port yet");
    }
  });
  const hosts = {
    global: {
      oauth: "https://login.microsoftonline.com",
      api: "https://graph.microsoft.com"
    },
    cn: {
      oauth: "https://login.chinacloudapi.cn",
      api: "https://microsoftgraph.chinacloudapi.cn"
    },
    us: {
      oauth: "https://login.microsoftonline.us",
      api: "https://graph.microsoft.us"
    },
    de: {
      oauth: "https://login.microsoftonline.de",
      api: "https://graph.microsoft.de"
    }
  };
  const hostFor = (addition) => hosts[addition.region || addition.Region || "global"] || hosts.global;
  const boolValue = (value, fallback = false) => {
    if (value === void 0 || value === null || value === "") return fallback;
    return value === true || value === "true";
  };
  const encodePath = (path) => {
    const clean = normalizePath(path || "/");
    if (clean === "/") return "/";
    return "/" + clean.split("/").filter(Boolean).map(encodeURIComponent).join("/");
  };
  const rootedPath = (addition, relPath) => {
    const root = normalizePath(addition.root_folder_path || addition.RootFolderPath || "/");
    return normalizePath(root + "/" + normalizePath(relPath || "/"));
  };
  const metaUrl = (addition, relPath) => {
    const host = hostFor(addition);
    const path = encodePath(rootedPath(addition, relPath));
    const isSharepoint = boolValue(addition.is_sharepoint || addition.IsSharepoint);
    const siteId = addition.site_id || addition.SiteId || "";
    if (isSharepoint) {
      if (path === "/") return `${host.api}/v1.0/sites/${encodeURIComponent(siteId)}/drive/root`;
      return `${host.api}/v1.0/sites/${encodeURIComponent(siteId)}/drive/root:${path}:`;
    }
    if (path === "/") return `${host.api}/v1.0/me/drive/root`;
    return `${host.api}/v1.0/me/drive/root:${path}:`;
  };
  const tokenUrl = (addition) => `${hostFor(addition).oauth}/common/oauth2/v2.0/token`;
  const graphHeaders = (addition) => ({
    Authorization: `Bearer ${addition.access_token || addition.AccessToken || ""}`
  });
  const checkGraph = (payload) => {
    var _a;
    if ((_a = payload == null ? void 0 : payload.error) == null ? void 0 : _a.message) throw new Error(payload.error.message);
    if (payload == null ? void 0 : payload.error_description) throw new Error(payload.error_description);
    return payload;
  };
  const saveDriverStorage = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const refreshToken = async (client, storage) => {
    const addition = storage.addition_json || storage;
    const useOnlineApi = boolValue(addition.use_online_api ?? addition.UseOnlineAPI, true);
    const apiAddress = addition.api_url_address || addition.APIAddress || "https://api.oplist.org/onedrive/renewapi";
    const refreshTokenValue = addition.refresh_token || addition.RefreshToken || "";
    if (useOnlineApi && apiAddress) {
      const url = new URL(apiAddress);
      url.searchParams.set("refresh_ui", refreshTokenValue);
      url.searchParams.set("server_use", "true");
      url.searchParams.set("driver_txt", "onedrive_pr");
      const resp2 = checkGraph(await remoteJson(client, url.toString(), { method: "GET" }));
      if (!resp2.refresh_token || !resp2.access_token) {
        throw new Error(resp2.text || "empty token returned from official API, a wrong refresh token may have been used");
      }
      addition.refresh_token = resp2.refresh_token;
      addition.access_token = resp2.access_token;
      await saveDriverStorage(storage);
      return addition.access_token;
    }
    const clientId = addition.client_id || addition.ClientID || "";
    const clientSecret = addition.client_secret || addition.ClientSecret || "";
    if (!clientId || !clientSecret) throw new Error("empty ClientID or ClientSecret");
    const form = new URLSearchParams({
      grant_type: "refresh_token",
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: addition.redirect_uri || addition.RedirectUri || "https://api.oplist.org/onedrive/callback",
      refresh_token: refreshTokenValue
    });
    const resp = checkGraph(await remoteJson(client, tokenUrl(addition), {
      body: form.toString(),
      contentType: "application/x-www-form-urlencoded",
      method: "POST"
    }));
    if (!resp.refresh_token || !resp.access_token) throw new Error("empty token returned from Microsoft Graph");
    addition.refresh_token = resp.refresh_token;
    addition.access_token = resp.access_token;
    await saveDriverStorage(storage);
    return addition.access_token;
  };
  const requestGraph = async (client, storage, url, {
    body,
    contentType = "application/json",
    method = "GET",
    retry = true
  } = {}) => {
    var _a;
    const addition = storage.addition_json;
    if (!addition.access_token && !addition.AccessToken) await refreshToken(client, storage);
    const resp = await remoteJson(client, url, {
      allowErrorStatus: true,
      body,
      contentType,
      headers: graphHeaders(addition),
      method
    });
    if (((_a = resp == null ? void 0 : resp.error) == null ? void 0 : _a.code) === "InvalidAuthenticationToken" && retry) {
      await refreshToken(client, storage);
      return requestGraph(client, storage, url, { body, contentType, method, retry: false });
    }
    return checkGraph(resp);
  };
  const fileTime = (file) => {
    var _a;
    const raw = ((_a = file == null ? void 0 : file.fileSystemInfo) == null ? void 0 : _a.lastModifiedDateTime) || (file == null ? void 0 : file.lastModifiedDateTime) || (file == null ? void 0 : file.createdDateTime);
    const date = raw ? new Date(raw) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const fileToObj = (file, relPath, storage) => {
    var _a, _b, _c, _d;
    const isDir2 = !file.file;
    return {
      name: file.name || basename(relPath),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: fileTime(file),
      created: ((_a = file == null ? void 0 : file.fileSystemInfo) == null ? void 0 : _a.createdDateTime) || fileTime(file),
      thumb: ((_d = (_c = (_b = file == null ? void 0 : file.thumbnails) == null ? void 0 : _b[0]) == null ? void 0 : _c.medium) == null ? void 0 : _d.url) || "",
      sign: "",
      type: isDir2 ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: file.id || "",
      raw_url: isDir2 ? "" : `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
      provider: "Onedrive"
    };
  };
  const customDownloadUrl = (addition, rawUrl) => {
    if (!addition.custom_host || !rawUrl) return rawUrl || "";
    try {
      const url = new URL(rawUrl);
      url.host = addition.custom_host;
      return url.toString();
    } catch (_) {
      return rawUrl || "";
    }
  };
  const createOneDriveDriver = ({ client }) => ({
    async list(storage, relPath) {
      const content = [];
      let next = `${metaUrl(storage.addition_json, relPath)}/children?$top=1000&$expand=thumbnails($select=medium)&$select=id,name,size,fileSystemInfo,content.downloadUrl,file,parentReference`;
      while (next) {
        const data = await requestGraph(client, storage, next);
        for (const file of data.value || []) {
          content.push(fileToObj(file, normalizePath(relPath + "/" + file.name), storage));
        }
        next = data["@odata.nextLink"] || "";
      }
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "Onedrive",
        direct_upload_tools: boolValue(storage.addition_json.enable_direct_upload) ? ["HttpDirect"] : []
      };
    },
    async get(storage, relPath) {
      const file = await requestGraph(client, storage, metaUrl(storage.addition_json, relPath));
      const url = customDownloadUrl(storage.addition_json, file["@microsoft.graph.downloadUrl"]);
      return {
        ...fileToObj(file, relPath, storage),
        raw_url: file.file ? url : "",
        url,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath) {
      const file = await requestGraph(client, storage, metaUrl(storage.addition_json, relPath));
      if (!file.file) throw new Error("not file");
      const url = customDownloadUrl(storage.addition_json, file["@microsoft.graph.downloadUrl"]);
      if (!url) throw new Error("get download url failed");
      return forwardProxy(client, url, { method: "GET", contentType: "application/octet-stream", responseEncoding: "base64" });
    },
    async mkdir(storage, relPath) {
      await requestGraph(client, storage, `${metaUrl(storage.addition_json, dirname(relPath))}/children`, {
        body: {
          name: basename(relPath),
          folder: {},
          "@microsoft.graph.conflictBehavior": "rename"
        },
        method: "POST"
      });
    },
    async remove(storage, relPath) {
      await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), { method: "DELETE" });
    },
    async rename(storage, relPath, newName) {
      await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), {
        body: {
          name: newName
        },
        method: "PATCH"
      });
    },
    async put(storage, relPath, content, mime) {
      await requestGraph(client, storage, `${metaUrl(storage.addition_json, relPath)}/content`, {
        body: content || "",
        contentType: mime || "application/octet-stream",
        method: "PUT"
      });
    }
  });
  const trimAddress = (address) => String(address || "").replace(/\/+$/, "");
  const headersFor = (addition) => ({
    Authorization: addition.token || addition.Token || ""
  });
  const checkResp = (payload) => {
    if (payload.code && payload.code !== 200) throw new Error(payload.message || `OpenList code ${payload.code}`);
    return payload.data;
  };
  const login = async (client, storage) => {
    var _a;
    const addition = storage.addition_json;
    if (!addition.username && !addition.Username) return;
    const payload = await remoteJson(
      client,
      `${trimAddress(addition.url || addition.address || addition.Address)}/api/auth/login`,
      {
        body: {
          username: addition.username || addition.Username || "",
          password: addition.password || addition.Password || ""
        },
        method: "POST",
        timeout: Number(addition.timeout || 3e4)
      }
    );
    addition.token = ((_a = payload == null ? void 0 : payload.data) == null ? void 0 : _a.token) || "";
    if (storage.saveDriverStorage) await storage.saveDriverStorage(addition);
  };
  const objFrom = (item, path) => ({
    name: item.name,
    path,
    is_dir: !!item.is_dir,
    size: Number(item.size || 0),
    modified: item.modified || (/* @__PURE__ */ new Date()).toISOString(),
    created: item.created || item.modified || (/* @__PURE__ */ new Date()).toISOString(),
    thumb: item.thumb || "",
    sign: item.sign || "",
    type: item.type || 0,
    hashinfo: item.hashinfo || item.hash_info || ""
  });
  const createOpenListDriver = ({ client }) => {
    const request = async (storage, apiPath, method, body, retry = false) => {
      const addition = storage.addition_json;
      const payload = await remoteJson(
        client,
        `${trimAddress(addition.url || addition.address || addition.Address)}/api${apiPath}`,
        {
          body,
          headers: headersFor(addition),
          method,
          timeout: Number(addition.timeout || 3e4)
        }
      );
      if ((payload.code === 401 || payload.code === 403) && !retry) {
        await login(client, storage);
        return request(storage, apiPath, method, body, true);
      }
      return checkResp(payload);
    };
    return {
      async list(storage, relPath, req) {
        var _a;
        const addition = storage.addition_json;
        const data = await request(storage, "/fs/list", "POST", {
          page: Number(req.page || 1),
          per_page: Number(req.per_page || req.perPage || 0),
          path: relPath,
          password: addition.meta_password || "",
          refresh: !!req.refresh
        });
        return {
          content: (data.content || []).map((item) => objFrom(item, normalizePath(relPath + "/" + item.name))),
          total: Number(data.total || ((_a = data.content) == null ? void 0 : _a.length) || 0),
          readme: data.readme || "",
          header: data.header || "",
          write: data.write !== false,
          provider: "OpenList",
          direct_upload_tools: []
        };
      },
      async get(storage, relPath) {
        const addition = storage.addition_json;
        const data = await request(storage, "/fs/get", "POST", {
          path: relPath,
          password: addition.meta_password || ""
        });
        return {
          ...objFrom(data, relPath),
          raw_url: data.raw_url || "",
          readme: data.readme || "",
          header: data.header || "",
          provider: "OpenList",
          related: data.related || []
        };
      },
      async mkdir(storage, relPath) {
        await request(storage, "/fs/mkdir", "POST", { path: relPath });
      },
      async remove(storage, relPath) {
        await request(storage, "/fs/remove", "POST", {
          dir: dirname(relPath),
          names: [relPath.split("/").filter(Boolean).pop()]
        });
      },
      async rename(storage, relPath, newName) {
        await request(storage, "/fs/rename", "POST", { path: relPath, name: newName });
      },
      async put(storage, relPath, content, mime) {
        await request(storage, "/fs/put", "PUT", { path: relPath, content, mime });
      }
    };
  };
  const utf8 = (input) => unescape(encodeURIComponent(String(input)));
  const rotr = (value, bits) => value >>> bits | value << 32 - bits;
  const hex = (bytes2) => Array.from(bytes2, (b) => b.toString(16).padStart(2, "0")).join("");
  const bytes = (input) => {
    if (input instanceof Uint8Array) return input;
    const text2 = utf8(input);
    const out = new Uint8Array(text2.length);
    for (let i = 0; i < text2.length; i += 1) out[i] = text2.charCodeAt(i);
    return out;
  };
  const K = [
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ];
  const sha256Bytes = (message) => {
    const msg = bytes(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1779033703;
    let h1 = 3144134277;
    let h2 = 1013904242;
    let h3 = 2773480762;
    let h4 = 1359893119;
    let h5 = 2600822924;
    let h6 = 528734635;
    let h7 = 1541459225;
    const w = new Uint32Array(64);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i = 0; i < 16; i += 1) w[i] = view.getUint32(offset + i * 4);
      for (let i = 16; i < 64; i += 1) {
        const s0 = rotr(w[i - 15], 7) ^ rotr(w[i - 15], 18) ^ w[i - 15] >>> 3;
        const s1 = rotr(w[i - 2], 17) ^ rotr(w[i - 2], 19) ^ w[i - 2] >>> 10;
        w[i] = w[i - 16] + s0 + w[i - 7] + s1 >>> 0;
      }
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      let f = h5;
      let g = h6;
      let h = h7;
      for (let i = 0; i < 64; i += 1) {
        const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const ch = e & f ^ ~e & g;
        const temp1 = h + s1 + ch + K[i] + w[i] >>> 0;
        const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const maj = a & b ^ a & c ^ b & c;
        const temp2 = s0 + maj >>> 0;
        h = g;
        g = f;
        f = e;
        e = d + temp1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = temp1 + temp2 >>> 0;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
      h5 = h5 + f >>> 0;
      h6 = h6 + g >>> 0;
      h7 = h7 + h >>> 0;
    }
    const out = new Uint8Array(32);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4, h5, h6, h7].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const sha256Hex = (message) => hex(sha256Bytes(message));
  const hmacSha256 = (key, message) => {
    let keyBytes = bytes(key);
    if (keyBytes.length > 64) keyBytes = sha256Bytes(keyBytes);
    const ipad = new Uint8Array(64);
    const opad = new Uint8Array(64);
    for (let i = 0; i < 64; i += 1) {
      const b = keyBytes[i] || 0;
      ipad[i] = b ^ 54;
      opad[i] = b ^ 92;
    }
    const inner = new Uint8Array(ipad.length + bytes(message).length);
    inner.set(ipad);
    inner.set(bytes(message), ipad.length);
    const outer = new Uint8Array(opad.length + 32);
    outer.set(opad);
    outer.set(sha256Bytes(inner), opad.length);
    return sha256Bytes(outer);
  };
  const amzDate = (date) => date.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp = (date) => amzDate(date).slice(0, 8);
  const encodeRfc3986 = (value) => encodeURIComponent(value).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
  const signAwsV4 = ({ accessKeyId, body = "", headers = {}, method, region, secretAccessKey, service = "s3", sessionToken = "", url }) => {
    const parsed = new URL(url);
    const now = /* @__PURE__ */ new Date();
    const amz = amzDate(now);
    const date = dateStamp(now);
    const payloadHash = sha256Hex(body || "");
    const normalizedHeaders = {
      host: parsed.host,
      "x-amz-content-sha256": payloadHash,
      "x-amz-date": amz,
      ...Object.fromEntries(Object.entries(headers).map(([key, value]) => [key.toLowerCase(), String(value).trim()]))
    };
    if (sessionToken) normalizedHeaders["x-amz-security-token"] = sessionToken;
    const signedHeaders = Object.keys(normalizedHeaders).sort();
    const canonicalHeaders = signedHeaders.map((key) => `${key}:${normalizedHeaders[key]}
`).join("");
    const query = [...parsed.searchParams.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([key, value]) => `${encodeRfc3986(key)}=${encodeRfc3986(value)}`).join("&");
    const canonicalRequest = [
      method.toUpperCase(),
      parsed.pathname || "/",
      query,
      canonicalHeaders,
      signedHeaders.join(";"),
      payloadHash
    ].join("\n");
    const scope = `${date}/${region}/${service}/aws4_request`;
    const stringToSign = [
      "AWS4-HMAC-SHA256",
      amz,
      scope,
      sha256Hex(canonicalRequest)
    ].join("\n");
    const kDate = hmacSha256(`AWS4${secretAccessKey}`, date);
    const kRegion = hmacSha256(kDate, region);
    const kService = hmacSha256(kRegion, service);
    const kSigning = hmacSha256(kService, "aws4_request");
    const signature = hex(hmacSha256(kSigning, stringToSign));
    return {
      ...normalizedHeaders,
      Authorization: `AWS4-HMAC-SHA256 Credential=${accessKeyId}/${scope}, SignedHeaders=${signedHeaders.join(";")}, Signature=${signature}`
    };
  };
  const tagText$1 = (xml, name) => {
    var _a;
    return ((_a = String(xml || "").match(new RegExp(`<${name}>([\\s\\S]*?)<\\/${name}>`, "i"))) == null ? void 0 : _a[1]) || "";
  };
  const decodeXml = (value) => String(value || "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  const keyFor = (path, dir = false) => {
    const key = normalizePath(path).replace(/^\/+/, "");
    return key && dir ? `${key}/` : key;
  };
  const s3Url = (addition, key = "", query = "") => {
    const endpoint = String(addition.endpoint || "").replace(/\/+$/, "");
    const bucket = addition.bucket;
    const forcePathStyle = addition.force_path_style !== false;
    const path = forcePathStyle ? normalizePath(`/${bucket}/${key}`) : normalizePath(`/${key}`);
    const base = forcePathStyle ? endpoint : endpoint.replace("://", `://${bucket}.`);
    return `${joinUrl(base, path)}${query ? `?${query}` : ""}`;
  };
  const signedRequest = (client, addition, method, key, {
    body = "",
    contentType = "application/octet-stream",
    headers: extraHeaders = {},
    query = "",
    responseEncoding = "text"
  } = {}) => {
    const url = s3Url(addition, key, query);
    const headers = signAwsV4({
      accessKeyId: addition.access_key_id,
      body,
      headers: {
        ...contentType ? { "content-type": contentType } : {},
        ...extraHeaders
      },
      method,
      region: addition.region || "us-east-1",
      secretAccessKey: addition.secret_access_key,
      sessionToken: addition.session_token || "",
      url
    });
    return forwardProxy(client, url, {
      body,
      contentType,
      headers,
      method,
      responseEncoding,
      timeout: Number(addition.timeout || 6e4)
    });
  };
  const parseListObjects = (xml, relPath, addition) => {
    const placeholder = addition.placeholder || ".siyuan-cloud";
    const dirs = (String(xml || "").match(/<CommonPrefixes>[\s\S]*?<\/CommonPrefixes>/gi) || []).map((chunk) => decodeXml(tagText$1(chunk, "Prefix")).replace(/\/+$/, "")).map((prefix) => basename(prefix)).filter(Boolean).map((name) => ({
      name,
      path: normalizePath(relPath + "/" + name),
      is_dir: true,
      size: 0,
      modified: (/* @__PURE__ */ new Date()).toISOString(),
      created: (/* @__PURE__ */ new Date()).toISOString()
    }));
    const files = (String(xml || "").match(/<Contents>[\s\S]*?<\/Contents>/gi) || []).map((chunk) => {
      const key = decodeXml(tagText$1(chunk, "Key"));
      const name = basename(key);
      return {
        name,
        path: normalizePath(relPath + "/" + name),
        is_dir: false,
        size: Number(tagText$1(chunk, "Size") || 0),
        modified: new Date(tagText$1(chunk, "LastModified") || Date.now()).toISOString(),
        created: new Date(tagText$1(chunk, "LastModified") || Date.now()).toISOString()
      };
    }).filter((item) => item.name && item.name !== placeholder);
    return [...dirs, ...files];
  };
  const createS3Driver = ({ client }) => ({
    async list(storage, relPath, req) {
      const addition = storage.addition_json;
      const prefix = keyFor(relPath, true);
      const version = addition.list_object_version === "v2" ? "list-type=2&" : "";
      const data = await signedRequest(client, addition, "GET", "", {
        contentType: "",
        query: `${version}prefix=${encodeURIComponent(prefix)}&delimiter=%2F`
      });
      const content = parseListObjects(data.body, relPath, addition);
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "S3",
        direct_upload_tools: addition.enable_direct_upload ? ["HttpDirect"] : []
      };
    },
    async get(storage, relPath) {
      var _a, _b, _c, _d;
      const addition = storage.addition_json;
      const data = await signedRequest(client, addition, "HEAD", keyFor(relPath), { contentType: "" });
      return {
        name: basename(relPath),
        path: relPath,
        is_dir: false,
        size: Number(((_a = data.headers) == null ? void 0 : _a["Content-Length"]) || ((_b = data.headers) == null ? void 0 : _b["content-length"]) || 0),
        modified: new Date(((_c = data.headers) == null ? void 0 : _c["Last-Modified"]) || ((_d = data.headers) == null ? void 0 : _d["last-modified"]) || Date.now()).toISOString(),
        created: (/* @__PURE__ */ new Date()).toISOString(),
        raw_url: `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
        provider: "S3",
        related: []
      };
    },
    async read(storage, relPath) {
      return signedRequest(client, storage.addition_json, "GET", keyFor(relPath), { contentType: "", responseEncoding: "base64" });
    },
    async mkdir(storage, relPath) {
      const addition = storage.addition_json;
      const name = addition.placeholder || ".siyuan-cloud";
      await signedRequest(client, addition, "PUT", keyFor(normalizePath(relPath + "/" + name)), { body: "" });
    },
    async remove(storage, relPath) {
      await signedRequest(client, storage.addition_json, "DELETE", keyFor(relPath), { contentType: "" });
    },
    async rename(storage, relPath, newName) {
      const addition = storage.addition_json;
      const src = `${addition.bucket}/${keyFor(relPath)}`;
      const dst = normalizePath(dirname(relPath) + "/" + newName).replace(/^\/+/, "");
      await signedRequest(client, addition, "PUT", dst, {
        contentType: "",
        headers: { "x-amz-copy-source": `/${encodeURIComponent(src).replace(/%2F/g, "/")}` }
      });
      await signedRequest(client, addition, "DELETE", keyFor(relPath), { contentType: "" });
    },
    async put(storage, relPath, content, mime) {
      await signedRequest(client, storage.addition_json, "PUT", keyFor(relPath), {
        body: content || "",
        contentType: mime || "application/octet-stream"
      });
    }
  });
  const davHeaders = (addition, extra = {}) => ({
    Authorization: basicAuth(addition.username, addition.password),
    ...extra
  });
  const stripTags = (value) => String(value || "").replace(/<[^>]+>/g, "").trim();
  const hrefText = (xml) => {
    var _a;
    return stripTags(((_a = xml.match(/<[^:>]*:?href[^>]*>[\s\S]*?<\/[^:>]*:?href>/i)) == null ? void 0 : _a[0]) || "");
  };
  const tagText = (xml, name) => {
    var _a;
    return stripTags(((_a = xml.match(new RegExp(`<[^:>]*:?${name}[^>]*>[\\s\\S]*?<\\/[^:>]*:?${name}>`, "i"))) == null ? void 0 : _a[0]) || "");
  };
  const isCollection = (xml) => /<[^:>]*:?collection\b/i.test(xml);
  const parseDavDate = (raw) => {
    const date = raw ? new Date(raw) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const parsePropfind = (xml, relPath) => {
    const responses = String(xml || "").match(/<[^:>]*:?response\b[\s\S]*?<\/[^:>]*:?response>/gi) || [];
    const current = normalizePath(relPath || "/");
    return responses.map((chunk) => {
      const href = decodeURIComponent(hrefText(chunk));
      const name = tagText(chunk, "displayname") || basename(href.replace(/\/+$/, ""));
      const path = normalizePath(current + "/" + name);
      return {
        name,
        path,
        is_dir: isCollection(chunk),
        size: Number(tagText(chunk, "getcontentlength") || 0),
        modified: parseDavDate(tagText(chunk, "getlastmodified")),
        created: parseDavDate(tagText(chunk, "creationdate"))
      };
    }).filter((item) => item.name && normalizePath(item.path) !== current);
  };
  const createWebDavDriver = ({ client }) => {
    const request = (storage, relPath, options = {}) => {
      const addition = storage.addition_json;
      return forwardProxy(client, joinUrl(addition.address, normalizePath((addition.root_folder_path || "/") + "/" + relPath)), {
        ...options,
        headers: davHeaders(addition, options.headers || {}),
        timeout: Number(addition.timeout || 3e4)
      });
    };
    return {
      async list(storage, relPath) {
        const data = await request(storage, relPath, {
          body: '<?xml version="1.0"?><propfind xmlns="DAV:"><allprop/></propfind>',
          contentType: "application/xml",
          headers: { Depth: "1" },
          method: "PROPFIND"
        });
        const content = parsePropfind(data.body, relPath);
        return {
          content,
          total: content.length,
          readme: "",
          header: "",
          write: true,
          provider: "WebDav",
          direct_upload_tools: []
        };
      },
      async get(storage, relPath) {
        var _a, _b;
        const head = await request(storage, relPath, { method: "HEAD" });
        return {
          name: basename(relPath),
          path: relPath,
          is_dir: false,
          size: Number(((_a = head.headers) == null ? void 0 : _a["Content-Length"]) || ((_b = head.headers) == null ? void 0 : _b["content-length"]) || 0),
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString(),
          raw_url: `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
          provider: "WebDav",
          related: []
        };
      },
      async read(storage, relPath) {
        return request(storage, relPath, { method: "GET", responseEncoding: "base64" });
      },
      async mkdir(storage, relPath) {
        await request(storage, relPath, { method: "MKCOL" });
      },
      async remove(storage, relPath) {
        await request(storage, relPath, { method: "DELETE" });
      },
      async rename(storage, relPath, newName) {
        const addition = storage.addition_json;
        await request(storage, relPath, {
          headers: { Destination: joinUrl(addition.address, normalizePath((addition.root_folder_path || "/") + "/" + dirname(relPath) + "/" + newName)) },
          method: "MOVE"
        });
      },
      async put(storage, relPath, content, mime) {
        await request(storage, relPath, {
          body: content || "",
          contentType: mime || "application/octet-stream",
          method: "PUT"
        });
      }
    };
  };
  const parseAddition = (storage) => {
    if (storage.addition_json) return storage.addition_json;
    try {
      return JSON.parse(storage.addition || "{}");
    } catch (_) {
      return {};
    }
  };
  const relPathForMount = (mountPath, path) => {
    const mount = normalizePath(mountPath);
    const current = normalizePath(path);
    if (mount === "/") return current;
    const rest = current === mount ? "" : current.slice(mount.length);
    return normalizePath(rest || "/");
  };
  const createDriverRuntime = ({ client, saveStorageAddition }) => {
    const drivers = {
      OpenList: createOpenListDriver({ client }),
      AListV3: createOpenListDriver({ client }),
      "AList V3": createOpenListDriver({ client }),
      S3: createS3Driver({ client }),
      Doge: createS3Driver({ client }),
      WebDav: createWebDavDriver({ client }),
      Onedrive: createOneDriveDriver({ client }),
      OneDrive: createOneDriveDriver({ client }),
      "123Pan": create123PanDriver({ client }),
      "123": create123PanDriver({ client }),
      BaiduNetdisk: createBaiduNetdiskDriver({ client }),
      BaiduNetDisk: createBaiduNetdiskDriver({ client })
    };
    const runtime = {
      drivers,
      canHandle(storage) {
        return !!drivers[storage == null ? void 0 : storage.driver];
      },
      mountEntries(storages, now) {
        const seen = /* @__PURE__ */ new Set();
        return (storages || []).filter((storage) => !storage.disabled && normalizePath(storage.mount_path || "/") !== "/").map((storage) => normalizePath(storage.mount_path)).map((mountPath) => mountPath.split("/").filter(Boolean)[0]).filter((name) => {
          if (!name || seen.has(name)) return false;
          seen.add(name);
          return true;
        }).map((name) => ({
          name,
          path: `/${name}`,
          is_dir: true,
          size: 0,
          modified: now(),
          created: now(),
          provider: "mount"
        }));
      },
      resolve(storages, path) {
        const current = normalizePath(path || "/");
        const candidates = (storages || []).filter((storage2) => !storage2.disabled && runtime.canHandle(storage2)).map((storage2) => {
          const addition = parseAddition(storage2);
          return {
            ...storage2,
            addition_json: addition,
            mount_path: normalizePath(storage2.mount_path || "/"),
            saveDriverStorage: async (updatedAddition = addition) => {
              if (saveStorageAddition) await saveStorageAddition(storage2, updatedAddition);
            }
          };
        }).filter((storage2) => storage2.mount_path !== "/" && (current === storage2.mount_path || current.startsWith(storage2.mount_path + "/"))).sort((a, b) => b.mount_path.length - a.mount_path.length);
        const storage = candidates[0];
        if (!storage) return null;
        return {
          storage,
          driver: drivers[storage.driver],
          relPath: relPathForMount(storage.mount_path, current)
        };
      },
      async test(driverName, addition) {
        const driver = drivers[driverName];
        if (!(driver == null ? void 0 : driver.test)) throw new Error(`driver [${driverName}] does not expose a test method`);
        return driver.test({
          addition_json: addition || {},
          driver: driverName,
          mount_path: "/"
        });
      }
    };
    return runtime;
  };
  const defaultSettings = () => ({
    site_title: "Siyuan Cloud",
    version: OPENLIST_VERSION,
    main_color: "#1890ff",
    logo: "",
    favicon: "",
    announcement: "",
    announcements: "",
    allow_indexed: "false",
    allow_mounted: "true",
    hide_storage_details: "true",
    hide_storage_details_in_manage_page: "true",
    show_disk_usage_in_plain_text: "false",
    text_types: "txt,htm,html,xml,java,properties,sql,js,md,json,conf,ini,vue,php,py,bat,gitignore,yml,go,sh,c,cpp,h,hpp,tsx,vtt,srt,ass,rs,lrc,strm",
    audio_types: "mp3,flac,ogg,m4a,wav,opus,wma",
    video_types: "mp4,mkv,avi,mov,rmvb,webm,flv,m3u8",
    image_types: "jpg,tiff,jpeg,png,gif,bmp,svg,ico,swf,webp,avif",
    proxy_types: "m3u8,url",
    proxy_ignore_headers: "authorization,referer",
    audio_autoplay: "true",
    video_autoplay: "true",
    preview_download_by_default: "false",
    preview_archives_by_default: "false",
    share_preview_download_by_default: "false",
    share_preview_archives_by_default: "false",
    readme_autorender: "true",
    filter_readme_scripts: "true",
    non_efs_zip_encoding: "IBM437",
    default_page_size: "30",
    package_download: "true",
    pagination_type: "all",
    robots_txt: "",
    hide_files: "",
    customize_head: "",
    customize_body: "",
    link_expiration: "0",
    sign_all: "true",
    privacy_regs: "",
    ocr_api: "https://api.example.com/ocr/file/json",
    filename_char_mapping: "",
    forward_direct_link_params: "",
    ignore_direct_link_params: "sign,sicloud_ts,raw",
    webauthn_login_enabled: "false",
    share_preview: "false",
    share_archive_preview: "false",
    share_force_proxy: "true",
    share_summary_content: "",
    handle_hook_after_writing: "false",
    handle_hook_rate_limit: "0",
    ignore_system_files: "false",
    search_index: "none",
    auto_update_index: "false",
    ignore_paths: "",
    max_index_depth: "20",
    index_progress: "{}",
    sso_login_enabled: "false",
    sso_login_platform: "Github",
    sso_client_id: "",
    sso_client_secret: "",
    sso_oidc_username_key: "name",
    sso_organization_name: "",
    sso_application_name: "",
    sso_endpoint_name: "",
    sso_jwt_public_key: "",
    sso_extra_scopes: "",
    sso_auto_register: "false",
    sso_default_dir: "/",
    sso_default_permission: "0",
    sso_compatibility_mode: "false",
    ldap_login_enabled: "false",
    ldap_server: "",
    ldap_skip_tls_verify: "false",
    ldap_manager_dn: "",
    ldap_manager_password: "",
    ldap_user_search_base: "",
    ldap_user_search_filter: "(uid=%s)",
    ldap_default_dir: "/",
    ldap_default_permission: "0",
    ldap_login_tips: "login with ldap",
    s3_access_key_id: "",
    s3_secret_access_key: "",
    s3_buckets: "[]",
    ftp_public_host: "127.0.0.1",
    ftp_pasv_port_map: "",
    ftp_mandatory_tls: "false",
    ftp_implicit_tls: "false",
    ftp_tls_private_key_path: "",
    ftp_tls_public_cert_path: "",
    sftp_disable_password_login: "false",
    task_offline_download_threads_num: "5",
    task_offline_download_transfer_threads_num: "5",
    task_upload_threads_num: "5",
    task_copy_threads_num: "5",
    task_decompress_download_threads_num: "5",
    task_decompress_upload_threads_num: "5",
    stream_max_client_download_speed: "-1",
    stream_max_client_upload_speed: "-1",
    stream_max_server_download_speed: "-1",
    stream_max_server_upload_speed: "-1",
    aria2_uri: "",
    aria2_secret: "",
    qbittorrent_url: "",
    qbittorrent_seedtime: "",
    transmission_uri: "",
    transmission_seedtime: "",
    "115_temp_dir": "",
    "123_temp_dir": "",
    "115_open_temp_dir": "",
    "123_open_temp_dir": "",
    "123_open_callback_url": "",
    pikpak_temp_dir: "",
    thunder_temp_dir: "",
    thunderx_temp_dir: "",
    thunder_browser_temp_dir: "",
    token: "siyuan-cloud-token"
  });
  const settingMeta = {
    version: { group: SETTING_GROUP.SITE, flag: SETTING_FLAG.READONLY },
    site_title: { group: SETTING_GROUP.SITE },
    announcement: { type: "text", group: SETTING_GROUP.SITE },
    announcements: { type: "text", group: SETTING_GROUP.SITE },
    allow_indexed: { type: "bool", group: SETTING_GROUP.SITE },
    allow_mounted: { type: "bool", group: SETTING_GROUP.SITE },
    robots_txt: { type: "text", group: SETTING_GROUP.SITE },
    logo: { type: "text", group: SETTING_GROUP.STYLE },
    favicon: { group: SETTING_GROUP.STYLE },
    main_color: { group: SETTING_GROUP.STYLE },
    hide_storage_details: { type: "bool", group: SETTING_GROUP.STYLE, flag: SETTING_FLAG.PRIVATE },
    hide_storage_details_in_manage_page: { type: "bool", group: SETTING_GROUP.STYLE, flag: SETTING_FLAG.PRIVATE },
    show_disk_usage_in_plain_text: { type: "bool", group: SETTING_GROUP.STYLE },
    text_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    audio_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    video_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    image_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    proxy_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    proxy_ignore_headers: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    audio_autoplay: { type: "bool", group: SETTING_GROUP.PREVIEW },
    video_autoplay: { type: "bool", group: SETTING_GROUP.PREVIEW },
    preview_download_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    preview_archives_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    share_preview_download_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    share_preview_archives_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    readme_autorender: { type: "bool", group: SETTING_GROUP.PREVIEW },
    filter_readme_scripts: { type: "bool", group: SETTING_GROUP.PREVIEW },
    non_efs_zip_encoding: { group: SETTING_GROUP.PREVIEW },
    hide_files: { type: "text", group: SETTING_GROUP.GLOBAL },
    customize_head: { type: "text", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    customize_body: { type: "text", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    link_expiration: { type: "number", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    sign_all: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    privacy_regs: { type: "text", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    ocr_api: { group: SETTING_GROUP.GLOBAL },
    filename_char_mapping: { type: "text", group: SETTING_GROUP.GLOBAL },
    forward_direct_link_params: { group: SETTING_GROUP.GLOBAL },
    ignore_direct_link_params: { group: SETTING_GROUP.GLOBAL },
    webauthn_login_enabled: { type: "bool", group: SETTING_GROUP.GLOBAL },
    share_preview: { type: "bool", group: SETTING_GROUP.GLOBAL },
    share_archive_preview: { type: "bool", group: SETTING_GROUP.GLOBAL },
    share_force_proxy: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    share_summary_content: { type: "text", group: SETTING_GROUP.GLOBAL },
    handle_hook_after_writing: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    handle_hook_rate_limit: { type: "number", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    ignore_system_files: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    token: { group: SETTING_GROUP.SINGLE, flag: SETTING_FLAG.PRIVATE },
    search_index: { type: "select", options: "none,bleve", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE },
    auto_update_index: { type: "bool", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE },
    ignore_paths: { type: "text", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE, help: "one path per line" },
    max_index_depth: { type: "number", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE, help: "max depth of index" },
    index_progress: { type: "text", group: SETTING_GROUP.SINGLE, flag: SETTING_FLAG.PRIVATE },
    sso_login_enabled: { type: "bool", group: SETTING_GROUP.SSO },
    sso_login_platform: { type: "select", options: "Casdoor,Github,Microsoft,Google,Dingtalk,OIDC", group: SETTING_GROUP.SSO },
    sso_client_id: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_client_secret: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_oidc_username_key: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_organization_name: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_application_name: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_endpoint_name: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_jwt_public_key: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_extra_scopes: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_auto_register: { type: "bool", group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_default_dir: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_default_permission: { type: "number", group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_compatibility_mode: { type: "bool", group: SETTING_GROUP.SSO },
    ldap_login_enabled: { type: "bool", group: SETTING_GROUP.LDAP },
    ldap_server: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_skip_tls_verify: { type: "bool", group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_manager_dn: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_manager_password: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_user_search_base: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_user_search_filter: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_default_dir: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_default_permission: { type: "number", group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_login_tips: { group: SETTING_GROUP.LDAP },
    s3_access_key_id: { group: SETTING_GROUP.S3, flag: SETTING_FLAG.PRIVATE },
    s3_secret_access_key: { group: SETTING_GROUP.S3, flag: SETTING_FLAG.PRIVATE },
    s3_buckets: { group: SETTING_GROUP.S3, flag: SETTING_FLAG.PRIVATE },
    ftp_public_host: { group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_pasv_port_map: { type: "text", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_mandatory_tls: { type: "bool", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_implicit_tls: { type: "bool", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_tls_private_key_path: { group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_tls_public_cert_path: { group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    sftp_disable_password_login: { type: "bool", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    task_offline_download_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_offline_download_transfer_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_upload_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_copy_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_decompress_download_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_decompress_upload_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_client_download_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_client_upload_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_server_download_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_server_upload_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    aria2_uri: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    aria2_secret: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    qbittorrent_url: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    qbittorrent_seedtime: { type: "number", group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    transmission_uri: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    transmission_seedtime: { type: "number", group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "115_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "123_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "115_open_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "123_open_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "123_open_callback_url": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    pikpak_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    thunder_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    thunderx_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    thunder_browser_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE }
  };
  const defaultState = (now) => ({
    settings: defaultSettings(),
    users: [
      {
        id: 1,
        username: "admin",
        password: "",
        role: 2,
        disabled: false,
        base_path: "/",
        permission: 67108863,
        sso_id: "",
        otp: false,
        otp_secret: ""
      }
    ],
    storages: [
      {
        id: 1,
        mount_path: "/",
        order: 0,
        driver: "SiYuanKernel",
        cache_expiration: 30,
        status: "work",
        addition: "{}",
        remark: "Virtual OpenList storage backed by SiYuan kernel plugin storage.",
        modified: now(),
        disabled: false
      }
    ],
    entries: {
      "/": {
        name: "",
        path: "/",
        is_dir: true,
        size: 0,
        modified: now(),
        created: now(),
        children: []
      }
    },
    tasks: {},
    metas: [],
    messages: [],
    ssh_keys: [],
    scan: { status: "idle", total: 0, done: 0 },
    webdav_locks: {},
    s3_multipart_uploads: {},
    sharings: []
  });
  const createVirtualFs = ({ getState, now }) => {
    const ensureDir = (path) => {
      const state = getState();
      const normalized = normalizePath(path);
      if (!state.entries[normalized]) {
        state.entries[normalized] = {
          name: basename(normalized),
          path: normalized,
          is_dir: true,
          size: 0,
          modified: now(),
          created: now(),
          children: []
        };
      }
      const parentPath = dirname(normalized);
      const parent = state.entries[parentPath];
      if (parent && parent.is_dir && normalized !== "/" && !parent.children.includes(normalized)) {
        parent.children.push(normalized);
        parent.children.sort();
        parent.modified = now();
      }
      return state.entries[normalized];
    };
    const createFile = (path, content, mime) => {
      var _a;
      const state = getState();
      const normalized = normalizePath(path);
      const parent = ensureDir(dirname(normalized));
      const text2 = content === void 0 || content === null ? "" : String(content);
      state.entries[normalized] = {
        name: basename(normalized),
        path: normalized,
        is_dir: false,
        size: text2.length,
        modified: now(),
        created: ((_a = state.entries[normalized]) == null ? void 0 : _a.created) || now(),
        content: text2,
        mime: mime || "text/plain; charset=utf-8"
      };
      if (!parent.children.includes(normalized)) {
        parent.children.push(normalized);
        parent.children.sort();
      }
      parent.modified = now();
      return state.entries[normalized];
    };
    const removeEntry = (path) => {
      const state = getState();
      const entry = state.entries[path];
      if (!entry || path === "/") return;
      if (entry.children) {
        for (const child of [...entry.children]) removeEntry(child);
      }
      const parent = state.entries[dirname(path)];
      if (parent && parent.children) {
        parent.children = parent.children.filter((item) => item !== path);
        parent.modified = now();
      }
      delete state.entries[path];
    };
    const cloneEntryTree = (srcPath, dstPath) => {
      const state = getState();
      const src = state.entries[srcPath];
      if (!src) throw new Error("object not found");
      if (src.is_dir) {
        ensureDir(dstPath);
        for (const child of src.children || []) {
          cloneEntryTree(child, normalizePath(dstPath + "/" + basename(child)));
        }
      } else {
        createFile(dstPath, src.content || "", src.mime);
      }
    };
    const moveEntryTree = (srcPath, dstPath) => {
      cloneEntryTree(srcPath, dstPath);
      removeEntry(srcPath);
    };
    const renameEntryInDir = (dir, srcName, newName, options) => {
      const state = getState();
      const srcPath = normalizePath(dir + "/" + srcName);
      const dstPath = normalizePath(dir + "/" + newName);
      if (!isSafeRelativeName(newName)) throw new Error("relative path is not allowed");
      if (!state.entries[srcPath]) return false;
      if (state.entries[dstPath] && dstPath !== srcPath && !(options == null ? void 0 : options.overwrite)) throw new Error(`file [${newName}] exists`);
      if (state.entries[dstPath] && dstPath !== srcPath) removeEntry(dstPath);
      moveEntryTree(srcPath, dstPath);
      return true;
    };
    const removeEmptyDirs = (rootPath2) => {
      var _a;
      const state = getState();
      let removed = 0;
      const walk = (path) => {
        const entry = state.entries[path];
        if (!entry || !entry.is_dir || path === "/") return false;
        for (const child of [...entry.children || []]) walk(child);
        if ((entry.children || []).length === 0) {
          removeEntry(path);
          removed += 1;
          return true;
        }
        return false;
      };
      for (const child of [...((_a = state.entries[rootPath2]) == null ? void 0 : _a.children) || []]) walk(child);
      return removed;
    };
    return {
      cloneEntryTree,
      createFile,
      ensureDir,
      moveEntryTree,
      removeEmptyDirs,
      removeEntry,
      renameEntryInDir
    };
  };
  const createWorkspaceAdapter = ({
    client,
    extensionType,
    failure: failure2,
    now,
    page,
    toObjResp
  }) => {
    const isWorkspacePath = (path) => normalizePath(path).startsWith("/@workspace");
    const workspaceRelPath = (path) => {
      const normalized = normalizePath(path);
      const rel = normalized.replace(/^\/@workspace\/?/, "");
      return rel.replace(/^\/+/, "");
    };
    const siyuanApiJson = async (apiPath, data) => {
      const response = await client.fetch(apiPath, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data || {})
      });
      const contentType = response.headers && (response.headers["Content-Type"] || response.headers["content-type"] || "");
      if (String(contentType).includes("application/json")) return response.json();
      return {
        code: response.ok ? 0 : response.status,
        msg: response.statusText || "",
        data: await response.text()
      };
    };
    const workspaceObjResp = (item) => ({
      name: item.name,
      size: item.size || 0,
      is_dir: !!(item.isDir || item.is_dir),
      modified: new Date(Number(item.updated || 0) * 1e3 || Date.now()).toISOString(),
      created: new Date(Number(item.updated || 0) * 1e3 || Date.now()).toISOString(),
      sign: "",
      thumb: "",
      type: extensionType(item.name, item.isDir || item.is_dir),
      hashinfo: "",
      hash_info: {},
      provider: "siyuan-workspace"
    });
    const workspaceList = async (path, req) => {
      const rel = workspaceRelPath(path);
      const payload = await siyuanApiJson("/api/file/readDir", { path: rel });
      if (payload.code !== 0) return { error: failure2(payload.msg || "readDir failed", payload.code || 500) };
      const content = (payload.data || []).filter((item) => item && item.name && !String(item.name).startsWith(".")).map(workspaceObjResp);
      return {
        data: {
          content: page(content, req || {}),
          total: content.length,
          readme: "",
          header: "",
          write: true,
          write_content_bypass: false,
          provider: "siyuan-workspace",
          direct_upload_tools: []
        }
      };
    };
    const workspaceGet = async (path) => {
      if (normalizePath(path) === "/@workspace") {
        return {
          data: {
            ...toObjResp({ name: "@workspace", is_dir: true, size: 0, modified: now(), created: now() }),
            raw_url: "",
            readme: "",
            header: "",
            provider: "siyuan-workspace",
            related: []
          }
        };
      }
      const rel = workspaceRelPath(path);
      const parent = workspaceRelPath(dirname(path));
      const payload = await siyuanApiJson("/api/file/readDir", { path: parent });
      if (payload.code !== 0) return { error: failure2(payload.msg || "readDir failed", payload.code || 500) };
      const item = (payload.data || []).find((entry) => entry.name === basename(path));
      if (!item) return { error: failure2("object not found", 404) };
      return {
        data: {
          ...workspaceObjResp(item),
          raw_url: item.isDir ? "" : "/plugin/private/siyuan-cloud/d" + normalizePath("/@workspace/" + rel),
          readme: "",
          header: "",
          provider: "siyuan-workspace",
          related: []
        }
      };
    };
    const workspaceReadText = async (path) => {
      const response = await client.fetch("/api/file/getFile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: workspaceRelPath(path) })
      });
      return {
        ok: response.ok,
        status: response.status || 200,
        text: await response.text(),
        contentType: response.headers && (response.headers["Content-Type"] || response.headers["content-type"]) || "application/octet-stream"
      };
    };
    return {
      isWorkspacePath,
      siyuanApiJson,
      workspaceGet,
      workspaceList,
      workspaceReadText,
      workspaceRelPath
    };
  };
  const DONE_STATES = /* @__PURE__ */ new Set(["succeeded", "failed", "canceled"]);
  const ensureTaskBuckets = (state) => {
    state.tasks = state.tasks || {};
    for (const type of TASK_TYPES) {
      state.tasks[type] = state.tasks[type] || {};
    }
    return state.tasks;
  };
  const createTaskRecord = ({
    creator,
    error,
    name,
    now,
    status,
    totalBytes,
    type
  }) => {
    const time = now();
    return {
      id: `${type}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
      name: name || type,
      creator: (creator == null ? void 0 : creator.username) || "admin",
      creator_role: (creator == null ? void 0 : creator.role) ?? 2,
      state: error ? "failed" : "succeeded",
      status: status || (error ? "failed" : "completed"),
      progress: error ? 0 : 100,
      start_time: time,
      end_time: time,
      total_bytes: totalBytes || 0,
      error: error || ""
    };
  };
  const createTaskStore = ({
    getState,
    now,
    saveState: saveState2
  }) => {
    const addTask = async (type, input) => {
      var _a;
      const state = getState();
      const tasks = ensureTaskBuckets(state);
      const task = createTaskRecord({
        ...input,
        creator: (_a = state.users) == null ? void 0 : _a[0],
        now,
        type
      });
      tasks[type][task.id] = task;
      await saveState2();
      return task;
    };
    const getTask = (type, id) => {
      var _a;
      const tasks = ensureTaskBuckets(getState());
      return ((_a = tasks[type]) == null ? void 0 : _a[id]) || null;
    };
    const listTasks = (type, done) => {
      const tasks = ensureTaskBuckets(getState());
      return Object.values(tasks[type] || {}).filter((task) => done ? DONE_STATES.has(task.state) : !DONE_STATES.has(task.state)).sort((a, b) => String(b.start_time || "").localeCompare(String(a.start_time || "")));
    };
    const removeTask = async (type, id) => {
      const tasks = ensureTaskBuckets(getState());
      if (tasks[type]) delete tasks[type][id];
      await saveState2();
    };
    const clearDone = async (type) => {
      const tasks = ensureTaskBuckets(getState());
      for (const task of Object.values(tasks[type] || {})) {
        if (DONE_STATES.has(task.state)) delete tasks[type][task.id];
      }
      await saveState2();
    };
    const markCanceled = async (type, id) => {
      const task = getTask(type, id);
      if (task) {
        task.state = "canceled";
        task.status = "canceled";
        task.end_time = now();
      }
      await saveState2();
    };
    return {
      addTask,
      clearDone,
      getTask,
      listTasks,
      markCanceled,
      removeTask
    };
  };
  const saveState = async (storage, state) => {
    await storage.put(STATE_FILE, JSON.stringify(state, null, 2));
  };
  const loadState = async ({ now, storage }) => {
    try {
      const file = await storage.get(STATE_FILE);
      const loaded = await file.json();
      if (loaded && loaded.entries && loaded.users) {
        return {
          shouldSave: false,
          state: {
            ...defaultState(now),
            ...loaded,
            settings: { ...defaultSettings(), ...loaded.settings || {} },
            tasks: loaded.tasks || {},
            metas: loaded.metas || [],
            messages: loaded.messages || [],
            ssh_keys: loaded.ssh_keys || [],
            scan: loaded.scan || { status: "idle", total: 0, done: 0 },
            webdav_locks: loaded.webdav_locks || {},
            s3_multipart_uploads: loaded.s3_multipart_uploads || {},
            sharings: loaded.sharings || []
          }
        };
      }
    } catch (_) {
    }
    return {
      shouldSave: true,
      state: defaultState(now)
    };
  };
  const taskListResp = (taskStore, type, done) => {
    const tasks = taskStore.listTasks(type, done);
    return pageResp(tasks, tasks.length);
  };
  const createTaskHandlers = ({
    parseJson,
    queryValue,
    saveState: saveState2,
    taskStore
  }) => {
    const map = {};
    const taskId = async (request) => {
      const req = await parseJson(request);
      return queryValue(request, "tid") || req.tid || req.id || "";
    };
    for (const type of TASK_TYPES) {
      map[`GET /api/task/${type}/undone`] = async () => jsonResponse(success(taskListResp(taskStore, type, false)));
      map[`GET /api/task/${type}/done`] = async () => jsonResponse(success(taskListResp(taskStore, type, true)));
      map[`GET /api/task/${type}/info`] = async (request) => {
        const task = taskStore.getTask(type, await taskId(request));
        return task ? jsonResponse(success(task)) : jsonResponse(failure("task not found", 404));
      };
      map[`POST /api/task/${type}/info`] = map[`GET /api/task/${type}/info`];
      map[`POST /api/task/${type}/retry`] = async (request) => {
        const task = taskStore.getTask(type, await taskId(request));
        if (task) {
          task.state = "succeeded";
          task.status = "completed";
          task.progress = 100;
          task.error = "";
          await saveState2();
        }
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/retry_failed`] = async () => jsonResponse(success());
      map[`POST /api/task/${type}/clear_done`] = async () => {
        await taskStore.clearDone(type);
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/clear_succeeded`] = map[`POST /api/task/${type}/clear_done`];
      map[`POST /api/task/${type}/cancel`] = async (request) => {
        await taskStore.markCanceled(type, await taskId(request));
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/delete`] = async (request) => {
        await taskStore.removeTask(type, await taskId(request));
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/cancel_some`] = async () => jsonResponse(success({}));
      map[`POST /api/task/${type}/delete_some`] = async () => jsonResponse(success([]));
      map[`POST /api/task/${type}/retry_some`] = async () => jsonResponse(success({}));
    }
    return map;
  };
  const normalizeMeta = (input, id) => ({
    id: Number(input.id || input.ID || id || 0),
    path: normalizePath(input.path || input.Path || "/"),
    read_users: Array.isArray(input.read_users) ? input.read_users : [],
    read_users_sub: !!input.read_users_sub,
    write_users: Array.isArray(input.write_users) ? input.write_users : [],
    write_users_sub: !!input.write_users_sub,
    password: String(input.password || ""),
    p_sub: !!input.p_sub,
    write: !!input.write,
    w_sub: !!input.w_sub,
    hide: String(input.hide || ""),
    h_sub: !!input.h_sub,
    readme: String(input.readme || ""),
    r_sub: !!input.r_sub,
    header: String(input.header || ""),
    header_sub: !!input.header_sub
  });
  const metaCoversPath = (metaPath, path, includeSub) => {
    const meta = normalizePath(metaPath);
    const target = normalizePath(path);
    if (meta === target) return true;
    return !!includeSub && target.startsWith(meta === "/" ? "/" : meta + "/");
  };
  const nearestMeta = (state, path) => {
    const target = normalizePath(path);
    return (state.metas || []).filter((meta) => metaCoversPath(meta.path, target, true)).sort((a, b) => b.path.length - a.path.length)[0] || null;
  };
  const validateHideRules = (hide) => {
    for (const line of String(hide || "").split(/\r?\n/)) {
      if (!line.trim()) continue;
    }
  };
  const isHiddenByMeta = (meta, path, name) => {
    if (!meta || !meta.hide || !metaCoversPath(meta.path, path, meta.h_sub)) return false;
    for (const line of String(meta.hide).split(/\r?\n/)) {
      if (!line.trim()) continue;
      try {
        const pattern = new RegExp(line);
        if (pattern.test(name) || pattern.test(path)) return true;
      } catch (_) {
        return false;
      }
    }
    return false;
  };
  const metaReadme = (meta, path) => meta && metaCoversPath(meta.path, path, meta.r_sub) ? meta.readme : "";
  const metaHeader = (meta, path) => meta && metaCoversPath(meta.path, path, meta.header_sub) ? meta.header : "";
  const createFsHandlers = ({
    cloneEntryTree,
    createFile,
    driverRuntime,
    ensureDir,
    getState,
    isWorkspacePath,
    moveEntryTree,
    now,
    page,
    parseJson,
    removeEmptyDirs,
    removeEntry,
    renameEntryInDir,
    saveState: saveState2,
    shareGet,
    shareList,
    siyuanApiJson,
    taskStore,
    toFsGetResp,
    toObjResp,
    workspaceGet,
    workspaceList,
    workspaceRelPath
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const boolValue2 = (value, fallback = false) => {
      if (value === void 0 || value === null || value === "") return fallback;
      return value === true || value === "true" || value === 1 || value === "1";
    };
    const storageShouldProxy = (storage) => {
      var _a;
      const config = ((_a = driverInfoMap()[storage == null ? void 0 : storage.driver]) == null ? void 0 : _a.config) || {};
      return boolValue2(config.only_proxy) || boolValue2(storage == null ? void 0 : storage.web_proxy, boolValue2(config.prefer_proxy));
    };
    const proxyRawUrl = (path) => `/plugin/private/siyuan-cloud/p${normalizePath(path)}`;
    const proxyRawUrlForStorage = (_storage, path) => proxyRawUrl(path);
    return {
      "ANY /api/fs/list": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path);
        const sharing = await shareList({ ...req, path });
        if (sharing == null ? void 0 : sharing.error) return jsonResponse(sharing.error);
        if (sharing == null ? void 0 : sharing.data) return jsonResponse(success(sharing.data));
        if (isWorkspacePath(path)) {
          const result = await workspaceList(path, req);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success(result.data));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            const data = await mount.driver.list(mount.storage, mount.relPath, req);
            return jsonResponse(success(data));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver list failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        const entry = state.entries[path];
        if (!entry || !entry.is_dir) return jsonResponse(failure("directory not found", 404));
        const meta = nearestMeta(getState(), path);
        const children = entry.children.map((childPath) => state.entries[childPath]).filter(Boolean).filter((item) => !isHiddenByMeta(meta, item.path, item.name)).map(toObjResp);
        if (path === "/") {
          children.unshift(toObjResp({
            name: "@workspace",
            is_dir: true,
            size: 0,
            modified: now(),
            created: now()
          }));
          for (const mountEntry of driverRuntime.mountEntries(state.storages, now)) {
            if (!children.some((item) => item.name === mountEntry.name)) children.unshift(toObjResp(mountEntry));
          }
        }
        const content = page(children, req);
        return jsonResponse(success({
          content,
          total: children.length,
          readme: metaReadme(meta, path),
          header: metaHeader(meta, path),
          write: true,
          write_content_bypass: true,
          provider: "siyuan-storage",
          direct_upload_tools: []
        }));
      },
      "ANY /api/fs/get": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path);
        const sharing = await shareGet({ ...req, path });
        if (sharing == null ? void 0 : sharing.error) return jsonResponse(sharing.error);
        if (sharing == null ? void 0 : sharing.data) return jsonResponse(success(sharing.data));
        if (isWorkspacePath(path)) {
          const result = await workspaceGet(path);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success(result.data));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            const shouldProxy = storageShouldProxy(mount.storage);
            const data = await mount.driver.get(mount.storage, mount.relPath, { skipLink: shouldProxy });
            if (data && !data.is_dir && shouldProxy) {
              data.raw_url = proxyRawUrlForStorage(mount.storage, path);
              data.url = data.raw_url;
            }
            return jsonResponse(success(data));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver get failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        const entry = state.entries[path];
        if (!entry) return jsonResponse(failure("object not found", 404));
        const meta = nearestMeta(getState(), path);
        return jsonResponse(success({
          ...toFsGetResp(entry, path),
          readme: metaReadme(meta, path),
          header: metaHeader(meta, path)
        }));
      },
      "ANY /api/fs/dirs": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path);
        if (isWorkspacePath(path)) {
          const result = await workspaceList(path, req);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success(result.data.content.filter((item) => item.is_dir).map((item) => ({
            name: item.name,
            modified: item.modified
          }))));
        }
        const entry = state.entries[path];
        if (!entry || !entry.is_dir) return jsonResponse(failure("directory not found", 404));
        const dirs = entry.children.map((childPath) => state.entries[childPath]).filter((item) => item && item.is_dir).map((item) => ({ name: item.name, modified: item.modified }));
        return jsonResponse(success(dirs));
      },
      "ANY /api/fs/search": async (request) => {
        const req = await parseJson(request);
        const parent = normalizePath(req.parent || req.path || "/");
        const keyword = String(req.keywords || req.keyword || "").toLowerCase();
        if (isWorkspacePath(parent)) {
          const result = await workspaceList(parent, req);
          if (result.error) return jsonResponse(result.error);
          const content = result.data.content.filter((entry) => !keyword || entry.name.toLowerCase().includes(keyword)).map((entry) => ({ parent, ...entry }));
          return jsonResponse(success(pageResp(page(content, req), content.length)));
        }
        const results = Object.values(state.entries).filter((entry) => entry.path !== "/" && entry.path.startsWith(parent) && (!keyword || entry.name.toLowerCase().includes(keyword))).map((entry) => ({ parent: dirname(entry.path), ...toObjResp(entry) }));
        return jsonResponse(success(pageResp(page(results, req), results.length)));
      },
      "POST /api/fs/mkdir": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path || [req.parent, req.name].filter(Boolean).join("/"));
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            await mount.driver.mkdir(mount.storage, mount.relPath);
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver mkdir failed", 502));
          }
        }
        ensureDir(dirname(path));
        ensureDir(path);
        await saveState2();
        return jsonResponse(success());
      },
      "PUT /api/fs/put": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path || req.file_path || req.name || "/untitled.txt");
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            await mount.driver.put(mount.storage, mount.relPath, req.content || req.data || "", req.mime);
            return jsonResponse(success({ path }));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver put failed", 502));
          }
        }
        createFile(path, req.content || req.data || "", req.mime);
        await saveState2();
        return jsonResponse(success({ path }));
      },
      "PUT /api/fs/form": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path || req.file_path || req.name || "/upload.txt");
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            await mount.driver.put(mount.storage, mount.relPath, req.content || req.data || "", req.mime);
            return jsonResponse(success({ path }));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver put failed", 502));
          }
        }
        createFile(path, req.content || req.data || "", req.mime);
        await saveState2();
        return jsonResponse(success({ path }));
      },
      "POST /api/fs/remove": async (request) => {
        const req = await parseJson(request);
        const names = Array.isArray(req.names) ? req.names : [];
        const dir = normalizePath(req.dir || req.path || "/");
        if (!names.length) return jsonResponse(failure("Empty file names", 400));
        if (isWorkspacePath(dir)) {
          for (const name of names) {
            const payload = await siyuanApiJson("/api/file/removeFile", { path: workspaceRelPath(normalizePath(dir + "/" + name)) });
            if (payload.code !== 0 && payload.code !== 404) return jsonResponse(failure(payload.msg || "removeFile failed", payload.code || 500));
          }
          return jsonResponse(success());
        }
        const mount = driverRuntime.resolve(state.storages, dir);
        if (mount) {
          try {
            for (const name of names) {
              await mount.driver.remove(mount.storage, normalizePath(mount.relPath + "/" + name));
            }
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver remove failed", 502));
          }
        }
        for (const name of names) {
          removeEntry(normalizePath(dir + "/" + name));
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/rename": async (request) => {
        const req = await parseJson(request);
        const oldPath = normalizePath(req.path);
        const newName = String(req.name || "").trim();
        if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
        const mount = driverRuntime.resolve(state.storages, oldPath);
        if (mount) {
          try {
            await mount.driver.rename(mount.storage, mount.relPath, newName);
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver rename failed", 502));
          }
        }
        if (isWorkspacePath(oldPath)) {
          const newPath = normalizePath(dirname(oldPath) + "/" + newName);
          const payload = await siyuanApiJson("/api/file/renameFile", {
            path: workspaceRelPath(oldPath),
            newPath: workspaceRelPath(newPath)
          });
          if (payload.code !== 0) return jsonResponse(failure(payload.msg || "renameFile failed", payload.code || 500));
          return jsonResponse(success());
        }
        const entry = state.entries[oldPath];
        if (!entry) return jsonResponse(failure("object not found", 404));
        try {
          renameEntryInDir(dirname(oldPath), entry.name, newName, { overwrite: req.overwrite });
        } catch (error) {
          return jsonResponse(failure(error.message, error.message.includes("exists") ? 403 : 400));
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/move": async (request) => {
        const req = await parseJson(request);
        const names = Array.isArray(req.names) ? req.names : [];
        if (!names.length) return jsonResponse(failure("Empty file names", 400));
        const srcDir = normalizePath(req.src_dir);
        const dstDir = normalizePath(req.dst_dir);
        if (driverRuntime.resolve(state.storages, srcDir) || driverRuntime.resolve(state.storages, dstDir)) {
          return jsonResponse(failure("driver move is not wired for mounted cloud storage yet", 501));
        }
        ensureDir(dstDir);
        for (const name of names) {
          const srcPath = normalizePath(srcDir + "/" + name);
          const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
          if (!state.entries[srcPath]) continue;
          if (!req.overwrite && state.entries[dstPath] && !req.skip_existing) return jsonResponse(failure(`file [${name}] exists`, 403));
          if (state.entries[dstPath]) removeEntry(dstPath);
          moveEntryTree(srcPath, dstPath);
        }
        const task = await taskStore.addTask("move", {
          name: `move ${names.length} item(s)`,
          status: "Move operations completed immediately"
        });
        return jsonResponse(success({ message: "Move operations completed immediately", tasks: [task] }));
      },
      "POST /api/fs/copy": async (request) => {
        const req = await parseJson(request);
        const names = Array.isArray(req.names) ? req.names : [];
        if (!names.length) return jsonResponse(failure("Empty file names", 400));
        const srcDir = normalizePath(req.src_dir);
        const dstDir = normalizePath(req.dst_dir);
        if (driverRuntime.resolve(state.storages, srcDir) || driverRuntime.resolve(state.storages, dstDir)) {
          return jsonResponse(failure("driver copy is not wired for mounted cloud storage yet", 501));
        }
        ensureDir(dstDir);
        for (const name of names) {
          const srcPath = normalizePath(srcDir + "/" + name);
          const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
          if (!state.entries[srcPath]) continue;
          if (!req.overwrite && state.entries[dstPath] && !req.skip_existing && !req.merge) return jsonResponse(failure(`file [${name}] exists`, 403));
          if (state.entries[dstPath] && !req.merge) removeEntry(dstPath);
          cloneEntryTree(srcPath, dstPath);
        }
        const task = await taskStore.addTask("copy", {
          name: `copy ${names.length} item(s)`,
          status: "Copy operations completed immediately"
        });
        return jsonResponse(success({ message: "Copy operations completed immediately", tasks: [task] }));
      },
      "POST /api/fs/batch_rename": async (request) => {
        const req = await parseJson(request);
        const srcDir = normalizePath(req.src_dir || "/");
        const renameObjects = Array.isArray(req.rename_objects) ? req.rename_objects : [];
        if (isWorkspacePath(srcDir)) {
          for (const item of renameObjects) {
            const srcName = String(item.src_name || "").trim();
            const newName = String(item.new_name || "").trim();
            if (!srcName || !newName) continue;
            if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
            const srcPath = normalizePath(srcDir + "/" + srcName);
            const newPath = normalizePath(srcDir + "/" + newName);
            const payload = await siyuanApiJson("/api/file/renameFile", {
              path: workspaceRelPath(srcPath),
              newPath: workspaceRelPath(newPath)
            });
            if (payload.code !== 0) return jsonResponse(failure(payload.msg || "renameFile failed", payload.code || 500));
          }
          return jsonResponse(success());
        }
        for (const item of renameObjects) {
          const srcName = String(item.src_name || "").trim();
          const newName = String(item.new_name || "").trim();
          if (!srcName || !newName) continue;
          try {
            renameEntryInDir(srcDir, srcName, newName, { overwrite: !!req.overwrite });
          } catch (error) {
            return jsonResponse(failure(error.message, error.message.includes("exists") ? 403 : 400));
          }
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/regex_rename": async (request) => {
        const req = await parseJson(request);
        const srcDir = normalizePath(req.src_dir || "/");
        let pattern;
        try {
          pattern = new RegExp(String(req.src_name_regex || ""));
        } catch (error) {
          return jsonResponse(failure(error.message, 400));
        }
        const replacement = String(req.new_name_regex || "");
        if (isWorkspacePath(srcDir)) {
          const result = await workspaceList(srcDir, { page: 1, per_page: 1e5 });
          if (result.error) return jsonResponse(result.error);
          for (const file of result.data.content || []) {
            if (!pattern.test(file.name)) continue;
            pattern.lastIndex = 0;
            const newName = file.name.replace(pattern, replacement);
            if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
            const payload = await siyuanApiJson("/api/file/renameFile", {
              path: workspaceRelPath(normalizePath(srcDir + "/" + file.name)),
              newPath: workspaceRelPath(normalizePath(srcDir + "/" + newName))
            });
            if (payload.code !== 0) return jsonResponse(failure(payload.msg || "renameFile failed", payload.code || 500));
          }
          return jsonResponse(success());
        }
        const dir = state.entries[srcDir];
        if (!dir || !dir.is_dir) return jsonResponse(failure("directory not found", 404));
        for (const childPath of [...dir.children || []]) {
          const entry = state.entries[childPath];
          if (!entry || !pattern.test(entry.name)) continue;
          pattern.lastIndex = 0;
          const newName = entry.name.replace(pattern, replacement);
          try {
            renameEntryInDir(srcDir, entry.name, newName, { overwrite: !!req.overwrite });
          } catch (error) {
            return jsonResponse(failure(error.message, error.message.includes("exists") ? 403 : 400));
          }
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/recursive_move": async (request) => {
        const req = await parseJson(request);
        const srcDir = normalizePath(req.src_dir || "/");
        const dstDir = normalizePath(req.dst_dir || "/");
        const conflictPolicy = String(req.conflict_policy || "skip").toLowerCase();
        if (isWorkspacePath(srcDir) || isWorkspacePath(dstDir)) {
          return jsonResponse(failure("recursive move for /@workspace is not available until workspace upload/move is completed", 501));
        }
        const src = state.entries[srcDir];
        if (!src || !src.is_dir) return jsonResponse(failure("source directory not found", 404));
        ensureDir(dstDir);
        const files = Object.values(state.entries).filter((entry) => entry.path !== srcDir && entry.path.startsWith(srcDir + "/") && !entry.is_dir).sort((a, b) => a.path.localeCompare(b.path));
        let count = 0;
        for (const file of files) {
          const dstPath = normalizePath(dstDir + "/" + file.name);
          if (dirname(file.path) === dstDir) continue;
          if (state.entries[dstPath]) {
            if (conflictPolicy === "cancel") return jsonResponse(failure(`file [${file.name}] exists`, 403));
            if (conflictPolicy === "skip") continue;
            removeEntry(dstPath);
          }
          moveEntryTree(file.path, dstPath);
          count += 1;
        }
        await saveState2();
        return jsonResponse(successWithMessage(`Successfully moved ${count} ${count === 1 ? "file" : "files"}`));
      },
      "POST /api/fs/remove_empty_directory": async (request) => {
        const req = await parseJson(request);
        removeEmptyDirs(normalizePath(req.src_dir || "/"));
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/link": async (request) => {
        const req = await parseJson(request);
        const path = normalizePath(req.path);
        if (isWorkspacePath(path)) {
          const result = await workspaceGet(path);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success({ url: "/plugin/private/siyuan-cloud/d" + path }));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount && mount.driver.read) {
          try {
            const data = await mount.driver.read(mount.storage, mount.relPath, {});
            const link = linkFromDriverData(data);
            return jsonResponse(success({
              url: link.url,
              header: link.header,
              method: link.method,
              content_length: link.content_length,
              raw_url: proxyRawUrlForStorage(mount.storage, path),
              provider: mount.storage.driver
            }));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver link failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        if (!state.entries[path]) return jsonResponse(failure("object not found", 404));
        return jsonResponse(success({ url: "/plugin/private/siyuan-cloud/d" + path }));
      },
      "POST /api/fs/add_offline_download": async (request) => {
        var _a;
        const req = await parseJson(request);
        const task = await taskStore.addTask("offline_download", {
          error: "offline download is not implemented in the SiYuan kernel port yet",
          name: req.url || ((_a = req.urls) == null ? void 0 : _a[0]) || "offline download",
          status: "not implemented"
        });
        return jsonResponse(failure(
          "offline download is not implemented in the SiYuan kernel port yet",
          501,
          { task }
        ), 501);
      },
      "POST /api/fs/get_direct_upload_info": async (request) => {
        const req = await parseJson(request);
        return jsonResponse(success({
          method: "put",
          url: "/plugin/private/siyuan-cloud/api/fs/put",
          headers: {},
          path: normalizePath(req.path || req.file_path || "/"),
          provider: "siyuan-storage",
          note: "Direct upload is folded back to the kernel compatibility /api/fs/put endpoint."
        }));
      },
      "ANY /api/fs/other": async () => jsonResponse(success(null))
    };
  };
  const createAdminHandlers = ({
    driverRuntime,
    getState,
    isWorkspacePath,
    listSettings,
    now,
    pageSlice,
    parseJson,
    queryValue,
    saveState: saveState2,
    saveToolSettings,
    settingItem,
    storageResp,
    workspaceGet
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const storageAddition = (reqAddition, currentAddition = "{}") => {
      if (typeof reqAddition === "string") return reqAddition;
      if (reqAddition !== void 0) return JSON.stringify(reqAddition || {});
      return currentAddition || "{}";
    };
    const exportConfig = () => ({
      version: 1,
      exported_at: (/* @__PURE__ */ new Date()).toISOString(),
      source: "siyuan-cloud",
      settings: { ...state.settings },
      users: state.users.map((user) => ({ ...user })),
      storages: state.storages.map((storage) => ({ ...storage })),
      metas: (state.metas || []).map((meta) => ({ ...meta })),
      sharings: (state.sharings || []).map((share) => ({ ...share }))
    });
    const asArray = (value, fallback = []) => Array.isArray(value) ? value : fallback;
    const boolValue2 = (value, fallback = false) => {
      if (value === void 0 || value === null || value === "") return fallback;
      return value === true || value === "true" || value === 1 || value === "1";
    };
    const driverConfig = (driver) => {
      var _a;
      return ((_a = driverInfoMap()[driver]) == null ? void 0 : _a.config) || {};
    };
    const proxyDefaults = (driver, source = {}) => {
      const config = driverConfig(driver);
      return {
        web_proxy: boolValue2(source.web_proxy, boolValue2(config.prefer_proxy)),
        webdav_policy: source.webdav_policy || (boolValue2(config.prefer_proxy) ? "native_proxy" : "302_redirect"),
        proxy_range: boolValue2(source.proxy_range),
        down_proxy_url: source.down_proxy_url || "",
        disable_proxy_sign: boolValue2(source.disable_proxy_sign)
      };
    };
    const normalizeStorageForImport = (storage, index) => {
      const driver = storage.driver || "SiYuanKernel";
      return {
        id: Number(storage.id || index + 1),
        mount_path: normalizePath(storage.mount_path || storage.mountPath || "/"),
        order: Number(storage.order ?? 0),
        driver,
        cache_expiration: Number(storage.cache_expiration ?? 30),
        custom_cache_policies: storage.custom_cache_policies || "",
        status: storage.status || "work",
        addition: storageAddition(storage.addition),
        remark: storage.remark || "",
        modified: Number(storage.modified || now()),
        disabled: !!storage.disabled,
        ...proxyDefaults(driver, storage)
      };
    };
    return {
      "GET /api/admin/user/list": async () => jsonResponse(success(pageResp(state.users.map((user) => ({ ...user, password: "", otp_secret: "" }))))),
      "GET /api/admin/user/get": async (request) => {
        const id = Number(queryValue(request, "id") || 1);
        const user = state.users.find((item) => item.id === id) || state.users[0];
        return jsonResponse(success({ ...user, password: "", otp_secret: "" }));
      },
      "POST /api/admin/user/update": async (request) => {
        const req = await parseJson(request);
        const index = state.users.findIndex((item) => item.id === Number(req.id));
        if (index < 0) return jsonResponse(failure("user not found", 404));
        state.users[index] = { ...state.users[index], ...req, password: req.password ? "" : state.users[index].password };
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/user/create": async (request) => {
        const req = await parseJson(request);
        if (!req.username) return jsonResponse(failure("username is required", 400));
        if (state.users.some((item) => item.username === req.username)) return jsonResponse(failure("user already exists", 409));
        const id = Math.max(0, ...state.users.map((item) => item.id || 0)) + 1;
        state.users.push({
          id,
          username: req.username,
          password: "",
          role: Number(req.role ?? 0),
          disabled: !!req.disabled,
          base_path: normalizePath(req.base_path || "/"),
          permission: Number(req.permission ?? 0),
          sso_id: req.sso_id || "",
          otp: false,
          otp_secret: ""
        });
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/user/delete": async (request) => {
        const req = await parseJson(request);
        const id = Number(req.id);
        if (id === 1) return jsonResponse(failure("admin user cannot be deleted", 403));
        state.users = state.users.filter((item) => item.id !== id);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/user/cancel_2fa": async (request) => {
        const req = await parseJson(request);
        const user = state.users.find((item) => item.id === Number(req.id));
        if (!user) return jsonResponse(failure("user not found", 404));
        user.otp = false;
        user.otp_secret = "";
        await saveState2();
        return jsonResponse(success());
      },
      "GET /api/admin/storage/list": async (request) => jsonResponse(success(pageSlice(state.storages.map(storageResp), request))),
      "GET /api/admin/storage/get": async (request) => {
        const id = Number(queryValue(request, "id") || 1);
        return jsonResponse(success(storageResp(state.storages.find((item) => item.id === id) || state.storages[0])));
      },
      "POST /api/admin/storage/create": async (request) => {
        const req = await parseJson(request);
        const mountPath = normalizePath(req.mount_path || req.mountPath || "");
        const existing = mountPath && state.storages.find((item) => item.mount_path === mountPath);
        if (existing) {
          const driver2 = req.driver || existing.driver || "SiYuanKernel";
          Object.assign(existing, {
            order: Number(req.order ?? existing.order ?? 0),
            driver: driver2,
            cache_expiration: Number(req.cache_expiration ?? existing.cache_expiration ?? 30),
            custom_cache_policies: req.custom_cache_policies ?? existing.custom_cache_policies ?? "",
            status: req.status || existing.status || "work",
            addition: storageAddition(req.addition, existing.addition),
            remark: req.remark ?? existing.remark ?? "",
            modified: now(),
            disabled: !!req.disabled,
            ...proxyDefaults(driver2, { ...existing, ...req })
          });
          await saveState2();
          return jsonResponse(success({ id: existing.id, updated: true }));
        }
        const id = Math.max(0, ...state.storages.map((item) => item.id || 0)) + 1;
        const driver = req.driver || "SiYuanKernel";
        state.storages.push({
          id,
          mount_path: mountPath || normalizePath("/mount-" + id),
          order: Number(req.order || 0),
          driver,
          cache_expiration: Number(req.cache_expiration ?? 30),
          custom_cache_policies: req.custom_cache_policies || "",
          status: req.status || "work",
          addition: storageAddition(req.addition),
          remark: req.remark || "",
          modified: now(),
          disabled: !!req.disabled,
          ...proxyDefaults(driver, req)
        });
        await saveState2();
        return jsonResponse(success({ id }));
      },
      "POST /api/admin/storage/update": async (request) => {
        const req = await parseJson(request);
        const storage = state.storages.find((item) => item.id === Number(req.id));
        if (!storage) return jsonResponse(failure("storage not found", 404));
        Object.assign(storage, {
          ...req,
          mount_path: req.mount_path ? normalizePath(req.mount_path) : storage.mount_path,
          addition: storageAddition(req.addition, storage.addition),
          cache_expiration: Number(req.cache_expiration ?? storage.cache_expiration ?? 30),
          disabled: !!req.disabled,
          modified: now(),
          ...proxyDefaults(req.driver || storage.driver, { ...storage, ...req })
        });
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/delete": async (request) => {
        const req = await parseJson(request);
        const id = Number(req.id);
        if (id === 1) return jsonResponse(failure("root storage cannot be deleted", 403));
        state.storages = state.storages.filter((item) => item.id !== id);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/enable": async (request) => {
        const req = await parseJson(request);
        const storage = state.storages.find((item) => item.id === Number(req.id));
        if (!storage) return jsonResponse(failure("storage not found", 404));
        storage.disabled = false;
        storage.status = "work";
        storage.modified = now();
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/disable": async (request) => {
        const req = await parseJson(request);
        const storage = state.storages.find((item) => item.id === Number(req.id));
        if (!storage) return jsonResponse(failure("storage not found", 404));
        storage.disabled = true;
        storage.status = "disabled";
        storage.modified = now();
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/load_all": async () => jsonResponse(success()),
      "GET /api/admin/config/export": async () => jsonResponse(success(exportConfig())),
      "POST /api/admin/config/import": async (request) => {
        const req = await parseJson(request);
        const payload = (req == null ? void 0 : req.config) || req;
        const mode = (req == null ? void 0 : req.mode) || "replace";
        if (!payload || typeof payload !== "object") return jsonResponse(failure("config is required", 400));
        if (payload.settings && typeof payload.settings === "object") {
          state.settings = mode === "merge" ? { ...state.settings, ...payload.settings } : { ...defaultSettings(), ...payload.settings };
        }
        if (payload.users) {
          const importedUsers = asArray(payload.users).map((user, index) => ({
            id: Number(user.id || index + 1),
            username: user.username || `user-${index + 1}`,
            password: user.password || "",
            role: Number(user.role ?? 0),
            disabled: !!user.disabled,
            base_path: normalizePath(user.base_path || "/"),
            permission: Number(user.permission ?? 0),
            sso_id: user.sso_id || "",
            otp: !!user.otp,
            otp_secret: user.otp_secret || ""
          }));
          state.users = importedUsers.length ? importedUsers : state.users;
        }
        if (payload.storages) {
          const importedStorages = asArray(payload.storages).map(normalizeStorageForImport);
          if (!importedStorages.some((item) => item.mount_path === "/")) {
            importedStorages.unshift(normalizeStorageForImport({ id: 1, mount_path: "/", driver: "SiYuanKernel", addition: "{}" }, 0));
          }
          state.storages = importedStorages;
        }
        if (payload.metas) state.metas = asArray(payload.metas).map((meta, index) => ({ ...meta, id: Number(meta.id || index + 1) }));
        if (payload.sharings) state.sharings = asArray(payload.sharings).map((share, index) => ({ ...share, id: Number(share.id || index + 1) }));
        await saveState2();
        return jsonResponse(success({
          users: state.users.length,
          storages: state.storages.length,
          metas: state.metas.length,
          sharings: state.sharings.length
        }));
      },
      "GET /api/admin/driver/names": async () => jsonResponse(success(driverNames())),
      "GET /api/admin/driver/list": async () => jsonResponse(success(driverInfoMap())),
      "GET /api/admin/driver/info": async (request) => {
        const driver = queryValue(request, "driver") || "SiYuanKernel";
        const info = driverInfoMap()[driver];
        if (!info) return jsonResponse(failure(`driver [${driver}] not found`, 404));
        return jsonResponse(success(info));
      },
      "POST /api/admin/driver/test": async (request) => {
        var _a;
        const req = await parseJson(request);
        const driver = req.driver || "SiYuanKernel";
        let addition;
        try {
          addition = typeof req.addition === "string" ? JSON.parse(req.addition || "{}") : req.addition || {};
        } catch (error) {
          return jsonResponse(failure(error.message || "invalid addition JSON", 400));
        }
        if (!((_a = driverRuntime == null ? void 0 : driverRuntime.drivers) == null ? void 0 : _a[driver])) return jsonResponse(failure(`driver [${driver}] not found`, 404));
        if (!driverRuntime.drivers[driver].test) return jsonResponse(failure(`driver [${driver}] does not expose a test method yet`, 501));
        try {
          return jsonResponse(success(await driverRuntime.test(driver, addition)));
        } catch (error) {
          return jsonResponse(failure(error.message || "driver test failed", 502, { driver }));
        }
      },
      "GET /api/admin/setting/get": async (request) => {
        const key = queryValue(request, "key");
        const keys = queryValue(request, "keys");
        if (key) return jsonResponse(success(settingItem(key, state.settings[key] || "")));
        return jsonResponse(success(keys.split(",").filter(Boolean).map((item, index) => settingItem(item, state.settings[item] || "", index))));
      },
      "GET /api/admin/setting/list": async (request) => jsonResponse(success(listSettings(request))),
      "POST /api/admin/setting/default": async (request) => jsonResponse(success(listSettings(request, defaultSettings()))),
      "POST /api/admin/setting/save": async (request) => {
        const req = await parseJson(request);
        const items = Array.isArray(req) ? req : [req];
        for (const item of items) {
          if (item && item.key) state.settings[item.key] = String(item.value ?? "");
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/setting/delete": async (request) => {
        const key = queryValue(request, "key") || (await parseJson(request)).key;
        if (key) delete state.settings[key];
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/setting/reset_token": async () => {
        state.settings.token = "siyuan-cloud-token-" + Math.random().toString(36).slice(2);
        await saveState2();
        return jsonResponse(success(state.settings.token));
      },
      "POST /api/admin/setting/set_aria2": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { aria2_uri: "uri", aria2_secret: "secret" }, "siyuan-cloud-aria2-placeholder");
      },
      "POST /api/admin/setting/set_qbit": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { qbittorrent_url: "url", qbittorrent_seedtime: "seedtime" });
      },
      "POST /api/admin/setting/set_transmission": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { transmission_uri: "uri", transmission_seedtime: "seedtime" });
      },
      "POST /api/admin/setting/set_115": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { "115_temp_dir": "temp_dir" });
      },
      "POST /api/admin/setting/set_115_open": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { "115_open_temp_dir": "temp_dir" });
      },
      "POST /api/admin/setting/set_123_pan": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { "123_temp_dir": "temp_dir" });
      },
      "POST /api/admin/setting/set_123_open": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { "123_open_temp_dir": "temp_dir", "123_open_callback_url": "callback_url" });
      },
      "POST /api/admin/setting/set_pikpak": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { pikpak_temp_dir: "temp_dir" });
      },
      "POST /api/admin/setting/set_thunder": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { thunder_temp_dir: "temp_dir" });
      },
      "POST /api/admin/setting/set_thunderx": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { thunderx_temp_dir: "temp_dir" });
      },
      "POST /api/admin/setting/set_thunder_browser": async (request) => {
        const req = await parseJson(request);
        return saveToolSettings(req, { thunder_browser_temp_dir: "temp_dir" });
      }
    };
  };
  const tokenResp = () => ({ token: "siyuan-cloud-port" });
  const createAuthHandlers = ({
    getState,
    parseJson,
    saveState: saveState2
  }) => ({
    "POST /api/auth/login": async () => jsonResponse(success(tokenResp())),
    "POST /api/auth/login/hash": async () => jsonResponse(success(tokenResp())),
    "POST /api/auth/login/ldap": async () => jsonResponse(success(tokenResp())),
    "GET /api/auth/logout": async () => jsonResponse(success()),
    "POST /api/auth/logout": async () => jsonResponse(success()),
    "GET /api/me": async () => {
      const user = { ...getState().users[0], password: "", otp_secret: "" };
      return jsonResponse(success(user));
    },
    "POST /api/me/update": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      state.users[0] = { ...state.users[0], ...req, id: 1, role: 2, password: req.password ? "" : state.users[0].password };
      await saveState2();
      return jsonResponse(success());
    }
  });
  const notImplemented = (name) => jsonResponse(failure(`${name} is not implemented in the SiYuan kernel port yet`, 501));
  const createCompatHandlers = () => ({
    "GET /api/auth/sso": async () => notImplemented("sso login"),
    "GET /api/auth/sso_callback": async () => notImplemented("sso callback"),
    "GET /api/auth/get_sso_id": async () => notImplemented("sso id lookup"),
    "GET /api/auth/sso_get_token": async () => notImplemented("sso token lookup"),
    "GET /api/authn/webauthn_begin_login": async () => notImplemented("webauthn login"),
    "POST /api/authn/webauthn_finish_login": async () => notImplemented("webauthn login"),
    "GET /api/authn/webauthn_begin_registration": async () => notImplemented("webauthn registration"),
    "POST /api/authn/webauthn_finish_registration": async () => notImplemented("webauthn registration"),
    "POST /api/authn/delete_authn": async () => jsonResponse(success()),
    "GET /api/authn/getcredentials": async () => jsonResponse(success([])),
    "POST /api/admin/user/del_cache": async () => jsonResponse(success())
  });
  const progress = (status, message) => ({
    done: status === "done" ? 1 : 0,
    message,
    status,
    total: 1
  });
  const createIndexHandlers = ({
    getState,
    saveState: saveState2
  }) => {
    const setProgress = async (value) => {
      getState().settings.index_progress = JSON.stringify(value);
      await saveState2();
      return jsonResponse(success());
    };
    return {
      "POST /api/admin/index/build": async () => setProgress(progress("done", "Siyuan Cloud virtual index is ready")),
      "POST /api/admin/index/update": async () => setProgress(progress("done", "Siyuan Cloud virtual index is updated")),
      "POST /api/admin/index/stop": async () => setProgress(progress("idle", "index stopped")),
      "POST /api/admin/index/clear": async () => setProgress(progress("idle", "index cleared")),
      "GET /api/admin/index/progress": async () => {
        try {
          return jsonResponse(success(JSON.parse(getState().settings.index_progress || "{}")));
        } catch (_) {
          return jsonResponse(success({}));
        }
      }
    };
  };
  const createMetaHandlers = ({
    getState,
    pageSlice,
    parseJson,
    queryValue,
    saveState: saveState2
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const nextId = () => Math.max(0, ...(state.metas || []).map((item) => item.id || 0)) + 1;
    return {
      "GET /api/admin/meta/list": async (request) => {
        state.metas = state.metas || [];
        return jsonResponse(success(pageSlice([...state.metas].sort((a, b) => a.id - b.id), request)));
      },
      "GET /api/admin/meta/get": async (request) => {
        const id = Number(queryValue(request, "id"));
        const meta = (state.metas || []).find((item) => item.id === id);
        return meta ? jsonResponse(success(meta)) : jsonResponse(failure("meta not found", 404));
      },
      "POST /api/admin/meta/create": async (request) => {
        const req = await parseJson(request);
        try {
          validateHideRules(req.hide);
        } catch (error) {
          return jsonResponse(failure(`${req.hide || ""} is illegal: ${error.message}`, 400));
        }
        state.metas = state.metas || [];
        const meta = normalizeMeta(req, nextId());
        if (state.metas.some((item) => item.path === meta.path)) return jsonResponse(failure("meta path already exists", 409));
        state.metas.push(meta);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/meta/update": async (request) => {
        const req = await parseJson(request);
        try {
          validateHideRules(req.hide);
        } catch (error) {
          return jsonResponse(failure(`${req.hide || ""} is illegal: ${error.message}`, 400));
        }
        state.metas = state.metas || [];
        const index = state.metas.findIndex((item) => item.id === Number(req.id));
        if (index < 0) return jsonResponse(failure("meta not found", 404));
        state.metas[index] = normalizeMeta({ ...state.metas[index], ...req }, state.metas[index].id);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/meta/delete": async (request) => {
        const req = await parseJson(request);
        const id = Number(queryValue(request, "id") || req.id);
        state.metas = (state.metas || []).filter((item) => item.id !== id);
        await saveState2();
        return jsonResponse(success());
      }
    };
  };
  const createMessageHandlers = ({
    getState,
    now,
    parseJson,
    saveState: saveState2
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    return {
      "POST /api/admin/message/get": async () => {
        state.messages = state.messages || [];
        return jsonResponse(success(pageResp([...state.messages].reverse(), state.messages.length)));
      },
      "POST /api/admin/message/send": async (request) => {
        const req = await parseJson(request);
        state.messages = state.messages || [];
        state.messages.push({
          id: `message-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
          title: req.title || req.Title || "",
          content: req.content || req.message || req.Message || "",
          type: req.type || "info",
          created: now()
        });
        await saveState2();
        return jsonResponse(success());
      }
    };
  };
  const createScanHandlers = ({
    getState,
    now,
    saveState: saveState2
  }) => {
    const setScan = async (scan) => {
      getState().scan = {
        updated: now(),
        ...scan
      };
      await saveState2();
      return jsonResponse(success());
    };
    return {
      "POST /api/admin/scan/start": async () => setScan({ status: "done", total: 1, done: 1 }),
      "POST /api/admin/scan/stop": async () => setScan({ status: "idle", total: 0, done: 0 }),
      "GET /api/admin/scan/progress": async () => jsonResponse(success(getState().scan || { status: "idle", total: 0, done: 0 }))
    };
  };
  const createSecurityHandlers = ({
    getState,
    now,
    parseJson,
    queryValue,
    saveState: saveState2
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const publicKeysForUser = (userId) => (state.ssh_keys || []).filter((item) => item.user_id === userId);
    const addKey = async (request, userId) => {
      const req = await parseJson(request);
      state.ssh_keys = state.ssh_keys || [];
      const id = Math.max(0, ...state.ssh_keys.map((item) => item.id || 0)) + 1;
      state.ssh_keys.push({
        id,
        user_id: Number(req.user_id || userId),
        title: req.title || req.name || `key-${id}`,
        key: req.key || req.public_key || "",
        created: now()
      });
      await saveState2();
      return jsonResponse(success({ id }));
    };
    const deleteKey = async (request, userId) => {
      const req = await parseJson(request);
      const id = Number(queryValue(request, "id") || req.id);
      state.ssh_keys = (state.ssh_keys || []).filter((item) => item.id !== id || userId && item.user_id !== userId);
      await saveState2();
      return jsonResponse(success());
    };
    return {
      "GET /api/me/sshkey/list": async () => jsonResponse(success(publicKeysForUser(1))),
      "POST /api/me/sshkey/add": async (request) => addKey(request, 1),
      "POST /api/me/sshkey/delete": async (request) => deleteKey(request, 1),
      "GET /api/admin/user/sshkey/list": async (request) => {
        const userId = Number(queryValue(request, "user_id") || queryValue(request, "id") || 1);
        return jsonResponse(success(publicKeysForUser(userId)));
      },
      "POST /api/admin/user/sshkey/delete": async (request) => deleteKey(request, 0),
      "POST /api/auth/2fa/generate": async () => {
        const user = state.users[0];
        if (!user) return jsonResponse(failure("user not found", 404));
        user.otp_secret = `siyuan-cloud-${Math.random().toString(36).slice(2, 12)}`;
        await saveState2();
        return jsonResponse(success({
          otp_secret: user.otp_secret,
          qr: ""
        }));
      },
      "POST /api/auth/2fa/verify": async () => {
        const user = state.users[0];
        if (!user) return jsonResponse(failure("user not found", 404));
        user.otp = true;
        await saveState2();
        return jsonResponse(success());
      }
    };
  };
  const acceptedArchiveExtensions = () => [
    "zip",
    "tar",
    "gz",
    "tgz",
    "7z",
    "rar",
    "iso"
  ];
  const archiveNotImplemented = (operation) => ({
    operation,
    reason: "SiYuan kernel JavaScript runtime has no archive reader wired yet.",
    upstream_source: "server/handles/archive.go + internal/op/archive.go + internal/archive/*",
    next: "Port a JS archive reader or expose a kernel-side archive primitive before enabling this route."
  });
  const createArchiveHandlers = ({ parseJson, taskStore }) => ({
    "ANY /api/fs/archive/meta": async () => jsonResponse(failure(
      "archive preview is not implemented in the SiYuan kernel port yet",
      501,
      archiveNotImplemented("meta")
    ), 501),
    "ANY /api/fs/archive/list": async () => jsonResponse(failure(
      "archive preview is not implemented in the SiYuan kernel port yet",
      501,
      archiveNotImplemented("list")
    ), 501),
    "POST /api/fs/archive/decompress": async (request) => {
      const req = await parseJson(request);
      const task = await taskStore.addTask("decompress", {
        error: "archive decompress is not implemented in the SiYuan kernel port yet",
        name: req.src_path || req.path || "archive decompress",
        status: "not implemented"
      });
      return jsonResponse(failure(
        "archive decompress is not implemented in the SiYuan kernel port yet",
        501,
        { ...archiveNotImplemented("decompress"), task }
      ), 501);
    }
  });
  const createPublicHandlers = ({
    getState,
    settingItem
  }) => {
    const publicSettings = () => {
      const result = {};
      for (const [key, value] of Object.entries(getState().settings)) {
        const item = settingItem(key, value, 0);
        if (item.flag !== SETTING_FLAG.PRIVATE) result[key] = item.value;
      }
      result.version = OPENLIST_VERSION;
      return result;
    };
    return {
      "ANY /api/public/settings": async () => jsonResponse(success(publicSettings())),
      "ANY /api/public/offline_download_tools": async () => jsonResponse(success([])),
      "ANY /api/public/archive_extensions": async () => jsonResponse(success(acceptedArchiveExtensions()))
    };
  };
  const createStatusHandlers = ({
    client,
    getState,
    handlersRef
  }) => {
    const getSyncInfo = async () => {
      let syncignore = "";
      try {
        const response = await client.fetch("/api/file/getFile", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ path: ".siyuan/syncignore" })
        });
        if (response.ok) syncignore = await response.text();
      } catch (_) {
        syncignore = "";
      }
      const lines = syncignore.replace(/\r\n/g, "\n").split("\n").map((line) => line.trim()).filter((line) => line && !line.startsWith("#"));
      const storagePath = "/storage/petal/siyuan-cloud/siyuan-cloud/state.json";
      const ignored = lines.some((line) => line === "/storage/petal/**/*" || line === "/storage/petal/**" || line === "/storage/petal/siyuan-cloud/**/*" || line === "/storage/petal/siyuan-cloud/**" || line === storagePath);
      return {
        persistent: true,
        syncable_by_default: true,
        ignored_by_syncignore: ignored,
        state_file: storagePath,
        source: "kernel/plugin/plugin.go + kernel/model/repository.go + kernel/model/sync.go"
      };
    };
    return {
      "GET /ping": async () => textResponse("pong"),
      "ANY /ping": async () => textResponse("pong"),
      "GET /siyuan-cloud/status": async () => {
        const state = getState();
        const handlers = handlersRef();
        return jsonResponse(success({
          ok: true,
          version: OPENLIST_VERSION,
          users: state.users.length,
          entries: Object.keys(state.entries).length,
          storages: state.storages.length,
          sharings: state.sharings.length,
          adapters: ["siyuan-storage", "siyuan-workspace", "onedrive", "123pan", "baidu_netdisk"],
          storage: await getSyncInfo(),
          routes: Object.keys(handlers).sort(),
          stages: [
            { key: "kernel", status: "done" },
            { key: "auth", status: "done" },
            { key: "fs", status: "done" },
            { key: "admin", status: "done" },
            { key: "meta", status: "done" },
            { key: "security", status: "active" },
            { key: "share", status: "done" },
            { key: "task", status: "active" },
            { key: "real-adapter", status: "active" },
            { key: "webdav", status: "active" },
            { key: "s3", status: "active" }
          ]
        }));
      }
    };
  };
  const shareResp = (share) => ({
    id: share.id,
    sid: share.sid,
    path: share.path,
    password: share.password || "",
    expires: share.expires || "",
    disabled: !!share.disabled,
    remark: share.remark || "",
    readme: share.readme || "",
    header: share.header || "",
    created: share.created,
    modified: share.modified
  });
  const validShare = (share, password2) => {
    if (!share || share.disabled) return false;
    if (share.password && share.password !== password2) return false;
    if (share.expires && !Number.isNaN(Date.parse(share.expires)) && Date.parse(share.expires) < Date.now()) return false;
    return true;
  };
  const sharePathInfo = ({ path, password: password2, state }) => {
    const normalized = normalizePath(path);
    const [sid, ...innerParts] = normalized.replace(/^\/+/, "").split("/");
    if (!sid) return null;
    const share = state.sharings.find((item) => item.sid === sid);
    if (!validShare(share, password2)) return null;
    const inner = normalizePath("/" + innerParts.join("/"));
    const targetPath = inner === "/" ? normalizePath(share.path) : normalizePath(share.path + "/" + inner.replace(/^\/+/, ""));
    return { inner, share, targetPath };
  };
  const createShareReader = ({
    getState,
    isWorkspacePath,
    page,
    toFsGetResp,
    toObjResp,
    workspaceGet,
    workspaceList
  }) => {
    const shareList = async (req) => {
      const state = getState();
      const info = sharePathInfo({ path: req.path, password: req.password || req.pwd, state });
      if (!info) return null;
      if (isWorkspacePath(info.targetPath)) {
        const result = await workspaceList(info.targetPath, req);
        if (result.error) return { error: result.error };
        return {
          data: {
            ...result.data,
            readme: info.share.readme || "",
            header: info.share.header || "",
            write: false
          }
        };
      }
      const entry = state.entries[info.targetPath];
      if (!entry) return { error: failure("object not found", 404) };
      const children = entry.is_dir ? (entry.children || []).map((childPath) => state.entries[childPath]).filter(Boolean).map(toObjResp) : [toObjResp(entry)];
      return {
        data: {
          content: page(children, req),
          total: children.length,
          readme: info.share.readme || "",
          header: info.share.header || "",
          write: false,
          write_content_bypass: false,
          provider: "sharing",
          direct_upload_tools: []
        }
      };
    };
    const shareGet = async (req) => {
      const state = getState();
      const info = sharePathInfo({ path: req.path, password: req.password || req.pwd, state });
      if (!info) return null;
      if (isWorkspacePath(info.targetPath)) {
        const result = await workspaceGet(info.targetPath);
        if (result.error) return { error: result.error };
        return {
          data: {
            ...result.data,
            readme: info.share.readme || "",
            header: info.share.header || "",
            provider: "sharing"
          }
        };
      }
      const entry = state.entries[info.targetPath];
      if (!entry) return { error: failure("object not found", 404) };
      return {
        data: {
          ...toFsGetResp(entry, info.targetPath),
          readme: info.share.readme || "",
          header: info.share.header || "",
          provider: "sharing"
        }
      };
    };
    return { shareGet, shareList };
  };
  const createShareHandlers = ({
    getState,
    isWorkspacePath,
    now,
    page,
    parseJson,
    queryValue,
    saveState: saveState2,
    workspaceGet
  }) => ({
    "ANY /api/share/list": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const content = page(state.sharings.map(shareResp), req);
      return jsonResponse(success(pageResp(content, state.sharings.length)));
    },
    "GET /api/share/get": async (request) => {
      const state = getState();
      const id = Number(queryValue(request, "id"));
      const sid = queryValue(request, "sid");
      const share = state.sharings.find((item) => item.id === id || item.sid === sid);
      if (!share) return jsonResponse(failure("share not found", 404));
      return jsonResponse(success(shareResp(share)));
    },
    "POST /api/share/create": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const path = normalizePath(req.path);
      if (isWorkspacePath(path)) {
        const result = await workspaceGet(path);
        if (result.error) return jsonResponse(result.error);
      } else if (!state.entries[path]) {
        return jsonResponse(failure("object not found", 404));
      }
      const id = Math.max(0, ...state.sharings.map((item) => item.id || 0)) + 1;
      const share = {
        id,
        sid: req.sid || Math.random().toString(36).slice(2, 10),
        path,
        password: req.password || "",
        expires: req.expires || "",
        disabled: !!req.disabled,
        remark: req.remark || "",
        readme: req.readme || "",
        header: req.header || "",
        created: now(),
        modified: now()
      };
      state.sharings.push(share);
      await saveState2();
      return jsonResponse(success(shareResp(share)));
    },
    "POST /api/share/update": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const share = state.sharings.find((item) => item.id === Number(req.id) || item.sid === req.sid);
      if (!share) return jsonResponse(failure("share not found", 404));
      Object.assign(share, {
        path: req.path ? normalizePath(req.path) : share.path,
        password: req.password ?? share.password,
        expires: req.expires ?? share.expires,
        disabled: req.disabled ?? share.disabled,
        remark: req.remark ?? share.remark,
        readme: req.readme ?? share.readme,
        header: req.header ?? share.header,
        modified: now()
      });
      await saveState2();
      return jsonResponse(success(shareResp(share)));
    },
    "POST /api/share/delete": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const ids = Array.isArray(req.ids) ? req.ids.map(Number) : [Number(req.id)];
      state.sharings = state.sharings.filter((item) => !ids.includes(item.id));
      await saveState2();
      return jsonResponse(success());
    },
    "POST /api/share/enable": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const share = state.sharings.find((item) => item.id === Number(req.id) || item.sid === req.sid);
      if (!share) return jsonResponse(failure("share not found", 404));
      share.disabled = false;
      share.modified = now();
      await saveState2();
      return jsonResponse(success());
    },
    "POST /api/share/disable": async (request) => {
      const req = await parseJson(request);
      const state = getState();
      const share = state.sharings.find((item) => item.id === Number(req.id) || item.sid === req.sid);
      if (!share) return jsonResponse(failure("share not found", 404));
      share.disabled = true;
      share.modified = now();
      await saveState2();
      return jsonResponse(success());
    }
  });
  const PROXY_IGNORE_HEADERS = [
    "authorization",
    "connection",
    "host",
    "proxy-authorization",
    "proxy-connection",
    "referer",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade"
  ];
  const processHeader = (origin = {}, override = {}) => {
    const result = {};
    for (const [key, value] of Object.entries(origin || {})) {
      if (PROXY_IGNORE_HEADERS.includes(String(key).toLowerCase())) continue;
      result[key] = Array.isArray(value) ? value.map(String) : [String(value)];
    }
    for (const [key, value] of Object.entries(override || {})) {
      if (value === void 0 || value === null || value === "") continue;
      result[key] = Array.isArray(value) ? value.map(String) : [String(value)];
    }
    return result;
  };
  const requestHeader = (request) => {
    const requestMeta = (request == null ? void 0 : request.request) || (request == null ? void 0 : request.Request) || {};
    return requestMeta.headers || requestMeta.Headers || {};
  };
  const proxy = (_ctx, link, file, _proxyRange) => {
    return proxyResponse(link.url, processHeader((file == null ? void 0 : file.request_header) || {}, link.header), link.method || "GET");
  };
  const proxyReadOptions = (request) => {
    return {
      headers: {},
      proxyHeaders: {},
      requestHeaders: requestHeader(request)
    };
  };
  const createRouter = ({
    getState,
    handleWebDav,
    handleS3,
    handlers,
    isWorkspacePath,
    pick,
    queryValue,
    readFileResponse: externalReadFileResponse,
    requestPath,
    warn,
    workspaceReadText
  }) => {
    const fallbackReadFileResponse = async (filePath) => {
      const state = getState();
      if (isWorkspacePath(filePath)) {
        const file = await workspaceReadText(filePath);
        if (!file.ok) return textResponse(file.text || "not found", file.status || 404);
        return textResponse(file.text, 200, file.contentType);
      }
      const entry = state.entries[filePath];
      if (!entry || entry.is_dir) return textResponse("not found", 404);
      return textResponse(entry.content || "", 200, entry.mime || "application/octet-stream");
    };
    const readFileResponse = externalReadFileResponse || fallbackReadFileResponse;
    const dispatch = async (request) => {
      const requestMeta = pick(request, "request", "Request");
      const method = String(pick(requestMeta, "method", "Method") || "GET").toUpperCase();
      const path = requestPath(request);
      const key = method + " " + path;
      const anyKey = "ANY " + path;
      const handler = handlers[key] || handlers[anyKey];
      if (handler) return handler(request);
      if (path === "/" || path === "/@manage") {
        return jsonResponse(success({
          name: "Siyuan Cloud",
          version: OPENLIST_VERSION,
          message: "OpenList compatibility layer is running.",
          private_base: "/plugin/private/siyuan-cloud",
          routes: Object.keys(handlers).sort()
        }));
      }
      if (path === "/dav" || path.startsWith("/dav/")) {
        return handleWebDav(request);
      }
      if (path === "/s3" || path.startsWith("/s3/")) {
        return handleS3(request);
      }
      if (path.startsWith("/sd/")) {
        const sharePath = normalizePath(path.replace(/^\/sd/, ""));
        const info = sharePathInfo({ path: sharePath, password: queryValue(request, "pwd"), state: getState() });
        if (!info) return textResponse("the share does not exist or password is wrong", 404);
        return readFileResponse(info.targetPath, request);
      }
      if (path.startsWith("/d/") || path.startsWith("/p/")) {
        return readFileResponse(normalizePath(path.replace(/^\/[dp]/, "")), request);
      }
      if (path.startsWith("/ad/") || path.startsWith("/ap/") || path.startsWith("/ae/")) {
        return textResponse("archive download is not implemented in the SiYuan kernel port yet", 501);
      }
      return jsonResponse(failure("route not implemented: " + key, 404), 404);
    };
    return async (request) => {
      try {
        return await dispatch(request);
      } catch (error) {
        await warn("request failed", String(error && error.stack || error));
        return jsonResponse(failure(String(error && error.message || error), 500), 500);
      }
    };
  };
  const DEFAULT_BUCKET = "siyuan-cloud";
  const escapeXml$1 = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const xmlResponse = (xml, statusCode = 200) => textResponse(xml, statusCode, "application/xml; charset=utf-8");
  const s3PathParts = (path) => {
    const clean = path.replace(/^\/s3\/?/, "").replace(/^\/+/, "");
    const [bucket, ...objectParts] = clean.split("/").filter(Boolean);
    return {
      bucket: bucket || "",
      object: objectParts.join("/")
    };
  };
  const requestBodyText = async (requestMeta) => {
    const body = requestMeta.body || requestMeta.Body || {};
    if (body.data !== void 0 && body.data !== null) {
      if (typeof body.data === "string") return body.data;
      if (typeof body.data.text === "function") return body.data.text();
      if (body.data instanceof ArrayBuffer) return String.fromCharCode(...new Uint8Array(body.data));
      if (typeof body.data === "object") return JSON.stringify(body.data);
    }
    if (body.string && Array.isArray(body.string.values)) return body.string.values.join("");
    return "";
  };
  const headerValue = (requestMeta, name) => {
    const headers = requestMeta.headers || requestMeta.Headers || {};
    const lower = name.toLowerCase();
    for (const [key, value] of Object.entries(headers)) {
      if (String(key).toLowerCase() !== lower) continue;
      if (Array.isArray(value)) return value[0] || "";
      return String(value || "");
    }
    return "";
  };
  const objectPath = (object) => normalizePath("/" + object);
  const listBucketsXml = () => xmlResponse([
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<ListAllMyBucketsResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
    `<Owner><ID>siyuan-cloud</ID><DisplayName>Siyuan Cloud</DisplayName></Owner>`,
    `<Buckets><Bucket><Name>${DEFAULT_BUCKET}</Name><CreationDate>${(/* @__PURE__ */ new Date()).toISOString()}</CreationDate></Bucket></Buckets>`,
    `</ListAllMyBucketsResult>`
  ].join(""));
  const errorXml = (code, message, statusCode) => xmlResponse([
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<Error><Code>${escapeXml$1(code)}</Code><Message>${escapeXml$1(message)}</Message></Error>`
  ].join(""), statusCode);
  const createS3Server = ({
    cloneEntryTree,
    createFile,
    ensureDir,
    getState,
    removeEntry,
    requestPath,
    saveState: saveState2
  }) => {
    const listBucketXml = (bucket, options) => {
      const state = getState();
      const normalizedPrefix = String(options.prefix || "").replace(/^\/+/, "");
      const delimiter = options.delimiter || "";
      const maxKeys = Math.max(1, Number(options.maxKeys));
      const allObjects = Object.values(state.entries).filter((entry) => entry.path !== "/" && !entry.is_dir).map((entry) => ({
        key: entry.path.replace(/^\//, ""),
        entry
      })).filter((item) => !normalizedPrefix || item.key.startsWith(normalizedPrefix)).sort((a, b) => a.key.localeCompare(b.key));
      const commonPrefixes = /* @__PURE__ */ new Set();
      const contents = [];
      for (const item of allObjects) {
        const rest = item.key.slice(normalizedPrefix.length);
        if (delimiter && rest.includes(delimiter)) {
          commonPrefixes.add(normalizedPrefix + rest.slice(0, rest.indexOf(delimiter) + delimiter.length));
          continue;
        }
        contents.push(item);
      }
      const contentXml = contents.slice(0, maxKeys).map(({ key, entry }) => [
        `<Contents>`,
        `<Key>${escapeXml$1(key)}</Key>`,
        `<LastModified>${escapeXml$1(entry.modified || (/* @__PURE__ */ new Date()).toISOString())}</LastModified>`,
        `<ETag>"${escapeXml$1(String(entry.size || 0))}"</ETag>`,
        `<Size>${Number(entry.size || 0)}</Size>`,
        `<StorageClass>STANDARD</StorageClass>`,
        `</Contents>`
      ].join("")).join("");
      const prefixXml = [...commonPrefixes].sort((a, b) => a.localeCompare(b)).slice(0, maxKeys).map((prefix) => `<CommonPrefixes><Prefix>${escapeXml$1(prefix)}</Prefix></CommonPrefixes>`).join("");
      return xmlResponse([
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<ListBucketResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
        `<Name>${escapeXml$1(bucket)}</Name>`,
        `<Prefix>${escapeXml$1(normalizedPrefix)}</Prefix>`,
        `<Delimiter>${escapeXml$1(delimiter)}</Delimiter>`,
        `<Marker></Marker><MaxKeys>${maxKeys}</MaxKeys><IsTruncated>false</IsTruncated>`,
        contentXml,
        prefixXml,
        `</ListBucketResult>`
      ].join(""));
    };
    const objectResponse = (entry, headOnly = false) => {
      const response = textResponse(headOnly ? "" : entry.content || "", 200, entry.mime || "application/octet-stream");
      response.headers["Content-Length"] = [String(entry.size || 0)];
      response.headers.ETag = [`"${entry.size || 0}"`];
      response.headers["Last-Modified"] = [new Date(entry.modified || Date.now()).toUTCString()];
      return response;
    };
    const copySource = (requestMeta) => {
      const raw = decodeURIComponent(headerValue(requestMeta, "x-amz-copy-source").replace(/^\/+/, ""));
      if (!raw) return null;
      const [bucket, ...objectParts] = raw.split("/");
      if (bucket !== DEFAULT_BUCKET) return null;
      return objectPath(objectParts.join("/"));
    };
    const copyResultXml = () => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<CopyObjectResult>`,
      `<LastModified>${(/* @__PURE__ */ new Date()).toISOString()}</LastModified>`,
      `<ETag>"0"</ETag>`,
      `</CopyObjectResult>`
    ].join(""));
    const multiDeleteXml = (objects) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<DeleteResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      ...objects.map((key) => `<Deleted><Key>${escapeXml$1(key)}</Key></Deleted>`),
      `</DeleteResult>`
    ].join(""));
    const parseDeleteObjects = async (requestMeta) => {
      const text2 = await requestBodyText(requestMeta);
      return [...text2.matchAll(/<Key>([^<]+)<\/Key>/g)].map((match) => match[1]);
    };
    const ensureMultipartState = () => {
      const state = getState();
      state.s3_multipart_uploads = state.s3_multipart_uploads || {};
      return state.s3_multipart_uploads;
    };
    const initiateMultipartXml = (bucket, object, uploadId) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<InitiateMultipartUploadResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      `<Bucket>${escapeXml$1(bucket)}</Bucket><Key>${escapeXml$1(object)}</Key><UploadId>${escapeXml$1(uploadId)}</UploadId>`,
      `</InitiateMultipartUploadResult>`
    ].join(""));
    const completeMultipartXml = (bucket, object, entry) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<CompleteMultipartUploadResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      `<Location>/s3/${escapeXml$1(bucket)}/${escapeXml$1(object)}</Location>`,
      `<Bucket>${escapeXml$1(bucket)}</Bucket><Key>${escapeXml$1(object)}</Key><ETag>"${escapeXml$1(String((entry == null ? void 0 : entry.size) || 0))}"</ETag>`,
      `</CompleteMultipartUploadResult>`
    ].join(""));
    const listMultipartXml = (bucket, object, uploadId, upload) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<ListPartsResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      `<Bucket>${escapeXml$1(bucket)}</Bucket><Key>${escapeXml$1(object)}</Key><UploadId>${escapeXml$1(uploadId)}</UploadId>`,
      ...Object.entries((upload == null ? void 0 : upload.parts) || {}).sort(([a], [b]) => Number(a) - Number(b)).map(([partNumber, part]) => `<Part><PartNumber>${Number(partNumber)}</PartNumber><ETag>"${part.size}"</ETag><Size>${part.size}</Size></Part>`),
      `</ListPartsResult>`
    ].join(""));
    const listMultipartUploadsXml = (bucket, uploads, options = {}) => {
      const prefix = String(options.prefix || "").replace(/^\/+/, "");
      const uploadXml = Object.entries(uploads).filter(([, upload]) => upload.bucket === bucket && (!prefix || upload.object.startsWith(prefix))).sort(([, a], [, b]) => String(a.object).localeCompare(String(b.object))).map(([uploadId, upload]) => [
        `<Upload>`,
        `<Key>${escapeXml$1(upload.object)}</Key>`,
        `<UploadId>${escapeXml$1(uploadId)}</UploadId>`,
        `<Initiator><ID>siyuan-cloud</ID><DisplayName>Siyuan Cloud</DisplayName></Initiator>`,
        `<Owner><ID>siyuan-cloud</ID><DisplayName>Siyuan Cloud</DisplayName></Owner>`,
        `<StorageClass>STANDARD</StorageClass>`,
        `<Initiated>${escapeXml$1(upload.started || (/* @__PURE__ */ new Date()).toISOString())}</Initiated>`,
        `</Upload>`
      ].join("")).join("");
      return xmlResponse([
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<ListMultipartUploadsResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
        `<Bucket>${escapeXml$1(bucket)}</Bucket>`,
        `<KeyMarker></KeyMarker><UploadIdMarker></UploadIdMarker>`,
        `<NextKeyMarker></NextKeyMarker><NextUploadIdMarker></NextUploadIdMarker>`,
        `<Prefix>${escapeXml$1(prefix)}</Prefix><Delimiter></Delimiter>`,
        `<MaxUploads>1000</MaxUploads><IsTruncated>false</IsTruncated>`,
        uploadXml,
        `</ListMultipartUploadsResult>`
      ].join(""));
    };
    return async (request) => {
      var _a;
      const requestMeta = request.request || request.Request || {};
      const method = String(requestMeta.method || requestMeta.Method || "GET").toUpperCase();
      const path = requestPath(request);
      const { bucket, object } = s3PathParts(path);
      if (method === "OPTIONS") {
        const response = textResponse("", 204);
        response.headers.Allow = ["OPTIONS, GET, HEAD, PUT, DELETE"];
        return response;
      }
      if (!bucket) {
        if (method === "GET" || method === "HEAD") return listBucketsXml();
        return errorXml("MethodNotAllowed", "method not allowed", 405);
      }
      if (bucket !== DEFAULT_BUCKET) return errorXml("NoSuchBucket", "bucket does not exist", 404);
      if (!object) {
        if (method === "POST") {
          const requestUrl2 = request.url || request.URL || {};
          const query2 = requestUrl2.query || requestUrl2.Query || "";
          if (new URLSearchParams(query2).has("delete")) {
            const objects = await parseDeleteObjects(requestMeta);
            for (const key of objects) removeEntry(objectPath(key));
            await saveState2();
            return multiDeleteXml(objects);
          }
        }
        if (method === "GET" || method === "HEAD") {
          const requestUrl2 = request.url || request.URL || {};
          const query2 = requestUrl2.query || requestUrl2.Query || "";
          const params2 = new URLSearchParams(query2);
          if (params2.has("uploads")) {
            return listMultipartUploadsXml(bucket, ensureMultipartState(), {
              prefix: params2.get("prefix") || ""
            });
          }
          return listBucketXml(bucket, {
            delimiter: params2.get("delimiter") || "",
            maxKeys: params2.get("max-keys") || params2.get("maxKeys") || 1e3,
            prefix: params2.get("prefix") || ""
          });
        }
        if (method === "PUT") return textResponse("", 200);
        if (method === "DELETE") return textResponse("", 204);
        return errorXml("MethodNotAllowed", "method not allowed", 405);
      }
      const fsPath = objectPath(object);
      const state = getState();
      const entry = state.entries[fsPath];
      const requestUrl = request.url || request.URL || {};
      const query = requestUrl.query || requestUrl.Query || "";
      const params = new URLSearchParams(query);
      if (method === "GET" || method === "HEAD") {
        if (params.has("uploadId")) {
          const uploadId = params.get("uploadId");
          const upload = ensureMultipartState()[uploadId];
          if (!upload) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
          return listMultipartXml(bucket, object, params.get("uploadId"), upload);
        }
        if (!entry || entry.is_dir) return errorXml("NoSuchKey", "object does not exist", 404);
        return objectResponse(entry, method === "HEAD");
      }
      if (method === "POST" && params.has("uploads")) {
        const uploadId = `upload-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
        ensureMultipartState()[uploadId] = { bucket, object, parts: {}, started: (/* @__PURE__ */ new Date()).toISOString() };
        await saveState2();
        return initiateMultipartXml(bucket, object, uploadId);
      }
      if (method === "POST" && params.has("uploadId")) {
        const uploadId = params.get("uploadId");
        const uploads = ensureMultipartState();
        const upload = uploads[uploadId];
        if (!upload) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
        const content = Object.entries(upload.parts || {}).sort(([a], [b]) => Number(a) - Number(b)).map(([, part]) => part.content || "").join("");
        ensureDir(dirname(fsPath));
        createFile(fsPath, content, "application/octet-stream");
        delete uploads[uploadId];
        await saveState2();
        return completeMultipartXml(bucket, object, getState().entries[fsPath]);
      }
      if (method === "PUT") {
        if (params.has("uploadId") && params.has("partNumber")) {
          const upload = ensureMultipartState()[params.get("uploadId")];
          if (!upload) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
          const content = await requestBodyText(requestMeta);
          upload.parts[String(params.get("partNumber"))] = {
            content,
            size: content.length
          };
          await saveState2();
          const response2 = textResponse("", 200);
          response2.headers.ETag = [`"${content.length}"`];
          return response2;
        }
        const srcPath = copySource(requestMeta);
        if (srcPath) {
          if (!state.entries[srcPath]) return errorXml("NoSuchKey", "copy source does not exist", 404);
          ensureDir(dirname(fsPath));
          cloneEntryTree(srcPath, fsPath);
          await saveState2();
          return copyResultXml();
        }
        const isDir2 = object.endsWith("/");
        if (isDir2) {
          ensureDir(fsPath);
        } else {
          ensureDir(dirname(fsPath));
          createFile(fsPath, await requestBodyText(requestMeta), headerValue(requestMeta, "Content-Type") || "application/octet-stream");
        }
        await saveState2();
        const response = textResponse("", 200);
        response.headers.ETag = [`"${((_a = getState().entries[fsPath]) == null ? void 0 : _a.size) || 0}"`];
        return response;
      }
      if (method === "DELETE") {
        if (params.has("uploadId")) {
          const uploadId = params.get("uploadId");
          const uploads = ensureMultipartState();
          if (!uploads[uploadId]) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
          delete uploads[uploadId];
          await saveState2();
          return textResponse("", 204);
        }
        removeEntry(fsPath);
        await saveState2();
        return textResponse("", 204);
      }
      return errorXml("MethodNotAllowed", "method not allowed", 405);
    };
  };
  const escapeXml = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const webdavPath = (path) => normalizePath(path.replace(/^\/dav\/?/, "/"));
  const propResponse = ({ href, item }) => {
    const collection = item.is_dir ? "<D:resourcetype><D:collection/></D:resourcetype>" : "<D:resourcetype/>";
    const length = item.is_dir ? "" : `<D:getcontentlength>${Number(item.size || 0)}</D:getcontentlength>`;
    return [
      "<D:response>",
      `<D:href>${escapeXml(href)}</D:href>`,
      "<D:propstat><D:prop>",
      `<D:displayname>${escapeXml(item.name || "")}</D:displayname>`,
      collection,
      length,
      `<D:getlastmodified>${escapeXml(new Date(item.modified || Date.now()).toUTCString())}</D:getlastmodified>`,
      "</D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat>",
      "</D:response>"
    ].join("");
  };
  const createWebDavServer = ({
    getState,
    cloneEntryTree,
    createFile,
    ensureDir,
    isWorkspacePath,
    moveEntryTree,
    readFileResponse,
    removeEntry,
    requestPath,
    saveState: saveState2,
    toObjResp,
    workspaceGet,
    workspaceList
  }) => {
    const listVirtual = (path) => {
      const state = getState();
      const entry = state.entries[path];
      if (!entry || !entry.is_dir) return null;
      const items = entry.children.map((childPath) => state.entries[childPath]).filter(Boolean);
      if (path === "/") {
        items.unshift({
          name: "@workspace",
          is_dir: true,
          size: 0,
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      return { entry, items };
    };
    const getVirtual = (path) => {
      const state = getState();
      if (path === "/") {
        return { name: "", is_dir: true, size: 0, modified: (/* @__PURE__ */ new Date()).toISOString() };
      }
      return state.entries[path] || null;
    };
    const propfind = async (request, path) => {
      var _a, _b;
      const fsPath = webdavPath(path);
      let current;
      let children = [];
      if (isWorkspacePath(fsPath)) {
        const got = await workspaceGet(fsPath);
        if (got.error) return textResponse("", got.error.code || 404);
        current = got.data;
        if (current.is_dir) {
          const listed = await workspaceList(fsPath, { page: 1, per_page: 1e5 });
          if (!listed.error) children = listed.data.content || [];
        }
      } else {
        current = getVirtual(fsPath);
        const listed = listVirtual(fsPath);
        if (listed) children = listed.items.map(toObjResp);
      }
      if (!current) return textResponse("", 404);
      const hrefBase = "/dav" + (fsPath === "/" ? "/" : fsPath);
      const responses = [propResponse({ href: hrefBase, item: current })];
      const depth = String(((_a = request.headers) == null ? void 0 : _a.depth) || ((_b = request.headers) == null ? void 0 : _b.Depth) || "1");
      if (current.is_dir && depth !== "0") {
        for (const child of children) {
          responses.push(propResponse({
            href: normalizePath(hrefBase + "/" + child.name) + (child.is_dir ? "/" : ""),
            item: child
          }));
        }
      }
      return textResponse(`<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:">${responses.join("")}</D:multistatus>`, 207, "application/xml; charset=utf-8");
    };
    const requestBodyText2 = async (requestMeta) => {
      const body = requestMeta.body || requestMeta.Body || {};
      if (body.data !== void 0 && body.data !== null) {
        if (typeof body.data === "string") return body.data;
        if (typeof body.data.text === "function") return body.data.text();
        if (body.data instanceof ArrayBuffer) return String.fromCharCode(...new Uint8Array(body.data));
        if (typeof body.data === "object") return JSON.stringify(body.data);
      }
      if (body.string && Array.isArray(body.string.values)) return body.string.values.join("");
      return "";
    };
    const headerValue2 = (requestMeta, name) => {
      const headers = requestMeta.headers || requestMeta.Headers || {};
      const lower = name.toLowerCase();
      for (const [key, value] of Object.entries(headers)) {
        if (String(key).toLowerCase() !== lower) continue;
        if (Array.isArray(value)) return value[0] || "";
        return String(value || "");
      }
      return "";
    };
    const destinationPath = (requestMeta) => {
      const raw = headerValue2(requestMeta, "Destination");
      if (!raw) return "";
      try {
        const parsed = new URL(raw);
        return webdavPath(parsed.pathname.replace(/^\/plugin\/private\/[^/]+/, ""));
      } catch (_) {
        return webdavPath(raw.replace(/^\/plugin\/private\/[^/]+/, ""));
      }
    };
    const rejectWorkspaceWrite = (fsPath) => {
      if (!isWorkspacePath(fsPath)) return null;
      return textResponse("WebDAV write operations for /@workspace are disabled until SiYuan upload/move support is proven", 501);
    };
    const lockToken = () => `opaquelocktoken:siyuan-cloud-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    const lockResponse = (token) => textResponse([
      `<?xml version="1.0" encoding="utf-8"?>`,
      `<D:prop xmlns:D="DAV:"><D:lockdiscovery><D:activelock>`,
      `<D:locktype><D:write/></D:locktype><D:lockscope><D:exclusive/></D:lockscope>`,
      `<D:depth>infinity</D:depth><D:timeout>Second-3600</D:timeout>`,
      `<D:locktoken><D:href>${escapeXml(token)}</D:href></D:locktoken>`,
      `</D:activelock></D:lockdiscovery></D:prop>`
    ].join(""), 200, "application/xml; charset=utf-8");
    return async (request) => {
      const requestMeta = request.request || request.Request || {};
      const method = String(requestMeta.method || requestMeta.Method || "GET").toUpperCase();
      const path = requestPath(request);
      if (method === "OPTIONS") {
        return {
          ...textResponse("", 204),
          headers: {
            Allow: ["OPTIONS, GET, HEAD, PROPFIND, MKCOL, PUT, DELETE, COPY, MOVE, LOCK, UNLOCK, PROPPATCH"],
            DAV: ["1, 2"]
          }
        };
      }
      if (method === "PROPFIND") return propfind(requestMeta, path);
      if (method === "GET" || method === "HEAD") return readFileResponse(webdavPath(path), request);
      if (method === "MKCOL") {
        const fsPath = webdavPath(path);
        const rejected = rejectWorkspaceWrite(fsPath);
        if (rejected) return rejected;
        ensureDir(fsPath);
        await saveState2();
        return textResponse("", 201);
      }
      if (method === "PUT") {
        const fsPath = webdavPath(path);
        const rejected = rejectWorkspaceWrite(fsPath);
        if (rejected) return rejected;
        createFile(fsPath, await requestBodyText2(requestMeta), headerValue2(requestMeta, "Content-Type"));
        await saveState2();
        return textResponse("", 201);
      }
      if (method === "DELETE") {
        const fsPath = webdavPath(path);
        const rejected = rejectWorkspaceWrite(fsPath);
        if (rejected) return rejected;
        removeEntry(fsPath);
        await saveState2();
        return textResponse("", 204);
      }
      if (method === "COPY" || method === "MOVE") {
        const srcPath = webdavPath(path);
        const dstPath = destinationPath(requestMeta);
        const rejected = rejectWorkspaceWrite(srcPath) || rejectWorkspaceWrite(dstPath);
        if (rejected) return rejected;
        if (!dstPath) return textResponse("missing Destination header", 400);
        if (method === "COPY") cloneEntryTree(srcPath, dstPath);
        if (method === "MOVE") moveEntryTree(srcPath, dstPath);
        await saveState2();
        return textResponse("", 201);
      }
      if (method === "LOCK") {
        const fsPath = webdavPath(path);
        const token = lockToken();
        const state = getState();
        state.webdav_locks = state.webdav_locks || {};
        state.webdav_locks[token] = { path: fsPath, created: (/* @__PURE__ */ new Date()).toISOString() };
        await saveState2();
        const response = lockResponse(token);
        response.headers["Lock-Token"] = [`<${token}>`];
        return response;
      }
      if (method === "UNLOCK") {
        const state = getState();
        const token = headerValue2(requestMeta, "Lock-Token").replace(/[<>]/g, "");
        if (state.webdav_locks && token) delete state.webdav_locks[token];
        await saveState2();
        return textResponse("", 204);
      }
      if (method === "PROPPATCH") {
        return textResponse(`<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:"/>`, 207, "application/xml; charset=utf-8");
      }
      return textResponse("method not allowed", 405);
    };
  };
  (function() {
    const now = () => (/* @__PURE__ */ new Date()).toISOString();
    let state = defaultState(now);
    const {
      cloneEntryTree,
      createFile,
      ensureDir,
      moveEntryTree,
      removeEmptyDirs,
      removeEntry,
      renameEntryInDir
    } = createVirtualFs({
      getState: () => state,
      now
    });
    const log = (...args) => siyuan.logger.info("[siyuan-cloud]", ...args);
    const warn = (...args) => siyuan.logger.warn("[siyuan-cloud]", ...args);
    const pick = (value, lowerName, upperName) => {
      if (!value) return void 0;
      if (value[lowerName] !== void 0) return value[lowerName];
      if (value[upperName] !== void 0) return value[upperName];
      return void 0;
    };
    const extensionType = (name, isDir2) => {
      if (isDir2) return 1;
      const ext = String(name).toLowerCase().split(".").pop() || "";
      if (["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif"].includes(ext)) return 2;
      if (["mp4", "mkv", "mov", "avi", "webm", "m4v"].includes(ext)) return 3;
      if (["mp3", "flac", "wav", "ogg", "m4a"].includes(ext)) return 4;
      if (["zip", "7z", "rar", "tar", "gz", "bz2"].includes(ext)) return 5;
      if (["pdf", "epub", "txt", "md", "json", "yaml", "yml", "csv", "log"].includes(ext)) return 6;
      return 0;
    };
    const toObjResp = (entry) => ({
      name: entry.name,
      size: entry.size || 0,
      is_dir: !!entry.is_dir,
      modified: entry.modified,
      created: entry.created || entry.modified,
      sign: "",
      thumb: "",
      type: extensionType(entry.name, entry.is_dir),
      hashinfo: "",
      hash_info: {}
    });
    const toFsGetResp = (entry, path) => ({
      ...toObjResp(entry),
      raw_url: entry.is_dir ? "" : "/plugin/private/siyuan-cloud/d" + normalizePath(path),
      readme: "",
      header: "",
      provider: "siyuan-storage",
      related: relatedEntries(path, entry).map(toObjResp)
    });
    const page = (items, req) => {
      const pageIndex = Math.max(1, Number(req.page || req.Page || 1));
      const perPage = Math.max(1, Number(req.per_page || req.perPage || req.PerPage || items.length || 1));
      const start = (pageIndex - 1) * perPage;
      return items.slice(start, start + perPage);
    };
    const {
      isWorkspacePath,
      siyuanApiJson,
      workspaceGet,
      workspaceList,
      workspaceReadText,
      workspaceRelPath
    } = createWorkspaceAdapter({
      client: siyuan.client,
      extensionType,
      failure,
      now,
      page,
      toObjResp
    });
    const relatedEntries = (path, entry) => {
      if (!entry || entry.is_dir) return [];
      const parent = state.entries[dirname(path)];
      if (!parent || !parent.children) return [];
      const stem = entry.name.replace(/\.[^.]+$/, "");
      return parent.children.map((childPath) => state.entries[childPath]).filter((item) => item && !item.is_dir && item.name !== entry.name && item.name.startsWith(stem));
    };
    const parseJson = async (request) => {
      const requestMeta = pick(request, "request", "Request");
      const body = pick(requestMeta, "body", "Body");
      if (!body) return {};
      if (body.data !== void 0 && body.data !== null) {
        if (typeof body.data === "object") {
          if (typeof body.data.json === "function") {
            try {
              return await body.data.json();
            } catch (_) {
            }
          }
          if (typeof body.data.text === "function") {
            const text2 = await body.data.text();
            if (!text2 || !String(text2).trim()) return {};
            try {
              return JSON.parse(text2);
            } catch (_) {
              return { content: text2 };
            }
          }
          return body.data;
        }
        if (typeof body.data === "string" && body.data.trim()) {
          try {
            return JSON.parse(body.data);
          } catch (_) {
            return { content: body.data };
          }
        }
      }
      if (body.form && typeof body.form === "object") {
        const values = body.form.values || body.form.Value || {};
        const files = body.form.files || body.form.File || {};
        const flattened = {};
        for (const key of Object.keys(values)) {
          const value = values[key];
          flattened[key] = Array.isArray(value) && value.length === 1 ? value[0] : value;
        }
        flattened.files = files;
        return flattened;
      }
      if (body.string && Array.isArray(body.string.values)) return { content: body.string.values.join("") };
      return {};
    };
    const queryValue = (request, key) => {
      const url = pick(request, "url", "URL");
      const queryMap = pick(url, "query", "Query");
      if (queryMap && typeof queryMap === "object") {
        const value = queryMap[key];
        return Array.isArray(value) ? String(value[0] || "") : String(value || "");
      }
      const query = queryMap || pick(url, "rawQuery", "RawQuery") || pick(url, "search", "Search") || "";
      const params = new URLSearchParams(query);
      return params.get(key) || "";
    };
    const decodePath = (path) => {
      try {
        return decodeURIComponent(path);
      } catch (_) {
        return path;
      }
    };
    const requestPath = (request) => {
      const context = pick(request, "context", "Context");
      const url = pick(request, "url", "URL");
      const fromContext = pick(context, "path", "Path");
      const fromUrl = pick(url, "path", "Path");
      const raw = fromContext || fromUrl || "/";
      return decodePath(raw.replace(/^\/plugin\/private\/[^/]+/, "") || "/");
    };
    const rawForwardHeaders = (headers = {}) => {
      const result = {};
      for (const [key, value] of Object.entries(headers || {})) {
        const normalized = String(key).toLowerCase();
        if (["accept-ranges", "content-range", "content-length", "etag", "last-modified", "cache-control"].includes(normalized)) {
          result[key] = Array.isArray(value) ? value.map(String) : [String(value)];
        }
      }
      return result;
    };
    const fileMime = (path) => {
      const ext = String(path || "").split(".").pop().toLowerCase();
      const types = {
        mp4: "video/mp4",
        m4v: "video/mp4",
        webm: "video/webm",
        mkv: "video/x-matroska",
        mov: "video/quicktime",
        mp3: "audio/mpeg",
        m4a: "audio/mp4",
        flac: "audio/flac",
        wav: "audio/wav",
        ogg: "audio/ogg"
      };
      return types[ext] || "application/octet-stream";
    };
    const saveState$1 = async () => {
      await saveState(siyuan.storage, state);
    };
    const saveStorageAddition = async (storage, addition) => {
      const target = state.storages.find((item) => item.id === storage.id) || state.storages.find((item) => item.mount_path === storage.mount_path);
      if (!target) return;
      target.addition = JSON.stringify(addition || {});
      target.modified = now();
      await saveState$1();
    };
    const driverRuntime = createDriverRuntime({
      client: siyuan.client,
      saveStorageAddition
    });
    const loadState$1 = async () => {
      const loaded = await loadState({ now, storage: siyuan.storage });
      state = loaded.state;
      if (loaded.shouldSave) {
        await saveState$1();
      }
      ensureDir("/");
    };
    const settingItem = (key, value, index) => {
      const meta = settingMeta[key] || {};
      return {
        key,
        value: String(value ?? ""),
        help: meta.help || "",
        type: meta.type || "string",
        options: meta.options || "",
        group: meta.group ?? SETTING_GROUP.SINGLE,
        flag: meta.flag ?? SETTING_FLAG.PUBLIC,
        index: index || 0
      };
    };
    const requestedGroups = (request) => {
      const raw = queryValue(request, "groups") || queryValue(request, "group");
      if (!raw) return null;
      const groups = raw.split(",").map((item) => Number(item.trim())).filter((item) => Number.isFinite(item));
      return groups.length ? groups : null;
    };
    const listSettings = (request, source) => {
      const groups = request ? requestedGroups(request) : null;
      return Object.entries(source || state.settings).map(([key, value], index) => settingItem(key, value, index)).filter((item) => !groups || groups.includes(item.group));
    };
    const saveToolSettings = async (req, keyMap, responseValue) => {
      for (const [settingKey, reqKey] of Object.entries(keyMap)) {
        state.settings[settingKey] = String(req[reqKey] ?? "");
      }
      await saveState$1();
      return jsonResponse(success(responseValue === void 0 ? "ok" : responseValue));
    };
    const pageSlice = (items, request) => {
      const pageIndex = Math.max(1, Number(queryValue(request, "page") || 1));
      const perPage = Math.max(1, Number(queryValue(request, "per_page") || queryValue(request, "perPage") || items.length || 1));
      const start = (pageIndex - 1) * perPage;
      return pageResp(items.slice(start, start + perPage), items.length);
    };
    const storageResp = (storage) => ({
      ...storage,
      mount_details: storage.mount_details || {
        total_space: 0,
        used_space: 0,
        free_space: 0
      }
    });
    const { shareGet, shareList } = createShareReader({
      getState: () => state,
      isWorkspacePath,
      page,
      toFsGetResp,
      toObjResp,
      workspaceGet,
      workspaceList
    });
    const taskStore = createTaskStore({
      getState: () => state,
      now,
      saveState: saveState$1
    });
    const readFileResponse = async (filePath, request) => {
      if (isWorkspacePath(filePath)) {
        const file = await workspaceReadText(filePath);
        if (!file.ok) return textResponse(file.text || "not found", file.status || 404);
        return textResponse(file.text, 200, file.contentType);
      }
      const mount = driverRuntime.resolve(state.storages, filePath);
      if (mount && mount.driver.read) {
        try {
          const options = proxyReadOptions(request, filePath);
          const data = await mount.driver.read(mount.storage, mount.relPath, options);
          if (data.link || data.Link || data.proxy_url || data.proxyUrl) {
            const link = linkFromDriverData(data);
            return proxy(null, link, { request_header: options.requestHeaders }, !!mount.storage.proxy_range);
          }
          if (data.redirect_url || data.redirectUrl) {
            return redirectResponse(data.redirect_url || data.redirectUrl, data.status || 302);
          }
          if (String(data.bodyEncoding || "").startsWith("base64")) {
            const headers = rawForwardHeaders(data.headers);
            if (!headers["Accept-Ranges"] && !headers["accept-ranges"]) headers["Accept-Ranges"] = ["bytes"];
            return rawResponse(
              base64ToArrayBuffer(data.body || ""),
              data.status || 200,
              data.contentType || fileMime(filePath),
              headers
            );
          }
          return textResponse(data.body || "", data.status || 200, data.contentType || "application/octet-stream");
        } catch (error) {
          return textResponse(error.message || "driver read failed", 502);
        }
      }
      const entry = state.entries[filePath];
      if (!entry || entry.is_dir) return textResponse("not found", 404);
      return textResponse(entry.content || "", 200, entry.mime || "application/octet-stream");
    };
    const handleWebDav = createWebDavServer({
      cloneEntryTree,
      createFile,
      ensureDir,
      getState: () => state,
      isWorkspacePath,
      moveEntryTree,
      readFileResponse,
      removeEntry,
      requestPath,
      saveState: saveState$1,
      toObjResp,
      workspaceGet,
      workspaceList
    });
    const handleS3 = createS3Server({
      cloneEntryTree,
      createFile,
      ensureDir,
      getState: () => state,
      removeEntry,
      requestPath,
      saveState: saveState$1
    });
    let handlers = {};
    handlers = {
      ...createStatusHandlers({
        client: siyuan.client,
        getState: () => state,
        handlersRef: () => handlers
      }),
      ...createTaskHandlers({
        parseJson,
        queryValue,
        saveState: saveState$1,
        taskStore
      }),
      ...createAuthHandlers({
        getState: () => state,
        parseJson,
        saveState: saveState$1
      }),
      ...createCompatHandlers(),
      ...createMetaHandlers({
        getState: () => state,
        pageSlice,
        parseJson,
        queryValue,
        saveState: saveState$1
      }),
      ...createMessageHandlers({
        getState: () => state,
        now,
        parseJson,
        saveState: saveState$1
      }),
      ...createIndexHandlers({
        getState: () => state,
        saveState: saveState$1
      }),
      ...createScanHandlers({
        getState: () => state,
        now,
        saveState: saveState$1
      }),
      ...createSecurityHandlers({
        getState: () => state,
        now,
        parseJson,
        queryValue,
        saveState: saveState$1
      }),
      ...createPublicHandlers({
        getState: () => state,
        settingItem
      }),
      ...createAdminHandlers({
        driverRuntime,
        getState: () => state,
        isWorkspacePath,
        listSettings,
        now,
        pageSlice,
        parseJson,
        queryValue,
        saveState: saveState$1,
        saveToolSettings,
        settingItem,
        storageResp,
        workspaceGet
      }),
      ...createFsHandlers({
        cloneEntryTree,
        createFile,
        driverRuntime,
        ensureDir,
        getState: () => state,
        isWorkspacePath,
        moveEntryTree,
        now,
        page,
        parseJson,
        removeEmptyDirs,
        removeEntry,
        renameEntryInDir,
        saveState: saveState$1,
        shareGet,
        shareList,
        siyuanApiJson,
        taskStore,
        toFsGetResp,
        toObjResp,
        workspaceGet,
        workspaceList,
        workspaceRelPath
      }),
      ...createArchiveHandlers({
        parseJson,
        taskStore
      }),
      ...createShareHandlers({
        getState: () => state,
        isWorkspacePath,
        now,
        page,
        parseJson,
        queryValue,
        saveState: saveState$1,
        workspaceGet
      })
    };
    const route = createRouter({
      getState: () => state,
      handleS3,
      handleWebDav,
      handlers,
      isWorkspacePath,
      pick,
      queryValue,
      readFileResponse,
      requestPath,
      warn,
      workspaceReadText
    });
    siyuan.plugin.lifecycle.onload = async () => {
      await loadState$1();
      await siyuan.rpc.bind("siyuan-cloud.status", async () => ({
        ok: true,
        version: OPENLIST_VERSION,
        users: state.users.length,
        entries: Object.keys(state.entries).length,
        routes: Object.keys(handlers).length
      }), "Return Siyuan Cloud compatibility runtime status.");
      await log("kernel plugin loaded", OPENLIST_VERSION);
    };
    siyuan.plugin.lifecycle.onunload = async () => {
      await saveState$1();
      await log("kernel plugin unloaded");
    };
    siyuan.server.private.http.handler = async (request) => {
      return route(request);
    };
  })();
})();
