(function() {
  "use strict";
  const OPENLIST_VERSION = "siyuan-cloud-port-0.5.0";
  const CONFIG_FILE = "config.json";
  const LEGACY_STATE_FILE = "siyuan-cloud/state.json";
  const RUNTIME_FILE = "runtime.json";
  const SEARCH_INDEX_FILE = "search-index.json";
  const TASK_TYPES = [
    "copy",
    "move",
    "upload",
    "offline_download",
    "offline_download_transfer",
    "aria2_down",
    "aria2_transfer",
    "qbit_down",
    "qbit_transfer",
    "index",
    "decompress",
    "decompress_upload"
  ];
  const success = (data) => ({
    code: 200,
    message: "success",
    data: data === void 0 ? null : data
  });
  const successWithMessage = (message, data) => ({
    code: 200,
    message: message || "success",
    data: data === void 0 ? null : data
  });
  const failure = (message, code, data) => ({
    code: code || 500,
    message: message || "error",
    data: data === void 0 ? null : data
  });
  const jsonResponse = (payload, statusCode) => ({
    statusCode: statusCode || 200,
    headers: {
      "Content-Type": ["application/json; charset=utf-8"],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
    },
    body: {
      data: {
        type: "JSON",
        data: payload
      }
    }
  });
  const textResponse = (text2, statusCode, contentType) => ({
    statusCode: statusCode || 200,
    headers: {
      "Content-Type": [contentType || "text/plain; charset=utf-8"],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
    },
    body: {
      string: {
        format: "%s",
        values: [text2]
      }
    }
  });
  const rawResponse = (data, statusCode, contentType, extraHeaders = {}) => ({
    statusCode: statusCode || 200,
    headers: {
      "Content-Type": [contentType || "application/octet-stream"],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION],
      ...extraHeaders
    },
    body: {
      raw: {
        contentType: contentType || "application/octet-stream",
        data
      }
    }
  });
  const redirectResponse = (location, statusCode = 302) => ({
    statusCode,
    headers: {
      Location: [location],
      "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
    },
    body: {
      redirect: {
        location
      }
    }
  });
  const proxyResponse = (url, headers = {}, method = "GET") => {
    const normalizedHeaders = {};
    for (const [key, value] of Object.entries(headers || {})) {
      if (value === void 0 || value === null || value === "") continue;
      normalizedHeaders[key] = Array.isArray(value) ? value.map(String) : [String(value)];
    }
    return {
      statusCode: 200,
      headers: {
        "X-SiYuan-OpenList-Port": [OPENLIST_VERSION]
      },
      body: {
        proxy: {
          url,
          method,
          headers: normalizedHeaders
        }
      }
    };
  };
  const base64ToArrayBuffer = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "").replace(/-/g, "+").replace(/_/g, "/");
    const bytes2 = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      bytes2.push(a << 2 | b >> 4);
      if (c >= 0) bytes2.push((b & 15) << 4 | c >> 2);
      if (d >= 0) bytes2.push((c & 3) << 6 | d);
    }
    return new Uint8Array(bytes2).buffer;
  };
  const pageResp = (content, total) => ({
    content,
    total: total === void 0 ? content.length : total
  });
  const normalizePath = (input) => {
    let value = input === void 0 || input === null || input === "" ? "/" : String(input);
    if (!value.startsWith("/")) value = "/" + value;
    value = value.replace(/\\/g, "/").replace(/\/+/g, "/");
    const parts = [];
    for (const part of value.split("/")) {
      if (!part || part === ".") continue;
      if (part === "..") continue;
      parts.push(part);
    }
    return "/" + parts.join("/");
  };
  const dirname = (path) => {
    const normalized = normalizePath(path);
    if (normalized === "/") return "/";
    const index = normalized.lastIndexOf("/");
    return index <= 0 ? "/" : normalized.slice(0, index);
  };
  const basename = (path) => {
    const normalized = normalizePath(path);
    if (normalized === "/") return "";
    return normalized.slice(normalized.lastIndexOf("/") + 1);
  };
  const isSafeRelativeName = (name) => {
    const value = String(name || "").trim();
    return !!value && !/[\\/]/.test(value) && value !== "." && value !== "..";
  };
  const linkFromDriverData = (data = {}) => {
    const link2 = data.link || {};
    if (!link2.url) throw new Error("driver read did not return link.url");
    return {
      url: link2.url,
      header: link2.header || {},
      method: link2.method || "GET",
      content_length: Number(link2.content_length || 0),
      concurrency: Number(link2.concurrency || 0),
      part_size: Number(link2.part_size || 0),
      range_reader: link2.range_reader || null
    };
  };
  const SETTING_GROUP = {
    SINGLE: 0,
    SITE: 1,
    STYLE: 2,
    PREVIEW: 3,
    GLOBAL: 4,
    OFFLINE_DOWNLOAD: 5,
    INDEX: 6,
    SSO: 7,
    LDAP: 8,
    S3: 9,
    FTP: 10,
    TRAFFIC: 11
  };
  const SETTING_FLAG = {
    PUBLIC: 0,
    PRIVATE: 1,
    READONLY: 2
  };
  const utf8$2 = (input) => unescape(encodeURIComponent(String(input)));
  const rotr = (value, bits2) => value >>> bits2 | value << 32 - bits2;
  const hex$9 = (bytes2) => Array.from(bytes2, (b) => b.toString(16).padStart(2, "0")).join("");
  const bytes$2 = (input) => {
    if (input instanceof Uint8Array) return input;
    const text2 = utf8$2(input);
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const K = [
    1116352408,
    1899447441,
    3049323471,
    3921009573,
    961987163,
    1508970993,
    2453635748,
    2870763221,
    3624381080,
    310598401,
    607225278,
    1426881987,
    1925078388,
    2162078206,
    2614888103,
    3248222580,
    3835390401,
    4022224774,
    264347078,
    604807628,
    770255983,
    1249150122,
    1555081692,
    1996064986,
    2554220882,
    2821834349,
    2952996808,
    3210313671,
    3336571891,
    3584528711,
    113926993,
    338241895,
    666307205,
    773529912,
    1294757372,
    1396182291,
    1695183700,
    1986661051,
    2177026350,
    2456956037,
    2730485921,
    2820302411,
    3259730800,
    3345764771,
    3516065817,
    3600352804,
    4094571909,
    275423344,
    430227734,
    506948616,
    659060556,
    883997877,
    958139571,
    1322822218,
    1537002063,
    1747873779,
    1955562222,
    2024104815,
    2227730452,
    2361852424,
    2428436474,
    2756734187,
    3204031479,
    3329325298
  ];
  const sha256Bytes = (message) => {
    const msg = bytes$2(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1779033703;
    let h1 = 3144134277;
    let h2 = 1013904242;
    let h3 = 2773480762;
    let h4 = 1359893119;
    let h5 = 2600822924;
    let h6 = 528734635;
    let h7 = 1541459225;
    const w = new Uint32Array(64);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i2 = 0; i2 < 16; i2 += 1) w[i2] = view.getUint32(offset + i2 * 4);
      for (let i2 = 16; i2 < 64; i2 += 1) {
        const s0 = rotr(w[i2 - 15], 7) ^ rotr(w[i2 - 15], 18) ^ w[i2 - 15] >>> 3;
        const s1 = rotr(w[i2 - 2], 17) ^ rotr(w[i2 - 2], 19) ^ w[i2 - 2] >>> 10;
        w[i2] = w[i2 - 16] + s0 + w[i2 - 7] + s1 >>> 0;
      }
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      let f = h5;
      let g = h6;
      let h = h7;
      for (let i2 = 0; i2 < 64; i2 += 1) {
        const s1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        const ch = e & f ^ ~e & g;
        const temp1 = h + s1 + ch + K[i2] + w[i2] >>> 0;
        const s0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        const maj = a & b ^ a & c ^ b & c;
        const temp2 = s0 + maj >>> 0;
        h = g;
        g = f;
        f = e;
        e = d + temp1 >>> 0;
        d = c;
        c = b;
        b = a;
        a = temp1 + temp2 >>> 0;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
      h5 = h5 + f >>> 0;
      h6 = h6 + g >>> 0;
      h7 = h7 + h >>> 0;
    }
    const out = new Uint8Array(32);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4, h5, h6, h7].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const sha256Hex = (message) => hex$9(sha256Bytes(message));
  const hmacSha256 = (key, message) => {
    let keyBytes = bytes$2(key);
    if (keyBytes.length > 64) keyBytes = sha256Bytes(keyBytes);
    const ipad = new Uint8Array(64);
    const opad = new Uint8Array(64);
    for (let i2 = 0; i2 < 64; i2 += 1) {
      const b = keyBytes[i2] || 0;
      ipad[i2] = b ^ 54;
      opad[i2] = b ^ 92;
    }
    const inner = new Uint8Array(ipad.length + bytes$2(message).length);
    inner.set(ipad);
    inner.set(bytes$2(message), ipad.length);
    const outer = new Uint8Array(opad.length + 32);
    outer.set(opad);
    outer.set(sha256Bytes(inner), opad.length);
    return sha256Bytes(outer);
  };
  const amzDate$1 = (date) => date.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp$1 = (date) => amzDate$1(date).slice(0, 8);
  const encodeRfc3986$1 = (value) => encodeURIComponent(value).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
  const signAwsV4 = ({ accessKeyId, body = "", headers = {}, method, region, secretAccessKey, service = "s3", sessionToken = "", url }) => {
    const parsed = new URL(url);
    const now = /* @__PURE__ */ new Date();
    const amz = amzDate$1(now);
    const date = dateStamp$1(now);
    const signingRegion = String(region ?? "");
    const payloadHash = sha256Hex(body || "");
    const normalizedHeaders = {
      host: parsed.host,
      "x-amz-content-sha256": payloadHash,
      "x-amz-date": amz,
      ...Object.fromEntries(Object.entries(headers).map(([key, value]) => [key.toLowerCase(), String(value).trim()]))
    };
    if (sessionToken) normalizedHeaders["x-amz-security-token"] = sessionToken;
    const signedHeaders = Object.keys(normalizedHeaders).sort();
    const canonicalHeaders = signedHeaders.map((key) => `${key}:${normalizedHeaders[key]}
`).join("");
    const query = [...parsed.searchParams.entries()].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([key, value]) => `${encodeRfc3986$1(key)}=${encodeRfc3986$1(value)}`).join("&");
    const canonicalRequest = [
      method.toUpperCase(),
      parsed.pathname || "/",
      query,
      canonicalHeaders,
      signedHeaders.join(";"),
      payloadHash
    ].join("\n");
    const scope = `${date}/${signingRegion}/${service}/aws4_request`;
    const stringToSign = [
      "AWS4-HMAC-SHA256",
      amz,
      scope,
      sha256Hex(canonicalRequest)
    ].join("\n");
    const kDate = hmacSha256(`AWS4${secretAccessKey}`, date);
    const kRegion = hmacSha256(kDate, signingRegion);
    const kService = hmacSha256(kRegion, service);
    const kSigning = hmacSha256(kService, "aws4_request");
    const signature2 = hex$9(hmacSha256(kSigning, stringToSign));
    return {
      ...normalizedHeaders,
      Authorization: `AWS4-HMAC-SHA256 Credential=${accessKeyId}/${scope}, SignedHeaders=${signedHeaders.join(";")}, Signature=${signature2}`
    };
  };
  const b64urlEncode = (value) => {
    const text2 = typeof value === "string" ? unescape(encodeURIComponent(value)) : value;
    const bytes2 = typeof text2 === "string" ? Array.from(text2, (char) => char.charCodeAt(0)) : text2;
    let binary = "";
    for (const byte of bytes2) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
  };
  const b64urlDecode = (value) => {
    const padded = String(value || "").replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(String(value || "").length / 4) * 4, "=");
    const binary = atob(padded);
    return decodeURIComponent(escape(binary));
  };
  const signature = (data, secret) => b64urlEncode(hmacSha256(secret || "siyuan-cloud-token", data));
  const generateAuthToken = (user, secret, nowMs = Date.now()) => {
    const header = b64urlEncode(JSON.stringify({ alg: "HS256", typ: "JWT" }));
    const now = Math.floor(nowMs / 1e3);
    const payload = b64urlEncode(JSON.stringify({
      exp: now + 48 * 3600,
      iat: now,
      iat_ms: nowMs,
      nbf: now,
      pwd_ts: Number((user == null ? void 0 : user.pwd_ts) || 0),
      username: (user == null ? void 0 : user.username) || ""
    }));
    const data = `${header}.${payload}`;
    return `${data}.${signature(data, secret)}`;
  };
  const parseAuthToken = (token, secret, nowMs = Date.now()) => {
    const parts = String(token || "").split(".");
    if (parts.length !== 3) throw new Error("that's not even a token");
    const data = `${parts[0]}.${parts[1]}`;
    if (signature(data, secret) !== parts[2]) throw new Error("couldn't handle this token");
    const payload = JSON.parse(b64urlDecode(parts[1]));
    const now = Math.floor(nowMs / 1e3);
    if (Number(payload.nbf || 0) > now) throw new Error("token not active yet");
    if (Number(payload.exp || 0) <= now) throw new Error("token is expired");
    return payload;
  };
  const passwordTimestamp = () => Date.now();
  const STATIC_HASH_SALT = "https://github.com/alist-org/alist";
  const staticPasswordHash = (value) => sha256Hex(`${String(value || "")}-${STATIC_HASH_SALT}`);
  const hashPassword = (staticHash, salt) => sha256Hex(`${String(staticHash || "")}-${String(salt || "")}`);
  const randomSalt = () => sha256Hex(`${Date.now()}-${Math.random()}-${Math.random()}`).slice(0, 16);
  const tokenFingerprint = (token) => sha256Hex(String(token || ""));
  const setUserPassword = (user, password2, now = passwordTimestamp()) => {
    const salt = randomSalt();
    user.salt = salt;
    user.pwd_salt = salt;
    user.pwd_hash = hashPassword(staticPasswordHash(password2), salt);
    user.pwd_ts = now;
    user.password = "";
    return user;
  };
  const verifyPassword = (user, password2) => {
    if (!(user == null ? void 0 : user.pwd_hash) || !(user.salt || user.pwd_salt)) return !(user == null ? void 0 : user.password) || String(password2 || "") === String(user.password || "");
    return user.pwd_hash === hashPassword(staticPasswordHash(password2), user.salt || user.pwd_salt);
  };
  const verifyStaticPasswordHash = (user, staticHash) => {
    if (!(user == null ? void 0 : user.pwd_hash) || !(user.salt || user.pwd_salt)) {
      if (!(user == null ? void 0 : user.password)) return !staticHash;
      return staticPasswordHash(user.password) === String(staticHash || "");
    }
    return user.pwd_hash === hashPassword(staticHash, user.salt || user.pwd_salt);
  };
  const USER_ROLE = {
    GENERAL: 0,
    GUEST: 1,
    ADMIN: 2
  };
  const ADMIN_PERMISSION = 29695;
  const USER_PERMISSION = {
    SEE_HIDES: 1 << 0,
    ACCESS_WITHOUT_PASSWORD: 1 << 1,
    OFFLINE_DOWNLOAD: 1 << 2,
    WRITE_CONTENT: 1 << 3,
    RENAME: 1 << 4,
    MOVE: 1 << 5,
    COPY: 1 << 6,
    REMOVE: 1 << 7,
    WEBDAV_READ: 1 << 8,
    WEBDAV_MANAGE: 1 << 9,
    READ_ARCHIVES: 1 << 12,
    DECOMPRESS: 1 << 13,
    SHARE: 1 << 14,
    CUSTOMIZE_SHARE_ID: 1 << 15
  };
  const isAdminUser = (user) => Number(user == null ? void 0 : user.role) === USER_ROLE.ADMIN;
  const hasPermission = (user, permission) => isAdminUser(user) || (Number((user == null ? void 0 : user.permission) || 0) & permission) !== 0;
  const canShare = (user) => isAdminUser(user) || (Number((user == null ? void 0 : user.permission) || 0) & USER_PERMISSION.SHARE) !== 0;
  const canCustomizeShareID = (user) => hasPermission(user, USER_PERMISSION.CUSTOMIZE_SHARE_ID);
  const canSeeHides = (user) => hasPermission(user, USER_PERMISSION.SEE_HIDES);
  const canAccessWithoutPassword = (user) => hasPermission(user, USER_PERMISSION.ACCESS_WITHOUT_PASSWORD);
  const canAddOfflineDownloadTasks = (user) => hasPermission(user, USER_PERMISSION.OFFLINE_DOWNLOAD);
  const canWriteContent = (user) => hasPermission(user, USER_PERMISSION.WRITE_CONTENT);
  const canRename = (user) => hasPermission(user, USER_PERMISSION.RENAME);
  const canMove = (user) => hasPermission(user, USER_PERMISSION.MOVE);
  const canCopy = (user) => hasPermission(user, USER_PERMISSION.COPY);
  const canRemove = (user) => hasPermission(user, USER_PERMISSION.REMOVE);
  const canWebdavRead = (user) => hasPermission(user, USER_PERMISSION.WEBDAV_READ);
  const canWebdavManage = (user) => hasPermission(user, USER_PERMISSION.WEBDAV_MANAGE);
  const canReadArchives = (user) => hasPermission(user, USER_PERMISSION.READ_ARCHIVES);
  const canDecompress = (user) => hasPermission(user, USER_PERMISSION.DECOMPRESS);
  const sanitizeUser = (user) => {
    const result = { ...user || {} };
    result.password = "";
    delete result.pwd_hash;
    delete result.pwd_salt;
    delete result.salt;
    delete result.logout_ts;
    delete result.logout_tokens;
    result.otp_secret = "";
    result.otp = !!((user == null ? void 0 : user.otp) || (user == null ? void 0 : user.otp_secret));
    return result;
  };
  const normalizeUser = (input = {}, index = 0) => ({
    id: Number(input.id || index + 1),
    username: String(input.username || `user-${index + 1}`),
    password: input.password || "",
    pwd_hash: input.pwd_hash || input.PwdHash || "",
    pwd_salt: input.pwd_salt || input.salt || input.Salt || "",
    salt: input.salt || input.pwd_salt || input.Salt || "",
    pwd_ts: Number(input.pwd_ts || input.pwdTS || 0),
    logout_ts: Number(input.logout_ts || input.logoutTS || 0),
    logout_tokens: Array.isArray(input.logout_tokens) ? input.logout_tokens.map(String) : [],
    role: Number(input.role ?? USER_ROLE.GENERAL),
    disabled: !!input.disabled,
    base_path: normalizePath(input.base_path || "/"),
    permission: Number(input.permission ?? 0),
    sso_id: input.sso_id || "",
    otp: !!(input.otp || input.otp_secret),
    otp_secret: input.otp_secret || "",
    allow_ldap: input.allow_ldap === void 0 ? true : !!input.allow_ldap,
    authn: input.authn || "[]",
    siyuan_account: input.siyuan_account || null
  });
  const defaultAdminUser = (username = "admin", account = null) => normalizeUser({
    id: 1,
    username,
    role: USER_ROLE.ADMIN,
    disabled: false,
    base_path: "/",
    permission: ADMIN_PERMISSION,
    siyuan_account: account
  }, 0);
  const defaultGuestUser = () => normalizeUser({
    id: 2,
    username: "guest",
    password: "guest",
    role: USER_ROLE.GUEST,
    disabled: true,
    base_path: "/",
    permission: 0
  }, 1);
  const pickAccountName = (conf) => {
    const user = (conf == null ? void 0 : conf.user) || (conf == null ? void 0 : conf.User) || {};
    return String(user.userNickname || user.userName || user.UserNickname || user.UserName || "").trim();
  };
  const accountFromSiyuanConf = (conf) => {
    const user = (conf == null ? void 0 : conf.user) || (conf == null ? void 0 : conf.User) || {};
    const username = pickAccountName(conf);
    if (!username) return null;
    return {
      user_id: String(user.userId || user.UserId || ""),
      user_name: String(user.userName || user.UserName || username),
      user_nickname: String(user.userNickname || user.UserNickname || username),
      user_avatar_url: String(user.userAvatarURL || user.UserAvatarURL || "")
    };
  };
  const syncDefaultUserWithSiyuan = (state, account) => {
    var _a2;
    if (!((_a2 = state == null ? void 0 : state.users) == null ? void 0 : _a2.length)) state.users = [defaultAdminUser()];
    const admin = state.users.find((user) => Number(user.role) === USER_ROLE.ADMIN) || state.users[0];
    if (!(account == null ? void 0 : account.user_nickname) && !(account == null ? void 0 : account.user_name)) {
      Object.assign(admin, normalizeUser(admin, 0), {
        id: Number(admin.id || 1),
        role: USER_ROLE.ADMIN,
        disabled: false,
        permission: Number(admin.permission || ADMIN_PERMISSION)
      });
      return false;
    }
    const username = account.user_nickname || account.user_name;
    const changed = admin.username !== username || JSON.stringify(admin.siyuan_account || null) !== JSON.stringify(account);
    Object.assign(admin, normalizeUser(admin, 0), {
      id: Number(admin.id || 1),
      username,
      role: USER_ROLE.ADMIN,
      disabled: false,
      base_path: normalizePath(admin.base_path || "/"),
      permission: Number(admin.permission || ADMIN_PERMISSION),
      sso_id: admin.sso_id || account.user_id || "",
      siyuan_account: account
    });
    return changed;
  };
  const field = (name, type = "string", defaultValue = "", options = "", required = false, help = "") => ({
    name,
    type,
    default: String(defaultValue ?? ""),
    options: Array.isArray(options) ? options.join(",") : options,
    required,
    help
  });
  const unsupported = (name, extra = [], common = [rootPath$1("/")]) => ({
    common,
    additional: extra,
    config: {
      name,
      local_sort: true,
      only_proxy: true,
      no_cache: false,
      no_upload: true,
      need_ms: false,
      default_root: "/",
      alert: "warning",
      only_indices: false,
      prefer_proxy: true,
      status: "metadata-only",
      note: "Driver metadata is copied for mount creation. Runtime behavior is still being ported to the SiYuan kernel JS environment."
    }
  });
  const supported = (name, extra = [], common) => {
    const info = unsupported(name, extra, common);
    info.config.status = "ported";
    info.config.note = "Runtime behavior is wired through SiYuan /api/network/forwardProxy in the kernel plugin.";
    info.config.no_upload = false;
    info.config.only_proxy = false;
    info.config.prefer_proxy = false;
    return info;
  };
  const preferProxy = (info) => {
    info.config.prefer_proxy = true;
    return info;
  };
  const configPatch = (info, patch) => {
    Object.assign(info.config, patch);
    return info;
  };
  const text = (name, required = false, help = "") => field(name, "string", "", "", required, help);
  const password = (name, required = false, help = "") => field(name, "password", "", "", required, help);
  const bool = (name, defaultValue = false, help = "") => field(name, "bool", defaultValue, "", false, help);
  const number = (name, defaultValue = "", required = false, help = "") => field(name, "number", defaultValue, "", required, help);
  const float = (name, defaultValue = "", required = false, help = "") => field(name, "float", defaultValue, "", required, help);
  const select = (name, options, defaultValue = "", required = false, help = "") => field(name, "select", defaultValue, options, required, help);
  const rootPath$1 = (defaultValue = "/") => field("root_folder_path", "string", defaultValue, "", false, "OpenList root folder path.");
  const rootId$4 = (defaultValue = "") => field("root_folder_id", "string", defaultValue, "", false, defaultValue ? `OpenList default root: ${defaultValue}` : "");
  const metadataOnlyNames = [
    "139Yun",
    "Alias",
    "AutoIndex",
    "Azure Blob Storage",
    "BaiduPhoto",
    "CNB Releases",
    "ChaoXingGroupDrive",
    "Chunk",
    "Cloudreve V4",
    "Crypt",
    "Degoo",
    "Doubao",
    "DoubaoNew",
    "DoubaoShare",
    "FTP",
    "FebBox",
    "FeijiPan",
    "GitHub API",
    "GitHub Releases",
    "HalalCloud",
    "HalalCloudOpen",
    "ILanZou",
    "IPFS API",
    "KodBox",
    "LenovoNasShare",
    "MediaFire",
    "MediaTrack",
    "Mega_nz",
    "Misskey",
    "MoPan",
    "NeteaseMusic",
    "OpenListShare",
    "PikPakShare",
    "ProtonDrive",
    "Seafile",
    "Strm",
    "Teambition",
    "Teldrive",
    "Template",
    "Terabox",
    "ThunderBrowser",
    "ThunderBrowserExpert",
    "ThunderExpert",
    "ThunderX",
    "ThunderXExpert",
    "UrlTree",
    "WeiYun",
    "WoPan",
    "YandexDisk"
  ];
  const withAliases = (map) => ({
    ...map,
    "115": map["115 Cloud"],
    "115Open": map["115 Open"],
    "115Share": map["115 Share"],
    "123": map["123Pan"],
    "123Open": map["123 Open"],
    "123Share": map["123PanShare"],
    "AliyunDrive": map.Aliyundrive,
    "AliyunDriveOpen": map.AliyundriveOpen,
    "AliyunDriveShare": map.AliyundriveShare,
    "OneDrive": map.Onedrive
  });
  const buildDriverInfoMap = () => withAliases({
    ...Object.fromEntries(metadataOnlyNames.map((name) => [name, unsupported(name)])),
    SiYuanWorkspace: {
      common: [field("root_folder_path", "string", "/@workspace", "", false, "SiYuan workspace files exposed through /api/file.")],
      additional: [],
      config: {
        name: "SiYuanWorkspace",
        local_sort: true,
        only_proxy: true,
        no_cache: true,
        no_upload: true,
        need_ms: false,
        default_root: "/@workspace",
        alert: "warning",
        only_indices: false,
        prefer_proxy: true,
        status: "ported",
        note: "Read/list/remove/rename are wired through SiYuan /api/file. Upload is still guarded."
      }
    },
    WebDav: preferProxy(supported("WebDav", [
      select("vendor", ["sharepoint", "other"], "other"),
      text("address", true),
      text("username", true),
      password("password", true),
      bool("tls_insecure_skip_verify", false)
    ])),
    OpenList: configPatch(supported("OpenList", [
      text("url", true),
      password("meta_password"),
      text("username"),
      password("password"),
      password("token"),
      bool("pass_ip_to_upsteam", true),
      bool("pass_ua_to_upsteam", true),
      bool("forward_archive_requests", true),
      bool("pass_refresh_flag_to_upsteam", false)
    ]), { proxy_range_option: true, link_cache_mode: "auto" }),
    AListV3: supported("AListV3", [
      text("url", true),
      text("username"),
      password("password"),
      password("token")
    ]),
    "AList V3": supported("AList V3", [
      text("url", true),
      text("username"),
      password("password"),
      password("token")
    ]),
    S3: configPatch(supported("S3", [
      rootPath$1("/"),
      text("bucket", true),
      text("endpoint", true),
      text("region"),
      text("access_key_id", true),
      password("secret_access_key", true),
      password("session_token"),
      text("custom_host"),
      bool("enable_custom_host_presign", false),
      number("sign_url_expire", 4),
      text("placeholder"),
      bool("force_path_style", false),
      select("list_object_version", ["v1", "v2"], "v1"),
      bool("remove_bucket", false),
      bool("add_filename_to_disposition", false),
      bool("enable_direct_upload", false),
      text("direct_upload_host")
    ]), { check_status: true }),
    Doge: configPatch(supported("Doge", [
      rootPath$1("/"),
      text("bucket", true),
      text("endpoint", true),
      text("region"),
      text("access_key_id", true),
      password("secret_access_key", true),
      password("session_token"),
      text("custom_host"),
      bool("enable_custom_host_presign", false),
      number("sign_url_expire", 4),
      text("placeholder"),
      bool("force_path_style", false),
      select("list_object_version", ["v1", "v2"], "v1"),
      bool("remove_bucket", false),
      bool("add_filename_to_disposition", false),
      bool("enable_direct_upload", false),
      text("direct_upload_host")
    ]), { check_status: true }),
    "115 Cloud": configPatch(supported("115 Cloud", [
      rootId$4("0"),
      text("cookie", false, "one of QR code token and cookie required"),
      text("qrcode_token", false, "one of QR code token and cookie required"),
      select("qrcode_source", ["web", "android", "ios", "tv", "alipaymini", "wechatmini", "qandroid"], "web"),
      number("page_size", 1e3),
      float("limit_rate", 2)
    ]), {
      link_cache_mode: "ua",
      no_upload: true,
      prefer_proxy: true,
      note: "Runtime ports OpenList 115 Cloud cookie/QR-token login, list/get/read/link, basic management, and storage details. Upload/offline download remain structured placeholders."
    }),
    "115 Open": configPatch(supported("115 Open", [
      rootId$4("0"),
      select("order_by", ["file_name", "file_size", "user_utime", "file_type"], "file_name"),
      select("order_direction", ["asc", "desc"], "asc"),
      float("limit_rate", 1),
      number("page_size", 200),
      password("access_token", true),
      password("refresh_token", true)
    ]), {
      default_root: "0",
      link_cache_mode: "ua",
      no_upload: true,
      prefer_proxy: true,
      note: "Runtime ports OpenList 115 Open token refresh, list/get/read/link, basic management, details, and offline add. Upload remains a structured placeholder."
    }),
    "115 Share": configPatch(supported("115 Share", [
      text("cookie", false, "one of QR code token and cookie required"),
      text("qrcode_token", false, "one of QR code token and cookie required"),
      select("qrcode_source", ["web", "android", "ios", "tv", "alipaymini", "wechatmini", "qandroid"], "web"),
      number("page_size", 1e3),
      float("limit_rate", 2),
      text("share_code", true),
      password("receive_code", true),
      rootId$4("0")
    ]), {
      default_root: "0",
      link_cache_mode: "ua",
      no_upload: true,
      note: "Runtime ports OpenList 115 Share cookie/QR-token login, list/get/read/link. OpenList marks management and upload as NotSupport."
    }),
    "123Pan": preferProxy(supported("123Pan", [
      rootId$4("0"),
      text("username", true),
      password("password", true),
      password("access_token"),
      number("UploadThread", 3),
      field("platform", "string", "web", "", false, "the platform header value, sent with API requests")
    ])),
    "123 Open": unsupported("123 Open", [
      rootId$4(),
      text("ClientID"),
      password("ClientSecret"),
      password("AccessToken"),
      password("RefreshToken"),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/123cloud/renewapi"),
      number("UploadThread", 3),
      bool("DirectLink", false),
      password("DirectLinkPrivateKey"),
      number("DirectLinkValidDuration", 30)
    ]),
    "123PanShare": unsupported("123PanShare", [text("share_key", true), password("share_pwd"), rootId$4()]),
    "123PanLink": unsupported("123PanLink", [text("url", true)]),
    "189Cloud": configPatch(supported("189Cloud", [rootId$4("-11"), text("username", true), password("password", true), text("cookie", false, "Fill in the cookie if need captcha")]), {
      alert: "info|You can try to use 189PC driver if this driver does not work."
    }),
    "189CloudPC": configPatch(supported("189CloudPC", [
      select("login_type", ["password", "qrcode"], "password", true),
      text("username", true),
      password("password", true),
      text("validate_code"),
      password("access_token"),
      password("refresh_token", false, "To switch accounts, please clear this field"),
      rootId$4("-11"),
      select("order_by", ["filename", "filesize", "lastOpTime"], "filename"),
      select("order_direction", ["asc", "desc"], "asc"),
      select("type", ["personal", "family"], "personal"),
      text("family_id"),
      select("upload_method", ["stream", "rapid", "old"], "stream"),
      field("upload_thread", "string", "3", "", false, "1<=thread<=32"),
      bool("family_transfer", false),
      bool("rapid_upload", false),
      bool("no_use_ocr", false),
      bool("generate_torrent", false, "Generate torrent file with CAS extension after upload")
    ]), {
      check_status: true,
      note: "Runtime ports OpenList 189CloudPC QR login, session refresh, family-cloud ID refill, list/get/read/link, and basic management. Password login and upload remain structured placeholders."
    }),
    "189CloudTV": configPatch(supported("189CloudTV", [
      rootId$4("-11"),
      password("access_token"),
      select("order_by", ["filename", "filesize", "lastOpTime"], "filename"),
      select("order_direction", ["asc", "desc"], "asc"),
      select("type", ["personal", "family"], "personal"),
      text("family_id"),
      field("upload_thread", "string", "3", "", false, "1<=thread<=32"),
      bool("rapid_upload", false)
    ]), {
      check_status: true,
      note: "Runtime ports OpenList 189CloudTV QR login, session refresh, family-cloud ID refill, list/get/read/link, and basic management. Upload remains a structured placeholder."
    }),
    Aliyundrive: unsupported("Aliyundrive", [
      rootId$4("root"),
      password("refresh_token", true),
      select("order_by", ["name", "size", "updated_at", "created_at"]),
      select("order_direction", ["ASC", "DESC"]),
      bool("rapid_upload", false),
      bool("internal_upload", false)
    ]),
    AliyundriveOpen: configPatch(supported("AliyundriveOpen", [
      select("drive_type", ["default", "resource", "backup"], "resource"),
      rootId$4(),
      password("refresh_token", true),
      select("order_by", ["name", "size", "updated_at", "created_at"]),
      select("order_direction", ["ASC", "DESC"]),
      bool("use_online_api", true),
      select("alipan_type", ["default", "alipanTV"], "default", true),
      field("api_url_address", "string", "https://api.oplist.org/alicloud/renewapi"),
      text("client_id"),
      password("client_secret"),
      select("remove_way", ["trash", "delete"], "trash", true),
      bool("rapid_upload", false),
      bool("internal_upload", false),
      select("livp_download_format", ["jpeg", "mov"], "jpeg"),
      password("access_token")
    ]), { default_root: "root", no_overwrite_upload: true }),
    AliyundriveShare: unsupported("AliyundriveShare", [
      rootId$4(),
      password("refresh_token", true),
      text("share_id", true),
      password("share_pwd"),
      select("order_by", ["name", "size", "updated_at", "created_at"]),
      select("order_direction", ["ASC", "DESC"])
    ]),
    BaiduNetdisk: preferProxy(supported("BaiduNetdisk", [
      rootPath$1("/"),
      select("order_by", ["name", "time", "size"], "name"),
      select("order_direction", ["asc", "desc"], "asc"),
      select("download_api", ["official", "crack", "crack_video"], "crack_video"),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/baiduyun/renewapi"),
      text("client_id"),
      password("client_secret"),
      field("custom_crack_ua", "string", "netdisk", "", true),
      password("access_token"),
      password("refresh_token", true),
      number("upload_thread", 3),
      number("upload_timeout", 60),
      field("upload_api", "string", "https://d.pcs.baidu.com"),
      bool("use_dynamic_upload_api", true),
      number("custom_upload_part_size", 0),
      bool("low_bandwith_upload_mode", false),
      bool("only_list_video_file", false)
    ])),
    Cloudreve: unsupported("Cloudreve", [text("address", true), text("username"), password("password"), password("token")]),
    Dropbox: unsupported("Dropbox", [password("refresh_token", true), text("client_id"), password("client_secret")]),
    GoogleDrive: unsupported("GoogleDrive", [
      rootId$4(),
      password("refresh_token", true),
      text("order_by", false, "such as: folder,name,modifiedTime"),
      select("order_direction", ["asc", "desc"]),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/googleui/renewapi"),
      text("client_id"),
      password("client_secret"),
      number("chunk_size", 5),
      bool("disable_disk_usage", false)
    ]),
    GooglePhoto: unsupported("GooglePhoto", [
      rootId$4(),
      password("refresh_token", true),
      field("client_id", "string", "202264815644.apps.googleusercontent.com", "", true),
      field("client_secret", "password", "X4Z3ca8xfWDb1Voo-F9a7ZxJ", "", true),
      bool("show_archive", false)
    ]),
    Lanzou: unsupported("Lanzou", [password("cookie", true)]),
    Onedrive: supported("Onedrive", [
      rootPath$1("/"),
      select("region", ["global", "cn", "us", "de"], "global", true),
      bool("is_sharepoint", false),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/onedrive/renewapi"),
      text("client_id"),
      password("client_secret"),
      field("redirect_uri", "string", "https://api.oplist.org/onedrive/callback", "", true),
      password("refresh_token", true),
      text("site_id"),
      number("chunk_size", 5),
      text("custom_host"),
      bool("disable_disk_usage", false),
      bool("enable_direct_upload", false)
    ]),
    OnedriveAPP: unsupported("OnedriveAPP", [
      rootPath$1("/"),
      select("region", ["global", "cn", "us", "de"], "global", true),
      text("client_id", true),
      password("client_secret", true),
      text("tenant_id"),
      text("email"),
      number("chunk_size", 5),
      text("custom_host"),
      bool("disable_disk_usage", false),
      bool("enable_direct_upload", false)
    ]),
    "Onedrive Sharelink": unsupported("Onedrive Sharelink", [text("share_url", true), rootPath$1("/")]),
    PikPak: unsupported("PikPak", [text("username", true), password("password", true)]),
    Quark: configPatch(supported("Quark", [
      password("cookie", true),
      rootId$4("0"),
      select("order_by", ["none", "file_type", "file_name", "updated_at"], "none"),
      select("order_direction", ["asc", "desc"], "asc"),
      bool("use_transcoding_address", false),
      bool("only_list_video_file", false),
      number("addition_version", 2)
    ]), { default_root: "0", no_overwrite_upload: true }),
    UC: configPatch(supported("UC", [
      password("cookie", true),
      rootId$4("0"),
      select("order_by", ["none", "file_type", "file_name", "updated_at"], "none"),
      select("order_direction", ["asc", "desc"], "asc"),
      bool("use_transcoding_address", false),
      bool("only_list_video_file", false),
      number("addition_version", 2)
    ]), {
      default_root: "0",
      no_overwrite_upload: true,
      only_proxy: true
    }),
    QuarkOpen: configPatch(supported("QuarkOpen", [
      rootId$4("0"),
      select("order_by", ["none", "file_type", "file_name", "updated_at", "created_at"], "none"),
      select("order_direction", ["asc", "desc"], "asc"),
      bool("use_online_api", true),
      field("api_url_address", "string", "https://api.oplist.org/quarkyun/renewapi"),
      password("access_token"),
      password("refresh_token", true),
      text("app_id", false, "Built-in public AppID is used when empty"),
      password("sign_key", false, "Built-in public SignKey is used when empty")
    ]), {
      default_root: "0",
      no_overwrite_upload: true,
      only_proxy: true,
      note: "Runtime ports OpenList QuarkOpen list/get/read/link, basic management, and multipart upload."
    }),
    QuarkTV: configPatch(supported("QuarkTV", [
      rootId$4("0"),
      select("order_by", ["file_name", "updated_at"], "updated_at"),
      select("order_direction", ["asc", "desc"], "desc"),
      password("refresh_token"),
      text("device_id"),
      text("query_token", false, "don't edit'"),
      select("link_method", ["download", "streaming"], "streaming", true)
    ]), {
      default_root: "0",
      no_overwrite_upload: true,
      no_upload: true,
      note: "Runtime ports OpenList QuarkTV login token refresh, list/get/read/link. OpenList marks management and upload methods as NotImplement."
    }),
    UCTV: configPatch(supported("UCTV", [
      rootId$4("0"),
      select("order_by", ["file_name", "updated_at"], "updated_at"),
      select("order_direction", ["asc", "desc"], "desc"),
      password("refresh_token"),
      text("device_id"),
      text("query_token", false, "don't edit'"),
      select("link_method", ["download", "streaming"], "streaming", true)
    ]), {
      default_root: "0",
      no_overwrite_upload: true,
      no_upload: true,
      note: "Runtime ports OpenList UCTV login token refresh, list/get/read/link. OpenList marks management and upload methods as NotImplement."
    }),
    SFTP: unsupported("SFTP", [text("address", true), text("username", true), password("password"), password("private_key")]),
    SMB: unsupported("SMB", [text("address", true), text("username"), password("password"), text("share_name")]),
    Thunder: unsupported("Thunder", [text("username"), password("password"), password("refresh_token")]),
    URLTree: unsupported("URLTree", [text("url", true)]),
    USS: unsupported("USS", [text("bucket", true), text("endpoint", true), text("operator", true), password("password", true)]),
    Virtual: unsupported("Virtual", []),
    WPS: configPatch(supported("WPS", [
      rootPath$1("/"),
      password("cookie", true, "Get Cookie from a fresh or incognito browser session."),
      select("mode", ["Personal", "Business"], "Personal"),
      text("custom_ua", false, "Custom User-Agent copied with the Cookie request.")
    ]), {
      check_status: true,
      no_upload: true,
      note: "Runtime ports OpenList WPS login check, root/group listing, get/read/link, basic management, and storage details. Upload remains disabled in the SiYuan kernel JavaScript runtime to avoid blocking the UI thread."
    }),
    Local: configPatch(unsupported("Local", [
      rootPath$1("/"),
      bool("directory_size", false, "This might impact host performance"),
      bool("thumbnail", false, "enable thumbnail"),
      text("thumb_cache_folder"),
      field("thumb_concurrency", "string", "16", "", false, "Number of concurrent thumbnail generation goroutines."),
      field("video_thumb_pos", "string", "20%", "", false, "The position of the video thumbnail."),
      bool("show_hidden", true, "show hidden directories and files"),
      field("mkdir_perm", "string", "777"),
      field("recycle_bin_path", "string", "delete permanently")
    ]), {
      no_cache: true,
      no_link_url: true,
      note: "Desktop frontend runtime accesses host fs through Electron. The kernel OpenList HTTP runtime keeps Local metadata only and does not proxy local disks."
    })
  });
  const driverInfoMap = () => buildDriverInfoMap();
  const exposedDriverNames = [
    "SiYuanWorkspace",
    "Local",
    "WebDav",
    "OpenList",
    "AListV3",
    "AList V3",
    "S3",
    "Doge",
    "115 Cloud",
    "115 Open",
    "115 Share",
    "123Pan",
    "189Cloud",
    "189CloudPC",
    "189CloudTV",
    "AliyundriveOpen",
    "BaiduNetdisk",
    "Onedrive",
    "Quark",
    "QuarkOpen",
    "QuarkTV",
    "UC",
    "UCTV",
    "WPS"
  ];
  const driverNames = () => {
    const map = driverInfoMap();
    return exposedDriverNames.filter((name) => map[name]);
  };
  const boolValue$3 = (value, fallback = false) => {
    if (value === void 0 || value === null || value === "") return fallback;
    return value === true || value === "true" || value === 1 || value === "1";
  };
  const numberValue = (value, fallback = 0) => {
    const number2 = Number(value);
    return Number.isFinite(number2) ? number2 : fallback;
  };
  const parseTime$1 = (value) => {
    if (!value) return (/* @__PURE__ */ new Date()).toISOString();
    if (typeof value === "number") {
      const date2 = new Date(value > 1e11 ? value : value * 1e3);
      return Number.isNaN(date2.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date2.toISOString();
    }
    const normalized = String(value).replace(/-/g, "/");
    const date = new Date(normalized);
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const dirnameOf = dirname;
  const basenameOf = basename;
  const rawDownloadUrl = (storage, relPath, proxy2 = false) => {
    const prefix = proxy2 ? "/p" : "/d";
    return `/plugin/private/siyuan-cloud${prefix}${normalizePath(storage.mount_path + "/" + relPath)}`;
  };
  const headerValue$8 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const userAgentFromOptions = (options = {}, fallback = "") => options.userAgent || headerValue$8(options.requestHeaders, "User-Agent") || headerValue$8(options.headers, "User-Agent") || fallback;
  const persistAddition$1 = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const createStorageCache = ({ ttl = 5 * 60 * 1e3, linkTtl = 30 * 60 * 1e3 } = {}) => {
    const list = /* @__PURE__ */ new Map();
    const file = /* @__PURE__ */ new Map();
    const link2 = /* @__PURE__ */ new Map();
    const storageKey2 = (storage) => String(storage.id || storage.mount_path || JSON.stringify(storage.addition_json || {}));
    const cached2 = async (map, key, producer, ttlMs = ttl) => {
      const now = Date.now();
      const hit = map.get(key);
      if (hit && hit.expires > now) return hit.value;
      const value = await producer();
      map.set(key, { value, expires: now + ttlMs });
      return value;
    };
    const clear = (storage) => {
      const prefix = `${storageKey2(storage)}:`;
      for (const map of [list, file, link2]) {
        for (const key of map.keys()) {
          if (key.startsWith(prefix)) map.delete(key);
        }
      }
    };
    return {
      clear,
      file: (storage, key, producer) => cached2(file, `${storageKey2(storage)}:file:${key}`, producer),
      link: (storage, key, producer) => cached2(link2, `${storageKey2(storage)}:link:${key}`, producer, linkTtl),
      list: (storage, key, producer) => cached2(list, `${storageKey2(storage)}:list:${key}`, producer)
    };
  };
  const encodePayload = (payload) => {
    if (payload === void 0 || payload === null) return "";
    return typeof payload === "string" ? payload : JSON.stringify(payload);
  };
  const proxyPayload = (body, contentType) => {
    if (body === void 0 || body === null) return { payload: "", payloadEncoding: "text" };
    if (typeof body !== "string" && String(contentType || "").includes("application/json")) {
      return { payload: body, payloadEncoding: "json" };
    }
    return { payload: encodePayload(body), payloadEncoding: "json" };
  };
  const forwardProxy = async (client, url, {
    body,
    allowErrorStatus = false,
    contentType = "application/json",
    headers = {},
    method = "GET",
    payloadEncoding,
    redirect,
    responseEncoding = "text",
    timeout = 3e4
  } = {}) => {
    const hasBody = body !== void 0 && body !== null;
    const encoded = hasBody ? payloadEncoding ? { payload: body, payloadEncoding } : proxyPayload(body, contentType) : null;
    const headerPairs = Object.entries(headers).filter(([, value]) => value !== void 0 && value !== null && value !== "").map(([key, value]) => ({ [key]: String(value) }));
    const proxyRequest = {
      url,
      method,
      headers: headerPairs,
      responseEncoding,
      timeout
    };
    if (encoded) {
      proxyRequest.payload = encoded.payload;
      proxyRequest.payloadEncoding = encoded.payloadEncoding;
    }
    if (hasBody && contentType !== "" && contentType !== null) proxyRequest.contentType = contentType;
    if (typeof redirect === "boolean") proxyRequest.redirect = redirect;
    const response = await client.fetch("/api/network/forwardProxy", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(proxyRequest)
    });
    const payload = await response.json();
    if (payload.code !== 0) throw new Error(payload.msg || "forwardProxy failed");
    const data = payload.data || {};
    if (!allowErrorStatus && data.status >= 400) throw new Error(`HTTP ${data.status}: ${String(data.body || "").slice(0, 300)}`);
    return data;
  };
  const remoteJsonWithMeta = async (client, url, options) => {
    const data = await forwardProxy(client, url, options);
    try {
      return {
        json: JSON.parse(data.body || "{}"),
        meta: data
      };
    } catch (error) {
      throw new Error(`invalid JSON response from ${url}: ${error.message}`);
    }
  };
  const remoteJson = async (client, url, options) => {
    const { json } = await remoteJsonWithMeta(client, url, options);
    return json;
  };
  const basicAuth = (username, password2) => {
    if (!username && !password2) return "";
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const input = unescape(encodeURIComponent(`${username || ""}:${password2 || ""}`));
    let output = "";
    for (let i2 = 0; i2 < input.length; i2 += 3) {
      const a = input.charCodeAt(i2);
      const b = input.charCodeAt(i2 + 1);
      const c = input.charCodeAt(i2 + 2);
      output += chars2[a >> 2];
      output += chars2[(a & 3) << 4 | (Number.isNaN(b) ? 0 : b >> 4)];
      output += Number.isNaN(b) ? "=" : chars2[(b & 15) << 2 | (Number.isNaN(c) ? 0 : c >> 6)];
      output += Number.isNaN(c) ? "=" : chars2[c & 63];
    }
    return `Basic ${output}`;
  };
  const joinUrl = (base, path) => {
    const trimmed = String(base || "").replace(/\/+$/, "");
    const encoded = String(path || "/").split("/").filter(Boolean).map((part) => encodeURIComponent(part)).join("/");
    return encoded ? `${trimmed}/${encoded}` : `${trimmed}/`;
  };
  const qrVerify = ({
    message = "",
    qrData = "",
    qr_data,
    qrSrc = "",
    qr_src,
    qrText = "",
    qr_text,
    status = "pending"
  } = {}) => ({
    message,
    qr_data: qrData || qr_data || "",
    qr_src: qrSrc || qr_src || "",
    qr_text: qrText || qr_text || "",
    status,
    type: "qrcode"
  });
  const qrVerifyError = (message, addition, verify) => {
    const error = new Error(message);
    error.addition = addition;
    error.verify = verify;
    return error;
  };
  const clearQrKeys = (addition, keys) => {
    for (const key of keys) delete addition[key];
  };
  const runQrLogin = async ({
    addition,
    clear,
    confirm,
    hasSession,
    pendingVerify,
    poll,
    start
  }) => {
    if (!hasSession(addition)) {
      const started = await start();
      throw qrVerifyError(started.message || "QR login pending", addition, qrVerify({
        ...started.verify,
        message: started.message || "",
        status: started.status || "waiting"
      }));
    }
    const state = await poll();
    if (state.status === "success") {
      const result = await confirm(state);
      await (clear == null ? void 0 : clear());
      return result;
    }
    if (state.status === "expired" || state.status === "canceled") {
      await (clear == null ? void 0 : clear());
      throw qrVerifyError(state.message || "QR code expired", addition, qrVerify({
        message: state.message || "",
        status: state.status
      }));
    }
    throw qrVerifyError(state.message || "QR login pending", addition, qrVerify({
      ...pendingVerify(),
      message: state.message || "",
      status: state.status || "pending"
    }));
  };
  const N = BigInt("0x8686980c0f5a24c4b9d43020cd2c22703ff3f450756529058b1cf88f09b8602136477198a6e2683149659bd122c33592fdb5ad47944ad1ea4d36c6b172aad6338c3bb6ac6227502d010993ac967d1aef00f0c8e038de2e4d3bc2ec368af2e9f10a6f1eda4f7262f136420c07c331b871bf139f74f3010e3c4fe57df3afb71683");
  const E = BigInt("0x10001");
  const KEY_LENGTH = 128;
  const xorKeySeed = [
    240,
    229,
    105,
    174,
    191,
    220,
    191,
    138,
    26,
    69,
    232,
    190,
    125,
    166,
    115,
    184,
    222,
    143,
    231,
    196,
    69,
    218,
    134,
    196,
    155,
    100,
    139,
    20,
    106,
    180,
    241,
    170,
    56,
    1,
    53,
    158,
    38,
    105,
    44,
    134,
    0,
    107,
    79,
    165,
    54,
    52,
    98,
    166,
    42,
    150,
    104,
    24,
    242,
    74,
    253,
    189,
    107,
    151,
    143,
    77,
    143,
    137,
    19,
    183,
    108,
    142,
    147,
    237,
    14,
    13,
    72,
    62,
    215,
    47,
    136,
    216,
    254,
    254,
    126,
    134,
    80,
    149,
    79,
    209,
    235,
    131,
    38,
    52,
    219,
    102,
    123,
    156,
    126,
    157,
    122,
    129,
    50,
    234,
    182,
    51,
    222,
    58,
    169,
    89,
    52,
    102,
    59,
    170,
    186,
    129,
    96,
    72,
    185,
    213,
    129,
    156,
    248,
    108,
    132,
    119,
    255,
    84,
    120,
    38,
    95,
    190,
    232,
    30,
    54,
    159,
    52,
    128,
    92,
    69,
    44,
    155,
    118,
    213,
    27,
    143,
    204,
    195,
    184,
    245
  ];
  const xorClientKey = [120, 6, 173, 76, 51, 134, 93, 24, 76, 1, 63, 70];
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const utf8Bytes$8 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    return Uint8Array.from([...text2].map((char) => char.charCodeAt(0)));
  };
  const utf8Text = (bytes2) => {
    const binary = [...bytes2].map((byte) => String.fromCharCode(byte)).join("");
    try {
      return decodeURIComponent(escape(binary));
    } catch (_) {
      return binary;
    }
  };
  const bytesToBase64$9 = (bytes2) => {
    let out = "";
    for (let i2 = 0; i2 < bytes2.length; i2 += 3) {
      const a = bytes2[i2];
      const b = bytes2[i2 + 1];
      const c = bytes2[i2 + 2];
      out += chars[a >> 2];
      out += chars[(a & 3) << 4 | (b || 0) >> 4];
      out += i2 + 1 < bytes2.length ? chars[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i2 + 2 < bytes2.length ? chars[c & 63] : "=";
    }
    return out;
  };
  const base64ToBytes$a = (value) => {
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars.indexOf(clean[i2]);
      const b = chars.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const modPow$1 = (base, exp, mod) => {
    let result = 1n;
    let value = base % mod;
    let power = exp;
    while (power > 0n) {
      if (power & 1n) result = result * value % mod;
      value = value * value % mod;
      power >>= 1n;
    }
    return result;
  };
  const bytesToBigInt$1 = (bytes2) => {
    let value = 0n;
    for (const byte of bytes2) value = (value << 8n) + BigInt(byte);
    return value;
  };
  const bigIntToBytes$1 = (value, length) => {
    const out = new Uint8Array(length);
    let current = value;
    for (let i2 = length - 1; i2 >= 0; i2 -= 1) {
      out[i2] = Number(current & 0xffn);
      current >>= 8n;
    }
    return out;
  };
  const bigIntToMinimalBytes = (value) => {
    if (value === 0n) return new Uint8Array();
    const out = [];
    let current = value;
    while (current > 0n) {
      out.unshift(Number(current & 0xffn));
      current >>= 8n;
    }
    return Uint8Array.from(out);
  };
  const randomNonZero = () => Math.floor(Math.random() * 255) + 1;
  const rsaEncryptSlice = (input) => {
    const padSize = KEY_LENGTH - input.length - 3;
    const block = new Uint8Array(KEY_LENGTH);
    block[0] = 0;
    block[1] = 2;
    for (let i2 = 0; i2 < padSize; i2 += 1) block[2 + i2] = randomNonZero();
    block[padSize + 2] = 0;
    block.set(input, padSize + 3);
    return bigIntToBytes$1(modPow$1(bytesToBigInt$1(block), E, N), KEY_LENGTH);
  };
  const rsaEncrypt = (input) => {
    const chunks = [];
    for (let i2 = 0; i2 < input.length; i2 += KEY_LENGTH - 11) {
      chunks.push(rsaEncryptSlice(input.slice(i2, i2 + KEY_LENGTH - 11)));
    }
    return Uint8Array.from(chunks.flatMap((chunk) => [...chunk]));
  };
  const rsaDecryptSlice = (input) => {
    const data = bigIntToMinimalBytes(modPow$1(bytesToBigInt$1(input), E, N));
    const start = data.findIndex((byte, index) => index > 0 && byte === 0);
    return start >= 0 ? data.slice(start + 1) : new Uint8Array();
  };
  const rsaDecrypt = (input) => {
    const chunks = [];
    for (let i2 = 0; i2 < input.length; i2 += KEY_LENGTH) chunks.push(rsaDecryptSlice(input.slice(i2, i2 + KEY_LENGTH)));
    return Uint8Array.from(chunks.flatMap((chunk) => [...chunk]));
  };
  const xorDeriveKey = (seed, size) => {
    const key = new Uint8Array(size);
    for (let i2 = 0; i2 < size; i2 += 1) {
      key[i2] = seed[i2] + xorKeySeed[size * i2] & 255 ^ xorKeySeed[size * (size - i2 - 1)];
    }
    return key;
  };
  const xorTransform = (data, key) => {
    const mod = data.length % 4;
    for (let i2 = 0; i2 < data.length; i2 += 1) {
      const keyIndex = i2 < mod ? i2 % key.length : (i2 - mod) % key.length;
      data[i2] ^= key[keyIndex];
    }
  };
  const reverse = (data) => data.reverse();
  const generateKey = () => Uint8Array.from({ length: 16 }, () => Math.floor(Math.random() * 256));
  const encode115 = (input, key = generateKey()) => {
    const bytes2 = utf8Bytes$8(input);
    const buf = new Uint8Array(16 + bytes2.length);
    buf.set(key, 0);
    buf.set(bytes2, 16);
    const body = buf.slice(16);
    xorTransform(body, xorDeriveKey(key, 4));
    reverse(body);
    xorTransform(body, xorClientKey);
    buf.set(body, 16);
    return bytesToBase64$9(rsaEncrypt(buf));
  };
  const decode115WithKey = (input, key) => {
    const data = rsaDecrypt(base64ToBytes$a(input));
    const decodeKey = key || data.slice(0, 16);
    const output = data.slice(16);
    xorTransform(output, xorDeriveKey(data.slice(0, 16), 12));
    reverse(output);
    xorTransform(output, xorDeriveKey(decodeKey, 4));
    return {
      key: data.slice(0, 16),
      text: utf8Text(output)
    };
  };
  const decode115 = (input, key) => decode115WithKey(input, key).text;
  const API_LOGIN_CHECK$1 = "https://passportapi.115.com/app/1.0/web/1.0/check/sso";
  const API_FILE_LIST = "https://webapi.115.com/files";
  const API_DIR_ADD = "https://webapi.115.com/files/add";
  const API_FILE_DELETE = "https://webapi.115.com/rb/delete";
  const API_FILE_MOVE = "https://webapi.115.com/files/move";
  const API_FILE_COPY = "https://webapi.115.com/files/copy";
  const API_FILE_RENAME = "https://webapi.115.com/files/batch_rename";
  const API_FILE_INDEX_INFO = "https://webapi.115.com/files/index_info";
  const API_FILE_INFO = "https://webapi.115.com/files/get_info";
  const API_DOWNLOAD_URL = "https://proapi.115.com/app/chrome/downurl";
  const API_QRCODE_TOKEN$1 = "https://qrcodeapi.115.com/api/1.0/web/1.0/token";
  const API_QRCODE_STATUS$1 = "https://qrcodeapi.115.com/get/status/";
  const API_QRCODE_LOGIN$1 = "https://passportapi.115.com/app/1.0/%s/1.0/login/qrcode";
  const UA$3 = "Mozilla/5.0 115Browser/35.6.0.3";
  const MAX_PAGE_SIZE$1 = 1150;
  const QR_KEYS$2 = ["qrcode_sign", "QRCodeSign", "qrcode_time", "QRCodeTime", "qrcode_content", "QRCodeContent", "qrcode_cookie", "QRCodeCookie"];
  const DOWNLOAD_CACHE_TTL = 5 * 60 * 1e3;
  const downloadInfoCache = /* @__PURE__ */ new WeakMap();
  const limiterState$2 = /* @__PURE__ */ new WeakMap();
  const additionValue$3 = (addition, lowerName, upperName, fallback = "") => {
    const value = (addition == null ? void 0 : addition[lowerName]) ?? (addition == null ? void 0 : addition[upperName]);
    return value === void 0 || value === null || value === "" ? fallback : value;
  };
  const qrSource$1 = (addition) => {
    return String(additionValue$3(addition, "qrcode_source", "QRCodeSource", "web") || "web").trim();
  };
  const cookieHeader$3 = (addition) => additionValue$3(addition, "cookie", "Cookie");
  const qrCookieHeader$1 = (addition) => additionValue$3(addition, "qrcode_cookie", "QRCodeCookie");
  const rootId$3 = (addition) => additionValue$3(addition, "root_folder_id", "RootFolderID", "0");
  const pageSize$2 = (addition) => Math.min(MAX_PAGE_SIZE$1, Math.max(1, Number(additionValue$3(addition, "page_size", "PageSize", 1e3)) || 1e3));
  const limitRate$2 = (addition) => Math.max(0, Number(additionValue$3(addition, "limit_rate", "LimitRate", 2)) || 0);
  const toForm = (data) => Object.entries(data).filter(([, value]) => value !== void 0 && value !== null).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`).join("&");
  const setCookieValues$1 = (headers) => {
    const pairs = Object.entries(headers || {});
    const entry = pairs.find(([key]) => key.toLowerCase() === "set-cookie");
    if (!entry) return [];
    return Array.isArray(entry[1]) ? entry[1] : [entry[1]];
  };
  const mergeCookies$3 = (...values) => {
    const map = /* @__PURE__ */ new Map();
    for (const value of values) {
      for (const part of String(value || "").split(";")) {
        const trimmed = part.trim();
        const index = trimmed.indexOf("=");
        if (index > 0) map.set(trimmed.slice(0, index), trimmed.slice(index + 1));
      }
    }
    return [...map.entries()].map(([key, value]) => `${key}=${value}`).join("; ");
  };
  const storeQrCookies$1 = (addition, headers) => {
    const cookies = setCookieValues$1(headers).map((cookie) => String(cookie).split(";")[0]).filter(Boolean);
    if (!cookies.length) return;
    addition.qrcode_cookie = mergeCookies$3(qrCookieHeader$1(addition), cookies.join("; "));
  };
  const requestHeaders$2 = (storage, extra = {}) => ({
    Cookie: cookieHeader$3(storage.addition_json),
    "User-Agent": UA$3,
    ...extra
  });
  const requestQrHeaders$1 = (storage, extra = {}) => ({
    Cookie: mergeCookies$3(cookieHeader$3(storage.addition_json), qrCookieHeader$1(storage.addition_json)),
    "User-Agent": UA$3,
    ...extra
  });
  const buildDownloadHeaders = (headers, responseHeaders) => {
    const result = { ...headers || {} };
    const cookies = [
      result.Cookie || result.cookie || "",
      ...setCookieValues$1(responseHeaders).map((cookie) => String(cookie).split(";")[0])
    ].filter(Boolean);
    if (cookies.length) result.Cookie = mergeCookies$3(...cookies);
    return result;
  };
  const check115$1 = (payload, fallback = "115 request failed") => {
    const code = Number((payload == null ? void 0 : payload.errno) ?? (payload == null ? void 0 : payload.errNo) ?? (payload == null ? void 0 : payload.code) ?? 0);
    if ((payload == null ? void 0 : payload.state) === false || code !== 0 || (payload == null ? void 0 : payload.error)) {
      throw new Error((payload == null ? void 0 : payload.msg) || (payload == null ? void 0 : payload.message) || (payload == null ? void 0 : payload.error) || `${fallback}: ${code}`);
    }
    return payload;
  };
  const requestJson$1 = async (client, storage, url, {
    body,
    headers = {},
    method = "GET",
    query = {},
    qrCookies = false
  } = {}) => {
    var _a2;
    const target = new URL(url);
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const formBody2 = body ? toForm(body) : void 0;
    const request2 = {
      body: formBody2,
      contentType: body ? "application/x-www-form-urlencoded" : "application/json;charset=UTF-8",
      headers: (qrCookies ? requestQrHeaders$1 : requestHeaders$2)(storage, headers),
      method
    };
    const result = await remoteJsonWithMeta(client, target.toString(), request2);
    storeQrCookies$1(storage.addition_json, (_a2 = result.meta) == null ? void 0 : _a2.headers);
    return check115$1(result.json);
  };
  const requestQrStatus$1 = async (client, storage, query) => {
    var _a2;
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") params.set(key, String(value));
    }
    const target = `${API_QRCODE_STATUS$1}?${params.toString()}`;
    const request2 = {
      contentType: "application/json;charset=UTF-8",
      headers: requestQrHeaders$1(storage),
      method: "GET"
    };
    const result = await remoteJsonWithMeta(client, target, request2);
    const payload = result.json;
    storeQrCookies$1(storage.addition_json, (_a2 = result.meta) == null ? void 0 : _a2.headers);
    return check115$1(payload);
  };
  const parse115Time = (value) => {
    if (!value) return (/* @__PURE__ */ new Date()).toISOString();
    if (/^\d+$/.test(String(value))) {
      const date2 = new Date(Number(value) * 1e3);
      return Number.isNaN(date2.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date2.toISOString();
    }
    const date = /* @__PURE__ */ new Date(String(value).replace(/-/g, "/") + " GMT+0800");
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const textValue = (...values) => {
    for (const value of values) {
      if (typeof value === "string" || typeof value === "number") {
        const text2 = String(value).trim();
        if (text2) return text2;
      }
    }
    return "";
  };
  const fileIdOf$1 = (item) => textValue(item == null ? void 0 : item.fid, item == null ? void 0 : item.file_id, item == null ? void 0 : item.fileID, item == null ? void 0 : item.FileID);
  const dirIdOf = (item) => textValue(item == null ? void 0 : item.cid, item == null ? void 0 : item.category_id, item == null ? void 0 : item.categoryID, item == null ? void 0 : item.CategoryID);
  const nameOf = (item) => textValue(item == null ? void 0 : item.n, item == null ? void 0 : item.name, item == null ? void 0 : item.Name);
  const pickCodeOf = (item) => textValue(item == null ? void 0 : item.pc, item == null ? void 0 : item.pick_code, item == null ? void 0 : item.pickcode, item == null ? void 0 : item.pickCode, item == null ? void 0 : item.PickCode);
  const isDirInfo = (item) => !fileIdOf$1(item);
  const fileToObj$c = (item, relPath, storage) => {
    const isDir2 = isDirInfo(item);
    const id = String(isDir2 ? dirIdOf(item) : fileIdOf$1(item));
    return {
      name: String(nameOf(item)),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(item.s || item.size || item.Size || 0),
      modified: parse115Time(item.t || item.update_time || item.UpdateTime),
      created: parse115Time(item.tp || item.create_time || item.CreateTime),
      thumb: item.u || item.thumb_url || item.ThumbURL || "",
      sign: "",
      type: isDir2 ? 1 : 0,
      hashinfo: item.sha || item.sha1 || item.Sha1 || "",
      hash_info: item.sha || item.sha1 || item.Sha1 ? { sha1: item.sha || item.sha1 || item.Sha1 } : {},
      id,
      pick_code: pickCodeOf(item),
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider: "115 Cloud"
    };
  };
  const listById = async (client, storage, id) => {
    const addition = storage.addition_json;
    const limit = pageSize$2(addition);
    const content = [];
    for (let offset = 0; ; offset += limit) {
      const data = await requestJson$1(client, storage, API_FILE_LIST, {
        query: {
          aid: "1",
          asc: "1",
          cid: id || "0",
          fc_mix: "0",
          format: "json",
          limit,
          natsort: "0",
          o: "user_ptime",
          offset,
          record_open_time: "1",
          show_dir: "1",
          snap: "0"
        }
      });
      content.push(...data.data || []);
      if (offset + limit >= Number(data.count || content.length)) break;
    }
    return content;
  };
  const findChild = async (client, storage, parentId, name) => {
    const items = await listById(client, storage, parentId);
    const target = items.find((item) => String(nameOf(item)) === name);
    if (!target) throw new Error(`object [${name}] not found`);
    return target;
  };
  const resolveFile$b = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    if (clean === "/") {
      return {
        cid: rootId$3(storage.addition_json),
        n: "root",
        t: Math.floor(Date.now() / 1e3),
        tp: Math.floor(Date.now() / 1e3)
      };
    }
    const parts = clean.split("/").filter(Boolean);
    let parentId = rootId$3(storage.addition_json);
    let item = null;
    for (const part of parts) {
      item = await findChild(client, storage, parentId, part);
      parentId = String(isDirInfo(item) ? dirIdOf(item) : fileIdOf$1(item));
    }
    return item;
  };
  const getFileById = async (client, storage, id) => {
    const data = await requestJson$1(client, storage, API_FILE_INFO, {
      query: { file_id: id }
    });
    return Array.isArray(data.data) ? data.data[0] || null : data.data || null;
  };
  const saveDriverStorage$1 = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const waitLimit$2 = async (storage) => {
    const rate = limitRate$2(storage.addition_json);
    if (rate <= 0) return;
    const interval = 1e3 / rate;
    const now = Date.now();
    const previous = limiterState$2.get(storage) || 0;
    const wait = Math.max(0, previous - now);
    limiterState$2.set(storage, Math.max(now, previous) + interval);
    if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
  };
  const qrStatus$1 = (payload) => {
    const data = (payload == null ? void 0 : payload.data) || payload || {};
    const raw = data.status ?? data.code ?? data.state ?? data.msg ?? data.message;
    const text2 = String(raw ?? data.msg ?? data.message ?? "").toLowerCase();
    const numeric = typeof raw === "boolean" ? NaN : Number(raw);
    const message = data.msg || data.message || "";
    if (numeric === 2) return { message, raw: payload, status: "success" };
    if (numeric === 1 || /scan|scanned|success|confirm|allowed|confirmed|qrcode_scan_confirmed/.test(text2)) return { message, raw: payload, status: "scanned" };
    if (numeric === -1 || /expire|expired|timeout|time out/.test(text2)) return { message: message || "115 QR code expired", status: "expired" };
    if (numeric === -2 || /cancel|canceled|cancelled/.test(text2)) return { message: message || "115 QR code canceled", status: "canceled" };
    return { message, raw: payload, status: "waiting" };
  };
  const startQrLogin$2 = async (client, storage) => {
    const addition = storage.addition_json;
    addition.qrcode_source = qrSource$1(addition);
    const data = await requestJson$1(client, storage, API_QRCODE_TOKEN$1);
    const session = data.data || {};
    if (!session.uid || !session.sign || !session.time) throw new Error("115 QR token response is empty");
    addition.qrcode_token = session.uid;
    addition.qrcode_sign = session.sign;
    addition.qrcode_time = session.time;
    addition.qrcode_content = session.qrcode || "";
    addition.cookie = "";
    return {
      message: "115 QR login pending",
      status: "waiting",
      verify: { qr_text: session.qrcode || "" }
    };
  };
  const pollQrLogin$2 = async (client, storage) => {
    const addition = storage.addition_json;
    const status = await requestQrStatus$1(client, storage, {
      uid: additionValue$3(addition, "qrcode_token", "QRCodeToken"),
      time: additionValue$3(addition, "qrcode_time", "QRCodeTime"),
      sign: additionValue$3(addition, "qrcode_sign", "QRCodeSign"),
      _: Date.now()
    });
    const state = qrStatus$1(status);
    return { message: state.message || "115 QR login pending", raw: status, status: state.status };
  };
  const run115QrLogin$1 = (client, storage) => runQrLogin({
    addition: storage.addition_json,
    clear: () => clearQrKeys(storage.addition_json, QR_KEYS$2),
    confirm: async () => {
      await loginByQrToken$1(client, storage);
      return ensureLogin$4(client, storage);
    },
    hasSession: (addition) => Boolean(
      additionValue$3(addition, "qrcode_token", "QRCodeToken") && additionValue$3(addition, "qrcode_sign", "QRCodeSign") && additionValue$3(addition, "qrcode_time", "QRCodeTime")
    ),
    pendingVerify: () => ({ qr_text: additionValue$3(storage.addition_json, "qrcode_content", "QRCodeContent") }),
    poll: () => pollQrLogin$2(client, storage),
    start: () => startQrLogin$2(client, storage)
  });
  const loginByQrToken$1 = async (client, storage) => {
    var _a2;
    const addition = storage.addition_json;
    const token = additionValue$3(addition, "qrcode_token", "QRCodeToken");
    if (!token) return false;
    const source = qrSource$1(addition);
    addition.qrcode_source = source;
    const data = await requestJson$1(client, storage, API_QRCODE_LOGIN$1.replace("%s", encodeURIComponent(source)), {
      body: { account: token, app: source },
      method: "POST",
      qrCookies: true
    });
    const credential = ((_a2 = data.data) == null ? void 0 : _a2.cookie) || {};
    if (!credential.UID || !credential.CID || !credential.SEID) throw new Error("115 QR login returned empty credential");
    addition.cookie = `UID=${credential.UID};CID=${credential.CID};SEID=${credential.SEID};KID=${credential.KID || ""}`;
    addition.qrcode_token = "";
    await saveDriverStorage$1(storage);
    return true;
  };
  const ensureLogin$4 = async (client, storage) => {
    if (!cookieHeader$3(storage.addition_json)) await loginByQrToken$1(client, storage);
    if (!cookieHeader$3(storage.addition_json)) throw new Error("missing cookie or qrcode account");
    const data = await requestJson$1(client, storage, API_LOGIN_CHECK$1, {
      query: { _: Date.now() }
    });
    return data;
  };
  const requestDownloadInfo = async (client, storage, file, userAgent) => {
    var _a2, _b2, _c;
    const pickcode = pickCodeOf(file);
    if (!pickcode) throw new Error("115 pickcode is empty");
    const cacheKey2 = `${pickcode}
${userAgent}
${cookieHeader$3(storage.addition_json)}`;
    const cached2 = (_a2 = downloadInfoCache.get(storage)) == null ? void 0 : _a2.get(cacheKey2);
    if (cached2 && cached2.expires > Date.now()) return cached2.info;
    const key = generateKey();
    const data = encode115(JSON.stringify({ pickcode }), key);
    const headers = requestHeaders$2(storage, { "User-Agent": userAgent });
    const downurl = `${API_DOWNLOAD_URL}?t=${Math.floor(Date.now() / 1e3)}`;
    const body = toForm({ data });
    const result = await remoteJsonWithMeta(client, downurl, {
      body,
      contentType: "application/x-www-form-urlencoded",
      headers,
      method: "POST"
    });
    const resp = check115$1(result.json);
    const decoded = JSON.parse(decode115(String(resp.data || ""), key) || "{}");
    const info = Object.values(decoded)[0];
    if (!((_b2 = info == null ? void 0 : info.url) == null ? void 0 : _b2.url)) throw new Error("115 download url is empty");
    const resolved = {
      ...info,
      header: buildDownloadHeaders(headers, (_c = result.meta) == null ? void 0 : _c.headers)
    };
    let cache2 = downloadInfoCache.get(storage);
    if (!cache2) {
      cache2 = /* @__PURE__ */ new Map();
      downloadInfoCache.set(storage, cache2);
    }
    cache2.set(cacheKey2, { expires: Date.now() + DOWNLOAD_CACHE_TTL, info: resolved });
    return resolved;
  };
  const create115Driver = ({ client }) => ({
    async test(storage, verify) {
      var _a2;
      let data;
      if ((verify == null ? void 0 : verify.type) === "qrcode" || !cookieHeader$3(storage.addition_json) && !additionValue$3(storage.addition_json, "qrcode_token", "QRCodeToken")) {
        data = await run115QrLogin$1(client, storage);
      } else {
        data = await ensureLogin$4(client, storage);
      }
      return {
        addition: storage.addition_json,
        message: ((_a2 = data == null ? void 0 : data.data) == null ? void 0 : _a2.user_id) ? `115 user ${data.data.user_id}` : "115 login ok",
        user: (data == null ? void 0 : data.data) || {}
      };
    },
    async list(storage, relPath) {
      await waitLimit$2(storage);
      await ensureLogin$4(client, storage);
      const dir = await resolveFile$b(client, storage, relPath);
      const dirId = String(dirIdOf(dir) || fileIdOf$1(dir) || rootId$3(storage.addition_json));
      const content = (await listById(client, storage, dirId)).map((item) => fileToObj$c(item, normalizePath(relPath + "/" + String(nameOf(item))), storage));
      return {
        content,
        direct_upload_tools: [],
        header: "",
        provider: "115 Cloud",
        readme: "",
        total: content.length,
        write: true
      };
    },
    async get(storage, relPath) {
      await waitLimit$2(storage);
      await ensureLogin$4(client, storage);
      const item = await resolveFile$b(client, storage, relPath);
      const obj = fileToObj$c(item, relPath, storage);
      return {
        ...obj,
        raw_url: obj.is_dir ? "" : rawDownloadUrl(storage, relPath),
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      await waitLimit$2(storage);
      await ensureLogin$4(client, storage);
      const item = await resolveFile$b(client, storage, relPath);
      const obj = fileToObj$c(item, relPath, storage);
      if (obj.is_dir) throw new Error("not file");
      if (!obj.pick_code && obj.id) {
        const detailed = await getFileById(client, storage, obj.id);
        Object.assign(obj, fileToObj$c({ ...item, ...detailed || {} }, relPath, storage));
      }
      const userAgent = userAgentFromOptions(options, UA$3);
      const info = await requestDownloadInfo(client, storage, obj, userAgent);
      return {
        link: {
          url: info.url.url,
          header: info.header || {},
          content_length: Number(info.file_size || obj.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      await waitLimit$2(storage);
      await ensureLogin$4(client, storage);
      const parent = await resolveFile$b(client, storage, normalizePath(relPath).replace(/\/[^/]+$/, "") || "/");
      await requestJson$1(client, storage, API_DIR_ADD, {
        body: { cname: basename(relPath), pid: parent.cid || parent.fid || rootId$3(storage.addition_json) },
        method: "POST"
      });
    },
    async move(storage, relPath, dstRelPath) {
      await waitLimit$2(storage);
      await ensureLogin$4(client, storage);
      const item = await resolveFile$b(client, storage, relPath);
      const dst = await resolveFile$b(client, storage, dstRelPath);
      await requestJson$1(client, storage, API_FILE_MOVE, {
        body: { "fid[0]": item.fid || item.cid, pid: dst.cid || dst.fid },
        method: "POST"
      });
    },
    async copy(storage, relPath, dstRelPath) {
      await waitLimit$2(storage);
      await ensureLogin$4(client, storage);
      const item = await resolveFile$b(client, storage, relPath);
      const dst = await resolveFile$b(client, storage, dstRelPath);
      await requestJson$1(client, storage, API_FILE_COPY, {
        body: { "fid[0]": item.fid || item.cid, pid: dst.cid || dst.fid },
        method: "POST"
      });
    },
    async remove(storage, relPath) {
      await waitLimit$2(storage);
      await ensureLogin$4(client, storage);
      const item = await resolveFile$b(client, storage, relPath);
      await requestJson$1(client, storage, API_FILE_DELETE, {
        body: { "fid[0]": item.fid || item.cid },
        method: "POST"
      });
    },
    async rename(storage, relPath, newName) {
      await waitLimit$2(storage);
      await ensureLogin$4(client, storage);
      const item = await resolveFile$b(client, storage, relPath);
      const id = item.fid || item.cid;
      await requestJson$1(client, storage, API_FILE_RENAME, {
        body: { fid: id, file_name: newName, [`files_new_name[${id}]`]: newName },
        method: "POST"
      });
    },
    async put() {
      throw new Error("115 Cloud upload is not implemented in the SiYuan kernel port yet");
    },
    async details(storage) {
      var _a2, _b2, _c, _d, _e, _f;
      await waitLimit$2(storage);
      await ensureLogin$4(client, storage);
      const data = await requestJson$1(client, storage, API_FILE_INDEX_INFO);
      const total = Number(((_c = (_b2 = (_a2 = data.data) == null ? void 0 : _a2.space_info) == null ? void 0 : _b2.all_total) == null ? void 0 : _c.size) || 0);
      const used = Number(((_f = (_e = (_d = data.data) == null ? void 0 : _d.space_info) == null ? void 0 : _e.all_use) == null ? void 0 : _f.size) || 0);
      return {
        total_space: total,
        used_space: used,
        free_space: Math.max(0, total - used)
      };
    }
  });
  const API$2 = "https://proapi.115.com";
  const AUTH_API = "https://passportapi.115.com";
  const UA$2 = "Mozilla/5.0 (Macintosh; Apple macOS 26_1_0) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36 Chrome/142.0.0.0 OpenList/425.6.30";
  const MAX_PAGE_SIZE = 1150;
  const cache$5 = createStorageCache();
  const limiterState$1 = /* @__PURE__ */ new WeakMap();
  const refreshPromises = /* @__PURE__ */ new WeakMap();
  const formBody$5 = (data) => new URLSearchParams(Object.entries(data).filter(([, value]) => value !== void 0 && value !== null && value !== "").map(([key, value]) => [key, String(value)])).toString();
  const additionValue$2 = (addition, lowerName, upperName, fallback = "") => {
    const value = (addition == null ? void 0 : addition[lowerName]) ?? (addition == null ? void 0 : addition[upperName]);
    return value === void 0 || value === null || value === "" ? fallback : value;
  };
  const rootId$2 = (addition) => additionValue$2(addition, "root_folder_id", "RootFolderID", "0");
  const pageSize$1 = (addition) => Math.min(MAX_PAGE_SIZE, Math.max(1, numberValue(additionValue$2(addition, "page_size", "PageSize", 200), 200)));
  const orderBy = (addition) => additionValue$2(addition, "order_by", "OrderBy", "");
  const orderDirection = (addition) => additionValue$2(addition, "order_direction", "OrderDirection", "");
  const accessToken = (addition) => additionValue$2(addition, "access_token", "AccessToken", "");
  const refreshTokenValue = (addition) => additionValue$2(addition, "refresh_token", "RefreshToken", "");
  const limitRate$1 = (addition) => Math.max(0, Number(additionValue$2(addition, "limit_rate", "LimitRate", 1)) || 0);
  const check115Open = (payload, fallback = "115 Open request failed") => {
    const code = Number((payload == null ? void 0 : payload.code) ?? 0);
    if ((payload == null ? void 0 : payload.state) === false || (payload == null ? void 0 : payload.state) === 0 && code !== 0 || code >= 4e7 || (payload == null ? void 0 : payload.error)) {
      throw new Error((payload == null ? void 0 : payload.message) || (payload == null ? void 0 : payload.msg) || (payload == null ? void 0 : payload.error) || `${fallback}: ${code}`);
    }
    return payload;
  };
  const unwrapData = (payload) => {
    const checked = check115Open(payload);
    return Object.hasOwn(checked || {}, "data") ? checked.data : checked;
  };
  const doRefreshToken = async (client, storage, previousRefreshToken = "") => {
    const addition = storage.addition_json;
    if (previousRefreshToken && refreshTokenValue(addition) && refreshTokenValue(addition) !== previousRefreshToken) {
      return accessToken(addition);
    }
    const refreshToken2 = refreshTokenValue(addition);
    if (!refreshToken2) throw new Error("empty refresh_token");
    const resp = unwrapData(await remoteJson(client, `${AUTH_API}/open/refreshToken`, {
      body: formBody$5({ refresh_token: refreshToken2 }),
      contentType: "application/x-www-form-urlencoded",
      method: "POST"
    }));
    if (!(resp == null ? void 0 : resp.access_token) || !(resp == null ? void 0 : resp.refresh_token)) throw new Error("115 Open refresh token returned empty token");
    addition.access_token = resp.access_token;
    addition.refresh_token = resp.refresh_token;
    await persistAddition$1(storage);
    return resp.access_token;
  };
  const refreshToken$3 = async (client, storage, previousRefreshToken = "") => {
    const existing = refreshPromises.get(storage);
    if (existing) return existing;
    const promise = doRefreshToken(client, storage, previousRefreshToken).finally(() => refreshPromises.delete(storage));
    refreshPromises.set(storage, promise);
    return promise;
  };
  const request115Open = async (client, storage, pathname, {
    body,
    method = "GET",
    query = {},
    retry = true,
    userAgent = UA$2
  } = {}) => {
    const target = new URL(`${API$2}${pathname}`);
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const tokenBeforeRequest = accessToken(storage.addition_json);
    const refreshTokenBeforeRequest = refreshTokenValue(storage.addition_json);
    const payload = await remoteJson(client, target.toString(), {
      allowErrorStatus: true,
      body: body ? formBody$5(body) : void 0,
      contentType: body ? "application/x-www-form-urlencoded" : "application/json;charset=UTF-8",
      headers: {
        Authorization: tokenBeforeRequest ? `Bearer ${tokenBeforeRequest}` : "",
        "User-Agent": userAgent
      },
      method
    });
    const code = Number((payload == null ? void 0 : payload.code) ?? 0);
    if (retry && (code === 99 || String(code).startsWith("401"))) {
      await refreshToken$3(client, storage, refreshTokenBeforeRequest);
      return request115Open(client, storage, pathname, { body, method, query, retry: false, userAgent });
    }
    return unwrapData(payload);
  };
  const waitLimit$1 = async (storage) => {
    const rate = limitRate$1(storage.addition_json);
    if (rate <= 0) return;
    const interval = 1e3 / rate;
    const now = Date.now();
    const previous = limiterState$1.get(storage) || 0;
    const wait = Math.max(0, previous - now);
    limiterState$1.set(storage, Math.max(now, previous) + interval);
    if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
  };
  const isDir$5 = (file) => String(file.fc ?? file.file_category) === "0";
  const fileIdOf = (file) => String(file.fid || file.file_id || "");
  const fileNameOf$4 = (file) => String(file.fn || file.file_name || "");
  const fileToObj$b = (file, relPath, storage) => {
    const dir = isDir$5(file);
    return {
      name: fileNameOf$4(file) || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: dir,
      size: Number(file.fs || file.file_size || file.size || 0),
      modified: parseTime$1(file.upt || file.user_utime || file.utime),
      created: parseTime$1(file.uppt || file.user_ptime || file.ptime),
      thumb: file.thumb || file.thumbnail || "",
      sign: "",
      type: dir ? 1 : 0,
      hashinfo: file.sha1 || "",
      hash_info: file.sha1 ? { sha1: file.sha1 } : {},
      id: fileIdOf(file),
      pid: String(file.pid || file.parent_id || ""),
      pick_code: file.pc || file.pick_code || "",
      raw_url: dir ? "" : rawDownloadUrl(storage, relPath),
      provider: "115 Open",
      file
    };
  };
  const listByParent$8 = async (client, storage, parentId) => {
    const id = parentId || rootId$2(storage.addition_json);
    return cache$5.list(storage, id, async () => {
      const addition = storage.addition_json;
      const limit = pageSize$1(addition);
      const content = [];
      for (let offset = 0; ; offset += limit) {
        await waitLimit$1(storage);
        const resp = await request115Open(client, storage, "/open/ufile/files", {
          query: {
            asc: orderDirection(addition) === "asc" ? "1" : "0",
            cid: id,
            custom_order: "0",
            cur: "0",
            limit,
            o: orderBy(addition),
            offset,
            show_dir: "1",
            star: "0",
            stdir: "0"
          }
        });
        const list = Array.isArray(resp) ? resp : (resp == null ? void 0 : resp.data) || [];
        content.push(...list);
        const count = Number((resp == null ? void 0 : resp.count) ?? content.length);
        if (content.length >= count || list.length === 0) break;
      }
      return content;
    });
  };
  const getFolderByPath = async (client, storage, relPath) => {
    var _a2, _b2;
    const resp = await request115Open(client, storage, "/open/folder/get_info", {
      body: { path: normalizePath(relPath || "/") },
      method: "POST"
    });
    const item = Array.isArray(resp) ? resp[0] : resp;
    if (!(item == null ? void 0 : item.file_id)) throw new Error(`object not found: ${relPath}`);
    return {
      fid: item.file_id,
      fn: item.file_name || basenameOf(relPath),
      fc: item.file_category || "0",
      pc: item.pick_code || "",
      sha1: item.sha1 || "",
      pid: ((_b2 = (_a2 = item.paths) == null ? void 0 : _a2[0]) == null ? void 0 : _b2.file_id) || "",
      upt: item.utime || item.open_time || 0,
      uppt: item.ptime || item.open_time || 0
    };
  };
  const resolveFile$a = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    return cache$5.file(storage, clean, async () => {
      if (clean === "/") {
        return {
          fid: rootId$2(storage.addition_json),
          fn: "root",
          fc: "0",
          pid: ""
        };
      }
      let parentId = rootId$2(storage.addition_json);
      let current = null;
      for (const part of clean.split("/").filter(Boolean)) {
        const files = await listByParent$8(client, storage, parentId);
        current = files.find((item) => fileNameOf$4(item) === part);
        if (!current) return getFolderByPath(client, storage, clean);
        parentId = fileIdOf(current);
      }
      return current;
    });
  };
  const linkFor$6 = async (client, storage, file, userAgent) => {
    var _a2;
    const pc = file.pc || file.pick_code;
    const resp = await request115Open(client, storage, "/open/ufile/downurl", {
      body: { pick_code: pc },
      method: "POST",
      userAgent
    });
    const id = fileIdOf(file);
    const info = (resp == null ? void 0 : resp[id]) || Object.values(resp || {})[0];
    if (!((_a2 = info == null ? void 0 : info.url) == null ? void 0 : _a2.url)) throw new Error("115 Open download url is empty");
    return {
      url: info.url.url,
      header: { "User-Agent": userAgent },
      content_length: Number(info.file_size || file.fs || file.file_size || 0)
    };
  };
  const manage$1 = async (client, storage, pathname, body) => {
    await waitLimit$1(storage);
    await request115Open(client, storage, pathname, { body, method: "POST" });
    cache$5.clear(storage);
  };
  const create115OpenDriver = ({ client }) => ({
    async test(storage) {
      const user = await request115Open(client, storage, "/open/user/info");
      return { user, addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const dir = await resolveFile$a(client, storage, relPath);
      const content = (await listByParent$8(client, storage, fileIdOf(dir))).map((file) => fileToObj$b(file, normalizePath(relPath + "/" + fileNameOf$4(file)), storage));
      return {
        content,
        direct_upload_tools: [],
        header: "",
        provider: "115 Open",
        readme: "",
        total: content.length,
        write: true
      };
    },
    async get(storage, relPath) {
      await waitLimit$1(storage);
      const file = await resolveFile$a(client, storage, relPath);
      return {
        ...fileToObj$b(file, relPath, storage),
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      await waitLimit$1(storage);
      const file = await resolveFile$a(client, storage, relPath);
      if (isDir$5(file)) throw new Error("not file");
      const userAgent = userAgentFromOptions(options, UA$2);
      return { link: await linkFor$6(client, storage, file, userAgent) };
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$a(client, storage, dirnameOf(relPath));
      await manage$1(client, storage, "/open/folder/add", {
        pid: fileIdOf(parent),
        file_name: basenameOf(relPath)
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$a(client, storage, relPath);
      const dst = await resolveFile$a(client, storage, dstRelPath);
      await manage$1(client, storage, "/open/ufile/move", {
        file_ids: fileIdOf(file),
        to_cid: fileIdOf(dst)
      });
    },
    async copy(storage, relPath, dstRelPath) {
      const file = await resolveFile$a(client, storage, relPath);
      const dst = await resolveFile$a(client, storage, dstRelPath);
      await manage$1(client, storage, "/open/ufile/copy", {
        pid: fileIdOf(dst),
        file_id: fileIdOf(file),
        no_dupli: "1"
      });
    },
    async remove(storage, relPath) {
      const file = await resolveFile$a(client, storage, relPath);
      await manage$1(client, storage, "/open/ufile/delete", {
        file_ids: fileIdOf(file),
        parent_id: file.pid || ""
      });
    },
    async rename(storage, relPath, newName) {
      const file = await resolveFile$a(client, storage, relPath);
      await manage$1(client, storage, "/open/ufile/update", {
        file_id: fileIdOf(file),
        file_name: newName
      });
    },
    async put() {
      throw new Error("115 Open upload is not implemented in the SiYuan kernel port yet");
    },
    async offlineDownload(storage, uris, dstRelPath = "/") {
      const dst = await resolveFile$a(client, storage, dstRelPath);
      const resp = await request115Open(client, storage, "/open/offline/add_task_urls", {
        body: {
          urls: (uris || []).join("\n"),
          wp_path_id: fileIdOf(dst)
        },
        method: "POST"
      });
      return (Array.isArray(resp) ? resp : []).filter((item) => (item == null ? void 0 : item.state) && (item == null ? void 0 : item.info_hash)).map((item) => item.info_hash);
    },
    async details(storage) {
      var _a2, _b2;
      const user = await request115Open(client, storage, "/open/user/info");
      const space = (user == null ? void 0 : user.rt_space_info) || (user == null ? void 0 : user.space_info) || {};
      const total = Number(((_a2 = space.all_total) == null ? void 0 : _a2.size) || 0);
      const used = Number(((_b2 = space.all_use) == null ? void 0 : _b2.size) || 0);
      return {
        total_space: total,
        used_space: used,
        free_space: Math.max(0, total - used)
      };
    }
  });
  const API_LOGIN_CHECK = "https://passportapi.115.com/app/1.0/web/1.0/check/sso";
  const API_QRCODE_TOKEN = "https://qrcodeapi.115.com/api/1.0/web/1.0/token";
  const API_QRCODE_STATUS = "https://qrcodeapi.115.com/get/status/";
  const API_QRCODE_LOGIN = "https://passportapi.115.com/app/1.0/%s/1.0/login/qrcode";
  const API_SHARE_SNAP = "https://115cdn.com/webapi/share/snap";
  const API_SHARE_DOWNLOAD = "https://115cdn.com/webapi/share/downurl";
  const UA$1 = "Mozilla/5.0 115Browser/35.6.0.3";
  const UA_NT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36";
  const QR_KEYS$1 = ["qrcode_sign", "QRCodeSign", "qrcode_time", "QRCodeTime", "qrcode_content", "QRCodeContent", "qrcode_cookie", "QRCodeCookie"];
  const cache$4 = createStorageCache();
  const limiterState = /* @__PURE__ */ new WeakMap();
  const additionValue$1 = (addition, lowerName, upperName, fallback = "") => {
    const value = (addition == null ? void 0 : addition[lowerName]) ?? (addition == null ? void 0 : addition[upperName]);
    return value === void 0 || value === null || value === "" ? fallback : value;
  };
  const qrSource = (addition) => {
    return String(additionValue$1(addition, "qrcode_source", "QRCodeSource", "web") || "web").trim();
  };
  const formBody$4 = (data) => Object.entries(data).filter(([, value]) => value !== void 0 && value !== null).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`).join("&");
  const setCookieValues = (headers) => {
    const pairs = Object.entries(headers || {});
    const entry = pairs.find(([key]) => key.toLowerCase() === "set-cookie");
    if (!entry) return [];
    return Array.isArray(entry[1]) ? entry[1] : [entry[1]];
  };
  const mergeCookies$2 = (...values) => {
    const map = /* @__PURE__ */ new Map();
    for (const value of values) {
      for (const part of String(value || "").split(";")) {
        const trimmed = part.trim();
        const index = trimmed.indexOf("=");
        if (index > 0) map.set(trimmed.slice(0, index), trimmed.slice(index + 1));
      }
    }
    return [...map.entries()].map(([key, value]) => `${key}=${value}`).join("; ");
  };
  const storeQrCookies = (addition, headers) => {
    const cookies = setCookieValues(headers).map((cookie) => String(cookie).split(";")[0]).filter(Boolean);
    if (!cookies.length) return;
    addition.qrcode_cookie = mergeCookies$2(qrCookieHeader(addition), cookies.join("; "));
  };
  const rootId$1 = (addition) => additionValue$1(addition, "root_folder_id", "RootFolderID", "0");
  const cookieHeader$2 = (addition) => additionValue$1(addition, "cookie", "Cookie");
  const qrCookieHeader = (addition) => additionValue$1(addition, "qrcode_cookie", "QRCodeCookie");
  const pageSize = (addition) => Math.max(1, numberValue(additionValue$1(addition, "page_size", "PageSize", 1e3), 1e3));
  const limitRate = (addition) => Math.max(0, Number(additionValue$1(addition, "limit_rate", "LimitRate", 2)) || 0);
  const shareCode = (addition) => additionValue$1(addition, "share_code", "ShareCode");
  const receiveCode = (addition) => additionValue$1(addition, "receive_code", "ReceiveCode");
  const shareReferer = (addition) => `https://115cdn.com/s/${shareCode(addition)}?password=${receiveCode(addition)}&`;
  const check115 = (payload, fallback = "115 Share request failed") => {
    const code = Number((payload == null ? void 0 : payload.errno) ?? (payload == null ? void 0 : payload.errNo) ?? (payload == null ? void 0 : payload.code) ?? 0);
    if ((payload == null ? void 0 : payload.state) === false || code !== 0 || (payload == null ? void 0 : payload.error)) {
      throw new Error((payload == null ? void 0 : payload.msg) || (payload == null ? void 0 : payload.message) || (payload == null ? void 0 : payload.error) || `${fallback}: ${code}`);
    }
    return payload;
  };
  const requestHeaders$1 = (storage, extra = {}) => ({
    Cookie: cookieHeader$2(storage.addition_json),
    "User-Agent": UA_NT,
    ...extra
  });
  const requestQrHeaders = (storage, extra = {}) => ({
    Cookie: mergeCookies$2(cookieHeader$2(storage.addition_json), qrCookieHeader(storage.addition_json)),
    "User-Agent": UA_NT,
    ...extra
  });
  const requestJson = async (client, storage, url, {
    body,
    headers = {},
    method = "GET",
    query = {},
    qrCookies = false
  } = {}) => {
    var _a2;
    const target = new URL(url);
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const form = body ? formBody$4(body) : void 0;
    const request2 = {
      body: form,
      contentType: body ? "application/x-www-form-urlencoded" : "application/json;charset=UTF-8",
      headers: (qrCookies ? requestQrHeaders : requestHeaders$1)(storage, headers),
      method
    };
    const result = await remoteJsonWithMeta(client, target.toString(), request2);
    storeQrCookies(storage.addition_json, (_a2 = result.meta) == null ? void 0 : _a2.headers);
    return check115(result.json);
  };
  const requestQrStatus = async (client, storage, query) => {
    var _a2;
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") params.set(key, String(value));
    }
    const target = `${API_QRCODE_STATUS}?${params.toString()}`;
    const request2 = {
      contentType: "application/json;charset=UTF-8",
      headers: requestQrHeaders(storage),
      method: "GET"
    };
    const result = await remoteJsonWithMeta(client, target, request2);
    const payload = result.json;
    storeQrCookies(storage.addition_json, (_a2 = result.meta) == null ? void 0 : _a2.headers);
    return check115(payload);
  };
  const waitLimit = async (storage) => {
    const rate = limitRate(storage.addition_json);
    if (rate <= 0) return;
    const interval = 1e3 / rate;
    const now = Date.now();
    const previous = limiterState.get(storage) || 0;
    const wait = Math.max(0, previous - now);
    limiterState.set(storage, Math.max(now, previous) + interval);
    if (wait > 0) await new Promise((resolve) => setTimeout(resolve, wait));
  };
  const qrStatus = (payload) => {
    const data = (payload == null ? void 0 : payload.data) || payload || {};
    const raw = data.status ?? data.code ?? data.state ?? data.msg ?? data.message;
    const text2 = String(raw ?? data.msg ?? data.message ?? "").toLowerCase();
    const numeric = typeof raw === "boolean" ? NaN : Number(raw);
    const message = data.msg || data.message || "";
    if (numeric === 2) return { message, raw: payload, status: "success" };
    if (numeric === 1 || /scan|scanned|success|confirm|allowed|confirmed|qrcode_scan_confirmed/.test(text2)) return { message, raw: payload, status: "scanned" };
    if (numeric === -1 || /expire|expired|timeout|time out/.test(text2)) return { message: message || "115 QR code expired", status: "expired" };
    if (numeric === -2 || /cancel|canceled|cancelled/.test(text2)) return { message: message || "115 QR code canceled", status: "canceled" };
    return { message, raw: payload, status: "waiting" };
  };
  const startQrLogin$1 = async (client, storage) => {
    const addition = storage.addition_json;
    addition.qrcode_source = qrSource(addition);
    const data = await requestJson(client, storage, API_QRCODE_TOKEN);
    const session = data.data || {};
    if (!session.uid || !session.sign || !session.time) throw new Error("115 QR token response is empty");
    addition.qrcode_token = session.uid;
    addition.qrcode_sign = session.sign;
    addition.qrcode_time = session.time;
    addition.qrcode_content = session.qrcode || "";
    addition.cookie = "";
    return {
      message: "115 QR login pending",
      status: "waiting",
      verify: { qr_text: session.qrcode || "" }
    };
  };
  const pollQrLogin$1 = async (client, storage) => {
    const addition = storage.addition_json;
    const status = await requestQrStatus(client, storage, {
      uid: additionValue$1(addition, "qrcode_token", "QRCodeToken"),
      time: additionValue$1(addition, "qrcode_time", "QRCodeTime"),
      sign: additionValue$1(addition, "qrcode_sign", "QRCodeSign"),
      _: Date.now()
    });
    const state = qrStatus(status);
    return { message: state.message || "115 QR login pending", raw: status, status: state.status };
  };
  const run115QrLogin = (client, storage) => runQrLogin({
    addition: storage.addition_json,
    clear: () => clearQrKeys(storage.addition_json, QR_KEYS$1),
    confirm: async () => {
      await loginByQrToken(client, storage);
      return ensureLogin$3(client, storage);
    },
    hasSession: (addition) => Boolean(
      additionValue$1(addition, "qrcode_token", "QRCodeToken") && additionValue$1(addition, "qrcode_sign", "QRCodeSign") && additionValue$1(addition, "qrcode_time", "QRCodeTime")
    ),
    pendingVerify: () => ({ qr_text: additionValue$1(storage.addition_json, "qrcode_content", "QRCodeContent") }),
    poll: () => pollQrLogin$1(client, storage),
    start: () => startQrLogin$1(client, storage)
  });
  const loginByQrToken = async (client, storage) => {
    var _a2;
    const addition = storage.addition_json;
    const token = additionValue$1(addition, "qrcode_token", "QRCodeToken");
    if (!token) return false;
    const source = qrSource(addition);
    addition.qrcode_source = source;
    const data = await requestJson(client, storage, API_QRCODE_LOGIN.replace("%s", encodeURIComponent(source)), {
      body: { account: token, app: source },
      method: "POST",
      qrCookies: true
    });
    const credential = ((_a2 = data.data) == null ? void 0 : _a2.cookie) || {};
    if (!credential.UID || !credential.CID || !credential.SEID) throw new Error("115 QR login returned empty credential");
    addition.cookie = `UID=${credential.UID};CID=${credential.CID};SEID=${credential.SEID};KID=${credential.KID || ""}`;
    addition.qrcode_token = "";
    await persistAddition$1(storage);
    return true;
  };
  const ensureLogin$3 = async (client, storage) => {
    if (!cookieHeader$2(storage.addition_json)) await loginByQrToken(client, storage);
    if (!cookieHeader$2(storage.addition_json)) throw new Error("missing cookie or qrcode account");
    await requestJson(client, storage, API_SHARE_SNAP, {
      headers: { referer: shareReferer(storage.addition_json) },
      query: {
        share_code: shareCode(storage.addition_json),
        receive_code: receiveCode(storage.addition_json),
        cid: rootId$1(storage.addition_json),
        limit: 1,
        asc: 0,
        offset: 0,
        format: "json"
      }
    });
    return requestJson(client, storage, API_LOGIN_CHECK, {
      query: { _: Date.now() }
    });
  };
  const isDir$4 = (item) => Number((item == null ? void 0 : item.is_file) ?? (item == null ? void 0 : item.isFile) ?? 0) === 0;
  const itemId = (item) => String(isDir$4(item) ? item.cid || item.category_id || item.categoryID : item.fid || item.file_id || item.fileID);
  const itemName = (item) => String(item.n || item.file_name || item.fileName || item.name || "");
  const fileToObj$a = (item, relPath, storage) => {
    const dir = isDir$4(item);
    return {
      name: itemName(item) || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: dir,
      size: Number(item.s || item.size || 0),
      modified: parseTime$1(item.t || item.update_time || item.updateTime),
      created: parseTime$1(item.t || item.update_time || item.updateTime),
      thumb: item.u || item.thumb_url || item.thumbURL || "",
      sign: "",
      type: dir ? 1 : 0,
      hashinfo: item.sha || item.sha1 || "",
      hash_info: item.sha || item.sha1 ? { sha1: item.sha || item.sha1 } : {},
      id: itemId(item),
      raw_url: dir ? "" : rawDownloadUrl(storage, relPath),
      provider: "115 Share",
      file: item
    };
  };
  const listByParent$7 = async (client, storage, parentId) => {
    const id = parentId || rootId$1(storage.addition_json);
    return cache$4.list(storage, id, async () => {
      await waitLimit(storage);
      const addition = storage.addition_json;
      const limit = pageSize(addition);
      const result = [];
      for (let offset = 0; ; offset += limit) {
        const resp = await requestJson(client, storage, API_SHARE_SNAP, {
          headers: { referer: shareReferer(addition), "User-Agent": UA_NT },
          query: {
            share_code: shareCode(addition),
            receive_code: receiveCode(addition),
            cid: id,
            limit,
            asc: 0,
            offset,
            format: "json"
          }
        });
        const data = resp.data || {};
        const list = data.list || [];
        result.push(...list);
        if (result.length >= Number(data.count || result.length) || list.length === 0) break;
      }
      return result;
    });
  };
  const resolveFile$9 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    return cache$4.file(storage, clean, async () => {
      if (clean === "/") {
        return {
          cid: rootId$1(storage.addition_json),
          n: "root",
          is_file: 0
        };
      }
      let parentId = rootId$1(storage.addition_json);
      let current = null;
      for (const part of clean.split("/").filter(Boolean)) {
        const files = await listByParent$7(client, storage, parentId);
        current = files.find((item) => itemName(item) === part);
        if (!current) throw new Error(`object not found: ${clean}`);
        parentId = itemId(current);
      }
      return current;
    });
  };
  const create115ShareDriver = ({ client }) => ({
    async test(storage, verify) {
      var _a2;
      let data;
      if ((verify == null ? void 0 : verify.type) === "qrcode" || !cookieHeader$2(storage.addition_json) && !additionValue$1(storage.addition_json, "qrcode_token", "QRCodeToken")) {
        data = await run115QrLogin(client, storage);
      } else {
        data = await ensureLogin$3(client, storage);
      }
      return {
        addition: storage.addition_json,
        message: ((_a2 = data == null ? void 0 : data.data) == null ? void 0 : _a2.user_id) ? `115 user ${data.data.user_id}` : "115 share login ok",
        user: (data == null ? void 0 : data.data) || {}
      };
    },
    async list(storage, relPath) {
      await ensureLogin$3(client, storage);
      const dir = await resolveFile$9(client, storage, relPath);
      const content = (await listByParent$7(client, storage, itemId(dir))).map((file) => fileToObj$a(file, normalizePath(relPath + "/" + itemName(file)), storage));
      return {
        content,
        direct_upload_tools: [],
        header: "",
        provider: "115 Share",
        readme: "",
        total: content.length,
        write: false
      };
    },
    async get(storage, relPath) {
      await ensureLogin$3(client, storage);
      const file = await resolveFile$9(client, storage, relPath);
      return {
        ...fileToObj$a(file, relPath, storage),
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      var _a2, _b2;
      await ensureLogin$3(client, storage);
      await waitLimit(storage);
      const file = await resolveFile$9(client, storage, relPath);
      if (isDir$4(file)) throw new Error("not file");
      const userAgent = options.userAgent || ((_a2 = options.headers) == null ? void 0 : _a2["User-Agent"]) || UA$1;
      const resp = await requestJson(client, storage, API_SHARE_DOWNLOAD, {
        headers: { referer: shareReferer(storage.addition_json), "User-Agent": userAgent },
        query: {
          share_code: shareCode(storage.addition_json),
          receive_code: receiveCode(storage.addition_json),
          file_id: itemId(file),
          dl: 1
        }
      });
      const info = resp.data || {};
      if (!((_b2 = info == null ? void 0 : info.url) == null ? void 0 : _b2.url)) throw new Error("115 Share download url is empty");
      return {
        link: {
          url: info.url.url,
          header: { "User-Agent": userAgent },
          content_length: Number(info.fs || info.file_size || file.s || file.size || 0)
        }
      };
    },
    async mkdir() {
      throw new Error("115 Share mkdir is not supported by the OpenList driver");
    },
    async move() {
      throw new Error("115 Share move is not supported by the OpenList driver");
    },
    async copy() {
      throw new Error("115 Share copy is not supported by the OpenList driver");
    },
    async remove() {
      throw new Error("115 Share remove is not supported by the OpenList driver");
    },
    async rename() {
      throw new Error("115 Share rename is not supported by the OpenList driver");
    },
    async put() {
      throw new Error("115 Share upload is not supported by the OpenList driver");
    }
  });
  const B_API = "https://yun.123pan.com/b/api";
  const LOGIN_API = "https://login.123pan.com/api";
  const SIGN_IN = LOGIN_API + "/user/sign_in";
  const USER_INFO = B_API + "/user/info";
  const FILE_LIST = B_API + "/file/list/new";
  const DOWNLOAD_INFO = B_API + "/file/download_info";
  const MKDIR = B_API + "/file/upload_request";
  const UPLOAD_REQUEST = B_API + "/file/upload_request";
  const UPLOAD_COMPLETE = B_API + "/file/upload_complete";
  const S3_PRE_SIGNED_URLS = B_API + "/file/s3_repare_upload_parts_batch";
  const S3_AUTH = B_API + "/file/s3_upload_object/auth";
  const UPLOAD_COMPLETE_V2 = B_API + "/file/upload_complete/v2";
  const MOVE = B_API + "/file/mod_pid";
  const RENAME = B_API + "/file/rename";
  const TRASH = B_API + "/file/trash";
  const UPLOAD_CHUNK_SIZE = 16 * 1024 * 1024;
  const crcTable = (() => {
    const table = [];
    for (let i2 = 0; i2 < 256; i2 += 1) {
      let c = i2;
      for (let j = 0; j < 8; j += 1) c = c & 1 ? 3988292384 ^ c >>> 1 : c >>> 1;
      table[i2] = c >>> 0;
    }
    return table;
  })();
  const crc32 = (value) => {
    let crc = 4294967295;
    const input = unescape(encodeURIComponent(String(value || "")));
    for (let i2 = 0; i2 < input.length; i2 += 1) {
      crc = crc >>> 8 ^ crcTable[(crc ^ input.charCodeAt(i2)) & 255];
    }
    return ((crc ^ 4294967295) >>> 0).toString();
  };
  const pad = (value) => String(value).padStart(2, "0");
  const signPath = (path, os = "web", version = "3") => {
    const table = ["a", "d", "e", "f", "g", "h", "l", "m", "y", "i", "j", "n", "o", "p", "k", "q", "r", "s", "t", "u", "b", "c", "v", "w", "s", "z"];
    const random = String(Math.round(1e7 * Math.random()));
    const now = new Date(Date.now() + 8 * 3600 * 1e3);
    const timestamp2 = String(Math.floor(now.getTime() / 1e3));
    const nowStr = `${now.getUTCFullYear()}${pad(now.getUTCMonth() + 1)}${pad(now.getUTCDate())}${pad(now.getUTCHours())}${pad(now.getUTCMinutes())}`;
    const encodedTime = nowStr.split("").map((char) => table[Number(char)]).join("");
    const timeSign = crc32(encodedTime);
    const data = [timestamp2, random, path, os, version, timeSign].join("|");
    const dataSign = crc32(data);
    return [timeSign, [timestamp2, random, dataSign].join("-")];
  };
  const signedApi = (rawUrl) => {
    const url = new URL(rawUrl);
    const [key, value] = signPath(url.pathname, "web", "3");
    url.searchParams.append(key, value);
    return url.toString();
  };
  const isEmail = (value) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(value || ""));
  const cleanUsername = (value) => String(value || "").trim().replace(/[\s-]/g, "");
  const decodeBase64 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    let output = "";
    let buffer = 0;
    let bits2 = 0;
    for (const char of String(value || "")) {
      if (char === "=") break;
      const index = chars2.indexOf(char);
      if (index < 0) continue;
      buffer = buffer << 6 | index;
      bits2 += 6;
      if (bits2 >= 8) {
        bits2 -= 8;
        output += String.fromCharCode(buffer >> bits2 & 255);
      }
    }
    try {
      return decodeURIComponent(escape(output));
    } catch (_) {
      return output;
    }
  };
  const base64ToBytes$9 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$8 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i2 = 0; i2 < bytes2.length; i2 += 3) {
      const a = bytes2[i2];
      const b = bytes2[i2 + 1];
      const c = bytes2[i2 + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i2 + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i2 + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$7 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const leftRotate$5 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$6 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$7(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i2) => Math.floor(Math.abs(Math.sin(i2 + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i2 = 0; i2 < 64; i2 += 1) {
        let f;
        let g;
        if (i2 < 16) {
          f = b & c | ~b & d;
          g = i2;
        } else if (i2 < 32) {
          f = d & b | ~d & c;
          g = (5 * i2 + 1) % 16;
        } else if (i2 < 48) {
          f = b ^ c ^ d;
          g = (3 * i2 + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i2 % 16;
        }
        const tmp = d;
        const word = view.getUint32(offset + g * 4, true);
        d = c;
        c = b;
        b = b + leftRotate$5(a + f + k[i2] + word >>> 0, s[i2]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const uploadBytes$6 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$9(content || "") : utf8Bytes$7(content || "");
  const platform = (addition) => addition.platform || addition.Platform || "web";
  const headersFor$2 = (addition, token = addition.access_token || addition.AccessToken || "") => ({
    origin: "https://yun.123pan.com",
    referer: "https://yun.123pan.com/",
    authorization: token ? `Bearer ${token}` : "",
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) siyuan-cloud-client",
    platform: platform(addition),
    "app-version": "3"
  });
  const check123 = (payload) => {
    const code = Number((payload == null ? void 0 : payload.code) ?? 0);
    if (code !== 0) throw new Error((payload == null ? void 0 : payload.message) || `123Pan code ${code}`);
    return payload;
  };
  const loginMessage = (payload) => {
    const message = (payload == null ? void 0 : payload.message) || "123Pan login failed";
    return /请进行验证/.test(String(message)) ? "请先在浏览器网页登录 123Pan 完成验证后，再回到插件登录" : message;
  };
  const login$1 = async (client, addition) => {
    var _a2;
    const username = addition.username || addition.Username || "";
    const passport = cleanUsername(username);
    const password2 = addition.password || addition.Password || "";
    const body = isEmail(username) ? { mail: String(username).trim(), password: password2, type: 2 } : { passport, password: password2, remember: true };
    const payload = await remoteJson(client, SIGN_IN, {
      body,
      headers: {
        origin: "https://yun.123pan.com",
        referer: "https://yun.123pan.com/",
        "user-agent": "Dart/2.19(dart:io)-siyuan-cloud",
        platform: "web",
        "app-version": "3"
      },
      method: "POST"
    });
    if (Number(payload == null ? void 0 : payload.code) !== 200) throw new Error(loginMessage(payload));
    addition.access_token = ((_a2 = payload == null ? void 0 : payload.data) == null ? void 0 : _a2.token) || "";
    return addition.access_token;
  };
  const request123 = async (client, storage, url, {
    body,
    method = "GET",
    query,
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    if (!addition.access_token && !addition.AccessToken) await login$1(client, addition);
    const api = new URL(url);
    for (const [key, value] of Object.entries(query || {})) api.searchParams.set(key, String(value));
    const payload = await remoteJson(client, signedApi(api.toString()), {
      allowErrorStatus: true,
      body,
      headers: headersFor$2(addition),
      method
    });
    if (Number(payload == null ? void 0 : payload.code) === 401 && retry) {
      await login$1(client, addition);
      return request123(client, storage, url, { body, method, query, retry: false });
    }
    return check123(payload);
  };
  const parseTime = (value) => {
    const date = value ? new Date(value) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const idOf = (file) => String((file == null ? void 0 : file.FileId) ?? (file == null ? void 0 : file.fileId) ?? (file == null ? void 0 : file.id) ?? "");
  const fileNameOf$3 = (file) => (file == null ? void 0 : file.FileName) || (file == null ? void 0 : file.fileName) || (file == null ? void 0 : file.name) || "";
  const isDir$3 = (file) => Number((file == null ? void 0 : file.Type) ?? (file == null ? void 0 : file.type) ?? 0) === 1;
  const thumbOf = (file) => {
    const raw = (file == null ? void 0 : file.DownloadUrl) || (file == null ? void 0 : file.downloadUrl) || "";
    if (!raw) return "";
    try {
      const url = new URL(raw);
      url.pathname = url.pathname.replace(/_24_24$/, "") + "_70_70";
      url.searchParams.set("w", "70");
      url.searchParams.set("h", "70");
      if (!url.searchParams.has("type")) url.searchParams.set("type", basename(fileNameOf$3(file)).replace(/^\./, ""));
      if (!url.searchParams.has("trade_key")) url.searchParams.set("trade_key", "123pan-thumbnail");
      return url.toString();
    } catch (_) {
      return "";
    }
  };
  const objFromFile = (file, relPath, storage) => {
    const dir = isDir$3(file);
    return {
      name: fileNameOf$3(file),
      path: normalizePath(relPath),
      is_dir: dir,
      size: Number((file == null ? void 0 : file.Size) ?? (file == null ? void 0 : file.size) ?? 0),
      modified: parseTime((file == null ? void 0 : file.UpdateAt) || (file == null ? void 0 : file.updateAt)),
      created: parseTime((file == null ? void 0 : file.UpdateAt) || (file == null ? void 0 : file.updateAt)),
      sign: "",
      thumb: thumbOf(file),
      type: dir ? 1 : 0,
      hashinfo: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) || "",
      hash_info: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) ? { md5: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) } : {},
      id: idOf(file),
      raw_url: dir ? "" : `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
      provider: "123Pan",
      file
    };
  };
  const rootId = (addition) => String(addition.root_folder_id || addition.RootFolderID || "0");
  const listByParentId = async (client, storage, parentId, parentName) => {
    let page = 1;
    let total = 0;
    const result = [];
    for (; ; ) {
      const payload = await request123(client, storage, FILE_LIST, {
        method: "GET",
        query: {
          driveId: "0",
          limit: "100",
          next: "0",
          orderBy: "file_id",
          orderDirection: "desc",
          parentFileId: parentId,
          trashed: "false",
          SearchData: "",
          Page: page,
          OnlyLookAbnormalFile: "0",
          event: "homeListFile",
          operateType: "4",
          inDirectSpace: "false"
        }
      });
      const data = payload.data || {};
      const list = data.InfoList || data.infoList || [];
      result.push(...list);
      total = Number(data.Total || data.total || total);
      page += 1;
      if (!list.length || String(data.Next ?? data.next) === "-1") break;
    }
    if (total && result.length !== total) {
      result.warning = `incorrect file count from remote at ${parentName}: expected ${total}, got ${result.length}`;
    }
    return result;
  };
  const resolveFile$8 = async (client, storage, relPath) => {
    const current = normalizePath(relPath || "/");
    if (current === "/") return { id: rootId(storage.addition_json), name: "root", path: "/", isRoot: true };
    let parentId = rootId(storage.addition_json);
    let parentPath = "/";
    let found = null;
    for (const part of current.split("/").filter(Boolean)) {
      const files = await listByParentId(client, storage, parentId, parentPath);
      found = files.find((file) => fileNameOf$3(file) === part);
      if (!found) throw new Error(`object not found: ${current}`);
      parentId = idOf(found);
      parentPath = normalizePath(parentPath + "/" + part);
    }
    return { file: found, id: idOf(found), name: fileNameOf$3(found), path: current };
  };
  const downloadUrlFor = async (client, storage, file) => {
    var _a2, _b2, _c, _d;
    const payload = await request123(client, storage, DOWNLOAD_INFO, {
      body: {
        driveId: 0,
        etag: (file == null ? void 0 : file.Etag) || (file == null ? void 0 : file.etag) || "",
        fileId: Number(idOf(file)),
        fileName: fileNameOf$3(file),
        s3keyFlag: (file == null ? void 0 : file.S3KeyFlag) || (file == null ? void 0 : file.s3KeyFlag) || "",
        size: Number((file == null ? void 0 : file.Size) ?? (file == null ? void 0 : file.size) ?? 0),
        type: Number((file == null ? void 0 : file.Type) ?? (file == null ? void 0 : file.type) ?? 0)
      },
      method: "POST"
    });
    const raw = ((_a2 = payload == null ? void 0 : payload.data) == null ? void 0 : _a2.DownloadUrl) || ((_b2 = payload == null ? void 0 : payload.data) == null ? void 0 : _b2.downloadUrl) || "";
    if (!raw) throw new Error("get download url failed");
    let referer = "https://yun.123pan.com/";
    try {
      const original = new URL(raw);
      referer = `${original.protocol}//${original.host}/`;
    } catch (_) {
    }
    let candidate = raw;
    try {
      const url = new URL(raw);
      const params = url.searchParams.get("params");
      candidate = params ? decodeBase64(params) : url.toString();
    } catch (_) {
      candidate = raw;
    }
    try {
      const resolved = await forwardProxy(client, candidate, {
        allowErrorStatus: true,
        contentType: "application/json",
        headers: { Referer: "https://yun.123pan.com/" },
        method: "GET",
        responseEncoding: "text"
      });
      const data = JSON.parse(resolved.body || "{}");
      return {
        url: ((_c = data == null ? void 0 : data.data) == null ? void 0 : _c.redirect_url) || ((_d = data == null ? void 0 : data.data) == null ? void 0 : _d.redirectUrl) || candidate,
        referer
      };
    } catch (_) {
      return { url: candidate, referer };
    }
  };
  const linkFor$5 = async (client, storage, file) => {
    const { url, referer } = await downloadUrlFor(client, storage, file);
    return {
      link: {
        url,
        header: {
          Referer: [referer]
        },
        content_length: Number((file == null ? void 0 : file.Size) ?? (file == null ? void 0 : file.size) ?? 0)
      }
    };
  };
  const uploadReqData = (data = {}) => data.data || data.Data || {};
  const uploadField = (data, name) => (data == null ? void 0 : data[name]) ?? (data == null ? void 0 : data[name.charAt(0).toLowerCase() + name.slice(1)]) ?? "";
  const getS3UploadUrls = async (client, storage, upReq, start, end, multipart) => {
    const data = uploadReqData(upReq);
    const payload = await request123(client, storage, multipart ? S3_PRE_SIGNED_URLS : S3_AUTH, {
      body: {
        StorageNode: uploadField(data, "StorageNode"),
        bucket: uploadField(data, "Bucket"),
        key: uploadField(data, "Key"),
        partNumberEnd: end,
        partNumberStart: start,
        uploadId: uploadField(data, "UploadId")
      },
      method: "POST"
    });
    return uploadReqData(payload).presignedUrls || uploadReqData(payload).PreSignedUrls || {};
  };
  const completeS3V2 = (client, storage, upReq, size, isMultipart) => {
    const data = uploadReqData(upReq);
    return request123(client, storage, UPLOAD_COMPLETE_V2, {
      body: {
        StorageNode: uploadField(data, "StorageNode"),
        bucket: uploadField(data, "Bucket"),
        fileId: uploadField(data, "FileId"),
        fileSize: size,
        isMultipart,
        key: uploadField(data, "Key"),
        uploadId: uploadField(data, "UploadId")
      },
      method: "POST"
    });
  };
  const putPresignedChunks = async (client, storage, upReq, bytes2) => {
    const chunkCount = Math.max(1, Math.ceil(bytes2.length / UPLOAD_CHUNK_SIZE));
    const multipart = chunkCount > 1;
    const batchSize = multipart ? 10 : 1;
    for (let index = 1; index <= chunkCount; index += batchSize) {
      const start = index;
      const end = Math.min(index + batchSize, chunkCount + 1);
      const urls = await getS3UploadUrls(client, storage, upReq, start, end, multipart);
      for (let cur = start; cur < end; cur += 1) {
        const offset = (cur - 1) * UPLOAD_CHUNK_SIZE;
        const chunk = bytes2.slice(offset, Math.min(offset + UPLOAD_CHUNK_SIZE, bytes2.length));
        const url = urls[String(cur)];
        if (!url) throw new Error(`upload url is empty for 123Pan chunk ${cur}`);
        await forwardProxy(client, url, {
          body: bytesToBase64$8(chunk),
          contentType: "application/octet-stream",
          headers: { "Content-Length": String(chunk.length) },
          method: "PUT",
          payloadEncoding: "base64",
          responseEncoding: "text",
          timeout: 12e4
        });
      }
    }
    await completeS3V2(client, storage, upReq, bytes2.length, multipart);
  };
  const putAwsS3 = async (client, upReq, bytes2, mime) => {
    const data = uploadReqData(upReq);
    const endpoint = String(uploadField(data, "EndPoint")).replace(/\/+$/, "");
    const bucket = uploadField(data, "Bucket");
    const key = uploadField(data, "Key");
    const url = `${endpoint}/${encodeURIComponent(bucket)}/${String(key).split("/").map(encodeURIComponent).join("/")}`;
    const body = bytesToBase64$8(bytes2);
    const headers = signAwsV4({
      accessKeyId: uploadField(data, "AccessKeyId"),
      body: bytes2,
      headers: {
        "content-type": mime || "application/octet-stream"
      },
      method: "PUT",
      region: "123pan",
      secretAccessKey: uploadField(data, "SecretAccessKey"),
      sessionToken: uploadField(data, "SessionToken"),
      url
    });
    await forwardProxy(client, url, {
      body,
      contentType: mime || "application/octet-stream",
      headers,
      method: "PUT",
      payloadEncoding: "base64",
      responseEncoding: "text",
      timeout: 12e4
    });
  };
  const create123PanDriver = ({ client }) => ({
    async list(storage, relPath) {
      const target = await resolveFile$8(client, storage, relPath);
      const files = await listByParentId(client, storage, target.id, target.name);
      const content = files.map((file) => objFromFile(file, normalizePath(relPath + "/" + fileNameOf$3(file)), storage));
      return {
        content,
        total: content.length,
        readme: "",
        header: files.warning || "",
        write: true,
        provider: "123Pan",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const target = await resolveFile$8(client, storage, relPath);
      if (target.isRoot) {
        return {
          name: "root",
          path: "/",
          is_dir: true,
          size: 0,
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString(),
          provider: "123Pan",
          related: []
        };
      }
      const obj = objFromFile(target.file, relPath, storage);
      if (!obj.is_dir && !options.skipLink) {
        obj.raw_url = (await linkFor$5(client, storage, target.file)).link.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath) {
      const target = await resolveFile$8(client, storage, relPath);
      if (target.isRoot || isDir$3(target.file)) throw new Error("not file");
      return linkFor$5(client, storage, target.file);
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$8(client, storage, dirname(relPath));
      await request123(client, storage, MKDIR, {
        body: {
          driveId: 0,
          etag: "",
          fileName: basename(relPath),
          parentFileId: parent.id,
          size: 0,
          type: 1
        },
        method: "POST"
      });
    },
    async remove(storage, relPath) {
      const target = await resolveFile$8(client, storage, relPath);
      if (target.isRoot) throw new Error("root cannot be removed");
      await request123(client, storage, TRASH, {
        body: {
          driveId: 0,
          operation: true,
          fileTrashInfoList: [target.file]
        },
        method: "POST"
      });
    },
    async rename(storage, relPath, newName) {
      const target = await resolveFile$8(client, storage, relPath);
      if (target.isRoot) throw new Error("root cannot be renamed");
      await request123(client, storage, RENAME, {
        body: {
          driveId: 0,
          fileId: Number(target.id),
          fileName: newName
        },
        method: "POST"
      });
    },
    async move(storage, relPath, dstRelPath) {
      const target = await resolveFile$8(client, storage, relPath);
      const dst = await resolveFile$8(client, storage, dstRelPath);
      await request123(client, storage, MOVE, {
        body: {
          fileIdList: [{ FileId: target.id }],
          parentFileId: dst.id
        },
        method: "POST"
      });
    },
    async put(storage, relPath, content, mime, options = {}) {
      const parent = await resolveFile$8(client, storage, dirname(relPath));
      const bytes2 = uploadBytes$6(content, options);
      const uploadReq = await request123(client, storage, UPLOAD_REQUEST, {
        body: {
          driveId: 0,
          duplicate: 2,
          etag: md5Hex$6(bytes2).toLowerCase(),
          fileName: basename(relPath),
          parentFileId: parent.id,
          size: Number(options.size ?? bytes2.length),
          type: 0
        },
        method: "POST"
      });
      const data = uploadReqData(uploadReq);
      if (uploadField(data, "Reuse") || !uploadField(data, "Key")) return;
      if (uploadField(data, "AccessKeyId") && uploadField(data, "SecretAccessKey") && uploadField(data, "SessionToken")) {
        await putAwsS3(client, uploadReq, bytes2, mime);
        await request123(client, storage, UPLOAD_COMPLETE, {
          body: { fileId: uploadField(data, "FileId") },
          method: "POST"
        });
        return;
      }
      await putPresignedChunks(client, storage, uploadReq, bytes2);
    },
    async test(storage) {
      const payload = await request123(client, storage, USER_INFO, {
        method: "GET"
      });
      const data = payload.data || {};
      return {
        ok: true,
        addition: storage.addition_json,
        user: {
          uid: data.UID || data.uid || 0,
          nickname: data.Nickname || data.nickname || "",
          space_used: data.SpaceUsed || data.spaceUsed || 0,
          space_permanent: data.SpacePermanent || data.spacePermanent || 0,
          space_temp: data.SpaceTemp || data.spaceTemp || 0,
          file_count: data.FileCount || data.fileCount || 0
        }
      };
    }
  });
  const DEFAULT_SLICE_SIZE$1 = 10485760;
  const utf8Bytes$6 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const base64ToBytes$8 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$7 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i2 = 0; i2 < bytes2.length; i2 += 3) {
      const a = bytes2[i2];
      const b = bytes2[i2 + 1];
      const c = bytes2[i2 + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i2 + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i2 + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const uploadBytes$5 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$8(content || "") : utf8Bytes$6(content || "");
  const hex$8 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const leftRotate$4 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$5 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$6(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i2) => Math.floor(Math.abs(Math.sin(i2 + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i2 = 0; i2 < 64; i2 += 1) {
        let f;
        let g;
        if (i2 < 16) {
          f = b & c | ~b & d;
          g = i2;
        } else if (i2 < 32) {
          f = d & b | ~d & c;
          g = (5 * i2 + 1) % 16;
        } else if (i2 < 48) {
          f = b ^ c ^ d;
          g = (3 * i2 + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i2 % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate$4(a + f + k[i2] + view.getUint32(offset + g * 4, true) >>> 0, s[i2]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    const out = new Uint8Array(16);
    const outView = new DataView(out.buffer);
    [a0, b0, c0, d0].forEach((value, index) => outView.setUint32(index * 4, value, true));
    return hex$8(out);
  };
  const md5Bytes = (input) => {
    const clean = md5Hex$5(input);
    const out = new Uint8Array(clean.length / 2);
    for (let i2 = 0; i2 < out.length; i2 += 1) out[i2] = Number.parseInt(clean.slice(i2 * 2, i2 * 2 + 2), 16);
    return out;
  };
  const rol$6 = (value, bits2) => value << bits2 | value >>> 32 - bits2;
  const sha1Bytes$6 = (message) => {
    const msg = message instanceof Uint8Array ? message : utf8Bytes$6(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i2 = 0; i2 < 16; i2 += 1) w[i2] = view.getUint32(offset + i2 * 4);
      for (let i2 = 16; i2 < 80; i2 += 1) w[i2] = rol$6(w[i2 - 3] ^ w[i2 - 8] ^ w[i2 - 14] ^ w[i2 - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i2 = 0; i2 < 80; i2 += 1) {
        let f;
        let k;
        if (i2 < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i2 < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i2 < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$6(a, 5) + f + e + k + w[i2] >>> 0;
        e = d;
        d = c;
        c = rol$6(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const hmacSha1 = (data, secret) => {
    let keyBytes = utf8Bytes$6(secret);
    if (keyBytes.length > 64) keyBytes = sha1Bytes$6(keyBytes);
    const ipad = new Uint8Array(64);
    const opad = new Uint8Array(64);
    for (let i2 = 0; i2 < 64; i2 += 1) {
      const b = keyBytes[i2] || 0;
      ipad[i2] = b ^ 54;
      opad[i2] = b ^ 92;
    }
    const msg = utf8Bytes$6(data);
    const inner = new Uint8Array(ipad.length + msg.length);
    inner.set(ipad);
    inner.set(msg, ipad.length);
    const outer = new Uint8Array(opad.length + 20);
    outer.set(opad);
    outer.set(sha1Bytes$6(inner), opad.length);
    return hex$8(sha1Bytes$6(outer));
  };
  const randomHex$1 = (pattern) => pattern.replace(/[xy]/g, (char) => {
    const t = Math.floor(16 * Math.random());
    const value = char === "x" ? t : 3 & t | 8;
    return value.toString(16);
  });
  const qs = (form) => {
    const params = new URLSearchParams();
    for (const [key, value] of Object.entries(form || {})) params.set(key, String(value));
    return Array.from(params.entries()).map(([key, value]) => `${key}=${value}`).join("&");
  };
  const encode = (value) => encodeURIComponent(String(value || ""));
  const decodeURIComponent189 = (value) => {
    try {
      return decodeURIComponent(String(value || ""));
    } catch (_) {
      return String(value || "");
    }
  };
  const sbox = Uint8Array.from([
    99,
    124,
    119,
    123,
    242,
    107,
    111,
    197,
    48,
    1,
    103,
    43,
    254,
    215,
    171,
    118,
    202,
    130,
    201,
    125,
    250,
    89,
    71,
    240,
    173,
    212,
    162,
    175,
    156,
    164,
    114,
    192,
    183,
    253,
    147,
    38,
    54,
    63,
    247,
    204,
    52,
    165,
    229,
    241,
    113,
    216,
    49,
    21,
    4,
    199,
    35,
    195,
    24,
    150,
    5,
    154,
    7,
    18,
    128,
    226,
    235,
    39,
    178,
    117,
    9,
    131,
    44,
    26,
    27,
    110,
    90,
    160,
    82,
    59,
    214,
    179,
    41,
    227,
    47,
    132,
    83,
    209,
    0,
    237,
    32,
    252,
    177,
    91,
    106,
    203,
    190,
    57,
    74,
    76,
    88,
    207,
    208,
    239,
    170,
    251,
    67,
    77,
    51,
    133,
    69,
    249,
    2,
    127,
    80,
    60,
    159,
    168,
    81,
    163,
    64,
    143,
    146,
    157,
    56,
    245,
    188,
    182,
    218,
    33,
    16,
    255,
    243,
    210,
    205,
    12,
    19,
    236,
    95,
    151,
    68,
    23,
    196,
    167,
    126,
    61,
    100,
    93,
    25,
    115,
    96,
    129,
    79,
    220,
    34,
    42,
    144,
    136,
    70,
    238,
    184,
    20,
    222,
    94,
    11,
    219,
    224,
    50,
    58,
    10,
    73,
    6,
    36,
    92,
    194,
    211,
    172,
    98,
    145,
    149,
    228,
    121,
    231,
    200,
    55,
    109,
    141,
    213,
    78,
    169,
    108,
    86,
    244,
    234,
    101,
    122,
    174,
    8,
    186,
    120,
    37,
    46,
    28,
    166,
    180,
    198,
    232,
    221,
    116,
    31,
    75,
    189,
    139,
    138,
    112,
    62,
    181,
    102,
    72,
    3,
    246,
    14,
    97,
    53,
    87,
    185,
    134,
    193,
    29,
    158,
    225,
    248,
    152,
    17,
    105,
    217,
    142,
    148,
    155,
    30,
    135,
    233,
    206,
    85,
    40,
    223,
    140,
    161,
    137,
    13,
    191,
    230,
    66,
    104,
    65,
    153,
    45,
    15,
    176,
    84,
    187,
    22
  ]);
  const rcon = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54];
  const xtime = (value) => (value << 1 ^ (value & 128 ? 27 : 0)) & 255;
  const addRoundKey = (state, keys, round) => {
    for (let i2 = 0; i2 < 16; i2 += 1) state[i2] ^= keys[round * 16 + i2];
  };
  const subBytes = (state) => {
    for (let i2 = 0; i2 < 16; i2 += 1) state[i2] = sbox[state[i2]];
  };
  const shiftRows = (state) => {
    const copy = Uint8Array.from(state);
    state[1] = copy[5];
    state[5] = copy[9];
    state[9] = copy[13];
    state[13] = copy[1];
    state[2] = copy[10];
    state[6] = copy[14];
    state[10] = copy[2];
    state[14] = copy[6];
    state[3] = copy[15];
    state[7] = copy[3];
    state[11] = copy[7];
    state[15] = copy[11];
  };
  const mixColumns = (state) => {
    for (let c = 0; c < 4; c += 1) {
      const i2 = c * 4;
      const a0 = state[i2];
      const a1 = state[i2 + 1];
      const a2 = state[i2 + 2];
      const a3 = state[i2 + 3];
      const t = a0 ^ a1 ^ a2 ^ a3;
      state[i2] ^= t ^ xtime(a0 ^ a1);
      state[i2 + 1] ^= t ^ xtime(a1 ^ a2);
      state[i2 + 2] ^= t ^ xtime(a2 ^ a3);
      state[i2 + 3] ^= t ^ xtime(a3 ^ a0);
    }
  };
  const expandKey = (key) => {
    const expanded = new Uint8Array(176);
    expanded.set(key.slice(0, 16));
    let bytesGenerated = 16;
    let rconIteration = 1;
    const temp = new Uint8Array(4);
    while (bytesGenerated < 176) {
      temp.set(expanded.slice(bytesGenerated - 4, bytesGenerated));
      if (bytesGenerated % 16 === 0) {
        const first = temp[0];
        temp[0] = sbox[temp[1]] ^ rcon[rconIteration];
        temp[1] = sbox[temp[2]];
        temp[2] = sbox[temp[3]];
        temp[3] = sbox[first];
        rconIteration += 1;
      }
      for (let i2 = 0; i2 < 4; i2 += 1) {
        expanded[bytesGenerated] = expanded[bytesGenerated - 16] ^ temp[i2];
        bytesGenerated += 1;
      }
    }
    return expanded;
  };
  const aesBlockEncrypt = (block, keys) => {
    const state = Uint8Array.from(block);
    addRoundKey(state, keys, 0);
    for (let round = 1; round < 10; round += 1) {
      subBytes(state);
      shiftRows(state);
      mixColumns(state);
      addRoundKey(state, keys, round);
    }
    subBytes(state);
    shiftRows(state);
    addRoundKey(state, keys, 10);
    return state;
  };
  const pkcs7Padding = (data, blockSize) => {
    const padding = blockSize - data.length % blockSize;
    const out = new Uint8Array(data.length + padding);
    out.set(data);
    out.fill(padding, data.length);
    return out;
  };
  const aesEncrypt = (data, key) => {
    const keys = expandKey(key.slice(0, 16));
    const padded = pkcs7Padding(data, 16);
    const out = new Uint8Array(padded.length);
    for (let offset = 0; offset < padded.length; offset += 16) {
      out.set(aesBlockEncrypt(padded.slice(offset, offset + 16), keys), offset);
    }
    return out;
  };
  const randomNonZeroByte = () => {
    let value = 0;
    while (value === 0) value = Math.floor(Math.random() * 256);
    return value;
  };
  const bytesToBigInt = (input) => BigInt(`0x${hex$8(input) || "0"}`);
  const bigIntToBytes = (value, length) => {
    let clean = value.toString(16);
    if (clean.length % 2) clean = `0${clean}`;
    const out = new Uint8Array(length);
    const start = Math.max(0, length - clean.length / 2);
    for (let i2 = 0; i2 < Math.min(length, clean.length / 2); i2 += 1) {
      out[start + i2] = Number.parseInt(clean.slice(i2 * 2, i2 * 2 + 2), 16);
    }
    return out;
  };
  const modPow = (base, exponent, modulus) => {
    let result = 1n;
    let b = base % modulus;
    let e = exponent;
    while (e > 0n) {
      if (e & 1n) result = result * b % modulus;
      e >>= 1n;
      b = b * b % modulus;
    }
    return result;
  };
  const readDerLength = (bytes2, cursor) => {
    let length = bytes2[cursor.index];
    cursor.index += 1;
    if (length < 128) return length;
    const count = length & 127;
    length = 0;
    for (let i2 = 0; i2 < count; i2 += 1) {
      length = length << 8 | bytes2[cursor.index];
      cursor.index += 1;
    }
    return length;
  };
  const readDer = (bytes2, cursor, tag) => {
    if (bytes2[cursor.index] !== tag) throw new Error("invalid 189Cloud RSA public key");
    cursor.index += 1;
    const length = readDerLength(bytes2, cursor);
    const start = cursor.index;
    cursor.index += length;
    return bytes2.slice(start, start + length);
  };
  const parseRsaPublicKey = (jRsakey) => {
    const der = base64ToBytes$8(String(jRsakey || "").replace(/-----[^-]+-----/g, "").replace(/\s+/g, ""));
    const outerCursor = { index: 0 };
    const spki = readDer(der, outerCursor, 48);
    const spkiCursor = { index: 0 };
    readDer(spki, spkiCursor, 48);
    const bitString = readDer(spki, spkiCursor, 3);
    const rsaDer = bitString.slice(1);
    const rsaCursor = { index: 0 };
    const sequence = readDer(rsaDer, rsaCursor, 48);
    const seqCursor = { index: 0 };
    let modulus = readDer(sequence, seqCursor, 2);
    const exponent = readDer(sequence, seqCursor, 2);
    while (modulus.length > 1 && modulus[0] === 0) modulus = modulus.slice(1);
    return { exponent: bytesToBigInt(exponent), modulus: bytesToBigInt(modulus), size: modulus.length };
  };
  const b64map = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const biRm = "0123456789abcdefghijklmnopqrstuvwxyz";
  const int2char = (value) => biRm[value];
  const b64tohex = (value) => {
    let out = "";
    let e = 0;
    let c = 0;
    for (const item of String(value || "")) {
      if (item === "=") continue;
      const v = b64map.indexOf(item);
      if (v < 0) continue;
      if (e === 0) {
        e = 1;
        out += int2char(v >> 2);
        c = 3 & v;
      } else if (e === 1) {
        e = 2;
        out += int2char(c << 2 | v >> 4);
        c = 15 & v;
      } else if (e === 2) {
        e = 3;
        out += int2char(c);
        out += int2char(v >> 2);
        c = 3 & v;
      } else {
        e = 0;
        out += int2char(c << 2 | v >> 4);
        out += int2char(15 & v);
      }
    }
    if (e === 1) out += int2char(c << 2);
    return out;
  };
  const rsaEncode = (origData, jRsakey, hexOutput) => {
    const { exponent, modulus, size } = parseRsaPublicKey(jRsakey);
    if (origData.length > size - 11) throw new Error("189Cloud RSA payload too large");
    const encoded = new Uint8Array(size);
    encoded[0] = 0;
    encoded[1] = 2;
    const padEnd = size - origData.length - 1;
    for (let i2 = 2; i2 < padEnd; i2 += 1) encoded[i2] = randomNonZeroByte();
    encoded[padEnd] = 0;
    encoded.set(origData, padEnd + 1);
    const encrypted = bigIntToBytes(modPow(bytesToBigInt(encoded), exponent, modulus), size);
    const b64 = bytesToBase64$7(encrypted);
    return hexOutput ? b64tohex(b64) : b64;
  };
  const getSessionKey = async (client, storage) => {
    const resp = await remoteJson(client, "https://cloud.189.cn/v2/getUserBriefInfo.action", {
      allowErrorStatus: true,
      headers: {
        Accept: "application/json;charset=UTF-8",
        Cookie: storage.addition_json.cookie || storage.addition_json.Cookie || "",
        Referer: "https://cloud.189.cn/",
        "User-Agent": "Mozilla/5.0"
      },
      method: "GET"
    });
    const sessionKey = (resp == null ? void 0 : resp.sessionKey) || "";
    if (!sessionKey) throw new Error("get 189Cloud sessionKey failed");
    return sessionKey;
  };
  const getResKey = async (client, storage) => {
    const addition = storage.addition_json || {};
    const now = Date.now();
    if (Number(addition.rsa_expire || addition.rsaExpire || 0) > now && (addition.rsa_pub_key || addition.pubKey) && (addition.rsa_pk_id || addition.pkId)) {
      return {
        pubKey: addition.rsa_pub_key || addition.pubKey,
        pkId: addition.rsa_pk_id || addition.pkId
      };
    }
    const resp = await remoteJson(client, "https://cloud.189.cn/api/security/generateRsaKey.action", {
      allowErrorStatus: true,
      headers: {
        Accept: "application/json;charset=UTF-8",
        Cookie: addition.cookie || addition.Cookie || "",
        Referer: "https://cloud.189.cn/",
        "User-Agent": "Mozilla/5.0"
      },
      method: "GET"
    });
    if (!(resp == null ? void 0 : resp.pubKey) || !(resp == null ? void 0 : resp.pkId)) throw new Error("get 189Cloud rsa key failed");
    addition.rsa_pub_key = resp.pubKey;
    addition.rsa_pk_id = resp.pkId;
    addition.rsa_expire = resp.expire;
    return { pubKey: resp.pubKey, pkId: resp.pkId };
  };
  const uploadRequest189 = async (client, storage, uri, form, sessionKey) => {
    const date = String(Date.now());
    const requestId = randomHex$1("xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx");
    let key = randomHex$1("xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx");
    key = key.slice(0, 16 + Math.floor(16 * Math.random()));
    const plain = qs(form);
    const encrypted = aesEncrypt(utf8Bytes$6(plain), utf8Bytes$6(key.slice(0, 16)));
    const params = hex$8(encrypted);
    const signature2 = hmacSha1(`SessionKey=${sessionKey}&Operate=GET&RequestURI=${uri}&Date=${date}&params=${params}`, key);
    const { pubKey, pkId } = await getResKey(client, storage);
    const encryptionText = rsaEncode(utf8Bytes$6(key), pubKey, false);
    const resp = await remoteJson(client, `https://upload.cloud.189.cn${uri}?params=${params}`, {
      allowErrorStatus: true,
      headers: {
        accept: "application/json;charset=UTF-8",
        SessionKey: sessionKey,
        Signature: signature2,
        "X-Request-Date": date,
        "X-Request-ID": requestId,
        EncryptionText: encryptionText,
        PkId: pkId
      },
      method: "GET"
    });
    if ((resp == null ? void 0 : resp.code) !== "SUCCESS") throw new Error(`${uri}---${(resp == null ? void 0 : resp.msg) || (resp == null ? void 0 : resp.code) || "189Cloud upload request failed"}`);
    return resp;
  };
  const parseUploadHeaders = (value) => {
    const headers = {};
    for (const item of decodeURIComponent189(value).split("&")) {
      const index = item.indexOf("=");
      if (index <= 0) continue;
      headers[item.slice(0, index)] = item.slice(index + 1);
    }
    return headers;
  };
  const sliceMd5 = (bytes2) => {
    const md5s = [];
    for (let offset = 0; offset < bytes2.length; offset += DEFAULT_SLICE_SIZE$1) {
      md5s.push(md5Hex$5(bytes2.slice(offset, Math.min(offset + DEFAULT_SLICE_SIZE$1, bytes2.length))).toUpperCase());
    }
    if (!md5s.length) md5s.push(md5Hex$5(new Uint8Array()).toUpperCase());
    return bytes2.length > DEFAULT_SLICE_SIZE$1 ? md5Hex$5(md5s.join("\n")) : md5s[0].toLowerCase();
  };
  const put189 = async (client, storage, resolveFile2, relPath, content, mime, options = {}) => {
    var _a2, _b2, _c;
    const dstDir = await resolveFile2(client, storage, dirnameOf(relPath));
    const bytes2 = uploadBytes$5(content, options);
    const sessionKey = await getSessionKey(client, storage);
    const fileMd5 = md5Hex$5(bytes2);
    const sliceMd5Hex = sliceMd5(bytes2);
    const init = await uploadRequest189(client, storage, "/person/initMultiUpload", {
      parentFolderId: String(dstDir.id || ""),
      fileName: encode(basenameOf(relPath)),
      fileSize: String(bytes2.length),
      sliceSize: String(DEFAULT_SLICE_SIZE$1),
      fileMd5,
      sliceMd5: sliceMd5Hex
    }, sessionKey);
    const uploadFileId = ((_a2 = init == null ? void 0 : init.data) == null ? void 0 : _a2.uploadFileId) || "";
    if (!uploadFileId) throw new Error("189Cloud initMultiUpload missing uploadFileId");
    if (Number(((_b2 = init == null ? void 0 : init.data) == null ? void 0 : _b2.fileDataExists) || 0) === 1) {
      await uploadRequest189(client, storage, "/person/commitMultiUploadFile", {
        uploadFileId,
        fileMd5,
        sliceMd5: sliceMd5Hex,
        lazyCheck: "1",
        opertype: "3"
      }, sessionKey);
      return;
    }
    const count = Math.ceil(bytes2.length / DEFAULT_SLICE_SIZE$1) || 1;
    for (let index = 1; index <= count; index += 1) {
      const start = (index - 1) * DEFAULT_SLICE_SIZE$1;
      const chunk = bytes2.slice(start, Math.min(start + DEFAULT_SLICE_SIZE$1, bytes2.length));
      const urls = await uploadRequest189(client, storage, "/person/getMultiUploadUrls", {
        partInfo: `${index}-${bytesToBase64$7(md5Bytes(chunk))}`,
        uploadFileId
      }, sessionKey);
      const uploadData = ((_c = urls == null ? void 0 : urls.uploadUrls) == null ? void 0 : _c[`partNumber_${index}`]) || {};
      if (!uploadData.requestURL) throw new Error(`189Cloud getMultiUploadUrls missing partNumber_${index}`);
      await forwardProxy(client, uploadData.requestURL, {
        body: bytesToBase64$7(chunk),
        contentType: mime || "application/octet-stream",
        headers: parseUploadHeaders(uploadData.requestHeader),
        method: "PUT",
        payloadEncoding: "base64",
        responseEncoding: "text"
      });
    }
    await uploadRequest189(client, storage, "/person/commitMultiUploadFile", {
      uploadFileId,
      fileMd5,
      sliceMd5: sliceMd5Hex,
      lazyCheck: "1",
      opertype: "3"
    }, sessionKey);
  };
  const USER_AGENT = "Mozilla/5.0 (Macintosh; Apple macOS 26_1_0) AppleWebKit/537.36 (KHTML, like Gecko) Safari/537.36 Chrome/142.0.0.0 OpenList/425.6.30";
  const headerValue$7 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of headerEntries$1(headers)) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? value.join("; ") : String(value || "");
    }
    return "";
  };
  const headerEntries$1 = (headers = {}) => {
    if (Array.isArray(headers)) {
      return headers.flatMap((item) => {
        if (!item || typeof item !== "object") return [];
        return Object.entries(item);
      });
    }
    return Object.entries(headers || {});
  };
  const cookiePairs$1 = (cookie) => String(cookie || "").split(";").map((item) => item.trim()).filter(Boolean).filter((item) => item.includes("="));
  const cookieNames = (cookie) => cookiePairs$1(cookie).map((item) => item.slice(0, item.indexOf("=")).trim()).filter(Boolean).sort();
  const filterCookieNames = (cookie, names) => {
    const values = /* @__PURE__ */ new Map();
    for (const item of cookiePairs$1(cookie)) {
      const name = item.slice(0, item.indexOf("=")).trim();
      values.set(name, item);
    }
    return names.map((name) => values.get(name)).filter(Boolean).join("; ");
  };
  const cookieForUrl = (storage, url) => {
    var _a2, _b2;
    const cookie = ((_a2 = storage.addition_json) == null ? void 0 : _a2.cookie) || ((_b2 = storage.addition_json) == null ? void 0 : _b2.Cookie) || "";
    try {
      const host = new URL(url).hostname;
      if (host === "open.e.189.cn") return filterCookieNames(cookie, ["pageOp", "LT", "GUID"]);
    } catch {
    }
    return cookie;
  };
  const mergeCookies$1 = (...cookies) => {
    const merged = /* @__PURE__ */ new Map();
    for (const cookie of cookies) {
      for (const pair of cookiePairs$1(cookie)) {
        const index = pair.indexOf("=");
        const key = pair.slice(0, index).trim();
        if (!key) continue;
        merged.set(key, pair.slice(index + 1).trim());
      }
    }
    return Array.from(merged, ([key, value]) => `${key}=${value}`).join("; ");
  };
  const setCookieToCookie$1 = (headers = {}) => {
    const values = [];
    for (const [key, value] of headerEntries$1(headers)) {
      if (String(key).toLowerCase() !== "set-cookie") continue;
      if (Array.isArray(value)) values.push(...value.map((item) => String(item || "")));
      else values.push(...String(value || "").split(/,(?=\s*[^;,=\s]+=[^;,]*)/));
    }
    return values.map((item) => item.trim().split(";")[0]).filter((item) => item.includes("=")).join("; ");
  };
  const formBody$3 = (data) => {
    const body = new URLSearchParams();
    for (const [key, value] of Object.entries(data || {})) body.set(key, String(value ?? ""));
    return body.toString();
  };
  const responseLocation = (response, baseUrl) => {
    const location = headerValue$7(response == null ? void 0 : response.headers, "Location");
    if (!location) return "";
    try {
      return new URL(location, baseUrl).toString();
    } catch {
      return location;
    }
  };
  const isRedirectStatus = (status) => [301, 302, 303, 307, 308].includes(Number(status));
  const remember189Cookies = async (storage, response) => {
    const addition = storage.addition_json || {};
    const setCookie2 = setCookieToCookie$1(response == null ? void 0 : response.headers);
    if (!setCookie2) return;
    addition.cookie = mergeCookies$1(addition.cookie || addition.Cookie || "", setCookie2);
    await persistAddition$1(storage);
  };
  const requestText = async (client, storage, url, options = {}) => {
    const headers = {
      Cookie: options.cookie === void 0 ? cookieForUrl(storage, url) : options.cookie,
      "User-Agent": USER_AGENT,
      ...options.headers || {}
    };
    const response = await forwardProxy(client, url, {
      allowErrorStatus: true,
      headers,
      redirect: options.redirect,
      responseEncoding: "text",
      body: options.body,
      contentType: options.contentType,
      method: options.method
    });
    await remember189Cookies(storage, response);
    return response;
  };
  const followLoginRedirect = async (client, storage, startUrl) => {
    let current = startUrl;
    let response = null;
    const chain = [];
    for (let index = 0; index < 10; index += 1) {
      response = await requestText(client, storage, current, {
        method: "GET",
        redirect: false
      });
      const location = responseLocation(response, current);
      chain.push({
        from: safeUrl(current),
        location: location ? safeUrl(location) : "",
        status: Number((response == null ? void 0 : response.status) || 0)
      });
      if (!isRedirectStatus(response.status) || !location) {
        return { chain, response, url: current };
      }
      current = location;
    }
    return { chain, response, url: current };
  };
  const safeUrl = (value) => {
    try {
      const url = new URL(value);
      const keys = Array.from(url.searchParams.keys()).sort();
      return `${url.origin}${url.pathname}${keys.length ? `?${keys.join(",")}` : ""}`;
    } catch {
      return String(value || "").split("?")[0];
    }
  };
  const loginContextSummary = ({ appId, chain, redirected, reqId: reqId2, storage, lt } = {}) => {
    var _a2, _b2;
    return JSON.stringify({
      app_id_present: !!appId,
      cookie_names: cookieNames(((_a2 = storage == null ? void 0 : storage.addition_json) == null ? void 0 : _a2.cookie) || ((_b2 = storage == null ? void 0 : storage.addition_json) == null ? void 0 : _b2.Cookie) || ""),
      final_url: safeUrl(redirected || ""),
      has_lt: !!lt,
      has_reqid: !!reqId2,
      redirect_chain: chain || []
    });
  };
  const postJson = async (client, storage, url, body, headers) => {
    const response = await requestText(client, storage, url, {
      body,
      contentType: "application/x-www-form-urlencoded; charset=UTF-8",
      headers,
      method: "POST"
    });
    try {
      return JSON.parse(response.body || "{}");
    } catch {
      throw new Error(`189Cloud invalid JSON response from ${url}`);
    }
  };
  const hasLoginCookie = (addition) => cookieNames((addition == null ? void 0 : addition.cookie) || (addition == null ? void 0 : addition.Cookie) || "").some((name) => /^(cookieUserSession|COOKIE_LOGIN_USER)$/i.test(name));
  const completeLogin = async (client, storage, payload) => {
    const addition = storage.addition_json || {};
    if (payload == null ? void 0 : payload.toUrl) {
      await followLoginRedirect(client, storage, payload.toUrl);
    }
    if (!hasLoginCookie(addition)) {
      throw new Error("189Cloud login failed: missing login cookie after successful authentication");
    }
    await persistAddition$1(storage);
  };
  class Cloud189SmsVerifyRequired extends Error {
    constructor(message, {
      addition,
      context,
      mobile,
      showName
    } = {}) {
      super(message);
      this.name = "Cloud189SmsVerifyRequired";
      this.verify = {
        type: "sms",
        mobile: mobile || "",
        second_context: context || null,
        show_name: showName || ""
      };
      this.addition = addition || {};
    }
  }
  const secondAuthHeaders = (context) => ({
    accept: "application/json;charset=UTF-8",
    "User-Agent": USER_AGENT,
    "X-Requested-With": "XMLHttpRequest",
    lt: context.lt || "",
    reqId: context.reqId || "",
    Referer: context.redirected || "",
    Origin: "https://open.e.189.cn"
  });
  const secondAuthData = (addition, context, smsCode) => {
    const conf = context.conf || {};
    const encrypt = context.encrypt || {};
    const userName = context.username || addition.username || "";
    return {
      mobile: context.mobile || "",
      appKey: context.appId || "cloud",
      userName: context.romaSecondAuth === "true" ? userName : `${encrypt.pre || ""}${rsaEncode(utf8Bytes$6(userName), encrypt.pubKey, true)}`,
      epd: `${encrypt.pre || ""}${rsaEncode(utf8Bytes$6(smsCode), encrypt.pubKey, true)}`,
      accountType: conf.accountType || "01",
      returnUrl: encodeURIComponent(conf.returnUrl || ""),
      isOauth2: String(!!conf.isOauth2),
      cb_SaveName: "3",
      state: conf.state || "",
      paramId: conf.paramId || ""
    };
  };
  const submitSecondAuth = async (client, storage, addition, context, smsCode) => {
    if (!context || !smsCode) throw new Error("189Cloud submitForSecondAuth failed: missing SMS verify context or code");
    const payload = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/submitForSecondAuth.do", formBody$3(secondAuthData(addition, context, smsCode)), secondAuthHeaders(context));
    if (Number(payload == null ? void 0 : payload.result) !== 0) {
      throw new Error(`189Cloud submitForSecondAuth failed: ${(payload == null ? void 0 : payload.msg) || ""}`);
    }
    await completeLogin(client, storage, payload);
  };
  const submit189Sms = async (client, storage, verify = {}) => {
    const addition = storage.addition_json || {};
    await submitSecondAuth(client, storage, addition, verify.second_context, verify.sms_code);
    return { addition };
  };
  const login189 = async (client, storage, { allowSms = true } = {}) => {
    const addition = storage.addition_json || {};
    if (!addition.username || !addition.password) return;
    const loginUrl = "https://cloud.189.cn/api/portal/loginUrl.action?redirectURL=https%3A%2F%2Fcloud.189.cn%2Fmain.action";
    const loginPage = await followLoginRedirect(client, storage, loginUrl);
    const redirected = loginPage.url || loginUrl;
    if (redirected === "https://cloud.189.cn/web/main") return;
    const redirectedUrl = new URL(redirected);
    const lt = redirectedUrl.searchParams.get("lt") || "";
    const reqId2 = redirectedUrl.searchParams.get("reqId") || "";
    const appId = redirectedUrl.searchParams.get("appId") || "cloud";
    const authHeaders = {
      lt,
      reqId: reqId2,
      Referer: redirected,
      Origin: "https://open.e.189.cn"
    };
    const ajaxHeaders = {
      accept: "application/json;charset=UTF-8",
      "User-Agent": USER_AGENT,
      "X-Requested-With": "XMLHttpRequest",
      ...authHeaders
    };
    const appConf = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/appConf.do", formBody$3({ version: "2.0", appKey: appId }), ajaxHeaders);
    if (String(appConf == null ? void 0 : appConf.result) !== "0") {
      throw new Error(`189Cloud appConf failed: ${(appConf == null ? void 0 : appConf.msg) || ""}; context=${loginContextSummary({
        appId,
        chain: loginPage.chain,
        redirected,
        reqId: reqId2,
        storage,
        lt
      })}`);
    }
    const encryptConf = await postJson(client, storage, "https://open.e.189.cn/api/logbox/config/encryptConf.do", formBody$3({ appId }), ajaxHeaders);
    if (Number(encryptConf == null ? void 0 : encryptConf.result) !== 0) throw new Error(`189Cloud encryptConf failed: ${(encryptConf == null ? void 0 : encryptConf.msg) || ""}`);
    const conf = appConf.data || {};
    const encrypt = encryptConf.data || {};
    const loginData = (apToken = "") => ({
      version: "v2.0",
      apToken,
      appKey: appId,
      pageKey: conf.pageKey || "",
      accountType: conf.accountType || "01",
      userName: `${encrypt.pre || ""}${rsaEncode(utf8Bytes$6(addition.username), encrypt.pubKey, true)}`,
      epd: `${encrypt.pre || ""}${rsaEncode(utf8Bytes$6(addition.password), encrypt.pubKey, true)}`,
      captchaType: "",
      validateCode: "",
      smsValidateCode: "",
      captchaToken: "",
      returnUrl: encodeURIComponent(conf.returnUrl || ""),
      mailSuffix: conf.mailSuffix || "@pan.cn",
      dynamicCheck: "FALSE",
      clientType: String(conf.clientType || 10010),
      cb_SaveName: "3",
      isOauth2: String(!!conf.isOauth2),
      state: "",
      paramId: conf.paramId || ""
    });
    let payload = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/loginSubmit.do", formBody$3(loginData()), ajaxHeaders);
    if (Number(payload == null ? void 0 : payload.result) === -134 && (payload == null ? void 0 : payload.apToken)) {
      payload = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/loginSubmit.do", formBody$3(loginData(payload.apToken)), ajaxHeaders);
    }
    if (Number(payload == null ? void 0 : payload.result) === -133) {
      if (!allowSms) {
        throw new Error("189Cloud SMS second verification is required; open the mount settings and verify SMS before browsing files");
      }
      const mobile = (payload == null ? void 0 : payload.mobile) || "";
      const showName = (payload == null ? void 0 : payload.showName) || "";
      const context = {
        appId,
        conf: {
          accountType: conf.accountType || "01",
          isOauth2: !!conf.isOauth2,
          paramId: conf.paramId || "",
          returnUrl: conf.returnUrl || "",
          state: conf.state || ""
        },
        encrypt: {
          pre: encrypt.pre || "",
          pubKey: encrypt.pubKey || ""
        },
        lt,
        mobile,
        redirected,
        reqId: reqId2,
        romaSecondAuth: (payload == null ? void 0 : payload.romaSecondAuth) || "",
        username: addition.username
      };
      const sendPayload = await postJson(client, storage, "https://open.e.189.cn/api/logbox/oauth2/sendSmsCodeForSecondAuth.do", formBody$3({
        mobile,
        appKey: appId
      }), ajaxHeaders);
      if (Number(sendPayload == null ? void 0 : sendPayload.result) !== 0) throw new Error(`189Cloud send second auth SMS failed: ${(sendPayload == null ? void 0 : sendPayload.msg) || ""}`);
      throw new Cloud189SmsVerifyRequired("189Cloud SMS second verification is required", {
        addition,
        context,
        mobile,
        showName
      });
    }
    if (Number(payload == null ? void 0 : payload.result) !== 0) throw new Error(`189Cloud loginSubmit failed: ${(payload == null ? void 0 : payload.msg) || ""}`);
    await completeLogin(client, storage, payload);
  };
  const randomNoCache = () => String(Date.now()) + String(Math.random()).slice(2, 8);
  const loginChecked = /* @__PURE__ */ new Set();
  const cookieHeader$1 = (addition) => addition.cookie || addition.Cookie || "";
  const storageLoginKey = (storage) => {
    var _a2, _b2;
    return String(storage.id || storage.mount_path || JSON.stringify({
      username: ((_a2 = storage.addition_json) == null ? void 0 : _a2.username) || "",
      root_folder_id: ((_b2 = storage.addition_json) == null ? void 0 : _b2.root_folder_id) || ""
    }));
  };
  const ensureLogin$2 = async (client, storage, { allowSms = false, force = false } = {}) => {
    const addition = storage.addition_json || {};
    if (!addition.username || !addition.password) return;
    const key = storageLoginKey(storage);
    if (!force && loginChecked.has(key)) return;
    if (!force && cookieHeader$1(addition)) {
      loginChecked.add(key);
      return;
    }
    await login189(client, storage, { allowSms });
    loginChecked.add(key);
  };
  const invalidSession = (payload) => {
    const text2 = [
      payload == null ? void 0 : payload.errorCode,
      payload == null ? void 0 : payload.errorMsg,
      payload == null ? void 0 : payload.res_message,
      payload == null ? void 0 : payload.resMessage,
      payload == null ? void 0 : payload.msg,
      payload == null ? void 0 : payload.message
    ].filter(Boolean).join(" ");
    return /InvalidSessionKey|cookieUserSession/i.test(text2);
  };
  const check189 = (payload) => {
    if (payload == null ? void 0 : payload.errorCode) throw new Error(payload.errorMsg || payload.errorCode);
    const code = Number((payload == null ? void 0 : payload.res_code) || (payload == null ? void 0 : payload.resCode) || 0);
    if (code !== 0) throw new Error((payload == null ? void 0 : payload.res_message) || (payload == null ? void 0 : payload.resMessage) || "189Cloud request failed");
    return payload;
  };
  const request189 = async (client, storage, url, {
    allowRelogin = false,
    body,
    contentType = "application/json",
    method = "GET",
    query = {},
    retried = false
  } = {}) => {
    await ensureLogin$2(client, storage);
    const target = new URL(url);
    target.searchParams.set("noCache", randomNoCache());
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const response = await forwardProxy(client, target.toString(), {
      allowErrorStatus: true,
      body,
      contentType,
      headers: {
        Accept: "application/json;charset=UTF-8",
        Cookie: cookieHeader$1(storage.addition_json),
        Referer: "https://cloud.189.cn/",
        "User-Agent": "Mozilla/5.0"
      },
      method
    });
    await remember189Cookies(storage, response);
    let resp;
    try {
      resp = JSON.parse(response.body || "{}");
    } catch (error) {
      throw new Error(`invalid JSON response from ${target.toString()}: ${error.message}`);
    }
    if (invalidSession(resp) && !retried) {
      if (!allowRelogin || cookieHeader$1(storage.addition_json)) {
        throw new Error("189Cloud login cookie is invalid or expired; open the mount settings and verify SMS again before browsing files");
      }
      await ensureLogin$2(client, storage, { force: true });
      return request189(client, storage, url, {
        allowRelogin,
        body,
        contentType,
        method,
        query,
        retried: true
      });
    }
    return check189(resp);
  };
  const formBody$2 = (data) => new URLSearchParams(
    Object.entries(data).map(([key, value]) => [key, typeof value === "string" ? value : JSON.stringify(value)])
  ).toString();
  const fileToObj$9 = (file, relPath, storage, isDir2) => {
    var _a2;
    return {
      name: file.name || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: !!isDir2,
      size: Number(file.size || 0),
      modified: parseTime$1(file.lastOpTime),
      created: parseTime$1(file.lastOpTime),
      sign: "",
      thumb: ((_a2 = file.icon) == null ? void 0 : _a2.smallUrl) || file.smallUrl || "",
      type: isDir2 ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: String(file.id || ""),
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider: "189Cloud",
      file: { ...file, is_dir: !!isDir2 }
    };
  };
  const rootFolderId$3 = (addition) => addition.root_folder_id || addition.RootFolderID || "-11";
  const listByParent$6 = async (client, storage, parentId) => {
    const result = [];
    let pageNum = 1;
    for (; ; ) {
      const resp = await request189(client, storage, "https://cloud.189.cn/api/open/file/listFiles.action", {
        method: "GET",
        query: {
          pageSize: "60",
          pageNum,
          mediaType: "0",
          folderId: parentId,
          iconOption: "5",
          orderBy: "lastOpTime",
          descending: "true"
        }
      });
      const list = resp.fileListAO || {};
      for (const folder of list.folderList || []) result.push({ ...folder, is_dir: true });
      for (const file of list.fileList || []) result.push({ ...file, is_dir: false });
      if (!list.count || !(list.folderList || []).length && !(list.fileList || []).length) break;
      pageNum += 1;
    }
    return result;
  };
  const resolveFile$7 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    if (clean === "/") {
      return {
        id: rootFolderId$3(storage.addition_json),
        name: "root",
        is_dir: true,
        path: "/"
      };
    }
    let parentId = rootFolderId$3(storage.addition_json);
    let current = null;
    for (const part of clean.split("/").filter(Boolean)) {
      const files = await listByParent$6(client, storage, parentId);
      current = files.find((item) => item.name === part);
      if (!current) throw new Error(`object not found: ${clean}`);
      parentId = String(current.id || "");
    }
    return current;
  };
  const headerValue$6 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const resolveRedirect$2 = async (client, url) => {
    const resp = await forwardProxy(client, url, {
      allowErrorStatus: true,
      headers: { "User-Agent": "Mozilla/5.0" },
      method: "GET",
      responseEncoding: "text"
    });
    return headerValue$6(resp.headers, "location") || url;
  };
  const linkFor$4 = async (client, storage, file) => {
    const resp = await request189(client, storage, "https://cloud.189.cn/api/portal/getFileInfo.action", {
      method: "GET",
      query: { fileId: file.id }
    });
    let url = resp.downloadUrl || resp.fileDownloadUrl || "";
    if (!url) throw new Error("get download url failed");
    if (url.startsWith("//")) url = "https:" + url;
    url = url.replace(/^http:\/\//, "https://");
    const redirected = await resolveRedirect$2(client, url);
    return redirected.replace(/^http:\/\//, "https://");
  };
  const batchTask$2 = async (client, storage, type, targetFolderId, files) => {
    const taskInfos = files.map((file) => ({
      fileId: String(file.id || ""),
      fileName: file.name || "",
      isFolder: file.is_dir ? 1 : 0
    }));
    await request189(client, storage, "https://cloud.189.cn/api/open/batch/createBatchTask.action", {
      body: formBody$2({
        type,
        targetFolderId: targetFolderId || "",
        taskInfos
      }),
      contentType: "application/x-www-form-urlencoded",
      method: "POST"
    });
  };
  const create189CloudDriver = ({ client }) => ({
    async verify(storage, verify) {
      if ((verify == null ? void 0 : verify.type) !== "sms") throw new Error("unsupported 189Cloud verify type");
      return submit189Sms(client, storage, verify);
    },
    async test(storage) {
      await ensureLogin$2(client, storage, { allowSms: true, force: true });
      await request189(client, storage, "https://cloud.189.cn/api/portal/getUserSizeInfo.action", { allowRelogin: true });
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$7(client, storage, relPath);
      const content = (await listByParent$6(client, storage, String(parent.id || ""))).map((file) => fileToObj$9(file, normalizePath(relPath + "/" + file.name), storage, file.is_dir));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "189Cloud",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$7(client, storage, relPath);
      const obj = fileToObj$9(file, relPath, storage, file.is_dir);
      if (!obj.is_dir && !options.skipLink) {
        const url = await linkFor$4(client, storage, file);
        obj.raw_url = url;
        obj.url = url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$7(client, storage, relPath);
      if (file.is_dir) throw new Error("not file");
      const url = await linkFor$4(client, storage, file);
      return {
        link: {
          url,
          header: options.proxyHeaders || options.headers || {},
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$7(client, storage, dirnameOf(relPath));
      await request189(client, storage, "https://cloud.189.cn/api/open/file/createFolder.action", {
        body: formBody$2({
          parentFolderId: String(parent.id || ""),
          folderName: basenameOf(relPath)
        }),
        contentType: "application/x-www-form-urlencoded",
        method: "POST"
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$7(client, storage, relPath);
      const dst = await resolveFile$7(client, storage, dstRelPath);
      await batchTask$2(client, storage, "MOVE", String(dst.id || ""), [file]);
    },
    async copy(storage, relPath, dstRelPath) {
      const file = await resolveFile$7(client, storage, relPath);
      const dst = await resolveFile$7(client, storage, dstRelPath);
      await batchTask$2(client, storage, "COPY", String(dst.id || ""), [file]);
    },
    async remove(storage, relPath) {
      const file = await resolveFile$7(client, storage, relPath);
      await batchTask$2(client, storage, "DELETE", "", [file]);
    },
    async rename(storage, relPath, newName) {
      const file = await resolveFile$7(client, storage, relPath);
      const isDir2 = !!file.is_dir;
      await request189(client, storage, isDir2 ? "https://cloud.189.cn/api/open/file/renameFolder.action" : "https://cloud.189.cn/api/open/file/renameFile.action", {
        body: formBody$2(isDir2 ? { folderId: String(file.id || ""), destFolderName: newName } : { fileId: String(file.id || ""), destFileName: newName }),
        contentType: "application/x-www-form-urlencoded",
        method: "POST"
      });
    },
    async put(storage, relPath, content, mime, options = {}) {
      await put189(client, storage, resolveFile$7, relPath, content, mime, options);
    }
  });
  const API_URL$2 = "https://api.cloud.189.cn";
  const TV_APP_KEY = "600100885";
  const TV_APP_SIGNATURE_SECRET = "fe5734c74c2f96a38157f420b32dc995";
  const TV_QR_LOGIN_URL = "https://open.e.189.cn/api/account/qrClinentLogin.do";
  const TV_QR_KEYS = ["temp_uuid", "TempUuid", "temp_qr_text"];
  const utf8$1 = (input) => unescape(encodeURIComponent(String(input)));
  const bytes$1 = (input) => {
    if (input instanceof Uint8Array) return input;
    const text2 = utf8$1(input);
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const hex$7 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const rol$5 = (value, bits2) => value << bits2 | value >>> 32 - bits2;
  const sha1Bytes$5 = (message) => {
    const msg = bytes$1(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i2 = 0; i2 < 16; i2 += 1) w[i2] = view.getUint32(offset + i2 * 4);
      for (let i2 = 16; i2 < 80; i2 += 1) w[i2] = rol$5(w[i2 - 3] ^ w[i2 - 8] ^ w[i2 - 14] ^ w[i2 - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i2 = 0; i2 < 80; i2 += 1) {
        let f;
        let k;
        if (i2 < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i2 < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i2 < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$5(a, 5) + f + e + k + w[i2] >>> 0;
        e = d;
        d = c;
        c = rol$5(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const hmacSha1Hex$1 = (key, message) => {
    let keyBytes = bytes$1(key);
    if (keyBytes.length > 64) keyBytes = sha1Bytes$5(keyBytes);
    const ipad = new Uint8Array(64);
    const opad = new Uint8Array(64);
    for (let i2 = 0; i2 < 64; i2 += 1) {
      const b = keyBytes[i2] || 0;
      ipad[i2] = b ^ 54;
      opad[i2] = b ^ 92;
    }
    const msg = bytes$1(message);
    const inner = new Uint8Array(ipad.length + msg.length);
    inner.set(ipad);
    inner.set(msg, ipad.length);
    const outer = new Uint8Array(opad.length + 20);
    outer.set(opad);
    outer.set(sha1Bytes$5(inner), opad.length);
    return hex$7(sha1Bytes$5(outer)).toUpperCase();
  };
  const pathOfUrl$1 = (url) => new URL(url).pathname || "/";
  const httpDate$1 = () => (/* @__PURE__ */ new Date()).toUTCString();
  const timestamp$1 = () => Date.now();
  const tvClientSuffix = () => ({
    clientType: "FAMILY_TV",
    version: "6.5.5",
    channelId: "home02",
    clientSn: "unknown",
    model: "PJX110",
    osFamily: "Android",
    osVersion: "35",
    networkAccessMode: "WIFI",
    telecomsOperator: "46011"
  });
  const toDesc$1 = (order) => order === "desc" ? "true" : "false";
  const toFamilyOrderBy$1 = (order) => {
    if (order === "filesize") return "2";
    if (order === "lastOpTime") return "3";
    return "1";
  };
  const familyMode$1 = (addition) => (addition.type || addition.Type || "personal") === "family";
  const rootFolderId$2 = (addition, isFamily) => {
    const value = addition.root_folder_id || addition.RootFolderID;
    if (isFamily && value === "-11") return "";
    if (value !== void 0 && value !== null && value !== "") return String(value);
    return isFamily ? "" : "-11";
  };
  const familyId$1 = (addition) => String(addition.family_id || addition.FamilyID || "");
  const normalize189SessionAddition$1 = (addition) => {
    if (familyMode$1(addition) && (addition.root_folder_id || addition.RootFolderID) === "-11") {
      addition.root_folder_id = "";
      delete addition.RootFolderID;
    }
    if (!familyMode$1(addition) && !(addition.root_folder_id || addition.RootFolderID)) {
      addition.root_folder_id = "-11";
      delete addition.RootFolderID;
    }
  };
  const checkResp$2 = (payload) => {
    if (!payload || typeof payload !== "object") return payload;
    const resCode = payload.res_code ?? payload.resCode;
    if (resCode !== void 0 && resCode !== null && resCode !== "" && Number(resCode) !== 0) {
      throw new Error(payload.res_message || payload.resMessage || `res_code: ${resCode}`);
    }
    if (payload.errorCode) throw new Error(payload.errorMsg || payload.errorCode);
    if (payload.code && payload.code !== "SUCCESS") throw new Error(payload.message || payload.msg || payload.code);
    if (payload.error) throw new Error(payload.message || payload.error);
    return payload;
  };
  const parse189Json$1 = (text2, url) => {
    const safe = String(text2 || "{}").replace(
      /"((?:id|parentId|familyId|fileId|folderId|targetFolderId|uploadFileId|userFileId|operId|srcFileOwnerId|taskId))"\s*:\s*(-?\d{15,})/gi,
      (_, key, value) => `"${key}":"${value}"`
    );
    try {
      return JSON.parse(safe);
    } catch (error) {
      throw new Error(`invalid JSON response from ${url}: ${error.message}`);
    }
  };
  const remote189Json$1 = async (client, url, options) => {
    const data = await forwardProxy(client, url, options);
    return parse189Json$1(data.body, url);
  };
  const headerValue$5 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const resolveRedirect$1 = async (client, url) => {
    const resp = await forwardProxy(client, url, {
      allowErrorStatus: true,
      headers: { "User-Agent": "Mozilla/5.0" },
      method: "GET",
      redirect: false,
      responseEncoding: "text"
    });
    return headerValue$5(resp.headers, "location") || url;
  };
  const requestTvAppKeyRaw = async (client, url, query = {}) => {
    const target = new URL(url);
    for (const [key, value] of Object.entries({ ...tvClientSuffix(), ...query })) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const tempTime = timestamp$1();
    const signText = `AppKey=${TV_APP_KEY}&Operate=GET&RequestURI=${pathOfUrl$1(url)}&Timestamp=${tempTime}`;
    return remote189Json$1(client, target.toString(), {
      allowErrorStatus: true,
      headers: {
        Accept: "application/json;charset=UTF-8",
        AppKey: TV_APP_KEY,
        AppSignature: hmacSha1Hex$1(TV_APP_SIGNATURE_SECRET, signText),
        Timestamp: String(tempTime),
        "User-Agent": "EcloudTV/6.5.5 (PJX110; unknown; home02) Android/35",
        "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}`
      },
      method: "GET"
    });
  };
  const requestTvAppKeyJson = async (client, url, query = {}) => checkResp$2(await requestTvAppKeyRaw(client, url, query));
  const jsonWithSignedQuery$1 = async (client, url, {
    addition,
    body,
    isFamily = false,
    method = "GET",
    query = {},
    responseEncoding = "text"
  } = {}) => {
    const target = new URL(url);
    const suffix = tvClientSuffix();
    for (const [key, value] of Object.entries({ ...suffix, ...query })) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const sessionKey = isFamily ? addition.familySessionKey : addition.sessionKey;
    const sessionSecret = isFamily ? addition.familySessionSecret : addition.sessionSecret;
    if (!sessionKey || !sessionSecret) throw new Error("189CloudTV requires access_token plus sessionKey/sessionSecret fields. Re-save after upstream login/session migration or import an OpenList-compatible session addition.");
    const date = httpDate$1();
    const signText = `SessionKey=${sessionKey}&Operate=${method}&RequestURI=${pathOfUrl$1(url)}&Date=${date}`;
    const headers = {
      Accept: "application/json;charset=UTF-8",
      Date: date,
      SessionKey: sessionKey,
      Signature: hmacSha1Hex$1(sessionSecret, signText),
      "User-Agent": "EcloudTV/6.5.5 (PJX110; unknown; home02) Android/35",
      "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}`
    };
    const resp = await remote189Json$1(client, target.toString(), {
      allowErrorStatus: true,
      body,
      contentType: "application/x-www-form-urlencoded",
      headers,
      method,
      responseEncoding
    });
    return checkResp$2(resp);
  };
  const refreshTvSession = async (client, storage) => {
    const addition = storage.addition_json;
    normalize189SessionAddition$1(addition);
    const accessToken2 = addition.access_token || addition.AccessToken;
    if (!accessToken2) throw new Error("189CloudTV access_token is empty; QR-code login is required");
    const url = `${API_URL$2}/family/manage/loginFamilyMerge.action`;
    const resp = await requestTvAppKeyJson(client, url, {
      e189AccessToken: accessToken2
    });
    addition.sessionKey = resp.sessionKey;
    addition.sessionSecret = resp.sessionSecret;
    addition.familySessionKey = resp.familySessionKey;
    addition.familySessionSecret = resp.familySessionSecret;
    addition.loginName = resp.loginName;
    if (familyMode$1(addition) && !familyId$1(addition)) {
      const familyResp = await jsonWithSignedQuery$1(client, `${API_URL$2}/family/manage/getFamilyList.action`, {
        addition,
        isFamily: true
      });
      const families = Array.isArray(familyResp.familyInfoResp) ? familyResp.familyInfoResp : [];
      const matched = families.find((item) => addition.loginName && String(item.remarkName || "").includes(addition.loginName)) || families.find((item) => addition.loginName && String(addition.loginName).includes(item.remarkName || "\0")) || families[0];
      if ((matched == null ? void 0 : matched.familyId) !== void 0 && (matched == null ? void 0 : matched.familyId) !== null) addition.family_id = String(matched.familyId);
    }
    await persistAddition$1(storage);
    return addition;
  };
  const tvQrText = (uuid) => {
    const value = String(uuid || "");
    if (/^https?:\/\//i.test(value)) return value;
    const url = new URL(TV_QR_LOGIN_URL);
    url.searchParams.set("paras", `new_uuid=${value}`);
    return url.toString();
  };
  const extractTvQrText = (message, fallbackUuid) => {
    var _a2;
    const text2 = String(message);
    const match = text2.match(/https:\/\/open\.e\.189\.cn\/api\/account\/qrClinentLogin\.do\?paras=[^\s,"'()<>]+/i);
    if (match == null ? void 0 : match[0]) return match[0];
    const paras = (_a2 = text2.match(/paras=([^\s,"'()<>]+)/i)) == null ? void 0 : _a2[1];
    return paras ? `${TV_QR_LOGIN_URL}?paras=${paras}` : tvQrText(fallbackUuid);
  };
  const startTvQrLogin = async (client, storage) => {
    const addition = storage.addition_json;
    const resp = await requestTvAppKeyJson(client, `${API_URL$2}/family/manage/getQrCodeUUID.action`);
    if (!resp.uuid) throw new Error("uuidInfo is empty");
    addition.temp_uuid = resp.uuid;
    addition.temp_qr_text = tvQrText(resp.uuid);
    await persistAddition$1(storage);
    return {
      message: "请使用天翼云盘 App 扫码登录，然后再次点击验证/保存。",
      status: "waiting",
      verify: { qr_text: addition.temp_qr_text }
    };
  };
  const pollTvQrLogin = async (client, storage) => {
    const addition = storage.addition_json;
    const tempUuid = addition.temp_uuid || addition.TempUuid;
    const resp = await requestTvAppKeyRaw(client, `${API_URL$2}/family/manage/qrcodeLoginResult.action`, {
      uuid: tempUuid
    });
    const accessToken2 = resp.accessToken || resp.e189AccessToken;
    if (accessToken2) return { accessToken: accessToken2, message: "189CloudTV QR login confirmed", status: "success" };
    const message = resp.res_message || resp.resMessage || resp.errorMsg || resp.message || resp.msg || "189CloudTV QR login pending";
    const code = String(resp.res_code || resp.resCode || resp.errorCode || resp.code || "");
    if (/expired|expire|timeout|QrCodeExpired/i.test(`${code} ${message}`)) {
      return { message: message || "189CloudTV QR code expired", status: "expired" };
    }
    if (/QrCodeRollLoginFail|qrCodeRollLogin/i.test(`${code} ${message}`)) {
      addition.temp_qr_text = extractTvQrText(message, tempUuid);
      await persistAddition$1(storage);
      return {
        message: "请使用天翼云盘 App 扫码登录，然后再次点击验证/保存。",
        status: "waiting"
      };
    }
    return {
      message,
      status: /confirm|scanned|已扫码|待确认/i.test(message) ? "scanned" : "waiting"
    };
  };
  const runTvQrLogin = (client, storage) => runQrLogin({
    addition: storage.addition_json,
    clear: () => {
      clearQrKeys(storage.addition_json, TV_QR_KEYS);
      return persistAddition$1(storage);
    },
    confirm: async (state) => {
      storage.addition_json.access_token = state.accessToken;
      delete storage.addition_json.AccessToken;
      await persistAddition$1(storage);
      return refreshTvSession(client, storage);
    },
    hasSession: (addition) => Boolean(addition.temp_uuid || addition.TempUuid),
    pendingVerify: () => ({ qr_text: storage.addition_json.temp_qr_text || tvQrText(storage.addition_json.temp_uuid || storage.addition_json.TempUuid) }),
    poll: () => pollTvQrLogin(client, storage),
    start: () => startTvQrLogin(client, storage)
  });
  const loginTvByQrCode = async (client, storage) => {
    const addition = storage.addition_json;
    return addition.access_token || addition.AccessToken ? refreshTvSession(client, storage) : runTvQrLogin(client, storage);
  };
  const ensureSession$1 = async (client, storage) => {
    const addition = storage.addition_json;
    if (addition.sessionKey && addition.sessionSecret) return addition;
    return refreshTvSession(client, storage);
  };
  const request189Session$1 = async (client, storage, url, opts = {}) => {
    const addition = await ensureSession$1(client, storage);
    return jsonWithSignedQuery$1(client, url, { ...opts, addition });
  };
  const fileToObj$8 = (file, relPath, storage, provider) => {
    var _a2;
    const isDir2 = !!file.is_dir;
    return {
      name: file.name || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: parseTime$1(file.lastOpTime || file.createDate),
      created: parseTime$1(file.createDate || file.lastOpTime),
      sign: "",
      thumb: ((_a2 = file.icon) == null ? void 0 : _a2.smallUrl) || file.smallUrl || "",
      type: isDir2 ? 1 : 0,
      hashinfo: file.md5 || file.Md5 || "",
      hash_info: file.md5 ? { md5: file.md5 } : {},
      id: String(file.id || ""),
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider,
      file: { ...file, is_dir: isDir2 }
    };
  };
  const listByParent$5 = async (client, storage, parentId) => {
    const addition = storage.addition_json;
    const isFamily = familyMode$1(addition);
    const url = `${API_URL$2}${isFamily ? "/family/file" : ""}/listFiles.action`;
    const result = [];
    const pageSize2 = 130;
    for (let pageNum = 1; ; pageNum += 1) {
      const query = {
        folderId: parentId,
        fileType: "0",
        mediaAttr: "0",
        iconOption: "5",
        pageNum,
        pageSize: pageSize2,
        recursive: isFamily ? void 0 : "0",
        orderBy: isFamily ? toFamilyOrderBy$1(addition.order_by || addition.OrderBy || "filename") : addition.order_by || addition.OrderBy || "filename",
        descending: toDesc$1(addition.order_direction || addition.OrderDirection || "asc"),
        familyId: isFamily ? familyId$1(addition) : void 0
      };
      const resp = await request189Session$1(client, storage, url, { isFamily, query });
      const list = resp.fileListAO || {};
      for (const folder of list.folderList || []) result.push({ ...folder, is_dir: true });
      for (const file of list.fileList || []) result.push({ ...file, is_dir: false });
      if (!list.count || !(list.folderList || []).length && !(list.fileList || []).length) break;
    }
    return result;
  };
  const resolveFile$6 = async (client, storage, relPath) => {
    const addition = storage.addition_json;
    const isFamily = familyMode$1(addition);
    const clean = normalizePath(relPath || "/");
    if (clean === "/") {
      return {
        id: rootFolderId$2(addition, isFamily),
        name: "root",
        is_dir: true,
        path: "/"
      };
    }
    let parentId = rootFolderId$2(addition, isFamily);
    let current = null;
    for (const part of clean.split("/").filter(Boolean)) {
      const files = await listByParent$5(client, storage, parentId);
      current = files.find((item) => item.name === part);
      if (!current) throw new Error(`object not found: ${clean}`);
      parentId = String(current.id || "");
    }
    return current;
  };
  const linkFor$3 = async (client, storage, file) => {
    const addition = storage.addition_json;
    const isFamily = familyMode$1(addition);
    const url = `${API_URL$2}${isFamily ? "/family/file" : ""}/getFileDownloadUrl.action`;
    const resp = await request189Session$1(client, storage, url, {
      isFamily,
      query: {
        fileId: file.id,
        familyId: isFamily ? familyId$1(addition) : void 0,
        dt: isFamily ? void 0 : "3",
        flag: isFamily ? void 0 : "1"
      }
    });
    let downloadUrl = resp.fileDownloadUrl || resp.downloadUrl || "";
    if (!downloadUrl) throw new Error("get download url failed");
    if (downloadUrl.startsWith("//")) downloadUrl = "https:" + downloadUrl;
    downloadUrl = downloadUrl.replace(/&amp;/g, "&").replace(/^http:\/\//, "https://");
    return (await resolveRedirect$1(client, downloadUrl)).replace(/^http:\/\//, "https://");
  };
  const formBody$1 = (data) => new URLSearchParams(
    Object.entries(data).filter(([, value]) => value !== void 0 && value !== null && value !== "").map(([key, value]) => [key, typeof value === "string" ? value : JSON.stringify(value)])
  ).toString();
  const batchTask$1 = async (client, storage, type, targetFolderId, files, other = {}) => {
    const addition = storage.addition_json;
    const isFamily = familyMode$1(addition);
    const taskInfos = files.map((file) => ({
      fileId: String(file.id || ""),
      fileName: file.name || "",
      isFolder: file.is_dir ? 1 : 0
    }));
    await request189Session$1(client, storage, `${API_URL$2}/batch/createBatchTask.action`, {
      body: formBody$1({
        type,
        targetFolderId,
        familyId: isFamily ? familyId$1(addition) : void 0,
        taskInfos,
        ...other
      }),
      isFamily,
      method: "POST"
    });
  };
  const create189SessionDriver$1 = ({ client, provider }) => ({
    async test(storage) {
      await loginTvByQrCode(client, storage);
      await request189Session$1(client, storage, `${API_URL$2}/getUserInfo.action`);
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$6(client, storage, relPath);
      const content = (await listByParent$5(client, storage, String(parent.id || ""))).map((file) => fileToObj$8(file, normalizePath(relPath + "/" + file.name), storage, provider));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider,
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$6(client, storage, relPath);
      const obj = fileToObj$8(file, relPath, storage, provider);
      if (!obj.is_dir && !options.skipLink) {
        const url = await linkFor$3(client, storage, file);
        obj.raw_url = url;
        obj.url = url;
      }
      return { ...obj, readme: "", header: "", related: [] };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$6(client, storage, relPath);
      if (file.is_dir) throw new Error("not file");
      const url = await linkFor$3(client, storage, file);
      return {
        link: {
          url,
          header: { "User-Agent": "Mozilla/5.0", ...options.proxyHeaders || options.headers || {} },
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      const addition = storage.addition_json;
      const isFamily = familyMode$1(addition);
      const parent = await resolveFile$6(client, storage, dirnameOf(relPath));
      await request189Session$1(client, storage, `${API_URL$2}${isFamily ? "/family/file" : ""}/createFolder.action`, {
        isFamily,
        method: "POST",
        query: {
          familyId: isFamily ? familyId$1(addition) : void 0,
          parentId: isFamily ? String(parent.id || "") : void 0,
          parentFolderId: isFamily ? void 0 : String(parent.id || ""),
          folderName: basenameOf(relPath),
          relativePath: ""
        }
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$6(client, storage, relPath);
      const dst = await resolveFile$6(client, storage, dstRelPath);
      await batchTask$1(client, storage, "MOVE", String(dst.id || ""), [file], { targetFileName: dst.name || "" });
    },
    async copy(storage, relPath, dstRelPath) {
      const file = await resolveFile$6(client, storage, relPath);
      const dst = await resolveFile$6(client, storage, dstRelPath);
      await batchTask$1(client, storage, "COPY", String(dst.id || ""), [file], { targetFileName: dst.name || "" });
    },
    async remove(storage, relPath) {
      const file = await resolveFile$6(client, storage, relPath);
      await batchTask$1(client, storage, "DELETE", "", [file]);
    },
    async rename(storage, relPath, newName) {
      const addition = storage.addition_json;
      const isFamily = familyMode$1(addition);
      const file = await resolveFile$6(client, storage, relPath);
      const isDir2 = !!file.is_dir;
      await request189Session$1(client, storage, `${API_URL$2}${isFamily ? "/family/file" : ""}/${isDir2 ? "renameFolder" : "renameFile"}.action`, {
        isFamily,
        method: isFamily ? "GET" : "POST",
        query: {
          familyId: isFamily ? familyId$1(addition) : void 0,
          folderId: isDir2 ? String(file.id || "") : void 0,
          fileId: isDir2 ? void 0 : String(file.id || ""),
          destFolderName: isDir2 ? newName : void 0,
          destFileName: isDir2 ? void 0 : newName
        }
      });
    },
    async put() {
      throw new Error(`${provider} old upload / rapid upload is not implemented in the SiYuan kernel port yet`);
    }
  });
  const create189CloudTVDriver = ({ client }) => create189SessionDriver$1({
    client,
    provider: "189CloudTV"
  });
  const API_URL$1 = "https://api.cloud.189.cn";
  const WEB_URL = "https://cloud.189.cn";
  const AUTH_URL = "https://open.e.189.cn";
  const PC_APP_ID = "8025431004";
  const PC_CLIENT_TYPE = "10020";
  const PC_RETURN_URL = "https://m.cloud.189.cn/zhuanti/2020/loginErrorPc/index.html";
  const PC_QR_KEYS = [
    "qrcode_uuid",
    "qrcode_encryuuid",
    "qrcode_encodeuuid",
    "qrcode_lt",
    "qrcode_reqid",
    "qrcode_param_id",
    "qrcode_captcha_token",
    "qrcode_cookie"
  ];
  const utf8 = (input) => unescape(encodeURIComponent(String(input)));
  const bytes = (input) => {
    if (input instanceof Uint8Array) return input;
    const text2 = utf8(input);
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const hex$6 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const rol$4 = (value, bits2) => value << bits2 | value >>> 32 - bits2;
  const sha1Bytes$4 = (message) => {
    const msg = bytes(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i2 = 0; i2 < 16; i2 += 1) w[i2] = view.getUint32(offset + i2 * 4);
      for (let i2 = 16; i2 < 80; i2 += 1) w[i2] = rol$4(w[i2 - 3] ^ w[i2 - 8] ^ w[i2 - 14] ^ w[i2 - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i2 = 0; i2 < 80; i2 += 1) {
        let f;
        let k;
        if (i2 < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i2 < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i2 < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$4(a, 5) + f + e + k + w[i2] >>> 0;
        e = d;
        d = c;
        c = rol$4(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const hmacSha1Hex = (key, message) => {
    let keyBytes = bytes(key);
    if (keyBytes.length > 64) keyBytes = sha1Bytes$4(keyBytes);
    const ipad = new Uint8Array(64);
    const opad = new Uint8Array(64);
    for (let i2 = 0; i2 < 64; i2 += 1) {
      const b = keyBytes[i2] || 0;
      ipad[i2] = b ^ 54;
      opad[i2] = b ^ 92;
    }
    const msg = bytes(message);
    const inner = new Uint8Array(ipad.length + msg.length);
    inner.set(ipad);
    inner.set(msg, ipad.length);
    const outer = new Uint8Array(opad.length + 20);
    outer.set(opad);
    outer.set(sha1Bytes$4(inner), opad.length);
    return hex$6(sha1Bytes$4(outer)).toUpperCase();
  };
  const pathOfUrl = (url) => new URL(url).pathname || "/";
  const httpDate = () => (/* @__PURE__ */ new Date()).toUTCString();
  const timestamp = () => Date.now();
  const randomSuffix = () => `${Math.floor(Math.random() * 1e5)}_${Math.floor(Math.random() * 1e10)}`;
  const formatPcQrDate = (date = /* @__PURE__ */ new Date()) => {
    const pad2 = (value, length = 2) => String(value).padStart(length, "0");
    return `${date.getFullYear()}-${pad2(date.getMonth() + 1)}-${pad2(date.getDate())}${pad2(date.getHours())}:${pad2(date.getMinutes())}:${pad2(date.getSeconds())}.${pad2(date.getMilliseconds(), 3)}`;
  };
  const toDesc = (order) => order === "desc" ? "true" : "false";
  const toFamilyOrderBy = (order) => {
    if (order === "filesize") return "2";
    if (order === "lastOpTime") return "3";
    return "1";
  };
  const familyMode = (addition) => (addition.type || addition.Type || "personal") === "family";
  const rootFolderId$1 = (addition, isFamily) => {
    const value = addition.root_folder_id || addition.RootFolderID;
    if (isFamily && value === "-11") return "";
    if (value !== void 0 && value !== null && value !== "") return String(value);
    return isFamily ? "" : "-11";
  };
  const familyId = (addition) => String(addition.family_id || addition.FamilyID || "");
  const normalize189SessionAddition = (addition) => {
    if (familyMode(addition) && (addition.root_folder_id || addition.RootFolderID) === "-11") {
      addition.root_folder_id = "";
      delete addition.RootFolderID;
    }
    if (!familyMode(addition) && !(addition.root_folder_id || addition.RootFolderID)) {
      addition.root_folder_id = "-11";
      delete addition.RootFolderID;
    }
  };
  const checkResp$1 = (payload) => {
    if (!payload || typeof payload !== "object") return payload;
    const resCode = payload.res_code ?? payload.resCode;
    if (resCode !== void 0 && resCode !== null && resCode !== "" && Number(resCode) !== 0) {
      throw new Error(payload.res_message || payload.resMessage || `res_code: ${resCode}`);
    }
    if (payload.errorCode) throw new Error(payload.errorMsg || payload.errorCode);
    if (payload.code && payload.code !== "SUCCESS") throw new Error(payload.message || payload.msg || payload.code);
    if (payload.error) throw new Error(payload.message || payload.error);
    return payload;
  };
  const headerEntries = (headers = {}) => {
    if (Array.isArray(headers)) {
      return headers.flatMap((item) => {
        if (!item || typeof item !== "object") return [];
        return Object.entries(item);
      });
    }
    return Object.entries(headers || {});
  };
  const cookiePairs = (cookie) => String(cookie || "").split(";").map((item) => item.trim()).filter(Boolean).filter((item) => item.includes("="));
  const mergeCookies = (...cookies) => {
    const merged = /* @__PURE__ */ new Map();
    for (const cookie of cookies) {
      for (const pair of cookiePairs(cookie)) {
        const index = pair.indexOf("=");
        const key = pair.slice(0, index).trim();
        if (!key) continue;
        merged.set(key, pair.slice(index + 1).trim());
      }
    }
    return Array.from(merged, ([key, value]) => `${key}=${value}`).join("; ");
  };
  const setCookieToCookie = (headers = {}) => {
    const values = [];
    for (const [key, value] of headerEntries(headers)) {
      if (String(key).toLowerCase() !== "set-cookie") continue;
      if (Array.isArray(value)) values.push(...value.map((item) => String(item || "")));
      else values.push(...String(value || "").split(/,(?=\s*[^;,=\s]+=[^;,]*)/));
    }
    return values.map((item) => item.trim().split(";")[0]).filter((item) => item.includes("=")).join("; ");
  };
  const rememberPcQrCookies = async (storage, response) => {
    const addition = storage.addition_json || {};
    const setCookie2 = setCookieToCookie(response == null ? void 0 : response.headers);
    if (!setCookie2) return;
    addition.qrcode_cookie = mergeCookies(addition.qrcode_cookie || "", setCookie2);
    await persistAddition$1(storage);
  };
  const parse189Json = (text2, url) => {
    const safe = String(text2 || "{}").replace(
      /"((?:id|parentId|familyId|fileId|folderId|targetFolderId|uploadFileId|userFileId|operId|srcFileOwnerId|taskId))"\s*:\s*(-?\d{15,})/gi,
      (_, key, value) => `"${key}":"${value}"`
    );
    try {
      return JSON.parse(safe);
    } catch (error) {
      throw new Error(`invalid JSON response from ${url}: ${error.message}`);
    }
  };
  const remote189Json = async (client, url, options = {}) => {
    const data = await forwardProxy(client, url, options);
    if (options.rememberPcCookies) await rememberPcQrCookies(options.storage, data);
    return parse189Json(data.body, url);
  };
  const remote189Text = async (client, storage, url, options = {}) => {
    var _a2;
    const data = await forwardProxy(client, url, {
      allowErrorStatus: true,
      headers: {
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        Cookie: ((_a2 = storage == null ? void 0 : storage.addition_json) == null ? void 0 : _a2.qrcode_cookie) || "",
        Referer: WEB_URL,
        "User-Agent": "Mozilla/5.0",
        ...options.headers || {}
      },
      method: "GET",
      responseEncoding: "text",
      ...options
    });
    if (storage) await rememberPcQrCookies(storage, data);
    return String(data.body || "");
  };
  const headerValue$4 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const resolveRedirect = async (client, url) => {
    const resp = await forwardProxy(client, url, {
      allowErrorStatus: true,
      headers: { "User-Agent": "Mozilla/5.0" },
      method: "GET",
      redirect: false,
      responseEncoding: "text"
    });
    return headerValue$4(resp.headers, "location") || url;
  };
  const jsonWithSignedQuery = async (client, url, {
    addition,
    body,
    isFamily = false,
    method = "GET",
    query = {},
    responseEncoding = "text"
  } = {}) => {
    const target = new URL(url);
    const suffix = {
      clientType: "TELEPC",
      version: "6.2",
      channelId: "web_cloud.189.cn",
      rand: randomSuffix()
    };
    for (const [key, value] of Object.entries({ ...suffix, ...query })) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const sessionKey = isFamily ? addition.familySessionKey : addition.sessionKey;
    const sessionSecret = isFamily ? addition.familySessionSecret : addition.sessionSecret;
    if (!sessionKey || !sessionSecret) throw new Error("189CloudPC requires access_token plus sessionKey/sessionSecret fields. Re-save after upstream login/session migration or import an OpenList-compatible session addition.");
    const date = httpDate();
    const signText = `SessionKey=${sessionKey}&Operate=${method}&RequestURI=${pathOfUrl(url)}&Date=${date}`;
    const headers = {
      Accept: "application/json;charset=UTF-8",
      Date: date,
      SessionKey: sessionKey,
      Signature: hmacSha1Hex(sessionSecret, signText),
      "User-Agent": "Mozilla/5.0",
      "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}`
    };
    const resp = await remote189Json(client, target.toString(), {
      allowErrorStatus: true,
      body,
      contentType: "application/x-www-form-urlencoded",
      headers,
      method,
      responseEncoding
    });
    return checkResp$1(resp);
  };
  const fillPcFamilyId = async (client, storage) => {
    const addition = storage.addition_json;
    normalize189SessionAddition(addition);
    if (!familyMode(addition) || familyId(addition)) return addition;
    const familyResp = await jsonWithSignedQuery(client, `${API_URL$1}/family/manage/getFamilyList.action`, {
      addition,
      isFamily: true
    });
    const families = Array.isArray(familyResp.familyInfoResp) ? familyResp.familyInfoResp : [];
    const matched = families.find((item) => addition.loginName && String(item.remarkName || "").includes(addition.loginName)) || families.find((item) => addition.loginName && String(addition.loginName).includes(item.remarkName || "\0")) || families[0];
    if ((matched == null ? void 0 : matched.familyId) !== void 0 && (matched == null ? void 0 : matched.familyId) !== null) addition.family_id = String(matched.familyId);
    await persistAddition$1(storage);
    return addition;
  };
  const extractPcBaseParams = (html) => {
    const pick = (patterns, name) => {
      for (const pattern of patterns) {
        const match = String(html || "").match(pattern);
        if (match == null ? void 0 : match[1]) return match[1];
      }
      throw new Error(`189CloudPC login page missing ${name}`);
    };
    return {
      captchaToken: pick([/'captchaToken'\s+value='(.+?)'/i, /captchaToken["']?\s*[:=]\s*["']([^"']+)/i], "captchaToken"),
      lt: pick([/lt\s*=\s*"(.+?)"/i, /["']lt["']\s*[:=]\s*["']([^"']+)/i], "lt"),
      paramId: pick([/paramId\s*=\s*"(.+?)"/i, /["']paramId["']\s*[:=]\s*["']([^"']+)/i], "paramId"),
      reqId: pick([/reqId\s*=\s*"(.+?)"/i, /["']reqId["']\s*[:=]\s*["']([^"']+)/i], "reqId")
    };
  };
  const initPcBaseParams = async (client, storage) => {
    const target = new URL(`${WEB_URL}/api/portal/unifyLoginForPC.action`);
    target.searchParams.set("appId", PC_APP_ID);
    target.searchParams.set("clientType", PC_CLIENT_TYPE);
    target.searchParams.set("returnURL", PC_RETURN_URL);
    target.searchParams.set("timeStamp", String(timestamp()));
    storage.addition_json.qrcode_cookie = "";
    return extractPcBaseParams(await remote189Text(client, storage, target.toString()));
  };
  const savePcSession = async (storage, tokenInfo) => {
    const addition = storage.addition_json;
    normalize189SessionAddition(addition);
    addition.access_token = tokenInfo.accessToken || tokenInfo.AccessToken || tokenInfo.access_token || addition.access_token || "";
    addition.refresh_token = tokenInfo.refreshToken || tokenInfo.RefreshToken || tokenInfo.refresh_token || addition.refresh_token || "";
    addition.sessionKey = tokenInfo.sessionKey || addition.sessionKey || "";
    addition.sessionSecret = tokenInfo.sessionSecret || addition.sessionSecret || "";
    addition.familySessionKey = tokenInfo.familySessionKey || addition.familySessionKey || "";
    addition.familySessionSecret = tokenInfo.familySessionSecret || addition.familySessionSecret || "";
    addition.loginName = tokenInfo.loginName || addition.loginName || "";
    delete addition.AccessToken;
    delete addition.RefreshToken;
    await persistAddition$1(storage);
    return addition;
  };
  const getPcSessionByRedirect = async (client, storage, redirectUrl) => {
    if (!redirectUrl) throw new Error("189CloudPC QR login missing redirect URL");
    const target = new URL(`${API_URL$1}/getSessionForPC.action`);
    for (const [key, value] of Object.entries({
      appId: PC_APP_ID,
      clientType: "TELEPC",
      version: "6.2",
      channelId: "web_cloud.189.cn",
      rand: randomSuffix(),
      redirectURL: redirectUrl
    })) target.searchParams.set(key, String(value));
    const tokenInfo = checkResp$1(await remote189Json(client, target.toString(), {
      allowErrorStatus: true,
      headers: {
        Accept: "application/json;charset=UTF-8",
        Cookie: storage.addition_json.qrcode_cookie || "",
        "User-Agent": "Mozilla/5.0",
        "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}`
      },
      method: "POST",
      rememberPcCookies: true,
      storage
    }));
    if (Number(tokenInfo.res_code || tokenInfo.resCode || 0) !== 0) throw new Error(tokenInfo.res_message || tokenInfo.resMessage || "189CloudPC getSessionForPC failed");
    await savePcSession(storage, tokenInfo);
    return fillPcFamilyId(client, storage);
  };
  const startPcQrLogin = async (client, storage) => {
    const addition = storage.addition_json;
    const baseParams = await initPcBaseParams(client, storage);
    const resp = checkResp$1(await remote189Json(client, `${AUTH_URL}/api/logbox/oauth2/getUUID.do`, {
      allowErrorStatus: true,
      body: formBody({ appId: PC_APP_ID }),
      contentType: "application/x-www-form-urlencoded",
      headers: {
        Accept: "application/json;charset=UTF-8",
        Cookie: addition.qrcode_cookie || "",
        Referer: AUTH_URL,
        "User-Agent": "Mozilla/5.0"
      },
      method: "POST",
      rememberPcCookies: true,
      storage
    }));
    const uuid = resp.uuid || resp.UUID;
    if (!uuid) throw new Error("189CloudPC QR login response missing uuid");
    addition.qrcode_uuid = uuid;
    addition.qrcode_encryuuid = resp.encryuuid || resp.EncryUUID || "";
    addition.qrcode_encodeuuid = resp.encodeuuid || resp.EncodeUUID || "";
    addition.qrcode_lt = baseParams.lt;
    addition.qrcode_reqid = baseParams.reqId;
    addition.qrcode_param_id = baseParams.paramId;
    addition.qrcode_captcha_token = baseParams.captchaToken;
    addition.access_token = "";
    addition.refresh_token = "";
    await persistAddition$1(storage);
    return {
      message: "请使用天翼云盘 App 扫码登录，然后再次点击验证/保存。",
      status: "waiting",
      verify: { qr_text: uuid }
    };
  };
  const pollPcQrLogin = async (client, storage) => {
    const addition = storage.addition_json;
    const now = /* @__PURE__ */ new Date();
    const state = checkResp$1(await remote189Json(client, `${AUTH_URL}/api/logbox/oauth2/qrcodeLoginState.do`, {
      allowErrorStatus: true,
      body: formBody({
        appId: PC_APP_ID,
        clientType: PC_CLIENT_TYPE,
        returnUrl: PC_RETURN_URL,
        paramId: addition.qrcode_param_id,
        uuid: addition.qrcode_uuid,
        encryuuid: addition.qrcode_encryuuid,
        date: formatPcQrDate(now),
        timeStamp: String(now.getTime())
      }),
      contentType: "application/x-www-form-urlencoded",
      headers: {
        Accept: "application/json;charset=UTF-8",
        Cookie: addition.qrcode_cookie || "",
        Referer: AUTH_URL,
        Reqid: addition.qrcode_reqid || "",
        lt: addition.qrcode_lt || "",
        "User-Agent": "Mozilla/5.0"
      },
      method: "POST",
      rememberPcCookies: true,
      storage
    }));
    const status = Number(state.status);
    if (status === 0) return { message: "189CloudPC QR login confirmed", redirectUrl: state.redirectUrl || state.redirectURL, status: "success" };
    if (status === -11001) return { message: "189CloudPC QR code expired, please refresh it", status: "expired" };
    return {
      message: state.msg || (status === -11002 ? "189CloudPC QR code scanned; confirm login on your phone" : "189CloudPC QR login pending"),
      status: status === -11002 ? "scanned" : "waiting"
    };
  };
  const runPcQrLogin = (client, storage) => runQrLogin({
    addition: storage.addition_json,
    clear: () => {
      clearQrKeys(storage.addition_json, PC_QR_KEYS);
      return persistAddition$1(storage);
    },
    confirm: async (state) => {
      await getPcSessionByRedirect(client, storage, state.redirectUrl);
      return storage.addition_json;
    },
    hasSession: (addition) => Boolean(addition.qrcode_uuid),
    pendingVerify: () => ({ qr_text: storage.addition_json.qrcode_uuid || "" }),
    poll: () => pollPcQrLogin(client, storage),
    start: () => startPcQrLogin(client, storage)
  });
  const loginPcByQrCode = async (client, storage) => storage.addition_json.access_token || storage.addition_json.AccessToken ? refreshPcSession(client, storage) : runPcQrLogin(client, storage);
  const refreshPcSession = async (client, storage) => {
    const addition = storage.addition_json;
    normalize189SessionAddition(addition);
    const accessToken2 = addition.access_token || addition.AccessToken;
    if (!accessToken2) throw new Error("189CloudPC access_token is empty; set login_type=qrcode to scan with the Tianyi Cloud app, or import an existing access_token/session");
    const url = new URL(`${API_URL$1}/getSessionForPC.action`);
    url.searchParams.set("clientType", "TELEPC");
    url.searchParams.set("version", "6.2");
    url.searchParams.set("channelId", "web_cloud.189.cn");
    url.searchParams.set("rand", randomSuffix());
    url.searchParams.set("appId", "8025431004");
    url.searchParams.set("accessToken", accessToken2);
    const resp = checkResp$1(await remote189Json(client, url.toString(), {
      allowErrorStatus: true,
      headers: { "X-Request-ID": `${Date.now()}-${Math.random().toString(16).slice(2)}` },
      method: "GET"
    }));
    addition.sessionKey = resp.sessionKey;
    addition.sessionSecret = resp.sessionSecret;
    addition.familySessionKey = resp.familySessionKey;
    addition.familySessionSecret = resp.familySessionSecret;
    addition.loginName = resp.loginName;
    await persistAddition$1(storage);
    return fillPcFamilyId(client, storage);
  };
  const ensureSession = async (client, storage) => {
    const addition = storage.addition_json;
    if (addition.sessionKey && addition.sessionSecret) return addition;
    return refreshPcSession(client, storage);
  };
  const request189Session = async (client, storage, url, opts = {}) => {
    const addition = await ensureSession(client, storage);
    return jsonWithSignedQuery(client, url, { ...opts, addition });
  };
  const fileToObj$7 = (file, relPath, storage, provider) => {
    var _a2;
    const isDir2 = !!file.is_dir;
    return {
      name: file.name || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: parseTime$1(file.lastOpTime || file.createDate),
      created: parseTime$1(file.createDate || file.lastOpTime),
      sign: "",
      thumb: ((_a2 = file.icon) == null ? void 0 : _a2.smallUrl) || file.smallUrl || "",
      type: isDir2 ? 1 : 0,
      hashinfo: file.md5 || file.Md5 || "",
      hash_info: file.md5 ? { md5: file.md5 } : {},
      id: String(file.id || ""),
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider,
      file: { ...file, is_dir: isDir2 }
    };
  };
  const listByParent$4 = async (client, storage, parentId) => {
    const addition = storage.addition_json;
    const isFamily = familyMode(addition);
    const url = `${API_URL$1}${isFamily ? "/family/file" : ""}/listFiles.action`;
    const result = [];
    const pageSize2 = 1e3;
    for (let pageNum = 1; ; pageNum += 1) {
      const query = {
        folderId: parentId,
        fileType: "0",
        mediaAttr: "0",
        iconOption: "5",
        pageNum,
        pageSize: pageSize2,
        recursive: isFamily ? void 0 : "0",
        orderBy: isFamily ? toFamilyOrderBy(addition.order_by || addition.OrderBy || "filename") : addition.order_by || addition.OrderBy || "filename",
        descending: toDesc(addition.order_direction || addition.OrderDirection || "asc"),
        familyId: isFamily ? familyId(addition) : void 0
      };
      const resp = await request189Session(client, storage, url, { isFamily, query });
      const list = resp.fileListAO || {};
      for (const folder of list.folderList || []) result.push({ ...folder, is_dir: true });
      for (const file of list.fileList || []) result.push({ ...file, is_dir: false });
      if (!list.count || !(list.folderList || []).length && !(list.fileList || []).length) break;
    }
    return result;
  };
  const resolveFile$5 = async (client, storage, relPath) => {
    const addition = storage.addition_json;
    const isFamily = familyMode(addition);
    const clean = normalizePath(relPath || "/");
    if (clean === "/") {
      return {
        id: rootFolderId$1(addition, isFamily),
        name: "root",
        is_dir: true,
        path: "/"
      };
    }
    let parentId = rootFolderId$1(addition, isFamily);
    let current = null;
    for (const part of clean.split("/").filter(Boolean)) {
      const files = await listByParent$4(client, storage, parentId);
      current = files.find((item) => item.name === part);
      if (!current) throw new Error(`object not found: ${clean}`);
      parentId = String(current.id || "");
    }
    return current;
  };
  const linkFor$2 = async (client, storage, file) => {
    const addition = storage.addition_json;
    const isFamily = familyMode(addition);
    const url = `${API_URL$1}${isFamily ? "/family/file" : ""}/getFileDownloadUrl.action`;
    const resp = await request189Session(client, storage, url, {
      isFamily,
      query: {
        fileId: file.id,
        familyId: isFamily ? familyId(addition) : void 0,
        dt: isFamily ? void 0 : "3",
        flag: isFamily ? void 0 : "1"
      }
    });
    let downloadUrl = resp.fileDownloadUrl || resp.downloadUrl || "";
    if (!downloadUrl) throw new Error("get download url failed");
    if (downloadUrl.startsWith("//")) downloadUrl = "https:" + downloadUrl;
    downloadUrl = downloadUrl.replace(/&amp;/g, "&").replace(/^http:\/\//, "https://");
    return (await resolveRedirect(client, downloadUrl)).replace(/^http:\/\//, "https://");
  };
  const formBody = (data) => new URLSearchParams(
    Object.entries(data).filter(([, value]) => value !== void 0 && value !== null && value !== "").map(([key, value]) => [key, typeof value === "string" ? value : JSON.stringify(value)])
  ).toString();
  const batchTask = async (client, storage, type, targetFolderId, files, other = {}) => {
    const addition = storage.addition_json;
    const isFamily = familyMode(addition);
    const taskInfos = files.map((file) => ({
      fileId: String(file.id || ""),
      fileName: file.name || "",
      isFolder: file.is_dir ? 1 : 0
    }));
    await request189Session(client, storage, `${API_URL$1}/batch/createBatchTask.action`, {
      body: formBody({
        type,
        targetFolderId,
        familyId: isFamily ? familyId(addition) : void 0,
        taskInfos,
        ...other
      }),
      isFamily,
      method: "POST"
    });
  };
  const create189SessionDriver = ({ client, provider }) => ({
    async test(storage) {
      if ((storage.addition_json.login_type || storage.addition_json.LoginType) === "qrcode") await loginPcByQrCode(client, storage);
      else await refreshPcSession(client, storage);
      await request189Session(client, storage, `${API_URL$1}/getUserInfo.action`);
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$5(client, storage, relPath);
      const content = (await listByParent$4(client, storage, String(parent.id || ""))).map((file) => fileToObj$7(file, normalizePath(relPath + "/" + file.name), storage, provider));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider,
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$5(client, storage, relPath);
      const obj = fileToObj$7(file, relPath, storage, provider);
      if (!obj.is_dir && !options.skipLink) {
        const url = await linkFor$2(client, storage, file);
        obj.raw_url = url;
        obj.url = url;
      }
      return { ...obj, readme: "", header: "", related: [] };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$5(client, storage, relPath);
      if (file.is_dir) throw new Error("not file");
      const url = await linkFor$2(client, storage, file);
      return {
        link: {
          url,
          header: { "User-Agent": "Mozilla/5.0", ...options.proxyHeaders || options.headers || {} },
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      const addition = storage.addition_json;
      const isFamily = familyMode(addition);
      const parent = await resolveFile$5(client, storage, dirnameOf(relPath));
      await request189Session(client, storage, `${API_URL$1}${isFamily ? "/family/file" : ""}/createFolder.action`, {
        isFamily,
        method: "POST",
        query: {
          familyId: isFamily ? familyId(addition) : void 0,
          parentId: isFamily ? String(parent.id || "") : void 0,
          parentFolderId: isFamily ? void 0 : String(parent.id || ""),
          folderName: basenameOf(relPath),
          relativePath: ""
        }
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$5(client, storage, relPath);
      const dst = await resolveFile$5(client, storage, dstRelPath);
      await batchTask(client, storage, "MOVE", String(dst.id || ""), [file], { targetFileName: dst.name || "" });
    },
    async copy(storage, relPath, dstRelPath) {
      const file = await resolveFile$5(client, storage, relPath);
      const dst = await resolveFile$5(client, storage, dstRelPath);
      await batchTask(client, storage, "COPY", String(dst.id || ""), [file], { targetFileName: dst.name || "" });
    },
    async remove(storage, relPath) {
      const file = await resolveFile$5(client, storage, relPath);
      await batchTask(client, storage, "DELETE", "", [file]);
    },
    async rename(storage, relPath, newName) {
      const addition = storage.addition_json;
      const isFamily = familyMode(addition);
      const file = await resolveFile$5(client, storage, relPath);
      const isDir2 = !!file.is_dir;
      await request189Session(client, storage, `${API_URL$1}${isFamily ? "/family/file" : ""}/${isDir2 ? "renameFolder" : "renameFile"}.action`, {
        isFamily,
        method: isFamily ? "GET" : "POST",
        query: {
          familyId: isFamily ? familyId(addition) : void 0,
          folderId: isDir2 ? String(file.id || "") : void 0,
          fileId: isDir2 ? void 0 : String(file.id || ""),
          destFolderName: isDir2 ? newName : void 0,
          destFileName: isDir2 ? void 0 : newName
        }
      });
    },
    async put() {
      throw new Error(`${provider} stream / rapid / old upload is not implemented in the SiYuan kernel port yet`);
    }
  });
  const create189CloudPCDriver = ({ client }) => create189SessionDriver({
    client,
    provider: "189CloudPC"
  });
  const API_URL = "https://openapi.alipan.com";
  const DEFAULT_RENEW_API$1 = "https://api.oplist.org/alicloud/renewapi";
  const CACHE_TTL = 55 * 1e3;
  const KB = 1024;
  const MB = 1024 * KB;
  const GB = 1024 * MB;
  const TB = 1024 * GB;
  const DEFAULT_UPLOAD_PART_SIZE = 20 * MB;
  const listCache = /* @__PURE__ */ new Map();
  const fileCache = /* @__PURE__ */ new Map();
  const linkCache = /* @__PURE__ */ new Map();
  const storageKey$2 = (storage) => String(storage.id || storage.mount_path || JSON.stringify(storage.addition_json || {}));
  const cached = async (map, key, producer, ttl = CACHE_TTL) => {
    const now = Date.now();
    const hit = map.get(key);
    if (hit && hit.expires > now) return hit.value;
    const value = await producer();
    map.set(key, { value, expires: now + ttl });
    return value;
  };
  const clearStorageCache = (storage) => {
    const prefix = `${storageKey$2(storage)}:`;
    for (const map of [listCache, fileCache, linkCache]) {
      for (const key of map.keys()) {
        if (key.startsWith(prefix)) map.delete(key);
      }
    }
  };
  const checkAli = (payload) => {
    if (payload == null ? void 0 : payload.code) throw new Error(`${payload.code}:${payload.message || ""}`.replace(/:$/, ""));
    return payload;
  };
  const driverTxt = (addition) => addition.alipan_type === "alipanTV" ? "alicloud_tv" : "alicloud_qr";
  const refreshToken$2 = async (client, storage) => {
    const addition = storage.addition_json || storage;
    const refreshTokenValue2 = addition.refresh_token || addition.RefreshToken || "";
    if (!refreshTokenValue2) throw new Error("empty refresh_token");
    if (boolValue$3(addition.use_online_api ?? addition.UseOnlineAPI, true) && (addition.api_url_address || DEFAULT_RENEW_API$1)) {
      const url = new URL(addition.api_url_address || DEFAULT_RENEW_API$1);
      url.searchParams.set("refresh_ui", refreshTokenValue2);
      url.searchParams.set("server_use", "true");
      url.searchParams.set("driver_txt", driverTxt(addition));
      const resp2 = await remoteJson(client, url.toString(), { method: "GET" });
      if (!resp2.refresh_token || !resp2.access_token) {
        throw new Error(resp2.text || "empty token returned from official API, a wrong refresh token may have been used");
      }
      addition.refresh_token = resp2.refresh_token;
      addition.access_token = resp2.access_token;
      await persistAddition$1(storage);
      return addition.access_token;
    }
    const clientId = addition.client_id || addition.ClientID || "";
    const clientSecret = addition.client_secret || addition.ClientSecret || "";
    if (!clientId || !clientSecret) throw new Error("empty ClientID or ClientSecret");
    const resp = checkAli(await remoteJson(client, `${API_URL}/oauth/access_token`, {
      body: {
        client_id: clientId,
        client_secret: clientSecret,
        grant_type: "refresh_token",
        refresh_token: refreshTokenValue2
      },
      method: "POST"
    }));
    if (!resp.refresh_token || !resp.access_token) throw new Error("empty token returned from alipan");
    addition.refresh_token = resp.refresh_token;
    addition.access_token = resp.access_token;
    await persistAddition$1(storage);
    return addition.access_token;
  };
  const ensureToken = async (client, storage) => {
    const addition = storage.addition_json || storage;
    if (addition.access_token || addition.AccessToken) return addition.access_token || addition.AccessToken;
    return refreshToken$2(client, storage);
  };
  const requestAli = async (client, storage, uri, {
    allowAliError = false,
    body,
    method = "POST",
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    await ensureToken(client, storage);
    const resp = await remoteJson(client, `${API_URL}${uri}`, {
      allowErrorStatus: true,
      body: body || {},
      headers: {
        Authorization: `Bearer ${addition.access_token || addition.AccessToken || ""}`
      },
      method
    });
    if ((resp == null ? void 0 : resp.code) && retry && ["AccessTokenInvalid", "AccessTokenExpired", "I400JD"].includes(resp.code)) {
      await refreshToken$2(client, storage);
      return requestAli(client, storage, uri, { allowAliError, body, method, retry: false });
    }
    if (allowAliError) return resp;
    return checkAli(resp);
  };
  const initDrive = async (client, storage) => {
    const addition = storage.addition_json;
    if (addition.drive_id) return addition.drive_id;
    const resp = await requestAli(client, storage, "/adrive/v1.0/user/getDriveInfo");
    const driveType = addition.drive_type || addition.DriveType || "resource";
    const driveId = resp[`${driveType}_drive_id`] || resp.default_drive_id || resp.resource_drive_id || resp.backup_drive_id;
    if (!driveId) throw new Error("get aliyundrive drive_id failed");
    addition.drive_id = driveId;
    await persistAddition$1(storage);
    return driveId;
  };
  const rootFolderId = (addition) => addition.root_folder_id || addition.RootFolderID || "root";
  const base64ToBytes$7 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$6 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i2 = 0; i2 < bytes2.length; i2 += 3) {
      const a = bytes2[i2];
      const b = bytes2[i2 + 1];
      const c = bytes2[i2 + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i2 + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i2 + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$5 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const uploadBytes$4 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$7(content || "") : utf8Bytes$5(content || "");
  const hex$5 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const rol$3 = (value, bits2) => value << bits2 | value >>> 32 - bits2;
  const sha1Bytes$3 = (message) => {
    const msg = message instanceof Uint8Array ? message : utf8Bytes$5(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i2 = 0; i2 < 16; i2 += 1) w[i2] = view.getUint32(offset + i2 * 4);
      for (let i2 = 16; i2 < 80; i2 += 1) w[i2] = rol$3(w[i2 - 3] ^ w[i2 - 8] ^ w[i2 - 14] ^ w[i2 - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i2 = 0; i2 < 80; i2 += 1) {
        let f;
        let k;
        if (i2 < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i2 < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i2 < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$3(a, 5) + f + e + k + w[i2] >>> 0;
        e = d;
        d = c;
        c = rol$3(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const sha1Hex$2 = (message) => hex$5(sha1Bytes$3(message));
  const leftRotate$3 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$4 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$5(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i2) => Math.floor(Math.abs(Math.sin(i2 + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i2 = 0; i2 < 64; i2 += 1) {
        let f;
        let g;
        if (i2 < 16) {
          f = b & c | ~b & d;
          g = i2;
        } else if (i2 < 32) {
          f = d & b | ~d & c;
          g = (5 * i2 + 1) % 16;
        } else if (i2 < 48) {
          f = b ^ c ^ d;
          g = (3 * i2 + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i2 % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate$3(a + f + k[i2] + view.getUint32(offset + g * 4, true) >>> 0, s[i2]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const proofCode$1 = (accessToken2, bytes2) => {
    if (!bytes2.length) return "";
    const start = Number(BigInt(`0x${md5Hex$4(accessToken2).slice(0, 16)}`) % BigInt(bytes2.length));
    return bytesToBase64$6(bytes2.slice(start, Math.min(start + 8, bytes2.length)));
  };
  const makePartInfos = (count) => Array.from({ length: count }, (_, index) => ({ part_number: index + 1 }));
  const uploadPartSize = (fileSize) => {
    if (fileSize <= DEFAULT_UPLOAD_PART_SIZE) return DEFAULT_UPLOAD_PART_SIZE;
    if (fileSize > TB) return 5 * GB;
    if (fileSize > 768 * GB) return 109951163;
    if (fileSize > 512 * GB) return 82463373;
    if (fileSize > 384 * GB) return 54975582;
    if (fileSize > 256 * GB) return 41231687;
    if (fileSize > 128 * GB) return 27487791;
    return DEFAULT_UPLOAD_PART_SIZE;
  };
  const uploadTime = () => (/* @__PURE__ */ new Date()).toISOString().replace(/\.\d{3}Z$/, ".000Z");
  const uploadUrlOf = (storage, url) => boolValue$3(storage.addition_json.internal_upload ?? storage.addition_json.InternalUpload, false) ? String(url || "").replace("https://cn-beijing-data.aliyundrive.net/", "http://ccp-bj29-bj-1592982087.oss-cn-beijing-internal.aliyuncs.com/") : url;
  const fileToObj$6 = (file, relPath, storage) => {
    const isDir2 = file.type === "folder";
    return {
      name: file.name || file.file_name || basenameOf(relPath),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: parseTime$1(file.updated_at),
      created: parseTime$1(file.created_at),
      sign: "",
      thumb: file.thumbnail || "",
      type: isDir2 ? 1 : 0,
      hashinfo: file.content_hash || "",
      hash_info: file.content_hash ? { sha1: file.content_hash } : {},
      id: file.file_id || "",
      raw_url: isDir2 ? "" : rawDownloadUrl(storage, relPath),
      provider: "AliyundriveOpen",
      file
    };
  };
  const listByParent$3 = async (client, storage, parentId) => {
    const cacheKey2 = `${storageKey$2(storage)}:list:${parentId}`;
    return cached(listCache, cacheKey2, async () => {
      const addition = storage.addition_json;
      const driveId = await initDrive(client, storage);
      const result = [];
      let marker = "";
      do {
        const resp = await requestAli(client, storage, "/adrive/v1.0/openFile/list", {
          body: {
            drive_id: driveId,
            limit: 200,
            marker,
            order_by: addition.order_by || addition.OrderBy || "",
            order_direction: addition.order_direction || addition.OrderDirection || "",
            parent_file_id: parentId
          }
        });
        result.push(...resp.items || []);
        marker = resp.next_marker || "";
      } while (marker);
      return result;
    });
  };
  const resolveFile$4 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    const cacheKey2 = `${storageKey$2(storage)}:file:${clean}`;
    return cached(fileCache, cacheKey2, async () => {
      if (clean === "/") {
        return {
          file_id: rootFolderId(storage.addition_json),
          name: "root",
          type: "folder",
          path: "/"
        };
      }
      let parentId = rootFolderId(storage.addition_json);
      let current = null;
      const parts = clean.split("/").filter(Boolean);
      for (const part of parts) {
        const files = await listByParent$3(client, storage, parentId);
        current = files.find((item) => (item.name || item.file_name) === part);
        if (!current) throw new Error(`object not found: ${clean}`);
        parentId = current.file_id;
      }
      return current;
    });
  };
  const linkFor$1 = async (client, storage, file) => {
    const cacheKey2 = `${storageKey$2(storage)}:link:${file.file_id || ""}`;
    return cached(linkCache, cacheKey2, async () => {
      var _a2;
      const driveId = await initDrive(client, storage);
      const resp = await requestAli(client, storage, "/adrive/v1.0/openFile/getDownloadUrl", {
        body: {
          drive_id: driveId,
          file_id: file.file_id,
          expire_sec: 14400
        }
      });
      const url = resp.url || ((_a2 = resp.streamsUrl) == null ? void 0 : _a2[storage.addition_json.livp_download_format || "jpeg"]) || "";
      if (!url) throw new Error("get download url failed");
      return url;
    });
  };
  const createAliyundriveOpenDriver = ({ client }) => ({
    async test(storage) {
      await initDrive(client, storage);
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$4(client, storage, relPath);
      const content = (await listByParent$3(client, storage, parent.file_id)).map((file) => fileToObj$6(file, normalizePath(relPath + "/" + (file.name || file.file_name)), storage));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "AliyundriveOpen",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$4(client, storage, relPath);
      const obj = fileToObj$6(file, relPath, storage);
      if (!obj.is_dir && !options.skipLink) {
        const url = await linkFor$1(client, storage, file);
        obj.raw_url = url;
        obj.url = url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$4(client, storage, relPath);
      if (file.type === "folder") throw new Error("not file");
      const url = await linkFor$1(client, storage, file);
      return {
        link: {
          url,
          header: options.proxyHeaders || options.headers || {},
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      const driveId = await initDrive(client, storage);
      const parent = await resolveFile$4(client, storage, dirnameOf(relPath));
      await requestAli(client, storage, "/adrive/v1.0/openFile/create", {
        body: {
          drive_id: driveId,
          parent_file_id: parent.file_id,
          name: basenameOf(relPath),
          type: "folder",
          check_name_mode: "refuse"
        }
      });
      clearStorageCache(storage);
    },
    async move(storage, relPath, dstRelPath) {
      const driveId = await initDrive(client, storage);
      const file = await resolveFile$4(client, storage, relPath);
      const dst = await resolveFile$4(client, storage, dstRelPath);
      await requestAli(client, storage, "/adrive/v1.0/openFile/move", {
        body: {
          drive_id: driveId,
          file_id: file.file_id,
          to_parent_file_id: dst.file_id,
          check_name_mode: "ignore"
        }
      });
      clearStorageCache(storage);
    },
    async copy(storage, relPath, dstRelPath) {
      const driveId = await initDrive(client, storage);
      const file = await resolveFile$4(client, storage, relPath);
      const dst = await resolveFile$4(client, storage, dstRelPath);
      await requestAli(client, storage, "/adrive/v1.0/openFile/copy", {
        body: {
          drive_id: driveId,
          file_id: file.file_id,
          to_parent_file_id: dst.file_id,
          auto_rename: false
        }
      });
      clearStorageCache(storage);
    },
    async remove(storage, relPath) {
      const driveId = await initDrive(client, storage);
      const file = await resolveFile$4(client, storage, relPath);
      const uri = storage.addition_json.remove_way === "delete" ? "/adrive/v1.0/openFile/delete" : "/adrive/v1.0/openFile/recyclebin/trash";
      await requestAli(client, storage, uri, {
        body: {
          drive_id: driveId,
          file_id: file.file_id
        }
      });
      clearStorageCache(storage);
    },
    async rename(storage, relPath, newName) {
      const driveId = await initDrive(client, storage);
      const file = await resolveFile$4(client, storage, relPath);
      await requestAli(client, storage, "/adrive/v1.0/openFile/update", {
        body: {
          drive_id: driveId,
          file_id: file.file_id,
          name: newName
        }
      });
      clearStorageCache(storage);
    },
    async other(storage, relPath, req = {}) {
      const driveId = await initDrive(client, storage);
      const file = await resolveFile$4(client, storage, relPath);
      if (req.method !== "video_preview") throw new Error("not support");
      return requestAli(client, storage, "/adrive/v1.0/openFile/getVideoPreviewPlayInfo", {
        body: {
          drive_id: driveId,
          file_id: file.file_id,
          category: "live_transcoding",
          url_expire_sec: 14400
        }
      });
    },
    async put(storage, relPath, content, mime, options = {}) {
      var _a2;
      const driveId = await initDrive(client, storage);
      const parent = await resolveFile$4(client, storage, dirnameOf(relPath));
      const bytes2 = uploadBytes$4(content, options);
      const size = Number(options.size ?? bytes2.length);
      const partSize = uploadPartSize(size);
      const count = Math.ceil(size / partSize);
      const createdAt = uploadTime();
      const rapidUpload = !options.forceStreamUpload && bytes2.length > 100 * 1024 && boolValue$3(storage.addition_json.rapid_upload ?? storage.addition_json.RapidUpload, false);
      const createData = {
        drive_id: driveId,
        parent_file_id: parent.file_id,
        name: basenameOf(relPath),
        type: "file",
        check_name_mode: "ignore",
        local_modified_at: createdAt,
        local_created_at: createdAt,
        part_info_list: makePartInfos(count)
      };
      if (rapidUpload) {
        createData.size = bytes2.length;
        createData.pre_hash = sha1Hex$2(bytes2.slice(0, 1024));
      }
      let createResp = await requestAli(client, storage, "/adrive/v1.0/openFile/create", {
        allowAliError: rapidUpload,
        body: createData
      });
      if (createResp == null ? void 0 : createResp.code) {
        if (createResp.code !== "PreHashMatched" || !rapidUpload) checkAli(createResp);
        delete createData.pre_hash;
        createData.proof_version = "v1";
        createData.content_hash_name = "sha1";
        createData.content_hash = sha1Hex$2(bytes2);
        createData.proof_code = proofCode$1(storage.addition_json.access_token || storage.addition_json.AccessToken || "", bytes2);
        createResp = await requestAli(client, storage, "/adrive/v1.0/openFile/create", {
          body: createData
        });
      }
      if (!createResp.rapid_upload) {
        for (let index = 0; index < (createResp.part_info_list || []).length; index += 1) {
          const offset = index * partSize;
          const chunk = bytes2.slice(offset, Math.min(offset + partSize, bytes2.length));
          const resp = await forwardProxy(client, uploadUrlOf(storage, (_a2 = createResp.part_info_list[index]) == null ? void 0 : _a2.upload_url), {
            allowErrorStatus: true,
            body: bytesToBase64$6(chunk),
            contentType: mime || "application/octet-stream",
            method: "PUT",
            payloadEncoding: "base64",
            responseEncoding: "text",
            timeout: 12e4
          });
          if (![200, 409].includes(Number(resp.status || 0))) throw new Error(`upload status: ${resp.status}`);
        }
      }
      await requestAli(client, storage, "/adrive/v1.0/openFile/complete", {
        body: {
          drive_id: driveId,
          file_id: createResp.file_id,
          upload_id: createResp.upload_id
        }
      });
      clearStorageCache(storage);
    },
    async details(storage) {
      var _a2, _b2;
      const resp = await requestAli(client, storage, "/adrive/v1.0/user/getSpaceInfo");
      const total = Number(((_a2 = resp.personal_space_info) == null ? void 0 : _a2.total_size) || 0);
      const used = Number(((_b2 = resp.personal_space_info) == null ? void 0 : _b2.used_size) || 0);
      return {
        total_space: total,
        used_space: used,
        free_space: Math.max(0, total - used)
      };
    }
  });
  const API$1 = "https://pan.baidu.com/rest/2.0";
  const OPEN_API = "https://openapi.baidu.com/oauth/2.0/token";
  const DEFAULT_RENEW_API = "https://api.oplist.org/baiduyun/renewapi";
  const LIST_CACHE_TTL = 5 * 60 * 1e3;
  const FILE_CACHE_TTL = 5 * 60 * 1e3;
  const LINK_CACHE_TTL = 10 * 60 * 1e3;
  const baiduCache = /* @__PURE__ */ new Map();
  const storageKey$1 = (storage) => String((storage == null ? void 0 : storage.id) || (storage == null ? void 0 : storage.mount_path) || (storage == null ? void 0 : storage.mount_path_hash) || "default");
  const cacheKey = (storage, type, key) => `${storageKey$1(storage)}:${type}:${key}`;
  const getCache = (key) => {
    const hit = baiduCache.get(key);
    if (!hit) return void 0;
    if (hit.expires <= Date.now()) {
      baiduCache.delete(key);
      return void 0;
    }
    return hit.value;
  };
  const setCache = (key, value, ttl) => {
    baiduCache.set(key, { expires: Date.now() + ttl, value });
    if (baiduCache.size > 512) {
      for (const cacheKeyValue of baiduCache.keys()) {
        baiduCache.delete(cacheKeyValue);
        if (baiduCache.size <= 384) break;
      }
    }
    return value;
  };
  const invalidateStorageCache = (storage) => {
    const prefix = `${storageKey$1(storage)}:`;
    for (const key of baiduCache.keys()) {
      if (key.startsWith(prefix)) baiduCache.delete(key);
    }
  };
  const boolValue$2 = (value, fallback = false) => {
    if (value === void 0 || value === null || value === "") return fallback;
    return value === true || value === "true";
  };
  const rootedPath$1 = (addition, relPath) => {
    const root = normalizePath(addition.root_folder_path || addition.RootFolderPath || "/");
    return normalizePath(root + "/" + normalizePath(relPath || "/"));
  };
  const baiduTime = (value) => {
    const date = Number(value || 0) ? new Date(Number(value) * 1e3) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const checkBaidu = (payload) => {
    const errno = Number((payload == null ? void 0 : payload.errno) || (payload == null ? void 0 : payload.error_code) || 0);
    if (errno && errno !== 31023) throw new Error((payload == null ? void 0 : payload.errmsg) || (payload == null ? void 0 : payload.error_msg) || `baidu errno: ${errno}`);
    return payload;
  };
  const persistAddition = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const refreshToken$1 = async (client, storage) => {
    const addition = storage.addition_json || storage;
    const refreshTokenValue2 = addition.refresh_token || addition.RefreshToken || "";
    if (!refreshTokenValue2) throw new Error("empty refresh_token");
    const useOnlineApi = boolValue$2(addition.use_online_api ?? addition.UseOnlineAPI, true);
    if (useOnlineApi) {
      const url2 = new URL(addition.api_url_address || addition.APIAddress || DEFAULT_RENEW_API);
      url2.searchParams.set("refresh_ui", refreshTokenValue2);
      url2.searchParams.set("server_use", "true");
      url2.searchParams.set("driver_txt", "baiduyun_go");
      const resp2 = await remoteJson(client, url2.toString(), { method: "GET" });
      if (!resp2.refresh_token || !resp2.access_token) throw new Error(resp2.text || "empty token returned from official API");
      addition.access_token = resp2.access_token;
      addition.refresh_token = resp2.refresh_token;
      await persistAddition(storage);
      return addition;
    }
    if (!addition.client_id || !addition.client_secret) throw new Error("empty ClientID or ClientSecret");
    const url = new URL(OPEN_API);
    url.searchParams.set("grant_type", "refresh_token");
    url.searchParams.set("refresh_token", refreshTokenValue2);
    url.searchParams.set("client_id", addition.client_id);
    url.searchParams.set("client_secret", addition.client_secret);
    const resp = await remoteJson(client, url.toString(), { method: "GET" });
    if (resp.error) throw new Error(`${resp.error}: ${resp.error_description || ""}`.trim());
    if (!resp.refresh_token || !resp.access_token) throw new Error("empty token returned from official API");
    addition.access_token = resp.access_token;
    addition.refresh_token = resp.refresh_token;
    await persistAddition(storage);
    return addition;
  };
  const ensureAccessToken$1 = async (client, storage) => {
    const addition = storage.addition_json || storage;
    if (addition.access_token || addition.AccessToken) return;
    await refreshToken$1(client, storage);
  };
  const requestBaidu = async (client, storage, url, {
    allowErrorStatus = false,
    body,
    contentType = "application/json",
    method = "GET",
    query = {},
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    await ensureAccessToken$1(client, storage);
    const target = new URL(url);
    target.searchParams.set("access_token", addition.access_token || addition.AccessToken || "");
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const resp = await remoteJson(client, target.toString(), {
      allowErrorStatus,
      body,
      contentType,
      method
    });
    const errno = Number((resp == null ? void 0 : resp.errno) || (resp == null ? void 0 : resp.error_code) || 0);
    if ((errno === 111 || errno === -6) && retry) {
      await refreshToken$1(client, storage);
      return requestBaidu(client, storage, url, { allowErrorStatus, body, contentType, method, query, retry: false });
    }
    return checkBaidu(resp);
  };
  const get = (client, storage, pathname, query, retry) => requestBaidu(client, storage, `${API$1}${pathname}`, { method: "GET", query, retry });
  const postForm = (client, storage, pathname, query, form) => requestBaidu(client, storage, `${API$1}${pathname}`, {
    body: new URLSearchParams(form).toString(),
    contentType: "application/x-www-form-urlencoded",
    method: "POST",
    query
  });
  const DEFAULT_UPLOAD_API = "https://d.pcs.baidu.com";
  const DEFAULT_SLICE_SIZE = 4 * 1024 * 1024;
  const VIP_SLICE_SIZE = 16 * 1024 * 1024;
  const SVIP_SLICE_SIZE = 32 * 1024 * 1024;
  const MAX_SLICE_NUM = 2048;
  const SLICE_STEP = 1024 * 1024;
  const SLICE_MD5_SIZE = 256 * 1024;
  const base64ToBytes$6 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$5 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i2 = 0; i2 < bytes2.length; i2 += 3) {
      const a = bytes2[i2];
      const b = bytes2[i2 + 1];
      const c = bytes2[i2 + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i2 + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i2 + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$4 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const uploadBytes$3 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$6(content || "") : utf8Bytes$4(content || "");
  const leftRotate$2 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$3 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$4(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i2) => Math.floor(Math.abs(Math.sin(i2 + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i2 = 0; i2 < 64; i2 += 1) {
        let f;
        let g;
        if (i2 < 16) {
          f = b & c | ~b & d;
          g = i2;
        } else if (i2 < 32) {
          f = d & b | ~d & c;
          g = (5 * i2 + 1) % 16;
        } else if (i2 < 48) {
          f = b ^ c ^ d;
          g = (3 * i2 + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i2 % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate$2(a + f + k[i2] + view.getUint32(offset + g * 4, true) >>> 0, s[i2]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const joinTime = (form, ctime, mtime) => {
    if (!mtime || !ctime) return;
    form.local_mtime = String(mtime);
    form.local_ctime = String(ctime);
  };
  const getSliceSize = (storage, filesize) => {
    const addition = storage.addition_json || {};
    const vipType = Number(addition.vip_type || addition.VipType || 0);
    const custom = Number(addition.custom_upload_part_size || addition.CustomUploadPartSize || 0);
    if (vipType === 0) return DEFAULT_SLICE_SIZE;
    if (custom) {
      if (custom < DEFAULT_SLICE_SIZE) return DEFAULT_SLICE_SIZE;
      if (vipType === 1 && custom > VIP_SLICE_SIZE) return VIP_SLICE_SIZE;
      if (vipType === 2 && custom > SVIP_SLICE_SIZE) return SVIP_SLICE_SIZE;
      return custom;
    }
    const maxSliceSize = vipType === 1 ? VIP_SLICE_SIZE : SVIP_SLICE_SIZE;
    if (boolValue$2(addition.low_bandwith_upload_mode ?? addition.LowBandwithUploadMode, false)) {
      for (let size = DEFAULT_SLICE_SIZE; size <= maxSliceSize; size += SLICE_STEP) {
        if (filesize <= MAX_SLICE_NUM * size) return size;
      }
    }
    return maxSliceSize;
  };
  const createFile = async (client, storage, path, size, isdir, uploadid, blockList, mtime, ctime) => {
    const form = {
      path,
      size: String(size),
      isdir: String(isdir),
      rtype: "3"
    };
    joinTime(form, ctime, mtime);
    if (uploadid) form.uploadid = uploadid;
    if (blockList) form.block_list = blockList;
    return postForm(client, storage, "/xpan/file", { method: "create" }, form);
  };
  const precreate = async (client, storage, path, size, blockList, contentMd5, sliceMd52, ctime, mtime) => {
    const form = {
      path,
      size: String(size),
      isdir: "0",
      autoinit: "1",
      rtype: "3",
      block_list: blockList
    };
    if (contentMd5 && sliceMd52) {
      form["content-md5"] = contentMd5;
      form["slice-md5"] = sliceMd52;
    }
    joinTime(form, ctime, mtime);
    return postForm(client, storage, "/xpan/file", { method: "precreate" }, form);
  };
  const requestForUploadUrl = async (client, storage, path, uploadid) => {
    var _a2, _b2, _c, _d;
    const payload = await requestBaidu(client, storage, `${DEFAULT_UPLOAD_API}/rest/2.0/pcs/file`, {
      method: "GET",
      query: {
        method: "locateupload",
        appid: "250528",
        path,
        uploadid,
        upload_version: "2.0"
      }
    });
    const server = ((_b2 = (_a2 = payload == null ? void 0 : payload.servers) == null ? void 0 : _a2[0]) == null ? void 0 : _b2.server) || ((_d = (_c = payload == null ? void 0 : payload.bak_servers) == null ? void 0 : _c[0]) == null ? void 0 : _d.server) || "";
    if (!server) throw new Error("upload URL is empty");
    return server;
  };
  const uploadApiOf = (storage) => {
    const api = storage.addition_json.upload_api || storage.addition_json.UploadAPI || DEFAULT_UPLOAD_API;
    try {
      return new URL(api).toString().replace(/\/+$/, "");
    } catch (_) {
      return DEFAULT_UPLOAD_API;
    }
  };
  const getUploadUrl = async (client, storage, path, uploadid) => {
    if (!boolValue$2(storage.addition_json.use_dynamic_upload_api ?? storage.addition_json.UseDynamicUploadAPI, true) || !uploadid) {
      return uploadApiOf(storage);
    }
    try {
      return await requestForUploadUrl(client, storage, path, uploadid);
    } catch (_) {
      return uploadApiOf(storage);
    }
  };
  const multipartBody = (fieldName, fileName, bytes2, boundary) => {
    const head = utf8Bytes$4(`--${boundary}\r
Content-Disposition: form-data; name="${fieldName}"; filename="${fileName}"\r
Content-Type: application/octet-stream\r
\r
`);
    const tail = utf8Bytes$4(`\r
--${boundary}--\r
`);
    const body = new Uint8Array(head.length + bytes2.length + tail.length);
    body.set(head);
    body.set(bytes2, head.length);
    body.set(tail, head.length + bytes2.length);
    return body;
  };
  const uploadSlice = async (client, storage, uploadUrl, params, fileName, bytes2) => {
    const target = new URL(`${uploadUrl.replace(/\/+$/, "")}/rest/2.0/pcs/superfile2`);
    for (const [key, value] of Object.entries(params)) target.searchParams.set(key, String(value));
    const boundary = `----siyuan-baidu-${Date.now().toString(16)}`;
    const body = multipartBody("file", fileName, bytes2, boundary);
    const resp = await forwardProxy(client, target.toString(), {
      allowErrorStatus: true,
      body: bytesToBase64$5(body),
      contentType: `multipart/form-data; boundary=${boundary}`,
      method: "POST",
      payloadEncoding: "base64",
      responseEncoding: "text",
      timeout: Number(storage.addition_json.upload_timeout || storage.addition_json.UploadSliceTimeout || 60) * 1e3
    });
    let payload = {};
    try {
      payload = JSON.parse(resp.body || "{}");
    } catch (_) {
      payload = {};
    }
    const lower = String(resp.body || "").toLowerCase();
    if (lower.includes("uploadid") && (lower.includes("invalid") || lower.includes("expired") || lower.includes("not found"))) {
      throw new Error("uploadid expired");
    }
    const errno = Number((payload == null ? void 0 : payload.errno) || (payload == null ? void 0 : payload.error_code) || 0);
    if (errno) throw new Error(`error uploading to baidu, response=${resp.body || ""}`);
  };
  const putRapid = async (client, storage, path, bytes2, mtime, ctime) => {
    const contentMd5 = md5Hex$3(bytes2);
    const blockList = JSON.stringify([contentMd5]);
    return createFile(client, storage, path, bytes2.length, 0, "", blockList, mtime, ctime);
  };
  const fileNameOf$2 = (file) => (file == null ? void 0 : file.server_filename) || (file == null ? void 0 : file.name) || basename((file == null ? void 0 : file.path) || "");
  const isDir$2 = (file) => Number((file == null ? void 0 : file.isdir) || 0) === 1;
  const VIDEO_EXTS = /* @__PURE__ */ new Set(["mp4", "mkv", "avi", "mov", "rmvb", "webm", "flv", "m3u8", "m4v"]);
  const AUDIO_EXTS = /* @__PURE__ */ new Set(["mp3", "flac", "ogg", "m4a", "wav", "opus", "wma"]);
  const fileExtOf = (file) => {
    var _a2;
    return ((_a2 = fileNameOf$2(file).split(".").pop()) == null ? void 0 : _a2.toLowerCase()) || "";
  };
  const isStreamMediaFile = (file) => [1, 2].includes(Number((file == null ? void 0 : file.category) || 0)) || VIDEO_EXTS.has(fileExtOf(file)) || AUDIO_EXTS.has(fileExtOf(file));
  const effectiveDownloadApi = (storage, file) => {
    const api = storage.addition_json.download_api || "official";
    return api === "crack_video" && !isStreamMediaFile(file) ? "official" : api;
  };
  const fileToObj$5 = (file, relPath, storage) => {
    var _a2;
    const actualPath = (file == null ? void 0 : file.path) || rootedPath$1(storage.addition_json, relPath);
    const dir = isDir$2(file);
    return {
      name: fileNameOf$2(file),
      path: normalizePath(relPath),
      is_dir: dir,
      size: Number((file == null ? void 0 : file.size) || 0),
      modified: baiduTime((file == null ? void 0 : file.server_mtime) || (file == null ? void 0 : file.mtime)),
      created: baiduTime((file == null ? void 0 : file.server_ctime) || (file == null ? void 0 : file.ctime)),
      sign: "",
      thumb: ((_a2 = file == null ? void 0 : file.thumbs) == null ? void 0 : _a2.url3) || "",
      type: dir ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: String((file == null ? void 0 : file.fs_id) || (file == null ? void 0 : file.id) || ""),
      raw_url: dir ? "" : `/plugin/private/siyuan-cloud/p${normalizePath(storage.mount_path + "/" + relPath)}`,
      provider: "BaiduNetdisk",
      file: { ...file, path: actualPath }
    };
  };
  const listFiles = async (client, storage, relPath) => {
    const cleanRelPath = normalizePath(relPath || "/");
    const cached2 = getCache(cacheKey(storage, "list", cleanRelPath));
    if (cached2) return cached2;
    const addition = storage.addition_json;
    const dir = rootedPath$1(addition, cleanRelPath);
    const result = [];
    for (let start = 0; ; start += 1e3) {
      const query = {
        method: "list",
        dir,
        web: "web",
        start,
        limit: 1e3
      };
      if (addition.order_by) {
        query.order = addition.order_by;
        if (addition.order_direction === "desc") query.desc = "1";
      }
      const payload = await get(client, storage, "/xpan/file", {
        ...query
      });
      const list = payload.list || [];
      for (const file of list) {
        if (!boolValue$2(addition.only_list_video_file) || file.isdir === 1 || file.category === 1) result.push(file);
      }
      if (list.length < 1e3) break;
    }
    return setCache(cacheKey(storage, "list", cleanRelPath), result, LIST_CACHE_TTL);
  };
  const resolveFile$3 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    if (clean === "/") return { isRoot: true, id: "", name: "root", path: "/" };
    const cached2 = getCache(cacheKey(storage, "file", clean));
    if (cached2) return cached2;
    const parent = dirname(clean);
    const name = basename(clean);
    const files = await listFiles(client, storage, parent);
    const file = files.find((entry) => fileNameOf$2(entry) === name);
    if (!file) throw new Error(`object not found: ${clean}`);
    return setCache(cacheKey(storage, "file", clean), { file, id: String(file.fs_id || ""), name: fileNameOf$2(file), path: clean }, FILE_CACHE_TTL);
  };
  const headerValue$3 = (headers = {}, name) => {
    const lower = String(name || "").toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== lower) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const resolveHeadLocation = async (client, url, headers) => {
    try {
      const resp = await forwardProxy(client, url, {
        allowErrorStatus: true,
        contentType: "application/octet-stream",
        headers,
        method: "HEAD",
        redirect: false,
        responseEncoding: "text",
        timeout: 3e4
      });
      return headerValue$3(resp.headers, "Location") || headerValue$3(resp.headers, "location");
    } catch (_) {
      return "";
    }
  };
  const linkOfficial = async (client, storage, file) => {
    var _a2, _b2;
    const payload = await get(client, storage, "/xpan/multimedia", {
      method: "filemetas",
      fsids: `[${file.fs_id || file.id}]`,
      dlink: "1"
    });
    const dlink = ((_b2 = (_a2 = payload == null ? void 0 : payload.list) == null ? void 0 : _a2[0]) == null ? void 0 : _b2.dlink) || "";
    if (!dlink) throw new Error("get baidu dlink failed");
    const headers = { "User-Agent": "pan.baidu.com" };
    const url = `${dlink}&access_token=${encodeURIComponent(storage.addition_json.access_token || "")}`;
    const location = await resolveHeadLocation(client, url, headers);
    return {
      headers,
      url: location || url
    };
  };
  const linkCrack = async (client, storage, file) => {
    var _a2, _b2;
    const payload = await requestBaidu(client, storage, "https://pan.baidu.com/api/filemetas", {
      method: "GET",
      query: {
        target: `["${file.path}"]`,
        dlink: "1",
        web: "5",
        origin: "dlna"
      }
    });
    const url = ((_b2 = (_a2 = payload == null ? void 0 : payload.info) == null ? void 0 : _a2[0]) == null ? void 0 : _b2.dlink) || "";
    if (!url) throw new Error("get baidu crack dlink failed");
    return {
      headers: { "User-Agent": storage.addition_json.custom_crack_ua || "netdisk" },
      url
    };
  };
  const linkCrackVideo = async (client, storage, file) => {
    var _a2, _b2, _c;
    const payload = await requestBaidu(client, storage, "https://pan.baidu.com/api/mediainfo", {
      allowErrorStatus: true,
      method: "GET",
      query: {
        type: "VideoURL",
        path: file.path,
        fs_id: file.fs_id || file.id,
        devuid: "0%1",
        clienttype: "1",
        channel: "android_15_25010PN30C_bd-netdisk_1523a",
        nom3u8: "1",
        dlink: "1",
        media: "1",
        origin: "dlna"
      }
    });
    const url = ((_a2 = payload == null ? void 0 : payload.info) == null ? void 0 : _a2.dlink) || ((_c = (_b2 = payload == null ? void 0 : payload.info) == null ? void 0 : _b2[0]) == null ? void 0 : _c.dlink) || "";
    if (!url) throw new Error("get baidu video dlink failed");
    return {
      headers: { "User-Agent": storage.addition_json.custom_crack_ua || "netdisk" },
      url
    };
  };
  const linkFor = async (client, storage, file) => {
    const api = effectiveDownloadApi(storage, file);
    const key = cacheKey(storage, "link", [
      api,
      file.fs_id || file.id || "",
      file.size || "",
      file.server_mtime || file.mtime || ""
    ].join(":"));
    const cached2 = getCache(key);
    if (cached2) return cached2;
    let link2;
    switch (api) {
      case "crack":
        link2 = await linkCrack(client, storage, file);
        break;
      case "crack_video":
        link2 = await linkCrackVideo(client, storage, file);
        break;
      default:
        link2 = await linkOfficial(client, storage, file);
    }
    return setCache(key, link2, LINK_CACHE_TTL);
  };
  const manage = (client, storage, opera, filelist) => postForm(client, storage, "/xpan/file", {
    method: "filemanager",
    opera
  }, {
    async: "0",
    filelist: JSON.stringify(filelist),
    ondup: "fail"
  });
  const createBaiduNetdiskDriver = ({ client }) => ({
    async test(storage) {
      await ensureAccessToken$1(client, storage);
      await get(client, storage, "/xpan/nas", { method: "uinfo" });
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const content = (await listFiles(client, storage, relPath)).map((file) => fileToObj$5(file, normalizePath(relPath + "/" + fileNameOf$2(file)), storage));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "BaiduNetdisk",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const target = await resolveFile$3(client, storage, relPath);
      if (target.isRoot) {
        return {
          name: "root",
          path: "/",
          is_dir: true,
          size: 0,
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString(),
          provider: "BaiduNetdisk",
          related: []
        };
      }
      const obj = fileToObj$5(target.file, relPath, storage);
      if (!obj.is_dir && !options.skipLink) {
        const link2 = await linkFor(client, storage, target.file);
        obj.raw_url = link2.url;
        obj.url = link2.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      var _a2;
      const target = await resolveFile$3(client, storage, relPath);
      if (target.isRoot || isDir$2(target.file)) throw new Error("not file");
      const link2 = await linkFor(client, storage, target.file);
      if (link2.body !== void 0) {
        return {
          body: link2.body,
          contentType: link2.contentType || "application/vnd.apple.mpegurl",
          headers: link2.headers || {},
          media_type: link2.media_type || "m3u8",
          status: 200
        };
      }
      const header = { ...link2.headers, ...options.proxyHeaders || options.headers || {} };
      return {
        link: {
          url: link2.url,
          header,
          content_length: Number(((_a2 = target.file) == null ? void 0 : _a2.size) || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      await postForm(client, storage, "/xpan/file", { method: "create" }, {
        path: rootedPath$1(storage.addition_json, relPath),
        size: "0",
        isdir: "1",
        rtype: "3"
      });
      invalidateStorageCache(storage);
    },
    async remove(storage, relPath) {
      const target = await resolveFile$3(client, storage, relPath);
      await manage(client, storage, "delete", [target.file.path]);
      invalidateStorageCache(storage);
    },
    async rename(storage, relPath, newName) {
      const target = await resolveFile$3(client, storage, relPath);
      await manage(client, storage, "rename", [{ path: target.file.path, newname: newName }]);
      invalidateStorageCache(storage);
    },
    async put(storage, relPath, content, mime, options = {}) {
      const bytes2 = uploadBytes$3(content, options);
      if (bytes2.length < 1) throw new Error("empty files are not allowed by baidu netdisk");
      const path = rootedPath$1(storage.addition_json, relPath);
      const now = Math.floor(Date.now() / 1e3);
      const mtime = Number(options.mtime || options.modified || now);
      const ctime = Number(options.ctime || options.created || now);
      try {
        await putRapid(client, storage, path, bytes2, mtime, ctime);
        invalidateStorageCache(storage);
        return;
      } catch (_) {
      }
      const sliceSize = getSliceSize(storage, bytes2.length);
      const blockList = [];
      for (let offset = 0; offset < bytes2.length; offset += sliceSize) {
        blockList.push(md5Hex$3(bytes2.slice(offset, Math.min(offset + sliceSize, bytes2.length))));
      }
      const blockListStr = JSON.stringify(blockList);
      const contentMd5 = md5Hex$3(bytes2);
      const sliceMd52 = md5Hex$3(bytes2.slice(0, Math.min(SLICE_MD5_SIZE, bytes2.length)));
      const pre = await precreate(client, storage, path, bytes2.length, blockListStr, contentMd5, sliceMd52, ctime, mtime);
      if (Number((pre == null ? void 0 : pre.return_type) || 0) === 2) {
        invalidateStorageCache(storage);
        return;
      }
      const uploadid = (pre == null ? void 0 : pre.uploadid) || "";
      if (!uploadid) throw new Error("baidu precreate missing uploadid");
      const partseqs = Array.isArray(pre == null ? void 0 : pre.block_list) && pre.block_list.length ? pre.block_list.map((part) => Number(part)) : blockList.map((_, index) => index);
      const uploadUrl = await getUploadUrl(client, storage, path, uploadid);
      const fileName = basename(path);
      for (const partseq of partseqs) {
        if (partseq < 0) continue;
        const offset = partseq * sliceSize;
        const chunk = bytes2.slice(offset, Math.min(offset + sliceSize, bytes2.length));
        await uploadSlice(client, storage, uploadUrl, {
          method: "upload",
          access_token: storage.addition_json.access_token || storage.addition_json.AccessToken || "",
          type: "tmpfile",
          path,
          uploadid,
          partseq
        }, fileName, chunk);
      }
      await createFile(client, storage, path, bytes2.length, 0, uploadid, blockListStr, mtime, ctime);
      invalidateStorageCache(storage);
    }
  });
  const hosts = {
    global: {
      oauth: "https://login.microsoftonline.com",
      api: "https://graph.microsoft.com"
    },
    cn: {
      oauth: "https://login.chinacloudapi.cn",
      api: "https://microsoftgraph.chinacloudapi.cn"
    },
    us: {
      oauth: "https://login.microsoftonline.us",
      api: "https://graph.microsoft.us"
    },
    de: {
      oauth: "https://login.microsoftonline.de",
      api: "https://graph.microsoft.de"
    }
  };
  const hostFor = (addition) => hosts[addition.region || addition.Region || "global"] || hosts.global;
  const additionValue = (addition, lowerName, upperName, fallback = "") => {
    const value = (addition == null ? void 0 : addition[lowerName]) ?? (addition == null ? void 0 : addition[upperName]);
    return value === void 0 || value === null || value === "" ? fallback : value;
  };
  const boolValue$1 = (value, fallback = false) => {
    if (value === void 0 || value === null || value === "") return fallback;
    return value === true || value === "true";
  };
  const encodePath = (path) => {
    const clean = normalizePath(path || "/");
    if (clean === "/") return "/";
    return "/" + clean.split("/").filter(Boolean).map(encodeURIComponent).join("/");
  };
  const rootedPath = (addition, relPath) => {
    const root = normalizePath(additionValue(addition, "root_folder_path", "RootFolderPath", "/"));
    return normalizePath(root + "/" + normalizePath(relPath || "/"));
  };
  const base64ToBytes$5 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$4 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i2 = 0; i2 < bytes2.length; i2 += 3) {
      const a = bytes2[i2];
      const b = bytes2[i2 + 1];
      const c = bytes2[i2 + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i2 + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i2 + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$3 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const uploadBytes$2 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$5(content || "") : utf8Bytes$3(content || "");
  const metaUrl = (addition, relPath) => {
    const host = hostFor(addition);
    const path = encodePath(rootedPath(addition, relPath));
    const isSharepoint = boolValue$1(additionValue(addition, "is_sharepoint", "IsSharepoint"));
    const siteId = additionValue(addition, "site_id", "SiteId");
    if (isSharepoint) {
      if (path === "/") return `${host.api}/v1.0/sites/${encodeURIComponent(siteId)}/drive/root`;
      return `${host.api}/v1.0/sites/${encodeURIComponent(siteId)}/drive/root:${path}:`;
    }
    if (path === "/") return `${host.api}/v1.0/me/drive/root`;
    return `${host.api}/v1.0/me/drive/root:${path}:`;
  };
  const chunkSizeOf = (addition) => Math.max(1, Number(addition.chunk_size || addition.ChunkSize || 5)) * 1024 * 1024;
  const metadataFromOptions = (options = {}) => {
    const fileSystemInfo = {};
    const modified = options.mtime || options.modified;
    const created = options.ctime || options.created;
    if (modified) fileSystemInfo.lastModifiedDateTime = new Date(modified).toISOString();
    if (created) fileSystemInfo.createdDateTime = new Date(created).toISOString();
    return { fileSystemInfo };
  };
  const updateMetadata = async (client, storage, relPath, options = {}) => {
    const metadata = metadataFromOptions(options);
    if (!Object.keys(metadata.fileSystemInfo).length) return;
    await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), {
      body: metadata,
      method: "PATCH"
    });
  };
  const createUploadSession = async (client, storage, relPath, metadata) => {
    const payload = await requestGraph(client, storage, `${metaUrl(storage.addition_json, relPath)}/createUploadSession`, {
      body: { item: metadata },
      method: "POST"
    });
    const uploadUrl = (payload == null ? void 0 : payload.uploadUrl) || "";
    if (!uploadUrl) throw new Error("failed to get upload URL from response");
    return uploadUrl;
  };
  const uploadSessionBytes = async (client, uploadUrl, bytes2, chunkSize) => {
    for (let start = 0; start < bytes2.length; start += chunkSize) {
      const end = Math.min(start + chunkSize, bytes2.length);
      const chunk = bytes2.slice(start, end);
      await forwardProxy(client, uploadUrl, {
        allowErrorStatus: false,
        body: bytesToBase64$4(chunk),
        contentType: "application/octet-stream",
        headers: {
          "Content-Length": String(chunk.length),
          "Content-Range": `bytes ${start}-${end - 1}/${bytes2.length}`
        },
        method: "PUT",
        payloadEncoding: "base64",
        responseEncoding: "text",
        timeout: 3e4
      });
    }
  };
  const tokenUrl = (addition) => `${hostFor(addition).oauth}/common/oauth2/v2.0/token`;
  const graphHeaders = (addition) => ({
    Authorization: `Bearer ${addition.access_token || addition.AccessToken || ""}`
  });
  const checkGraph = (payload) => {
    var _a2;
    if ((_a2 = payload == null ? void 0 : payload.error) == null ? void 0 : _a2.message) throw new Error(payload.error.message);
    if (payload == null ? void 0 : payload.error_description) throw new Error(payload.error_description);
    return payload;
  };
  const saveDriverStorage = async (storage) => {
    if (storage == null ? void 0 : storage.saveDriverStorage) await storage.saveDriverStorage(storage.addition_json);
  };
  const refreshToken = async (client, storage) => {
    const addition = storage.addition_json || storage;
    const useOnlineApi = boolValue$1(addition.use_online_api ?? addition.UseOnlineAPI, true);
    const apiAddress = addition.api_url_address || addition.APIAddress || "https://api.oplist.org/onedrive/renewapi";
    const refreshTokenValue2 = addition.refresh_token || addition.RefreshToken || "";
    if (useOnlineApi && apiAddress) {
      const url = new URL(apiAddress);
      url.searchParams.set("refresh_ui", refreshTokenValue2);
      url.searchParams.set("server_use", "true");
      url.searchParams.set("driver_txt", "onedrive_pr");
      const resp2 = checkGraph(await remoteJson(client, url.toString(), { method: "GET" }));
      if (!resp2.refresh_token || !resp2.access_token) {
        throw new Error(resp2.text || "empty token returned from official API, a wrong refresh token may have been used");
      }
      addition.refresh_token = resp2.refresh_token;
      addition.access_token = resp2.access_token;
      await saveDriverStorage(storage);
      return addition.access_token;
    }
    const clientId = addition.client_id || addition.ClientID || "";
    const clientSecret = addition.client_secret || addition.ClientSecret || "";
    if (!clientId || !clientSecret) throw new Error("empty ClientID or ClientSecret");
    const form = new URLSearchParams({
      grant_type: "refresh_token",
      client_id: clientId,
      client_secret: clientSecret,
      redirect_uri: addition.redirect_uri || addition.RedirectUri || "https://api.oplist.org/onedrive/callback",
      refresh_token: refreshTokenValue2
    });
    const resp = checkGraph(await remoteJson(client, tokenUrl(addition), {
      body: form.toString(),
      contentType: "application/x-www-form-urlencoded",
      method: "POST"
    }));
    if (!resp.refresh_token || !resp.access_token) throw new Error("empty token returned from Microsoft Graph");
    addition.refresh_token = resp.refresh_token;
    addition.access_token = resp.access_token;
    await saveDriverStorage(storage);
    return addition.access_token;
  };
  const requestGraph = async (client, storage, url, {
    body,
    contentType = "application/json",
    method = "GET",
    payloadEncoding,
    retry = true
  } = {}) => {
    var _a2;
    const addition = storage.addition_json;
    if (!addition.access_token && !addition.AccessToken) await refreshToken(client, storage);
    const resp = await remoteJson(client, url, {
      allowErrorStatus: true,
      body,
      contentType,
      headers: graphHeaders(addition),
      method,
      payloadEncoding
    });
    if (((_a2 = resp == null ? void 0 : resp.error) == null ? void 0 : _a2.code) === "InvalidAuthenticationToken" && retry) {
      await refreshToken(client, storage);
      return requestGraph(client, storage, url, { body, contentType, method, payloadEncoding, retry: false });
    }
    return checkGraph(resp);
  };
  const fileTime = (file) => {
    var _a2;
    const raw = ((_a2 = file == null ? void 0 : file.fileSystemInfo) == null ? void 0 : _a2.lastModifiedDateTime) || (file == null ? void 0 : file.lastModifiedDateTime) || (file == null ? void 0 : file.createdDateTime);
    const date = raw ? new Date(raw) : /* @__PURE__ */ new Date();
    return Number.isNaN(date.getTime()) ? (/* @__PURE__ */ new Date()).toISOString() : date.toISOString();
  };
  const fileToObj$4 = (file, relPath, storage) => {
    var _a2, _b2, _c, _d;
    const isDir2 = !file.file;
    return {
      name: file.name || basename(relPath),
      path: normalizePath(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: fileTime(file),
      created: ((_a2 = file == null ? void 0 : file.fileSystemInfo) == null ? void 0 : _a2.createdDateTime) || fileTime(file),
      thumb: ((_d = (_c = (_b2 = file == null ? void 0 : file.thumbnails) == null ? void 0 : _b2[0]) == null ? void 0 : _c.medium) == null ? void 0 : _d.url) || "",
      sign: "",
      type: isDir2 ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: file.id || "",
      raw_url: isDir2 ? "" : `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
      provider: "Onedrive"
    };
  };
  const customDownloadUrl = (addition, rawUrl) => {
    const customHost = additionValue(addition, "custom_host", "CustomHost");
    if (!customHost || !rawUrl) return rawUrl || "";
    try {
      const url = new URL(rawUrl);
      url.host = customHost;
      return url.toString();
    } catch (_) {
      return rawUrl || "";
    }
  };
  const driveUrl$1 = (addition) => {
    const host = hostFor(addition);
    if (boolValue$1(additionValue(addition, "is_sharepoint", "IsSharepoint"))) {
      return `${host.api}/v1.0/sites/${encodeURIComponent(additionValue(addition, "site_id", "SiteId"))}/drive`;
    }
    return `${host.api}/v1.0/me/drive`;
  };
  const createOneDriveDriver = ({ client }) => ({
    async list(storage, relPath) {
      const content = [];
      let next = `${metaUrl(storage.addition_json, relPath)}/children?$top=1000&$expand=thumbnails($select=medium)&$select=id,name,size,fileSystemInfo,content.downloadUrl,file,parentReference`;
      while (next) {
        const data = await requestGraph(client, storage, next);
        for (const file of data.value || []) {
          content.push(fileToObj$4(file, normalizePath(relPath + "/" + file.name), storage));
        }
        next = data["@odata.nextLink"] || "";
      }
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "Onedrive",
        direct_upload_tools: boolValue$1(additionValue(storage.addition_json, "enable_direct_upload", "EnableDirectUpload")) ? ["HttpDirect"] : []
      };
    },
    async get(storage, relPath) {
      const file = await requestGraph(client, storage, metaUrl(storage.addition_json, relPath));
      const url = customDownloadUrl(storage.addition_json, file["@microsoft.graph.downloadUrl"]);
      return {
        ...fileToObj$4(file, relPath, storage),
        raw_url: file.file ? url : "",
        url,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath) {
      const file = await requestGraph(client, storage, metaUrl(storage.addition_json, relPath));
      if (!file.file) throw new Error("not file");
      const url = customDownloadUrl(storage.addition_json, file["@microsoft.graph.downloadUrl"]);
      if (!url) throw new Error("get download url failed");
      return {
        link: {
          url,
          header: {},
          content_length: Number(file.size || 0)
        }
      };
    },
    async mkdir(storage, relPath) {
      await requestGraph(client, storage, `${metaUrl(storage.addition_json, dirname(relPath))}/children`, {
        body: {
          name: basename(relPath),
          folder: {},
          "@microsoft.graph.conflictBehavior": "rename"
        },
        method: "POST"
      });
    },
    async move(storage, relPath, dstRelPath) {
      const dst = await requestGraph(client, storage, metaUrl(storage.addition_json, dstRelPath));
      await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), {
        body: {
          parentReference: {
            id: dst.id
          },
          name: basename(relPath)
        },
        method: "PATCH"
      });
    },
    async copy(storage, relPath, dstRelPath) {
      var _a2;
      const dst = await requestGraph(client, storage, metaUrl(storage.addition_json, dstRelPath));
      await requestGraph(client, storage, `${metaUrl(storage.addition_json, relPath)}/copy`, {
        body: {
          parentReference: {
            driveId: ((_a2 = dst.parentReference) == null ? void 0 : _a2.driveId) || dst.driveId,
            id: dst.id
          },
          name: basename(relPath)
        },
        method: "POST"
      });
    },
    async remove(storage, relPath) {
      await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), { method: "DELETE" });
    },
    async rename(storage, relPath, newName) {
      var _a2;
      const file = await requestGraph(client, storage, metaUrl(storage.addition_json, relPath));
      await requestGraph(client, storage, metaUrl(storage.addition_json, relPath), {
        body: {
          parentReference: {
            id: ((_a2 = file.parentReference) == null ? void 0 : _a2.id) || "root"
          },
          name: newName
        },
        method: "PATCH"
      });
    },
    async put(storage, relPath, content, mime, options = {}) {
      const bytes2 = uploadBytes$2(content, options);
      if (bytes2.length <= 4 * 1024 * 1024) {
        await requestGraph(client, storage, `${metaUrl(storage.addition_json, relPath)}/content`, {
          body: content || "",
          contentType: mime || "application/octet-stream",
          method: "PUT",
          payloadEncoding: options.bodyEncoding === "base64" ? "base64" : void 0
        });
        await updateMetadata(client, storage, relPath, options);
        return;
      }
      const uploadUrl = await createUploadSession(client, storage, relPath, metadataFromOptions(options));
      await uploadSessionBytes(client, uploadUrl, bytes2, chunkSizeOf(storage.addition_json));
    },
    async getDirectUploadInfo(storage, relPath) {
      if (!boolValue$1(additionValue(storage.addition_json, "enable_direct_upload", "EnableDirectUpload"), false)) {
        throw new Error("direct upload is not implemented for this storage");
      }
      const uploadUrl = await createUploadSession(client, storage, relPath, {
        "@microsoft.graph.conflictBehavior": "rename"
      });
      return {
        upload_url: uploadUrl,
        uploadUrl,
        chunk_size: chunkSizeOf(storage.addition_json),
        chunkSize: chunkSizeOf(storage.addition_json),
        method: "PUT"
      };
    },
    async details(storage) {
      var _a2, _b2;
      if (boolValue$1(additionValue(storage.addition_json, "disable_disk_usage", "DisableDiskUsage"))) {
        throw new Error("storage details are disabled");
      }
      const drive = await requestGraph(client, storage, driveUrl$1(storage.addition_json), { retry: false });
      const total = Number(((_a2 = drive == null ? void 0 : drive.quota) == null ? void 0 : _a2.total) || 0);
      const used = Number(((_b2 = drive == null ? void 0 : drive.quota) == null ? void 0 : _b2.used) || 0);
      return {
        total_space: total,
        used_space: used,
        free_space: Math.max(0, total - used)
      };
    }
  });
  const trimAddress = (address) => String(address || "").replace(/\/+$/, "");
  const addressOf = (addition) => {
    const address = trimAddress(addition.url || addition.address || addition.Address);
    return address.replace(/\/(?:admin|@manage)$/i, "");
  };
  const headersFor$1 = (addition) => ({
    Authorization: addition.token || addition.Token || ""
  });
  const checkResp = (payload) => {
    if (payload.code && payload.code !== 200) throw new Error(payload.message || `OpenList code ${payload.code}`);
    return payload.data;
  };
  const absoluteUrl = (addition, rawUrl) => {
    const value = String(rawUrl || "");
    if (!value) return "";
    if (/^https?:\/\//i.test(value)) return value;
    const address = addressOf(addition);
    return `${address}${value.startsWith("/") ? "" : "/"}${value}`;
  };
  const withOpenListHint = async (operation) => {
    try {
      return await operation();
    } catch (error) {
      const message = (error == null ? void 0 : error.message) || "";
      if (/ip address .*prohibited|prohibited/i.test(message)) {
        throw new Error("SiYuan v3.7.0 blocked this OpenList/AList upstream in /api/network/forwardProxy SSRF protection. Use an address the SiYuan kernel is allowed to dial, or expose OpenList/AList through a routed domain/reverse proxy. The API base URL should not include /admin.");
      }
      throw error;
    }
  };
  const login = async (client, storage) => {
    var _a2;
    const addition = storage.addition_json;
    if (!addition.username && !addition.Username) return;
    const payload = await withOpenListHint(() => remoteJson(
      client,
      `${addressOf(addition)}/api/auth/login`,
      {
        body: {
          username: addition.username || addition.Username || "",
          password: addition.password || addition.Password || ""
        },
        method: "POST",
        timeout: Number(addition.timeout || 3e4)
      }
    ));
    addition.token = ((_a2 = payload == null ? void 0 : payload.data) == null ? void 0 : _a2.token) || "";
    if (storage.saveDriverStorage) await storage.saveDriverStorage(addition);
  };
  const objFrom = (item, path) => ({
    name: item.name,
    path,
    is_dir: !!item.is_dir,
    size: Number(item.size || 0),
    modified: item.modified || (/* @__PURE__ */ new Date()).toISOString(),
    created: item.created || item.modified || (/* @__PURE__ */ new Date()).toISOString(),
    thumb: item.thumb || "",
    sign: item.sign || "",
    type: item.type || 0,
    hashinfo: item.hashinfo || item.hash_info || ""
  });
  const createOpenListDriver = ({ client }) => {
    const request2 = async (storage, apiPath, method, body, retry = false) => {
      const addition = storage.addition_json;
      const payload = await withOpenListHint(() => remoteJson(
        client,
        `${addressOf(addition)}/api${apiPath}`,
        {
          body,
          headers: headersFor$1(addition),
          method,
          timeout: Number(addition.timeout || 3e4)
        }
      ));
      if ((payload.code === 401 || payload.code === 403) && !retry) {
        await login(client, storage);
        return request2(storage, apiPath, method, body, true);
      }
      return checkResp(payload);
    };
    return {
      async list(storage, relPath, req) {
        var _a2;
        const addition = storage.addition_json;
        const data = await request2(storage, "/fs/list", "POST", {
          page: Number(req.page || 1),
          per_page: Number(req.per_page || req.perPage || 0),
          path: relPath,
          password: addition.meta_password || "",
          refresh: !!req.refresh
        });
        return {
          content: (data.content || []).map((item) => objFrom(item, normalizePath(relPath + "/" + item.name))),
          total: Number(data.total || ((_a2 = data.content) == null ? void 0 : _a2.length) || 0),
          readme: data.readme || "",
          header: data.header || "",
          write: data.write !== false,
          provider: "OpenList",
          direct_upload_tools: []
        };
      },
      async get(storage, relPath, options = {}) {
        const addition = storage.addition_json;
        const data = await request2(storage, "/fs/get", "POST", {
          path: relPath,
          password: addition.meta_password || ""
        });
        return {
          ...objFrom(data, relPath),
          raw_url: options.skipLink ? "" : absoluteUrl(addition, data.raw_url || data.url || ""),
          readme: data.readme || "",
          header: data.header || "",
          provider: "OpenList",
          related: data.related || []
        };
      },
      async read(storage, relPath, options = {}) {
        const data = await this.get(storage, relPath);
        const url = absoluteUrl(storage.addition_json, data.raw_url || data.url || "");
        if (!url) throw new Error("OpenList returned empty raw_url");
        return {
          link: {
            content_length: Number(data.size || 0),
            header: options.proxyHeaders || options.headers || {},
            method: "GET",
            url
          }
        };
      },
      async mkdir(storage, relPath) {
        await request2(storage, "/fs/mkdir", "POST", { path: relPath });
      },
      async move(storage, relPath, dstRelPath) {
        await request2(storage, "/fs/move", "POST", {
          src_dir: dirname(relPath),
          dst_dir: normalizePath(dstRelPath),
          names: [basename(relPath)]
        });
      },
      async copy(storage, relPath, dstRelPath) {
        await request2(storage, "/fs/copy", "POST", {
          src_dir: dirname(relPath),
          dst_dir: normalizePath(dstRelPath),
          names: [basename(relPath)]
        });
      },
      async remove(storage, relPath) {
        await request2(storage, "/fs/remove", "POST", {
          dir: dirname(relPath),
          names: [relPath.split("/").filter(Boolean).pop()]
        });
      },
      async rename(storage, relPath, newName) {
        await request2(storage, "/fs/rename", "POST", { path: relPath, name: newName });
      },
      async other(storage, relPath, req = {}) {
        return request2(storage, "/fs/other", "POST", {
          path: relPath,
          method: req.method || "",
          data: req.data === void 0 ? null : req.data,
          password: storage.addition_json.meta_password || ""
        });
      },
      async test(storage) {
        const addition = storage.addition_json;
        await request2(storage, "/fs/list", "POST", {
          page: 1,
          per_page: 1,
          path: addition.root_folder_path || addition.root_folder_id || "/",
          password: addition.meta_password || "",
          refresh: false
        });
        return { ok: true };
      },
      async put(storage, relPath, content, mime, options = {}) {
        const addition = storage.addition_json;
        const response = await withOpenListHint(() => forwardProxy(
          client,
          `${addressOf(addition)}/api/fs/put`,
          {
            allowErrorStatus: true,
            body: content || "",
            contentType: mime || "application/octet-stream",
            headers: {
              Authorization: addition.token || addition.Token || "",
              "File-Path": relPath,
              Password: addition.meta_password || ""
            },
            method: "PUT",
            payloadEncoding: options.bodyEncoding === "base64" ? "base64" : void 0,
            responseEncoding: "text",
            timeout: Number(addition.timeout || 3e4)
          }
        ));
        const payload = JSON.parse(response.body || "{}");
        checkResp(payload);
      }
    };
  };
  const API = "https://open-api-drive.quark.cn";
  const UA = "go-resty/3.0.0-beta.1 (https://resty.dev)";
  const DEFAULT_APP_ID = "93b14d40cbef4e5d91945ec93d26fe8f";
  const DEFAULT_SIGN_KEY = "6d27122d2d7b41598a1dbb9b5f605e00";
  const cache$3 = createStorageCache();
  const randomHex = () => Math.floor(Math.random() * 4294967295).toString(16).padStart(8, "0");
  const reqId = () => `${randomHex()}-${randomHex().slice(0, 4)}-${randomHex().slice(0, 4)}-${randomHex().slice(0, 4)}-${randomHex()}${randomHex().slice(0, 4)}`;
  const checkQuarkOpen = (payload) => {
    if (Number((payload == null ? void 0 : payload.status) || 0) >= 400 || Number((payload == null ? void 0 : payload.errno) || 0) !== 0) {
      throw new Error((payload == null ? void 0 : payload.error_info) || (payload == null ? void 0 : payload.message) || "quark open request failed");
    }
    return payload;
  };
  const generateReqSign$1 = (method, pathname, signKey) => {
    const timestamp2 = String(Date.now());
    return {
      req_id: reqId(),
      tm: timestamp2,
      token: sha256Hex(`${method.toUpperCase()}&${pathname}&${timestamp2}&${signKey || ""}`)
    };
  };
  const refreshTokenOnline = async (client, storage) => {
    const addition = storage.addition_json;
    if (!boolValue$3(addition.use_online_api, true)) {
      throw new Error("local refresh token logic is not implemented yet, please use online API or contact the developer");
    }
    const target = new URL(addition.api_url_address || "https://api.oplist.org/quarkyun/renewapi");
    target.searchParams.set("refresh_ui", addition.refresh_token || "");
    target.searchParams.set("server_use", "true");
    target.searchParams.set("driver_txt", "quarkyun_oa");
    const resp = await remoteJson(client, target.toString(), { method: "GET" });
    if (!(resp == null ? void 0 : resp.refresh_token) || !(resp == null ? void 0 : resp.access_token)) {
      throw new Error((resp == null ? void 0 : resp.text) || "empty token returned from official API, a wrong refresh token may have been used");
    }
    addition.refresh_token = resp.refresh_token;
    addition.access_token = resp.access_token;
    if (resp.app_id) addition.app_id = resp.app_id;
    if (resp.sign_key) addition.sign_key = resp.sign_key;
    await persistAddition$1(storage);
  };
  const ensureAccessToken = async (client, storage) => {
    if (!storage.addition_json.access_token) await refreshTokenOnline(client, storage);
  };
  const ensurePublicParams = (storage) => {
    if (!(storage.addition_json.app_id || DEFAULT_APP_ID) || !(storage.addition_json.sign_key || DEFAULT_SIGN_KEY)) ;
  };
  const requestQuarkOpen = async (client, storage, pathname, {
    body,
    manualSign,
    method = "GET",
    retry = true
  } = {}) => {
    const addition = storage.addition_json;
    if (!addition.access_token && retry) await ensureAccessToken(client, storage);
    ensurePublicParams(storage);
    const appId = addition.app_id || DEFAULT_APP_ID;
    const signKey = addition.sign_key || DEFAULT_SIGN_KEY;
    const sign = manualSign || generateReqSign$1(method, pathname, signKey);
    const target = new URL(`${API}${pathname}`);
    target.searchParams.set("req_id", sign.req_id);
    target.searchParams.set("access_token", addition.access_token || "");
    const resp = await remoteJson(client, target.toString(), {
      allowErrorStatus: true,
      body,
      headers: {
        Accept: "application/json, text/plain, */*",
        "User-Agent": UA,
        "x-pan-client-id": appId,
        "x-pan-tm": sign.tm,
        "x-pan-token": sign.token
      },
      method
    });
    const tokenExpired = Number((resp == null ? void 0 : resp.status) || 0) === -1 && (Number((resp == null ? void 0 : resp.errno) || 0) === 11001 || Number((resp == null ? void 0 : resp.errno) || 0) === 14001 && String((resp == null ? void 0 : resp.error_info) || "").includes("access_token"));
    if (tokenExpired && retry) {
      await refreshTokenOnline(client, storage);
      return requestQuarkOpen(client, storage, pathname, { body, method, retry: false });
    }
    return checkQuarkOpen(resp);
  };
  const rememberUserId = async (storage, user = {}) => {
    const userId = user.user_id || user.userId || user.UserID || user.userid || "";
    if (userId && storage.addition_json.user_id !== userId) {
      storage.addition_json.user_id = userId;
      await persistAddition$1(storage);
    }
    return storage.addition_json.user_id || userId;
  };
  const ensureUserId = async (client, storage) => {
    if (storage.addition_json.user_id) return storage.addition_json.user_id;
    const resp = await requestQuarkOpen(client, storage, "/open/v1/user/info", { method: "GET" });
    const userId = await rememberUserId(storage, (resp == null ? void 0 : resp.data) || {});
    if (!userId) throw new Error("failed to get user ID");
    return userId;
  };
  const base64ToBytes$4 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$3 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i2 = 0; i2 < bytes2.length; i2 += 3) {
      const a = bytes2[i2];
      const b = bytes2[i2 + 1];
      const c = bytes2[i2 + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i2 + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i2 + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$2 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const uploadBytes$1 = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$4(content || "") : utf8Bytes$2(content || "");
  const hex$4 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const rol$2 = (value, bits2) => value << bits2 | value >>> 32 - bits2;
  const sha1Bytes$2 = (message) => {
    const msg = message instanceof Uint8Array ? message : utf8Bytes$2(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i2 = 0; i2 < 16; i2 += 1) w[i2] = view.getUint32(offset + i2 * 4);
      for (let i2 = 16; i2 < 80; i2 += 1) w[i2] = rol$2(w[i2 - 3] ^ w[i2 - 8] ^ w[i2 - 14] ^ w[i2 - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i2 = 0; i2 < 80; i2 += 1) {
        let f;
        let k;
        if (i2 < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i2 < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i2 < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$2(a, 5) + f + e + k + w[i2] >>> 0;
        e = d;
        d = c;
        c = rol$2(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const sha1Hex$1 = (message) => hex$4(sha1Bytes$2(message));
  const leftRotate$1 = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$2 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$2(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i2) => Math.floor(Math.abs(Math.sin(i2 + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i2 = 0; i2 < 64; i2 += 1) {
        let f;
        let g;
        if (i2 < 16) {
          f = b & c | ~b & d;
          g = i2;
        } else if (i2 < 32) {
          f = d & b | ~d & c;
          g = (5 * i2 + 1) % 16;
        } else if (i2 < 48) {
          f = b ^ c ^ d;
          g = (3 * i2 + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i2 % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate$1(a + f + k[i2] + view.getUint32(offset + g * 4, true) >>> 0, s[i2]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const proofCode = (seed, bytes2) => {
    if (!bytes2.length) return "";
    const start = Number(BigInt(`0x${md5Hex$2(seed).slice(0, 16)}`) % BigInt(bytes2.length));
    return bytesToBase64$3(bytes2.slice(start, Math.min(start + 8, bytes2.length)));
  };
  const partInfoList = (size, partSize) => {
    const parts = [];
    for (let left = size, part = 1; left > 0; part += 1) {
      const current = Math.min(partSize, left);
      parts.push({ part_number: part, part_size: current });
      left -= current;
    }
    return parts;
  };
  const timeFromMs$2 = (value) => parseTime$1(Number(value || 0));
  const fileNameOf$1 = (file) => file.filename || file.file_name || file.name || "";
  const isDir$1 = (file) => String(file.file_type) === "0";
  const fileToObj$3 = (file, relPath) => {
    const dir = isDir$1(file);
    return {
      name: fileNameOf$1(file) || basenameOf(relPath),
      is_dir: dir,
      size: Number(file.size || 0),
      modified: timeFromMs$2(file.updated_at),
      created: timeFromMs$2(file.created_at),
      sign: "",
      thumb: file.thumbnail_url || "",
      type: dir ? 1 : 0,
      hashinfo: file.content_hash || "",
      hash_info: file.content_hash ? { sha1: file.content_hash } : {},
      id: file.fid || "",
      file
    };
  };
  const listByParent$2 = async (client, storage, parentId) => {
    const cacheKey2 = parentId || storage.addition_json.root_folder_id || "0";
    return cache$3.list(storage, cacheKey2, async () => {
      const addition = storage.addition_json;
      const result = [];
      let queryCursor = null;
      for (; ; ) {
        const reqBody = {
          parent_fid: parentId || addition.root_folder_id || "0",
          size: 100,
          sort: "file_name:asc"
        };
        if ((addition.order_by || "none") !== "none") {
          reqBody.sort = `${addition.order_by}:${addition.order_direction || "asc"}`;
        }
        if (queryCursor == null ? void 0 : queryCursor.token) reqBody.query_cursor = queryCursor;
        const resp = await requestQuarkOpen(client, storage, "/open/v1/file/list", {
          body: reqBody,
          method: "POST"
        });
        const data = (resp == null ? void 0 : resp.data) || {};
        result.push(...data.file_list || []);
        if (data.last_page) break;
        queryCursor = data.next_query_cursor || null;
        if (!(queryCursor == null ? void 0 : queryCursor.token)) break;
      }
      return result;
    });
  };
  const resolveFile$2 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    return cache$3.file(storage, clean, async () => {
      const rootId2 = storage.addition_json.root_folder_id || storage.addition_json.RootFolderID || "0";
      if (clean === "/") {
        return {
          fid: rootId2,
          filename: "root",
          file_type: "0",
          path: "/"
        };
      }
      let parentId = rootId2;
      let current = null;
      for (const part of clean.split("/").filter(Boolean)) {
        const files = await listByParent$2(client, storage, parentId);
        current = files.find((item) => fileNameOf$1(item) === part);
        if (!current) throw new Error(`object not found: ${clean}`);
        parentId = current.fid;
      }
      return current;
    });
  };
  const downloadLink$3 = async (client, storage, file) => {
    return cache$3.link(storage, file.fid || "", async () => {
      var _a2;
      const resp = await requestQuarkOpen(client, storage, "/open/v1/file/get_download_url", {
        body: { fid: file.fid },
        method: "POST"
      });
      const url = ((_a2 = resp == null ? void 0 : resp.data) == null ? void 0 : _a2.download_url) || "";
      if (!url) throw new Error("get download url failed");
      return {
        header: {
          Cookie: `x_pan_client_id=${storage.addition_json.app_id || DEFAULT_APP_ID}; x_pan_access_token=${storage.addition_json.access_token || ""}`
        },
        url,
        content_length: Number(file.size || 0)
      };
    });
  };
  const manageFile$1 = async (client, storage, pathname, body) => {
    await requestQuarkOpen(client, storage, pathname, { body, method: "POST" });
    cache$3.clear(storage);
  };
  const createQuarkOpenDriver = ({ client }) => ({
    async test(storage) {
      const resp = await requestQuarkOpen(client, storage, "/open/v1/user/info", { method: "GET" });
      const userId = await rememberUserId(storage, (resp == null ? void 0 : resp.data) || {});
      if (!userId) throw new Error("failed to get user ID");
      return { user: (resp == null ? void 0 : resp.data) || {}, addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$2(client, storage, relPath);
      const content = (await listByParent$2(client, storage, parent.fid)).map((file) => fileToObj$3(file, normalizePath(relPath + "/" + fileNameOf$1(file))));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: storage.driver || "QuarkOpen",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$2(client, storage, relPath);
      const obj = fileToObj$3(file, relPath);
      if (!obj.is_dir && !options.skipLink) {
        const link2 = await downloadLink$3(client, storage, file);
        obj.raw_url = link2.url;
        obj.url = link2.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$2(client, storage, relPath);
      if (isDir$1(file)) throw new Error("not file");
      const link2 = await downloadLink$3(client, storage, file);
      return {
        link: {
          url: link2.url,
          header: { ...link2.header, ...options.proxyHeaders || options.headers || {} },
          content_length: link2.content_length,
          concurrency: 3,
          part_size: 10 * 1024 * 1024
        }
      };
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$2(client, storage, dirnameOf(relPath));
      await manageFile$1(client, storage, "/open/v1/dir", {
        dir_path: basenameOf(relPath),
        pdir_fid: parent.fid
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$2(client, storage, relPath);
      const dst = await resolveFile$2(client, storage, dstRelPath);
      await manageFile$1(client, storage, "/open/v1/file/move", {
        action_type: 1,
        fid_list: [file.fid],
        to_pdir_fid: dst.fid
      });
    },
    async remove(storage, relPath) {
      const file = await resolveFile$2(client, storage, relPath);
      await manageFile$1(client, storage, "/open/v1/file/delete", {
        action_type: 1,
        fid_list: [file.fid]
      });
    },
    async rename(storage, relPath, newName) {
      const file = await resolveFile$2(client, storage, relPath);
      await manageFile$1(client, storage, "/open/v1/file/rename", {
        conflict_mode: "REUSE",
        fid: file.fid,
        file_name: newName
      });
    },
    async copy() {
      throw new Error("QuarkOpen copy is not supported by the OpenList driver");
    },
    async put(storage, relPath, content, mime, options = {}) {
      var _a2, _b2, _c, _d, _e, _f, _g;
      const parent = await resolveFile$2(client, storage, dirnameOf(relPath));
      const bytes2 = uploadBytes$1(content, options);
      const prePath = "/open/v1/file/upload_pre";
      const preSign = generateReqSign$1("POST", prePath, storage.addition_json.sign_key || DEFAULT_SIGN_KEY);
      const proofSeed1 = md5Hex$2(`${await ensureUserId(client, storage)}${preSign.token}`);
      const proofSeed2 = md5Hex$2(String(bytes2.length));
      const pre = await requestQuarkOpen(client, storage, prePath, {
        body: {
          file_name: basenameOf(relPath),
          size: bytes2.length,
          format_type: mime || "application/octet-stream",
          md5: md5Hex$2(bytes2),
          sha1: sha1Hex$1(bytes2),
          l_created_at: Date.now(),
          l_updated_at: Date.now(),
          pdir_fid: parent.fid,
          same_path_reuse: true,
          proof_version: "v1",
          proof_seed1: proofSeed1,
          proof_seed2: proofSeed2,
          proof_code1: proofCode(proofSeed1, bytes2),
          proof_code2: proofCode(proofSeed2, bytes2)
        },
        manualSign: preSign,
        method: "POST"
      });
      const preData = (pre == null ? void 0 : pre.data) || {};
      if (preData.finish) {
        cache$3.clear(storage);
        return;
      }
      const partSize = Number(preData.part_size || bytes2.length || 1);
      const parts = partInfoList(bytes2.length, partSize);
      const uploadInfo = await requestQuarkOpen(client, storage, "/open/v1/file/get_upload_urls", {
        body: {
          task_id: preData.task_id,
          part_info_list: parts
        },
        method: "POST"
      });
      const uploadData = (uploadInfo == null ? void 0 : uploadInfo.data) || {};
      const etags = [];
      for (let index = 0; index < (uploadData.upload_urls || []).length; index += 1) {
        const part = parts[index];
        const start = (part.part_number - 1) * partSize;
        const chunk = bytes2.slice(start, Math.min(start + part.part_size, bytes2.length));
        const uploadUrl = uploadData.upload_urls[index];
        const resp = await forwardProxy(client, uploadUrl.upload_url, {
          allowErrorStatus: true,
          body: bytesToBase64$3(chunk),
          contentType: "application/octet-stream",
          headers: {
            Authorization: ((_a2 = uploadUrl.signature_info) == null ? void 0 : _a2.signature) || "",
            "X-Oss-Date": ((_b2 = uploadData.common_headers) == null ? void 0 : _b2["X-Oss-Date"]) || "",
            "X-Oss-Content-Sha256": ((_c = uploadData.common_headers) == null ? void 0 : _c["X-Oss-Content-Sha256"]) || "",
            "Accept-Encoding": "gzip",
            "User-Agent": "Go-http-client/1.1"
          },
          method: "PUT",
          payloadEncoding: "base64",
          responseEncoding: "text",
          timeout: 12e4
        });
        if (Number(resp.status || 0) !== 200) throw new Error(`up status: ${resp.status}`);
        etags.push(((_d = resp.headers) == null ? void 0 : _d.Etag) || ((_e = resp.headers) == null ? void 0 : _e.ETag) || ((_f = resp.headers) == null ? void 0 : _f.etag) || "");
      }
      const finishParts = parts.map((part, index) => ({
        part_number: part.part_number,
        part_size: part.part_size,
        etag: etags[index]
      }));
      const finish = await requestQuarkOpen(client, storage, "/open/v1/file/upload_finish", {
        body: {
          task_id: preData.task_id,
          part_info_list: finishParts
        },
        method: "POST"
      });
      if (((_g = finish == null ? void 0 : finish.data) == null ? void 0 : _g.finish) !== true) throw new Error(`upload finish failed, task_id: ${preData.task_id}`);
      cache$3.clear(storage);
    }
  });
  const configs$1 = {
    Quark: {
      api: "https://drive.quark.cn/1/clouddrive",
      pr: "ucpro",
      referer: "https://pan.quark.cn",
      ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) quark-cloud-drive/2.5.20 Chrome/100.0.4896.160 Electron/18.3.5.4-b478491100 Safari/537.36 Channel/pckk_other_ch"
    },
    UC: {
      api: "https://pc-api.uc.cn/1/clouddrive",
      pr: "UCBrowser",
      referer: "https://drive.uc.cn",
      ua: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) uc-cloud-drive/2.5.20 Chrome/100.0.4896.160 Electron/18.3.5.4-b478491100 Safari/537.36 Channel/pckk_other_ch"
    }
  };
  const checkQuark = (payload) => {
    if (Number((payload == null ? void 0 : payload.status) || 0) >= 400 || Number((payload == null ? void 0 : payload.code) || 0) !== 0) {
      throw new Error((payload == null ? void 0 : payload.message) || "quark request failed");
    }
    return payload;
  };
  const cookieHeader = (addition) => addition.cookie || addition.Cookie || "";
  const headerValues$1 = (headers = {}, name) => {
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() === name.toLowerCase()) return Array.isArray(value) ? value : [value];
    }
    return [];
  };
  const setCookie = (cookie, name, value) => {
    const parts = String(cookie || "").split(";").map((item) => item.trim()).filter(Boolean);
    const prefix = `${name}=`;
    const next = `${name}=${value}`;
    const index = parts.findIndex((item) => item.startsWith(prefix));
    if (index >= 0) parts[index] = next;
    else parts.push(next);
    return parts.join("; ");
  };
  const rememberQuarkCookies = async (storage, headers) => {
    let cookie = cookieHeader(storage.addition_json);
    const before = cookie;
    for (const item of headerValues$1(headers, "set-cookie")) {
      const pair = String(item || "").split(";")[0];
      const index = pair.indexOf("=");
      if (index <= 0) continue;
      const name = pair.slice(0, index);
      if (name !== "__puus" && !(storage.driver === "Quark" && boolValue$3(storage.addition_json.use_transcoding_address) && name === "__pus")) continue;
      cookie = setCookie(cookie, name, pair.slice(index + 1));
    }
    if (cookie && cookie !== before) {
      storage.addition_json.cookie = cookie;
      await persistAddition$1(storage);
    }
  };
  const confFor$1 = (storage) => configs$1[storage.driver] || configs$1.Quark;
  const cache$2 = createStorageCache();
  const requestQuark = async (client, storage, pathname, {
    body,
    method = "GET",
    query = {},
    userAgent
  } = {}) => {
    const conf = confFor$1(storage);
    const target = new URL(`${conf.api}${pathname}`);
    target.searchParams.set("pr", conf.pr);
    target.searchParams.set("fr", "pc");
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const { json, meta } = await remoteJsonWithMeta(client, target.toString(), {
      allowErrorStatus: true,
      body,
      headers: {
        Accept: "application/json, text/plain, */*",
        Cookie: cookieHeader(storage.addition_json),
        Referer: conf.referer,
        "User-Agent": userAgent || conf.ua
      },
      method
    });
    await rememberQuarkCookies(storage, meta == null ? void 0 : meta.headers);
    return checkQuark(json);
  };
  const base64ToBytes$3 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const out = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      out.push(a << 2 | b >> 4);
      if (c >= 0) out.push((b & 15) << 4 | c >> 2);
      if (d >= 0) out.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(out);
  };
  const bytesToBase64$2 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i2 = 0; i2 < bytes2.length; i2 += 3) {
      const a = bytes2[i2];
      const b = bytes2[i2 + 1];
      const c = bytes2[i2 + 2];
      out += chars2[a >> 2];
      out += chars2[(a & 3) << 4 | (b || 0) >> 4];
      out += i2 + 1 < bytes2.length ? chars2[(b & 15) << 2 | (c || 0) >> 6] : "=";
      out += i2 + 2 < bytes2.length ? chars2[c & 63] : "=";
    }
    return out;
  };
  const utf8Bytes$1 = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    const out = new Uint8Array(text2.length);
    for (let i2 = 0; i2 < text2.length; i2 += 1) out[i2] = text2.charCodeAt(i2);
    return out;
  };
  const uploadBytes = (content, options = {}) => options.bodyEncoding === "base64" ? base64ToBytes$3(content || "") : utf8Bytes$1(content || "");
  const hex$3 = (input) => Array.from(input, (b) => b.toString(16).padStart(2, "0")).join("");
  const hexToBytes = (value) => {
    const clean = String(value || "");
    const out = new Uint8Array(clean.length / 2);
    for (let i2 = 0; i2 < out.length; i2 += 1) out[i2] = Number.parseInt(clean.slice(i2 * 2, i2 * 2 + 2), 16);
    return out;
  };
  const rol$1 = (value, bits2) => value << bits2 | value >>> 32 - bits2;
  const sha1Bytes$1 = (message) => {
    const msg = message instanceof Uint8Array ? message : utf8Bytes$1(message);
    const bitLen = msg.length * 8;
    const paddedLen = msg.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(msg);
    padded[msg.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i2 = 0; i2 < 16; i2 += 1) w[i2] = view.getUint32(offset + i2 * 4);
      for (let i2 = 16; i2 < 80; i2 += 1) w[i2] = rol$1(w[i2 - 3] ^ w[i2 - 8] ^ w[i2 - 14] ^ w[i2 - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i2 = 0; i2 < 80; i2 += 1) {
        let f;
        let k;
        if (i2 < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i2 < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i2 < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol$1(a, 5) + f + e + k + w[i2] >>> 0;
        e = d;
        d = c;
        c = rol$1(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const sha1Hex = (message) => hex$3(sha1Bytes$1(message));
  const leftRotate = (value, amount) => value << amount | value >>> 32 - amount;
  const md5Hex$1 = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes$1(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i2) => Math.floor(Math.abs(Math.sin(i2 + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i2 = 0; i2 < 64; i2 += 1) {
        let f;
        let g;
        if (i2 < 16) {
          f = b & c | ~b & d;
          g = i2;
        } else if (i2 < 32) {
          f = d & b | ~d & c;
          g = (5 * i2 + 1) % 16;
        } else if (i2 < 48) {
          f = b ^ c ^ d;
          g = (3 * i2 + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i2 % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + leftRotate(a + f + k[i2] + view.getUint32(offset + g * 4, true) >>> 0, s[i2]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    return [a0, b0, c0, d0].map((value) => [value & 255, value >>> 8 & 255, value >>> 16 & 255, value >>> 24 & 255].map((byte) => byte.toString(16).padStart(2, "0")).join("")).join("");
  };
  const httpTime = () => (/* @__PURE__ */ new Date()).toUTCString();
  const OSS_USER_AGENT = "aliyun-sdk-js/6.6.1 Chrome 98.0.4758.80 on Windows 10 64-bit";
  const timeFromMs$1 = (value) => parseTime$1(Number(value || 0));
  const fileToObj$2 = (file, relPath) => {
    const isDir2 = !file.file;
    return {
      name: file.file_name || basenameOf(relPath),
      is_dir: isDir2,
      size: Number(file.size || 0),
      modified: timeFromMs$1(file.updated_at || file.l_updated_at),
      created: timeFromMs$1(file.created_at || file.l_created_at),
      sign: "",
      thumb: file.thumbnail || "",
      type: isDir2 ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: file.fid || "",
      file
    };
  };
  const listByParent$1 = async (client, storage, parentId) => {
    const cacheKey2 = parentId || storage.addition_json.root_folder_id || "0";
    return cache$2.list(storage, cacheKey2, async () => {
      var _a2, _b2;
      const addition = storage.addition_json;
      const result = [];
      const size = 100;
      let page = 1;
      for (; ; ) {
        const query = {
          pdir_fid: parentId || addition.root_folder_id || "0",
          _size: size,
          _fetch_total: "1",
          fetch_all_file: "1",
          fetch_risk_file_name: "1",
          _page: page
        };
        if ((addition.order_by || "none") !== "none") {
          query._sort = `file_type:asc,${addition.order_by}:${addition.order_direction || "asc"}`;
        }
        const resp = await requestQuark(client, storage, "/file/sort", { method: "GET", query });
        const list = ((_a2 = resp == null ? void 0 : resp.data) == null ? void 0 : _a2.list) || [];
        for (const file of list) {
          if (!boolValue$3(addition.only_list_video_file) || !file.file || Number(file.category || 0) === 1) {
            result.push({ ...file, file_name: decodeHtml(file.file_name || "") });
          }
        }
        if (page * size >= Number(((_b2 = resp == null ? void 0 : resp.metadata) == null ? void 0 : _b2._total) || list.length)) break;
        page += 1;
      }
      return result;
    });
  };
  const decodeHtml = (value) => String(value || "").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  const resolveFile$1 = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    return cache$2.file(storage, clean, async () => {
      const rootId2 = storage.addition_json.root_folder_id || storage.addition_json.RootFolderID || "0";
      if (clean === "/") {
        return {
          fid: rootId2,
          file_name: "root",
          file: false,
          path: "/"
        };
      }
      let parentId = rootId2;
      let current = null;
      for (const part of clean.split("/").filter(Boolean)) {
        const files = await listByParent$1(client, storage, parentId);
        current = files.find((item) => item.file_name === part);
        if (!current) throw new Error(`object not found: ${clean}`);
        parentId = current.fid;
      }
      return current;
    });
  };
  const downloadLink$2 = async (client, storage, file) => {
    return cache$2.link(storage, `${storage.driver || "Quark"}:${file.fid}:${boolValue$3(storage.addition_json.use_transcoding_address)}`, async () => {
      var _a2, _b2, _c, _d;
      const conf = confFor$1(storage);
      if (boolValue$3(storage.addition_json.use_transcoding_address) && storage.driver === "Quark" && Number(file.category || 0) === 1 && Number(file.size || 0) > 0) {
        const resp2 = await requestQuark(client, storage, "/file/v2/play/project", {
          body: {
            fid: file.fid,
            resolutions: "low,normal,high,super,2k,4k",
            supports: "fmp4_av,m3u8,dolby_vision"
          },
          method: "POST",
          userAgent: conf.ua
        });
        for (const info of ((_a2 = resp2 == null ? void 0 : resp2.data) == null ? void 0 : _a2.video_list) || []) {
          if ((_b2 = info == null ? void 0 : info.video_info) == null ? void 0 : _b2.url) {
            return {
              header: {},
              url: info.video_info.url,
              content_length: Number(info.video_info.size || file.size || 0)
            };
          }
        }
      }
      const resp = await requestQuark(client, storage, "/file/download", {
        body: { fids: [file.fid] },
        method: "POST",
        userAgent: conf.ua
      });
      const url = ((_d = (_c = resp == null ? void 0 : resp.data) == null ? void 0 : _c[0]) == null ? void 0 : _d.download_url) || "";
      if (!url) throw new Error("get download url failed");
      return {
        header: {
          Cookie: cookieHeader(storage.addition_json),
          Referer: conf.referer,
          "User-Agent": conf.ua
        },
        url,
        content_length: Number(file.size || 0)
      };
    });
  };
  const manageFile = async (client, storage, pathname, body) => {
    await requestQuark(client, storage, pathname, { body, method: "POST" });
    cache$2.clear(storage);
  };
  const memberInfo = async (client, storage) => requestQuark(client, storage, "/member", {
    method: "GET",
    query: {
      fetch_subscribe: "false",
      _ch: "home",
      fetch_identity: "false"
    }
  });
  const uploadHost = (preData) => `https://${preData.bucket}.${String(preData.upload_url || "").slice(7)}/${preData.obj_key}`;
  const upPre = async (client, storage, relPath, parentId, bytes2, mime) => {
    const now = Date.now();
    return requestQuark(client, storage, "/file/upload/pre", {
      body: {
        ccp_hash_update: true,
        dir_name: "",
        file_name: basenameOf(relPath),
        format_type: mime,
        l_created_at: now,
        l_updated_at: now,
        pdir_fid: parentId,
        size: bytes2.length
      },
      method: "POST"
    });
  };
  const upHash = async (client, storage, md5, sha1, taskId) => {
    var _a2;
    const resp = await requestQuark(client, storage, "/file/update/hash", {
      body: {
        md5,
        sha1,
        task_id: taskId
      },
      method: "POST"
    });
    return Boolean((_a2 = resp == null ? void 0 : resp.data) == null ? void 0 : _a2.finish);
  };
  const upPart = async (client, storage, pre, mime, partNumber, bytes2) => {
    var _a2, _b2, _c, _d;
    const data = (pre == null ? void 0 : pre.data) || {};
    const timeStr = httpTime();
    const auth = await requestQuark(client, storage, "/file/upload/auth", {
      body: {
        auth_info: data.auth_info,
        auth_meta: `PUT

${mime}
${timeStr}
x-oss-date:${timeStr}
x-oss-user-agent:${OSS_USER_AGENT}
/${data.bucket}/${data.obj_key}?partNumber=${partNumber}&uploadId=${data.upload_id}`,
        task_id: data.task_id
      },
      method: "POST"
    });
    const target = new URL(uploadHost(data));
    target.searchParams.set("partNumber", String(partNumber));
    target.searchParams.set("uploadId", data.upload_id);
    const resp = await forwardProxy(client, target.toString(), {
      allowErrorStatus: true,
      body: bytesToBase64$2(bytes2),
      contentType: mime,
      headers: {
        Authorization: ((_a2 = auth == null ? void 0 : auth.data) == null ? void 0 : _a2.auth_key) || "",
        "Content-Type": mime,
        Referer: "https://pan.quark.cn/",
        "x-oss-date": timeStr,
        "x-oss-user-agent": OSS_USER_AGENT
      },
      method: "PUT",
      payloadEncoding: "base64",
      responseEncoding: "text",
      timeout: 12e4
    });
    if (Number(resp.status || 0) !== 200) throw new Error(`up status: ${resp.status}, error: ${resp.body || ""}`);
    return ((_b2 = resp.headers) == null ? void 0 : _b2.Etag) || ((_c = resp.headers) == null ? void 0 : _c.ETag) || ((_d = resp.headers) == null ? void 0 : _d.etag) || "";
  };
  const upCommit = async (client, storage, pre, etags) => {
    var _a2;
    const data = (pre == null ? void 0 : pre.data) || {};
    const timeStr = httpTime();
    const body = `<?xml version="1.0" encoding="UTF-8"?>
<CompleteMultipartUpload>
${etags.map((etag, index) => `<Part>
<PartNumber>${index + 1}</PartNumber>
<ETag>${etag}</ETag>
</Part>
`).join("")}</CompleteMultipartUpload>`;
    const contentMd5 = bytesToBase64$2(hexToBytes(md5Hex$1(body)));
    const callbackBase64 = bytesToBase64$2(utf8Bytes$1(JSON.stringify(data.callback || {})));
    const auth = await requestQuark(client, storage, "/file/upload/auth", {
      body: {
        auth_info: data.auth_info,
        auth_meta: `POST
${contentMd5}
application/xml
${timeStr}
x-oss-callback:${callbackBase64}
x-oss-date:${timeStr}
x-oss-user-agent:${OSS_USER_AGENT}
/${data.bucket}/${data.obj_key}?uploadId=${data.upload_id}`,
        task_id: data.task_id
      },
      method: "POST"
    });
    const target = new URL(uploadHost(data));
    target.searchParams.set("uploadId", data.upload_id);
    const resp = await forwardProxy(client, target.toString(), {
      allowErrorStatus: true,
      body,
      contentType: "application/xml",
      headers: {
        Authorization: ((_a2 = auth == null ? void 0 : auth.data) == null ? void 0 : _a2.auth_key) || "",
        "Content-MD5": contentMd5,
        "Content-Type": "application/xml",
        Referer: "https://pan.quark.cn/",
        "x-oss-callback": callbackBase64,
        "x-oss-date": timeStr,
        "x-oss-user-agent": OSS_USER_AGENT
      },
      method: "POST",
      responseEncoding: "text",
      timeout: 12e4
    });
    if (Number(resp.status || 0) !== 200) throw new Error(`up status: ${resp.status}, error: ${resp.body || ""}`);
  };
  const upFinish = async (client, storage, pre) => {
    const data = (pre == null ? void 0 : pre.data) || {};
    await requestQuark(client, storage, "/file/upload/finish", {
      body: {
        obj_key: data.obj_key,
        task_id: data.task_id
      },
      method: "POST"
    });
    cache$2.clear(storage);
  };
  const createQuarkDriver = ({ client }) => ({
    async test(storage) {
      await requestQuark(client, storage, "/config");
      if (storage.addition_json.AdditionVersion !== 2 && storage.addition_json.addition_version !== 2) {
        storage.addition_json.addition_version = 2;
        await persistAddition$1(storage);
      }
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const parent = await resolveFile$1(client, storage, relPath);
      const content = (await listByParent$1(client, storage, parent.fid)).map((file) => fileToObj$2(file, normalizePath(relPath + "/" + file.file_name)));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: storage.driver || "Quark",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const file = await resolveFile$1(client, storage, relPath);
      const obj = fileToObj$2(file, relPath);
      if (!obj.is_dir && !options.skipLink) {
        const link2 = await downloadLink$2(client, storage, file);
        obj.raw_url = link2.url;
        obj.url = link2.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      const file = await resolveFile$1(client, storage, relPath);
      if (!file.file) throw new Error("not file");
      const link2 = await downloadLink$2(client, storage, file);
      const header = { ...link2.header, ...options.proxyHeaders || options.headers || {} };
      return {
        link: {
          url: link2.url,
          header,
          content_length: link2.content_length,
          concurrency: 3,
          part_size: 10 * 1024 * 1024
        }
      };
    },
    async mkdir(storage, relPath) {
      const parent = await resolveFile$1(client, storage, dirnameOf(relPath));
      await manageFile(client, storage, "/file", {
        dir_init_lock: false,
        dir_path: "",
        file_name: basenameOf(relPath),
        pdir_fid: parent.fid
      });
    },
    async move(storage, relPath, dstRelPath) {
      const file = await resolveFile$1(client, storage, relPath);
      const dst = await resolveFile$1(client, storage, dstRelPath);
      await manageFile(client, storage, "/file/move", {
        action_type: 1,
        exclude_fids: [],
        filelist: [file.fid],
        to_pdir_fid: dst.fid
      });
    },
    async remove(storage, relPath) {
      const file = await resolveFile$1(client, storage, relPath);
      await manageFile(client, storage, "/file/delete", {
        action_type: 1,
        exclude_fids: [],
        filelist: [file.fid]
      });
    },
    async rename(storage, relPath, newName) {
      const file = await resolveFile$1(client, storage, relPath);
      await manageFile(client, storage, "/file/rename", {
        fid: file.fid,
        file_name: newName
      });
    },
    async copy() {
      throw new Error("Quark copy is not supported by the OpenList driver");
    },
    async details(storage) {
      var _a2, _b2, _c, _d;
      const resp = await memberInfo(client, storage);
      const total = Number(((_a2 = resp == null ? void 0 : resp.data) == null ? void 0 : _a2.total_capacity) || ((_b2 = resp == null ? void 0 : resp.data) == null ? void 0 : _b2.totalCapacity) || 0);
      const used = Number(((_c = resp == null ? void 0 : resp.data) == null ? void 0 : _c.use_capacity) || ((_d = resp == null ? void 0 : resp.data) == null ? void 0 : _d.useCapacity) || 0);
      return {
        total_space: total,
        used_space: used,
        free_space: Math.max(0, total - used)
      };
    },
    async put(storage, relPath, content, mime, options = {}) {
      var _a2, _b2;
      const parent = await resolveFile$1(client, storage, dirnameOf(relPath));
      const bytes2 = uploadBytes(content, options);
      const uploadMime = mime || "application/octet-stream";
      const pre = await upPre(client, storage, relPath, parent.fid, bytes2, uploadMime);
      if (await upHash(client, storage, md5Hex$1(bytes2), sha1Hex(bytes2), ((_a2 = pre == null ? void 0 : pre.data) == null ? void 0 : _a2.task_id) || "")) {
        cache$2.clear(storage);
        return;
      }
      const partSize = Number(((_b2 = pre == null ? void 0 : pre.metadata) == null ? void 0 : _b2.part_size) || bytes2.length || 1);
      const etags = [];
      for (let offset = 0, partNumber = 1; offset < bytes2.length; offset += partSize, partNumber += 1) {
        const chunk = bytes2.slice(offset, Math.min(offset + partSize, bytes2.length));
        const etag = await upPart(client, storage, pre, uploadMime, partNumber, chunk);
        if (etag === "finish") {
          cache$2.clear(storage);
          return;
        }
        etags.push(etag);
      }
      await upCommit(client, storage, pre, etags);
      await upFinish(client, storage, pre);
    }
  });
  const UserAgent = "Mozilla/5.0 (Linux; U; Android 13; zh-cn; M2004J7AC Build/UKQ1.231108.001) AppleWebKit/533.1 (KHTML, like Gecko) Mobile Safari/533.1";
  const DeviceBrand = "Xiaomi";
  const Platform = "tv";
  const DeviceName = "M2004J7AC";
  const DeviceModel = "M2004J7AC";
  const BuildDevice = "M2004J7AC";
  const BuildProduct = "M2004J7AC";
  const DeviceGpu = "Adreno (TM) 550";
  const ActivityRect = "{}";
  const accessTokenCache = /* @__PURE__ */ new Map();
  const cache$1 = createStorageCache();
  const QR_KEYS = ["query_token", "qrcode_content"];
  const configs = {
    QuarkTV: {
      api: "https://open-api-drive.quark.cn",
      clientID: "d3194e61504e493eb6222857bccfed94",
      signKey: "kw2dvtd7p4t3pjl2d9ed9yc8yej8kw2d",
      appVer: "1.8.2.2",
      channel: "GENERAL",
      codeApi: "http://api.extscreen.com/quarkdrive"
    },
    UCTV: {
      api: "https://open-api-drive.uc.cn",
      clientID: "5acf882d27b74502b7040b0c65519aa7",
      signKey: "l3srvtd7p42l0d0x1u8d7yc8ye9kki4d",
      appVer: "1.7.2.2",
      channel: "UCTVOFFICIALWEB",
      codeApi: "http://api.extscreen.com/ucdrive"
    }
  };
  const confFor = (storage) => configs[storage.driver] || configs.QuarkTV;
  const storageKey = (storage) => `${storage.driver || "QuarkTV"}:${storage.id || storage.mount_path || ""}`;
  const accessTokenFor = (storage) => accessTokenCache.get(storageKey(storage)) || storage.addition_json.access_token || "";
  const checkQuarkTV = (payload) => {
    if (Number((payload == null ? void 0 : payload.status) || 0) >= 400 || Number((payload == null ? void 0 : payload.errno) || 0) !== 0) {
      throw new Error((payload == null ? void 0 : payload.error_info) || (payload == null ? void 0 : payload.message) || "quark tv request failed");
    }
    return payload;
  };
  const ensureDeviceID = async (storage) => {
    if (!storage.addition_json.device_id) {
      storage.addition_json.device_id = sha256Hex(String(Date.now())).slice(0, 32);
      await persistAddition$1(storage);
    }
    return storage.addition_json.device_id;
  };
  const generateReqSign = async (storage, method, pathname, signKey) => {
    const timestamp2 = String(Date.now());
    const deviceID = await ensureDeviceID(storage);
    return {
      req_id: sha256Hex(`${deviceID}${timestamp2}`).slice(0, 32),
      tm: timestamp2,
      token: sha256Hex(`${method.toUpperCase()}&${pathname}&${timestamp2}&${signKey || ""}`)
    };
  };
  const commonQuery = (storage, conf, sign) => ({
    req_id: sign.req_id,
    access_token: accessTokenFor(storage),
    app_ver: conf.appVer,
    device_id: storage.addition_json.device_id || "",
    device_brand: DeviceBrand,
    platform: Platform,
    device_name: DeviceName,
    device_model: DeviceModel,
    build_device: BuildDevice,
    build_product: BuildProduct,
    device_gpu: DeviceGpu,
    activity_rect: ActivityRect,
    channel: conf.channel
  });
  const refreshTokenByTV = async (client, storage, code, isRefresh) => {
    const conf = confFor(storage);
    const sign = await generateReqSign(storage, "POST", "/token", conf.signKey);
    const body = {
      ...commonQuery(storage, conf, sign)
    };
    delete body.access_token;
    if (isRefresh) body.refresh_token = code;
    else body.code = code;
    const resp = await remoteJson(client, `${conf.codeApi}/token`, {
      body,
      headers: { "Content-Type": "application/json" },
      method: "POST"
    });
    if (Number((resp == null ? void 0 : resp.code) || 0) !== 200) throw new Error((resp == null ? void 0 : resp.message) || "refresh token failed");
    const data = (resp == null ? void 0 : resp.data) || {};
    if (!data.refresh_token) throw new Error("refresh token is empty");
    storage.addition_json.refresh_token = data.refresh_token;
    accessTokenCache.set(storageKey(storage), data.access_token || "");
    await persistAddition$1(storage);
  };
  const requestQuarkTV = async (client, storage, pathname, {
    method = "GET",
    query = {},
    retry = true
  } = {}) => {
    const conf = confFor(storage);
    const sign = await generateReqSign(storage, method, pathname, conf.signKey);
    const target = new URL(`${conf.api}${pathname}`);
    const mergedQuery = {
      ...commonQuery(storage, conf, sign),
      ...query
    };
    for (const [key, value] of Object.entries(mergedQuery)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    const resp = await remoteJson(client, target.toString(), {
      allowErrorStatus: true,
      headers: {
        Accept: "application/json, text/plain, */*",
        "User-Agent": UserAgent,
        "x-pan-client-id": conf.clientID,
        "x-pan-tm": sign.tm,
        "x-pan-token": sign.token
      },
      method
    });
    const errInfo = String((resp == null ? void 0 : resp.error_info) || "").toLowerCase();
    const maybeTokenInvalid = Number((resp == null ? void 0 : resp.status) || 0) === -1 && [10001, 11001].includes(Number((resp == null ? void 0 : resp.errno) || 0)) || errInfo && (errInfo.includes("access token") || errInfo.includes("access_token") || errInfo.includes("token"));
    if (maybeTokenInvalid && retry) {
      await refreshTokenByTV(client, storage, storage.addition_json.refresh_token, true);
      return requestQuarkTV(client, storage, pathname, { method, query, retry: false });
    }
    return checkQuarkTV(resp);
  };
  const getLoginCode = async (client, storage) => {
    const conf = confFor(storage);
    const resp = await requestQuarkTV(client, storage, "/oauth/authorize", {
      method: "GET",
      query: {
        auth_type: "code",
        client_id: conf.clientID,
        scope: "netdisk",
        qrcode: "1",
        qr_width: "460",
        qr_height: "460"
      }
    });
    if (resp == null ? void 0 : resp.query_token) {
      storage.addition_json.query_token = resp.query_token;
      storage.addition_json.qrcode_content = resp.qr_data || "";
      await persistAddition$1(storage);
    }
    return (resp == null ? void 0 : resp.qr_data) || "";
  };
  const getCode = async (client, storage) => {
    const conf = confFor(storage);
    const resp = await requestQuarkTV(client, storage, "/oauth/code", {
      method: "GET",
      query: {
        client_id: conf.clientID,
        scope: "netdisk",
        query_token: storage.addition_json.query_token || ""
      }
    });
    return (resp == null ? void 0 : resp.code) || "";
  };
  const isQrPendingError = (error) => /未确认授权|not.*confirm|not.*authorize|pending|waiting/i.test(String((error == null ? void 0 : error.message) || error || ""));
  const startQrLogin = async (client, storage) => {
    const qrData = await getLoginCode(client, storage);
    return {
      message: "QuarkTV QR login pending",
      status: "waiting",
      verify: { qr_data: qrData }
    };
  };
  const pollQrLogin = async (client, storage) => {
    try {
      const code = await getCode(client, storage);
      return code ? { code, message: "QuarkTV QR login confirmed", status: "success" } : { message: "QuarkTV QR login pending", status: "waiting" };
    } catch (error) {
      if (isQrPendingError(error)) {
        return {
          message: error.message || "QuarkTV QR login pending",
          status: "scanned"
        };
      }
      throw error;
    }
  };
  const runTVQrLogin = (client, storage) => runQrLogin({
    addition: storage.addition_json,
    clear: () => clearQrKeys(storage.addition_json, QR_KEYS),
    confirm: async (state) => {
      await refreshTokenByTV(client, storage, state.code, false);
      return ensureLogin$1(client, storage);
    },
    hasSession: (addition) => Boolean(addition.query_token),
    pendingVerify: () => ({ qr_data: storage.addition_json.qrcode_content || "" }),
    poll: () => pollQrLogin(client, storage),
    start: () => startQrLogin(client, storage)
  });
  const ensureLogin$1 = async (client, storage) => {
    await ensureDeviceID(storage);
    if (!storage.addition_json.refresh_token) {
      await runTVQrLogin(client, storage);
    }
    if (!accessTokenFor(storage)) {
      await refreshTokenByTV(client, storage, storage.addition_json.refresh_token, true);
    }
    await requestQuarkTV(client, storage, "/user", {
      method: "GET",
      query: { method: "user_info" }
    });
  };
  const timeFromMs = (value) => parseTime$1(Number(value || 0));
  const fileNameOf = (file) => file.filename || file.file_name || file.name || "";
  const isDir = (file) => Number(file.isdir || 0) === 1 || String(file.file_type) === "0";
  const fileToObj$1 = (file, relPath) => {
    const dir = isDir(file);
    return {
      name: fileNameOf(file) || basenameOf(relPath),
      is_dir: dir,
      size: Number(file.size || 0),
      modified: timeFromMs(file.updated_at),
      created: timeFromMs(file.created_at),
      sign: "",
      thumb: file.thumbnail_url || "",
      type: dir ? 1 : 0,
      hashinfo: "",
      hash_info: {},
      id: file.fid || "",
      file
    };
  };
  const listByParent = async (client, storage, parentId) => {
    const cacheKey2 = parentId || storage.addition_json.root_folder_id || "0";
    return cache$1.list(storage, cacheKey2, async () => {
      const addition = storage.addition_json;
      const result = [];
      const pageSize2 = 100;
      let pageIndex = 0;
      const desc = (addition.order_direction || "desc") === "asc" ? "0" : "1";
      const orderBy2 = (addition.order_by || "updated_at") === "file_name" ? "1" : "3";
      for (; ; ) {
        const resp = await requestQuarkTV(client, storage, "/file", {
          method: "GET",
          query: {
            method: "list",
            parent_fid: parentId || addition.root_folder_id || "0",
            order_by: orderBy2,
            desc,
            category: "",
            source: "",
            ex_source: "",
            list_all: "0",
            page_size: pageSize2,
            page_index: pageIndex
          }
        });
        const data = (resp == null ? void 0 : resp.data) || {};
        result.push(...data.files || []);
        if (result.length >= Number(data.total_count || result.length) || (data.files || []).length < pageSize2) break;
        pageIndex += 1;
      }
      return result;
    });
  };
  const resolveFile = async (client, storage, relPath) => {
    const clean = normalizePath(relPath || "/");
    return cache$1.file(storage, clean, async () => {
      const rootId2 = storage.addition_json.root_folder_id || storage.addition_json.RootFolderID || "0";
      if (clean === "/") {
        return {
          fid: rootId2,
          filename: "root",
          file_type: "0",
          isdir: 1,
          path: "/"
        };
      }
      let parentId = rootId2;
      let current = null;
      for (const part of clean.split("/").filter(Boolean)) {
        const files = await listByParent(client, storage, parentId);
        current = files.find((item) => fileNameOf(item) === part);
        if (!current) throw new Error(`object not found: ${clean}`);
        parentId = current.fid;
      }
      return current;
    });
  };
  const getTranscodingLink = async (client, storage, file) => {
    var _a2;
    const resp = await requestQuarkTV(client, storage, "/file", {
      method: "GET",
      query: {
        method: "streaming",
        group_by: "source",
        fid: file.fid,
        resolution: "low,normal,high,super,2k,4k",
        support: "dolby_vision"
      }
    });
    for (const info of ((_a2 = resp == null ? void 0 : resp.data) == null ? void 0 : _a2.video_info) || []) {
      if (info == null ? void 0 : info.url) {
        return {
          header: {},
          url: info.url,
          content_length: Number(info.size || file.size || 0)
        };
      }
    }
    throw new Error("no link found");
  };
  const getDownloadLink = async (client, storage, file) => {
    var _a2, _b2;
    const resp = await requestQuarkTV(client, storage, "/file", {
      method: "GET",
      query: {
        method: "download",
        group_by: "source",
        fid: file.fid,
        resolution: "low,normal,high,super,2k,4k",
        support: "dolby_vision"
      }
    });
    const url = ((_a2 = resp == null ? void 0 : resp.data) == null ? void 0 : _a2.download_url) || "";
    if (!url) throw new Error("get download url failed");
    return {
      header: {},
      url,
      content_length: Number(((_b2 = resp == null ? void 0 : resp.data) == null ? void 0 : _b2.size) || file.size || 0)
    };
  };
  const downloadLink$1 = async (client, storage, file) => {
    return cache$1.link(storage, `${file.fid || ""}:${storage.addition_json.link_method || "download"}`, async () => {
      if ((storage.addition_json.link_method || "download") === "streaming" && Number(file.category || 0) === 1 && Number(file.size || 0) > 0) {
        return getTranscodingLink(client, storage, file);
      }
      return getDownloadLink(client, storage, file);
    });
  };
  const createQuarkUCTVDriver = ({ client }) => ({
    async test(storage) {
      await ensureLogin$1(client, storage);
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      await ensureLogin$1(client, storage);
      const parent = await resolveFile(client, storage, relPath);
      const content = (await listByParent(client, storage, parent.fid)).map((file) => fileToObj$1(file, normalizePath(relPath + "/" + fileNameOf(file))));
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: false,
        provider: storage.driver || "QuarkTV",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      await ensureLogin$1(client, storage);
      const file = await resolveFile(client, storage, relPath);
      const obj = fileToObj$1(file, relPath);
      if (!obj.is_dir && !options.skipLink) {
        const link2 = await downloadLink$1(client, storage, file);
        obj.raw_url = link2.url;
        obj.url = link2.url;
      }
      return {
        ...obj,
        readme: "",
        header: "",
        related: []
      };
    },
    async read(storage, relPath, options = {}) {
      await ensureLogin$1(client, storage);
      const file = await resolveFile(client, storage, relPath);
      if (isDir(file)) throw new Error("not file");
      const link2 = await downloadLink$1(client, storage, file);
      return {
        link: {
          url: link2.url,
          header: { ...link2.header, ...options.proxyHeaders || options.headers || {} },
          content_length: link2.content_length,
          concurrency: 3,
          part_size: 10 * 1024 * 1024
        }
      };
    },
    async mkdir() {
      throw new Error("QuarkTV mkdir is not implemented by the OpenList driver");
    },
    async move() {
      throw new Error("QuarkTV move is not implemented by the OpenList driver");
    },
    async remove() {
      throw new Error("QuarkTV remove is not implemented by the OpenList driver");
    },
    async rename() {
      throw new Error("QuarkTV rename is not implemented by the OpenList driver");
    },
    async copy() {
      throw new Error("QuarkTV copy is not implemented by the OpenList driver");
    },
    async put() {
      throw new Error("QuarkTV upload is not implemented by the OpenList driver");
    }
  });
  const tagText$1 = (xml, name) => {
    var _a2;
    return ((_a2 = String(xml || "").match(new RegExp(`<${name}>([\\s\\S]*?)<\\/${name}>`, "i"))) == null ? void 0 : _a2[1]) || "";
  };
  const decodeXml = (value) => String(value || "").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&");
  const hex$2 = (bytes2) => Array.from(bytes2, (b) => b.toString(16).padStart(2, "0")).join("");
  const keyFor = (path, dir = false) => {
    const key = normalizePath(path).replace(/^\/+/, "");
    return key && dir ? `${key}/` : key;
  };
  const boolValue = (value, fallback = false) => {
    if (value === void 0 || value === null || value === "") return fallback;
    return value === true || value === "true" || value === 1 || value === "1";
  };
  const regionOf = (addition) => String(addition.region ?? addition.Region ?? "");
  const signExpireSeconds = (addition) => String(Number(addition.sign_url_expire || 4) * 3600);
  const placeholderName = (addition) => addition.placeholder || ".siyuan-cloud";
  const headerValue$2 = (headers = {}, name) => {
    const target = String(name).toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const base64ToBytes$2 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "");
    const bytes2 = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      bytes2.push(a << 2 | b >> 4);
      if (c >= 0) bytes2.push((b & 15) << 4 | c >> 2);
      if (d >= 0) bytes2.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(bytes2);
  };
  const s3Url = (addition, key = "", query = "") => {
    const endpoint = String(addition.endpoint || "").replace(/\/+$/, "");
    const bucket = addition.bucket;
    const forcePathStyle = boolValue(addition.force_path_style || addition.ForcePathStyle, false);
    const path = forcePathStyle ? normalizePath(`/${bucket}/${key}`) : normalizePath(`/${key}`);
    const base = forcePathStyle ? endpoint : endpoint.replace("://", `://${bucket}.`);
    const encodedPath = path.split("/").filter(Boolean).map(encodeRfc3986$1).join("/");
    return `${base}/${encodedPath}${query ? `?${query}` : ""}`;
  };
  const rewriteHost = (url, host) => {
    const target = new URL(url);
    const customHost = String(host || "");
    if (!customHost) return target;
    const split = customHost.split("://");
    if (split.length === 2 && ["http", "https"].includes(split[0])) {
      target.protocol = `${split[0]}:`;
      target.host = split[1];
    } else {
      target.host = customHost;
    }
    return target;
  };
  const removeBucketFromPath = (url, addition) => {
    if (!boolValue(addition.remove_bucket || addition.RemoveBucket, false)) return url.toString();
    const bucketPrefix = `/${addition.bucket}`;
    if (url.pathname === bucketPrefix) url.pathname = "/";
    else if (url.pathname.startsWith(`${bucketPrefix}/`)) url.pathname = url.pathname.slice(bucketPrefix.length) || "/";
    return url.toString();
  };
  const directUploadUrl = (addition, key = "") => {
    const url = rewriteHost(s3Url(addition, key), addition.direct_upload_host || addition.DirectUploadHost || "");
    return url.toString();
  };
  const amzDate = (date) => date.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp = (date) => amzDate(date).slice(0, 8);
  const canonicalQuery$1 = (params) => Object.entries(params).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([name, value]) => `${encodeRfc3986$1(name)}=${encodeRfc3986$1(value)}`).join("&");
  const withQuery = (url, query) => `${url.origin}${url.pathname}${query ? `?${query}` : ""}`;
  const presignPutObject = (addition, key) => {
    const now = /* @__PURE__ */ new Date();
    const amz = amzDate(now);
    const date = dateStamp(now);
    const region = regionOf(addition);
    const scope = `${date}/${region}/s3/aws4_request`;
    const url = new URL(directUploadUrl(addition, key));
    const params = {
      "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
      "X-Amz-Credential": `${addition.access_key_id}/${scope}`,
      "X-Amz-Date": amz,
      "X-Amz-Expires": signExpireSeconds(addition),
      "X-Amz-SignedHeaders": "host"
    };
    if (addition.session_token) params["X-Amz-Security-Token"] = addition.session_token;
    const query = canonicalQuery$1(params);
    const canonicalRequest = [
      "PUT",
      url.pathname || "/",
      query,
      `host:${url.host}
`,
      "host",
      "UNSIGNED-PAYLOAD"
    ].join("\n");
    const stringToSign = [
      "AWS4-HMAC-SHA256",
      amz,
      scope,
      sha256Hex(canonicalRequest)
    ].join("\n");
    const kDate = hmacSha256(`AWS4${addition.secret_access_key}`, date);
    const kRegion = hmacSha256(kDate, region);
    const kService = hmacSha256(kRegion, "s3");
    const kSigning = hmacSha256(kService, "aws4_request");
    return withQuery(url, `${query}&X-Amz-Signature=${hex$2(hmacSha256(kSigning, stringToSign))}`);
  };
  const presignGetObject = (addition, key, { customHost = "", disposition = "" } = {}) => {
    const now = /* @__PURE__ */ new Date();
    const amz = amzDate(now);
    const date = dateStamp(now);
    const region = regionOf(addition);
    const scope = `${date}/${region}/s3/aws4_request`;
    const url = rewriteHost(s3Url(addition, key), customHost);
    const params = {
      "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
      "X-Amz-Credential": `${addition.access_key_id}/${scope}`,
      "X-Amz-Date": amz,
      "X-Amz-Expires": signExpireSeconds(addition),
      "X-Amz-SignedHeaders": "host"
    };
    if (addition.session_token) params["X-Amz-Security-Token"] = addition.session_token;
    if (disposition) params["response-content-disposition"] = disposition;
    const query = canonicalQuery$1(params);
    const canonicalRequest = [
      "GET",
      url.pathname || "/",
      query,
      `host:${url.host}
`,
      "host",
      "UNSIGNED-PAYLOAD"
    ].join("\n");
    const stringToSign = [
      "AWS4-HMAC-SHA256",
      amz,
      scope,
      sha256Hex(canonicalRequest)
    ].join("\n");
    const kDate = hmacSha256(`AWS4${addition.secret_access_key}`, date);
    const kRegion = hmacSha256(kDate, region);
    const kService = hmacSha256(kRegion, "s3");
    const kSigning = hmacSha256(kService, "aws4_request");
    const signed = new URL(withQuery(url, `${query}&X-Amz-Signature=${hex$2(hmacSha256(kSigning, stringToSign))}`));
    return removeBucketFromPath(signed, addition);
  };
  const contentDisposition = (addition, fileName) => {
    const encoded = encodeRfc3986$1(fileName || "");
    if (boolValue(addition.add_filename_to_disposition || addition.AddFilenameToDisposition, false)) {
      return `attachment; filename="${encoded}"; filename*=UTF-8''${encoded}`;
    }
    return `attachment; filename*=UTF-8''${encoded}`;
  };
  const signedRequest = (client, addition, method, key, {
    body = "",
    contentType = "application/octet-stream",
    headers: extraHeaders = {},
    payloadEncoding,
    query = "",
    signingBody,
    responseEncoding = "text",
    allowErrorStatus = false
  } = {}) => {
    const url = s3Url(addition, key, query);
    const headers = signAwsV4({
      accessKeyId: addition.access_key_id,
      body: signingBody === void 0 ? body : signingBody,
      headers: {
        ...contentType ? { "content-type": contentType } : {},
        ...extraHeaders
      },
      method,
      region: regionOf(addition),
      secretAccessKey: addition.secret_access_key,
      sessionToken: addition.session_token || "",
      url
    });
    return forwardProxy(client, url, {
      allowErrorStatus,
      body,
      contentType,
      headers,
      method,
      payloadEncoding,
      responseEncoding,
      timeout: Number(addition.timeout || 6e4)
    });
  };
  const signedGetLink = (addition, key, fileName) => {
    const customHost = addition.custom_host || addition.CustomHost || "";
    if (customHost) {
      const unsigned = rewriteHost(s3Url(addition, key), customHost);
      if (!boolValue(addition.enable_custom_host_presign || addition.EnableCustomHostPresign, false))
        return { url: removeBucketFromPath(unsigned, addition), header: {} };
      return { url: presignGetObject(addition, key, { customHost }), header: {} };
    }
    return {
      url: presignGetObject(addition, key, { disposition: contentDisposition(addition, fileName) }),
      header: {}
    };
  };
  const signedProxyGetLink = (addition, key, extraHeaders = {}) => {
    const url = s3Url(addition, key);
    return {
      url,
      header: signAwsV4({
        accessKeyId: addition.access_key_id,
        body: "",
        headers: extraHeaders,
        method: "GET",
        region: regionOf(addition),
        secretAccessKey: addition.secret_access_key,
        sessionToken: addition.session_token || "",
        url
      }),
      method: "GET"
    };
  };
  const listQuery = ({ continuationToken = "", marker = "", prefix, startAfter = "", version }) => {
    const params = new URLSearchParams();
    if (version === "v2") params.set("list-type", "2");
    params.set("prefix", prefix);
    params.set("delimiter", "/");
    if (version === "v2" && continuationToken) params.set("continuation-token", continuationToken);
    if (version === "v2" && startAfter) params.set("start-after", startAfter);
    if (version !== "v2" && marker) params.set("marker", marker);
    return params.toString();
  };
  const listState = (xml) => ({
    contents: String(xml || "").match(/<Contents>[\s\S]*?<\/Contents>/gi) || [],
    isTruncated: tagText$1(xml, "IsTruncated").toLowerCase() === "true",
    nextContinuationToken: decodeXml(tagText$1(xml, "NextContinuationToken")),
    nextMarker: decodeXml(tagText$1(xml, "NextMarker"))
  });
  const listKeys = async (client, addition, prefix, { maxKeys = 0 } = {}) => {
    const version = addition.list_object_version === "v2" ? "v2" : "v1";
    const keys = [];
    let continuationToken = "";
    let marker = "";
    let startAfter = "";
    for (; ; ) {
      const params = new URLSearchParams();
      if (version === "v2") params.set("list-type", "2");
      params.set("prefix", prefix);
      if (version === "v2" && continuationToken) params.set("continuation-token", continuationToken);
      if (version === "v2" && startAfter) params.set("start-after", startAfter);
      if (version !== "v2" && marker) params.set("marker", marker);
      if (maxKeys) params.set("max-keys", String(maxKeys));
      const data = await signedRequest(client, addition, "GET", "", {
        contentType: "",
        query: params.toString()
      });
      const state = listState(data.body);
      keys.push(...state.contents.map((chunk) => decodeXml(tagText$1(chunk, "Key"))).filter(Boolean));
      if (maxKeys && keys.length >= maxKeys) return keys.slice(0, maxKeys);
      if (!state.isTruncated) break;
      if (version === "v2") {
        continuationToken = state.nextContinuationToken;
        if (continuationToken) continue;
        const last = state.contents.at(-1);
        if (!last) break;
        startAfter = decodeXml(tagText$1(last, "Key"));
        if (!startAfter) break;
        continue;
      }
      marker = state.nextMarker;
      if (!marker) {
        const last = state.contents.at(-1);
        marker = last ? decodeXml(tagText$1(last, "Key")) : "";
      }
      if (!marker) break;
    }
    return keys;
  };
  const parseListObjects = (xml, relPath, addition) => {
    const placeholder = placeholderName(addition);
    const dirs = (String(xml || "").match(/<CommonPrefixes>[\s\S]*?<\/CommonPrefixes>/gi) || []).map((chunk) => decodeXml(tagText$1(chunk, "Prefix")).replace(/\/+$/, "")).map((prefix) => basename(prefix)).filter(Boolean).map((name) => ({
      name,
      path: normalizePath(relPath + "/" + name),
      is_dir: true,
      size: 0,
      modified: (/* @__PURE__ */ new Date()).toISOString(),
      created: (/* @__PURE__ */ new Date()).toISOString()
    }));
    const files = (String(xml || "").match(/<Contents>[\s\S]*?<\/Contents>/gi) || []).map((chunk) => {
      const key = decodeXml(tagText$1(chunk, "Key"));
      if (key.endsWith("/")) return null;
      const name = basename(key);
      return {
        name,
        path: normalizePath(relPath + "/" + name),
        is_dir: false,
        size: Number(tagText$1(chunk, "Size") || 0),
        modified: new Date(tagText$1(chunk, "LastModified") || Date.now()).toISOString(),
        created: new Date(tagText$1(chunk, "LastModified") || Date.now()).toISOString()
      };
    }).filter((item) => (item == null ? void 0 : item.name) && item.name !== placeholder && item.name !== addition.placeholder);
    return [...dirs, ...files];
  };
  const copyFile = async (client, addition, srcRelPath, dstKey) => {
    const src = `${addition.bucket}/${keyFor(srcRelPath)}`;
    await signedRequest(client, addition, "PUT", dstKey, {
      contentType: "",
      headers: { "x-amz-copy-source": `/${encodeURIComponent(src).replace(/%2F/g, "/")}` }
    });
  };
  const copyPath$1 = async (client, addition, relPath, dstRelPath, dstName = basename(relPath)) => {
    const srcPrefix = keyFor(relPath, true);
    const dstPath = normalizePath(dstRelPath + "/" + dstName);
    const dstBase = keyFor(dstPath, true);
    const keys = await listKeys(client, addition, srcPrefix, { maxKeys: 1 });
    if (!keys.length) {
      await copyFile(client, addition, relPath, keyFor(dstPath));
      return;
    }
    const allKeys = await listKeys(client, addition, srcPrefix);
    for (const key of allKeys) {
      await copyFile(client, addition, key, `${dstBase}${key.slice(srcPrefix.length)}`);
    }
  };
  const removePath = async (client, addition, relPath) => {
    const prefix = keyFor(relPath, true);
    const keys = await listKeys(client, addition, prefix, { maxKeys: 1 });
    if (!keys.length) {
      await signedRequest(client, addition, "DELETE", keyFor(relPath), { contentType: "" });
      return;
    }
    for (const key of await listKeys(client, addition, prefix)) {
      await signedRequest(client, addition, "DELETE", key, { contentType: "" });
    }
    await signedRequest(client, addition, "DELETE", keyFor(normalizePath(relPath + "/" + placeholderName(addition))), { contentType: "" });
    if (addition.placeholder) {
      await signedRequest(client, addition, "DELETE", keyFor(normalizePath(relPath + "/" + addition.placeholder)), { contentType: "" });
    }
  };
  const createS3Driver = ({ client }) => ({
    async list(storage, relPath, req) {
      const addition = storage.addition_json;
      const prefix = keyFor(relPath, true);
      const version = addition.list_object_version === "v2" ? "v2" : "v1";
      const content = [];
      let continuationToken = "";
      let marker = "";
      let startAfter = "";
      for (; ; ) {
        const data = await signedRequest(client, addition, "GET", "", {
          contentType: "",
          query: listQuery({ continuationToken, marker, prefix, startAfter, version })
        });
        content.push(...parseListObjects(data.body, relPath, addition));
        const state = listState(data.body);
        if (!state.isTruncated) break;
        if (version === "v2") {
          continuationToken = state.nextContinuationToken;
          if (continuationToken) continue;
          const last = state.contents.at(-1);
          if (!last) break;
          startAfter = decodeXml(tagText$1(last, "Key"));
          if (!startAfter) break;
          continue;
        }
        marker = state.nextMarker;
        if (!marker) {
          const last = state.contents.at(-1);
          marker = last ? decodeXml(tagText$1(last, "Key")) : "";
        }
        if (!marker) break;
      }
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "S3",
        direct_upload_tools: addition.enable_direct_upload ? ["HttpDirect"] : []
      };
    },
    async get(storage, relPath) {
      var _a2, _b2, _c, _d;
      const addition = storage.addition_json;
      const data = await signedRequest(client, addition, "HEAD", keyFor(relPath), {
        allowErrorStatus: true,
        contentType: ""
      });
      if (Number(data.status || 0) === 404) {
        const prefix = keyFor(relPath, true);
        const version = addition.list_object_version === "v2" ? "v2" : "v1";
        const listed = await signedRequest(client, addition, "GET", "", {
          contentType: "",
          query: `${listQuery({ prefix, version })}&max-keys=1`
        });
        if (parseListObjects(listed.body, relPath, addition).length || listState(listed.body).contents.length) {
          return {
            name: basename(relPath),
            path: relPath,
            is_dir: true,
            size: 0,
            modified: (/* @__PURE__ */ new Date()).toISOString(),
            created: (/* @__PURE__ */ new Date()).toISOString(),
            raw_url: "",
            provider: "S3",
            related: []
          };
        }
      }
      if (Number(data.status || 0) >= 400) throw new Error(`HTTP ${data.status}: object not found`);
      return {
        name: basename(relPath),
        path: relPath,
        is_dir: false,
        size: Number(((_a2 = data.headers) == null ? void 0 : _a2["Content-Length"]) || ((_b2 = data.headers) == null ? void 0 : _b2["content-length"]) || 0),
        modified: new Date(((_c = data.headers) == null ? void 0 : _c["Last-Modified"]) || ((_d = data.headers) == null ? void 0 : _d["last-modified"]) || Date.now()).toISOString(),
        created: (/* @__PURE__ */ new Date()).toISOString(),
        raw_url: `/plugin/private/siyuan-cloud/d${normalizePath(storage.mount_path + "/" + relPath)}`,
        provider: "S3",
        related: []
      };
    },
    async link(storage, relPath) {
      const addition = storage.addition_json;
      const link2 = signedGetLink(addition, keyFor(relPath), basename(relPath));
      return {
        link: {
          url: link2.url,
          header: link2.header,
          method: "GET"
        }
      };
    },
    async read(storage, relPath, options = {}) {
      const range = headerValue$2(options.requestHeaders, "Range");
      return { link: signedProxyGetLink(storage.addition_json, keyFor(relPath), range ? { Range: range } : {}) };
    },
    async mkdir(storage, relPath) {
      const addition = storage.addition_json;
      const name = placeholderName(addition);
      await signedRequest(client, addition, "PUT", keyFor(normalizePath(relPath + "/" + name)), { body: "" });
    },
    async move(storage, relPath, dstRelPath) {
      const addition = storage.addition_json;
      await copyPath$1(client, addition, relPath, dstRelPath);
      await removePath(client, addition, relPath);
    },
    async copy(storage, relPath, dstRelPath) {
      const addition = storage.addition_json;
      await copyPath$1(client, addition, relPath, dstRelPath);
    },
    async remove(storage, relPath) {
      await removePath(client, storage.addition_json, relPath);
    },
    async rename(storage, relPath, newName) {
      const addition = storage.addition_json;
      await copyPath$1(client, addition, relPath, dirname(relPath), newName);
      await removePath(client, addition, relPath);
    },
    async put(storage, relPath, content, mime, options = {}) {
      const signingBody = options.bodyEncoding === "base64" ? base64ToBytes$2(content || "") : content || "";
      await signedRequest(client, storage.addition_json, "PUT", keyFor(relPath), {
        body: content || "",
        contentType: mime || "application/octet-stream",
        payloadEncoding: options.bodyEncoding === "base64" ? "base64" : void 0,
        signingBody
      });
    },
    async getDirectUploadInfo(storage, relPath) {
      const addition = storage.addition_json;
      if (!addition.enable_direct_upload) throw new Error("direct upload is not implemented for this storage");
      return {
        upload_url: presignPutObject(addition, keyFor(relPath)),
        method: "PUT"
      };
    }
  });
  const joinWorkspacePath = (root, relPath) => {
    const cleanRoot = normalizePath(root || "/@workspace").replace(/^\/@workspace\/?/, "");
    const cleanRel = normalizePath(relPath || "/").replace(/^\/+/, "");
    return normalizePath(`/@workspace/${[cleanRoot, cleanRel].filter(Boolean).join("/")}`);
  };
  const createSiYuanWorkspaceDriver = ({ workspaceGet, workspaceList, workspacePublicUrl, workspaceReadText }) => {
    const objForMount = (storage, relPath, obj = {}) => {
      var _a2;
      const isDir2 = !!obj.is_dir;
      const path = normalizePath(`${storage.mount_path}/${normalizePath(relPath).replace(/^\/+/, "")}`);
      const workspacePath = joinWorkspacePath((_a2 = storage.addition_json) == null ? void 0 : _a2.root_folder_path, relPath);
      return {
        ...obj,
        path,
        raw_url: isDir2 ? "" : workspacePublicUrl(workspacePath) || `/plugin/private/siyuan-cloud/d${path}`,
        provider: "siyuan-workspace"
      };
    };
    return {
      async list(storage, relPath, req = {}) {
        var _a2;
        const workspacePath = joinWorkspacePath((_a2 = storage.addition_json) == null ? void 0 : _a2.root_folder_path, relPath);
        const result = await workspaceList(workspacePath, req);
        if (result.error) throw new Error(result.error.message || "workspace list failed");
        return {
          ...result.data,
          content: (result.data.content || []).map((item) => objForMount(storage, normalizePath(`${relPath}/${item.name}`), item)),
          provider: "siyuan-workspace"
        };
      },
      async get(storage, relPath) {
        var _a2;
        const workspacePath = joinWorkspacePath((_a2 = storage.addition_json) == null ? void 0 : _a2.root_folder_path, relPath);
        const result = await workspaceGet(workspacePath);
        if (result.error) throw new Error(result.error.message || "workspace get failed");
        return objForMount(storage, relPath, result.data);
      },
      async read(storage, relPath) {
        var _a2;
        const workspacePath = joinWorkspacePath((_a2 = storage.addition_json) == null ? void 0 : _a2.root_folder_path, relPath);
        const publicUrl = workspacePublicUrl(workspacePath);
        if (publicUrl) return { redirect: publicUrl };
        const result = await workspaceReadText(workspacePath);
        if (!result.ok) throw new Error(`workspace read failed: ${result.status}`);
        return {
          body: result.text,
          bodyEncoding: "text",
          contentType: result.contentType,
          status: result.status
        };
      },
      async test() {
        return { status: "work" };
      }
    };
  };
  const propfindBody = `<d:propfind xmlns:d='DAV:'>
  <d:prop>
    <d:displayname/>
    <d:resourcetype/>
    <d:getcontentlength/>
    <d:getcontenttype/>
    <d:getetag/>
    <d:getlastmodified/>
  </d:prop>
</d:propfind>`;
  const fixSlash = (path) => String(path || "/").endsWith("/") ? String(path || "/") : `${path}/`;
  const join = (path0, path1) => `${String(path0 || "").replace(/\/+$/, "")}/${String(path1 || "").replace(/^\/+/, "")}`;
  const rootPath = (storage) => storage.addition_json.root_folder_path || "/";
  const fullPath = (storage, path) => normalizePath(join(rootPath(storage), path));
  const requestUrl = (storage, path) => joinUrl(storage.addition_json.address, path);
  const requestHeaders = (addition, headers = {}) => ({
    Authorization: basicAuth(addition.username, addition.password),
    ...headers
  });
  const request = (client, storage, path, options = {}) => forwardProxy(client, requestUrl(storage, path), {
    ...options,
    headers: requestHeaders(storage.addition_json, options.headers || {}),
    timeout: Number(storage.addition_json.timeout || 3e4)
  });
  const propfind = (client, storage, path, self) => request(client, storage, path, {
    body: propfindBody,
    contentType: "application/xml;charset=UTF-8",
    headers: {
      Accept: "application/xml,text/xml",
      "Accept-Charset": "utf-8",
      "Accept-Encoding": "",
      Depth: self ? "0" : "1"
    },
    method: "PROPFIND"
  });
  const stripTags = (value) => String(value || "").replace(/<[^>]+>/g, "").trim();
  const tagText = (xml, name) => {
    var _a2;
    return stripTags(((_a2 = xml.match(new RegExp(`<[^:>]*:?${name}[^>]*>[\\s\\S]*?<\\/[^:>]*:?${name}>`, "i"))) == null ? void 0 : _a2[0]) || "");
  };
  const hrefText = (xml) => {
    var _a2;
    return stripTags(((_a2 = xml.match(/<[^:>]*:?href[^>]*>[\s\S]*?<\/[^:>]*:?href>/i)) == null ? void 0 : _a2[0]) || "");
  };
  const isCollection = (xml) => /<[^:>]*:?collection\b/i.test(xml);
  const pathUnescape = (value) => {
    const raw = String(value || "");
    try {
      return decodeURIComponent(new URL(raw, "http://webdav.local").pathname);
    } catch (_) {
      try {
        return decodeURIComponent(raw.split(/[?#]/)[0]);
      } catch (_2) {
        return raw.split(/[?#]/)[0];
      }
    }
  };
  const parseModified = (value, fallback = (/* @__PURE__ */ new Date()).toISOString()) => {
    const date = value ? new Date(value) : new Date(fallback);
    return Number.isNaN(date.getTime()) ? fallback : date.toISOString();
  };
  const responses = (xml) => String(xml || "").match(/<[^:>]*:?response\b[\s\S]*?<\/[^:>]*:?response>/gi) || [];
  const readDir = async (client, storage, path) => {
    const dirPath = fixSlash(fullPath(storage, path));
    const data = await propfind(client, storage, dirPath, false);
    let skipSelf = true;
    return responses(data.body).flatMap((chunk) => {
      const collection = isCollection(chunk);
      if (skipSelf) {
        skipSelf = false;
        if (collection) return [];
        throw new Error("405");
      }
      const hrefName = basename(pathUnescape(hrefText(chunk)).replace(/\/+$/, ""));
      const name = hrefName || tagText(chunk, "displayname");
      if (!name) return [];
      return [{
        name,
        path: normalizePath(join(path, name)),
        is_dir: collection,
        size: collection ? 0 : Number(tagText(chunk, "getcontentlength") || 0),
        modified: parseModified(tagText(chunk, "getlastmodified"))
      }];
    });
  };
  const stat = async (client, storage, path) => {
    const data = await propfind(client, storage, fullPath(storage, path), true);
    const chunk = responses(data.body)[0];
    if (!chunk) throw new Error("object not found");
    const collection = isCollection(chunk);
    return {
      name: tagText(chunk, "displayname") || basename(path),
      path,
      is_dir: collection,
      size: collection ? 0 : Number(tagText(chunk, "getcontentlength") || 0),
      modified: collection ? (/* @__PURE__ */ new Date(0)).toISOString() : parseModified(tagText(chunk, "getlastmodified"), (/* @__PURE__ */ new Date(0)).toISOString())
    };
  };
  const link = (storage, path) => ({
    url: requestUrl(storage, fullPath(storage, path)),
    header: requestHeaders(storage.addition_json)
  });
  const mkdirAll = async (client, storage, path) => {
    await request(client, storage, fixSlash(fullPath(storage, path)), { method: "MKCOL" });
  };
  const copyMove = (client, storage, method, oldPath, newPath) => request(client, storage, fullPath(storage, oldPath), {
    headers: {
      Destination: requestUrl(storage, fullPath(storage, newPath)),
      Overwrite: "T"
    },
    method
  });
  const renamePath = (client, storage, oldPath, newPath) => copyMove(client, storage, "MOVE", oldPath, newPath);
  const copyPath = (client, storage, oldPath, newPath) => copyMove(client, storage, "COPY", oldPath, newPath);
  const removeAll = async (client, storage, path) => {
    await request(client, storage, fullPath(storage, path), { method: "DELETE" });
  };
  const writeStream = (client, storage, path, content, mime, options = {}) => {
    const body = content || "";
    return request(client, storage, fullPath(storage, path), {
      body,
      contentType: mime || "application/octet-stream",
      headers: {
        "Content-Length": String(options.size || (options.bodyEncoding === "base64" ? 0 : String(body).length)),
        "Content-Type": mime || "application/octet-stream"
      },
      method: "PUT",
      payloadEncoding: options.bodyEncoding === "base64" ? "base64" : void 0
    });
  };
  const createWebDavDriver = ({ client }) => ({
    async list(storage, relPath) {
      const content = await readDir(client, storage, relPath);
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "WebDav",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath) {
      const info = await stat(client, storage, relPath);
      return {
        ...info,
        provider: "WebDav",
        related: []
      };
    },
    async read(storage, relPath) {
      return { link: link(storage, relPath) };
    },
    async mkdir(storage, relPath) {
      await mkdirAll(client, storage, relPath);
    },
    async move(storage, relPath, dstRelPath) {
      await renamePath(client, storage, relPath, normalizePath(join(dstRelPath, basename(relPath))));
    },
    async copy(storage, relPath, dstRelPath) {
      await copyPath(client, storage, relPath, normalizePath(join(dstRelPath, basename(relPath))));
    },
    async remove(storage, relPath) {
      await removeAll(client, storage, relPath);
    },
    async rename(storage, relPath, newName) {
      await renamePath(client, storage, relPath, normalizePath(join(dirname(relPath), newName)));
    },
    async put(storage, relPath, content, mime, options = {}) {
      await writeStream(client, storage, relPath, content, mime, options);
    }
  });
  const ENDPOINT_BUSINESS = "https://365.kdocs.cn";
  const ENDPOINT_PERSONAL = "https://drive.wps.cn";
  const LOGIN_ENDPOINT = "https://account.kdocs.cn/api/v3/islogin";
  const DEFAULT_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36";
  const cache = createStorageCache();
  const modeOf = (addition = {}) => addition.mode || addition.Mode || "Personal";
  const cookieOf = (addition = {}) => addition.cookie || addition.Cookie || "";
  const customUaOf = (addition = {}) => addition.custom_ua || addition.CustomUA || "";
  const getUA = (addition = {}) => customUaOf(addition) || DEFAULT_UA;
  const isPersonal = (storage) => {
    const login2 = storage.__wpsLogin;
    if (login2 && login2.is_company_account !== void 0) return !login2.is_company_account;
    return modeOf(storage.addition_json) === "Personal";
  };
  const driveHost = (storage) => isPersonal(storage) ? ENDPOINT_PERSONAL : ENDPOINT_BUSINESS;
  const drivePrefix = (storage) => isPersonal(storage) ? "" : "/3rd/drive";
  const driveUrl = (storage, path) => `${driveHost(storage)}${drivePrefix(storage)}${path}`;
  const headersFor = (storage, json = false) => {
    const headers = {
      Accept: "application/json",
      Cookie: cookieOf(storage.addition_json),
      "User-Agent": getUA(storage.addition_json)
    };
    if (json) {
      headers["Content-Type"] = "application/json";
      headers.Origin = driveHost(storage);
    }
    return headers;
  };
  const checkAPI = (payload, meta) => {
    if ((payload == null ? void 0 : payload.result) && payload.result !== "ok") {
      throw new Error(`${payload.result}: ${payload.msg || "unknown error"}`);
    }
    if (Number((meta == null ? void 0 : meta.status) || 0) >= 400) {
      throw new Error((payload == null ? void 0 : payload.msg) || `http error: ${meta.status}`);
    }
    return payload;
  };
  const requestWps = async (client, storage, url, {
    body,
    method = "GET",
    query = {},
    json = false,
    retryDuplicated = false
  } = {}) => {
    const target = new URL(url);
    for (const [key, value] of Object.entries(query)) {
      if (value !== void 0 && value !== null && value !== "") target.searchParams.set(key, String(value));
    }
    for (; ; ) {
      const { json: payload, meta } = await remoteJsonWithMeta(client, target.toString(), {
        allowErrorStatus: true,
        body,
        headers: headersFor(storage, json),
        method
      });
      if (retryDuplicated && Number((meta == null ? void 0 : meta.status) || 0) === 403 && (payload == null ? void 0 : payload.result) === "fileTaskDuplicated") {
        await new Promise((resolve) => setTimeout(resolve, 500));
        continue;
      }
      return checkAPI(payload, meta);
    }
  };
  const joinPath$1 = (basePath, name) => {
    if (!basePath || basePath === "/") return `/${name}`;
    return `${String(basePath).replace(/\/+$/, "")}/${name}`;
  };
  const groupToObj = (group, basePath = "/") => ({
    name: group.name || "",
    is_dir: true,
    size: 0,
    modified: (/* @__PURE__ */ new Date()).toISOString(),
    created: (/* @__PURE__ */ new Date()).toISOString(),
    id: String(group.group_id || group.id || ""),
    path: joinPath$1(basePath, group.name || ""),
    provider: "WPS",
    wps: {
      kind: "group",
      group_id: Number(group.group_id || group.id || 0)
    }
  });
  const canDownload = (file, personal) => {
    var _a2;
    if (!file || file.ftype === "folder") return false;
    if (Number(((_a2 = file.file_perms_acl) == null ? void 0 : _a2.download) || 0) !== 0) return true;
    return personal;
  };
  const fileToObj = (file, basePath = "/", personal = true) => {
    const isDir2 = file.ftype === "folder";
    return {
      name: file.fname || "",
      is_dir: isDir2,
      size: Number(file.fsize || 0),
      modified: parseTime$1(Number(file.mtime || 0)),
      created: parseTime$1(Number(file.ctime || 0)),
      id: String(file.id || ""),
      path: joinPath$1(basePath, file.fname || ""),
      provider: "WPS",
      wps: {
        kind: isDir2 ? "folder" : "file",
        file_id: Number(file.id || 0),
        group_id: Number(file.groupid || 0),
        has_file: true,
        can_download: canDownload(file, personal)
      }
    };
  };
  const rootNode = () => ({
    name: "root",
    is_dir: true,
    size: 0,
    modified: (/* @__PURE__ */ new Date()).toISOString(),
    created: (/* @__PURE__ */ new Date()).toISOString(),
    id: "root",
    path: "/",
    provider: "WPS",
    wps: { kind: "root" }
  });
  const ensureLogin = async (client, storage) => {
    if (storage.__wpsLogin) return storage.__wpsLogin;
    if (!cookieOf(storage.addition_json)) throw new Error("cookie is empty");
    const { json, meta } = await remoteJsonWithMeta(client, LOGIN_ENDPOINT, {
      allowErrorStatus: true,
      headers: headersFor(storage),
      method: "GET"
    });
    if (Number((meta == null ? void 0 : meta.status) || 0) >= 400) throw new Error(`failed to check login status, status code: ${meta.status}`);
    if (modeOf(storage.addition_json) === "Business" && !Number((json == null ? void 0 : json.companyid) || (json == null ? void 0 : json.current_companyid) || 0)) {
      throw new Error("wps company id is empty, please check business account login");
    }
    storage.__wpsLogin = json || {};
    return storage.__wpsLogin;
  };
  const getGroups = async (client, storage) => {
    await ensureLogin(client, storage);
    return cache.list(storage, "groups", async () => {
      var _a2, _b2;
      if (modeOf(storage.addition_json) === "Personal") {
        const resp2 = await requestWps(client, storage, driveUrl(storage, "/api/v3/groups"));
        return (resp2.groups || []).map((group) => ({ group_id: group.id, name: group.name }));
      }
      const companyID = Number(((_a2 = storage.__wpsLogin) == null ? void 0 : _a2.companyid) || ((_b2 = storage.__wpsLogin) == null ? void 0 : _b2.current_companyid) || 0);
      const resp = await requestWps(client, storage, `${ENDPOINT_BUSINESS}/3rd/plus/groups/v1/companies/${companyID}/users/self/groups/private`);
      return resp.groups || [];
    });
  };
  const getFiles = async (client, storage, groupID, parentID = 0) => {
    await ensureLogin(client, storage);
    return cache.list(storage, `files:${groupID}:${parentID}`, async () => {
      const files = [];
      let offset = 0;
      for (let index = 0; index < 50; index += 1) {
        const resp = await requestWps(client, storage, driveUrl(storage, `/api/v5/groups/${groupID}/files`), {
          query: {
            parentid: parentID,
            offset
          }
        });
        files.push(...resp.files || []);
        if (Number(resp.next_offset) === -1) break;
        offset = Number(resp.next_offset || 0);
      }
      return files;
    });
  };
  const childrenForNode = async (client, storage, node, basePath = "/") => {
    var _a2, _b2, _c, _d, _e;
    if (!node || ((_a2 = node.wps) == null ? void 0 : _a2.kind) === "root") {
      return (await getGroups(client, storage)).map((group) => groupToObj(group, basePath));
    }
    if (((_b2 = node.wps) == null ? void 0 : _b2.kind) !== "group" && ((_c = node.wps) == null ? void 0 : _c.kind) !== "folder") return [];
    const parentID = ((_d = node.wps) == null ? void 0 : _d.kind) === "folder" && ((_e = node.wps) == null ? void 0 : _e.has_file) ? Number(node.wps.file_id || 0) : 0;
    return (await getFiles(client, storage, Number(node.wps.group_id || 0), parentID)).map((file) => fileToObj(file, basePath, isPersonal(storage)));
  };
  const resolveRoot = async (client, storage) => {
    const rootPath2 = storage.addition_json.root_folder_path || storage.addition_json.RootFolderPath || "/";
    if (rootPath2 === "/") return rootNode();
    let current = rootNode();
    let basePath = "/";
    for (const name of String(rootPath2).split("/").filter(Boolean)) {
      const children = await childrenForNode(client, storage, current, basePath);
      current = children.find((item) => item.is_dir && item.name === name);
      if (!current) throw new Error(`root path ${JSON.stringify(rootPath2)} not found`);
      basePath = current.path;
    }
    return { ...current, name: "root", path: "/" };
  };
  const resolveNode = async (client, storage, relPath) => {
    const cleanParts = String(relPath || "/").split("/").filter(Boolean);
    let current = await resolveRoot(client, storage);
    let basePath = "/";
    if (!cleanParts.length) return current;
    for (const name of cleanParts) {
      const children = await childrenForNode(client, storage, current, basePath);
      current = children.find((item) => item.name === name);
      if (!current) throw new Error(`object not found: ${relPath}`);
      basePath = current.path;
    }
    return current;
  };
  const downloadLink = async (client, storage, node) => {
    if (!(node == null ? void 0 : node.wps) || node.wps.kind !== "file" || !node.wps.has_file) throw new Error("not support");
    if (!node.wps.can_download) throw new Error("can not download");
    return cache.link(storage, `download:${node.wps.group_id}:${node.wps.file_id}`, async () => {
      const resp = await requestWps(
        client,
        storage,
        `${driveHost(storage)}${drivePrefix(storage)}/api/v5/groups/${node.wps.group_id}/files/${node.wps.file_id}/download`,
        { query: { support_checksums: "sha1" } }
      );
      if (!resp.url) throw new Error("empty download url");
      return {
        url: resp.url,
        header: {
          Referer: driveHost(storage),
          "User-Agent": getUA(storage.addition_json)
        },
        content_length: Number(node.size || 0)
      };
    });
  };
  const doJSON = async (client, storage, method, path, body, retryDuplicated = false) => {
    const resp = await requestWps(client, storage, driveUrl(storage, path), {
      body,
      json: true,
      method,
      retryDuplicated
    });
    cache.clear(storage);
    return resp;
  };
  const parentInfo = async (client, storage, relPath) => {
    var _a2, _b2, _c, _d;
    const parent = await resolveNode(client, storage, dirnameOf(relPath));
    if (((_a2 = parent.wps) == null ? void 0 : _a2.kind) !== "group" && ((_b2 = parent.wps) == null ? void 0 : _b2.kind) !== "folder") throw new Error("not support");
    return {
      groupID: Number(parent.wps.group_id || 0),
      parentID: ((_c = parent.wps) == null ? void 0 : _c.kind) === "folder" && ((_d = parent.wps) == null ? void 0 : _d.has_file) ? Number(parent.wps.file_id || 0) : 0,
      parent
    };
  };
  const createWpsDriver = ({ client }) => ({
    async test(storage) {
      await ensureLogin(client, storage);
      await resolveRoot(client, storage);
      return { addition: storage.addition_json };
    },
    async list(storage, relPath) {
      const node = await resolveNode(client, storage, relPath);
      const content = await childrenForNode(client, storage, node, relPath || "/");
      return {
        content,
        total: content.length,
        readme: "",
        header: "",
        write: true,
        provider: "WPS",
        direct_upload_tools: []
      };
    },
    async get(storage, relPath, options = {}) {
      const node = await resolveNode(client, storage, relPath);
      const result = {
        ...node,
        readme: "",
        header: "",
        related: []
      };
      if (!result.is_dir && !options.skipLink) {
        const link2 = await downloadLink(client, storage, node);
        result.raw_url = link2.url;
        result.url = link2.url;
      }
      return result;
    },
    async read(storage, relPath, options = {}) {
      const node = await resolveNode(client, storage, relPath);
      if (node.is_dir) throw new Error("not file");
      const link2 = await downloadLink(client, storage, node);
      return {
        link: {
          url: link2.url,
          header: { ...link2.header, ...options.proxyHeaders || options.headers || {} },
          content_length: link2.content_length
        }
      };
    },
    async mkdir(storage, relPath) {
      const { groupID, parentID } = await parentInfo(client, storage, relPath);
      await doJSON(client, storage, "POST", "/api/v5/files/folder", {
        groupid: groupID,
        name: basenameOf(relPath),
        parentid: parentID
      });
    },
    async move(storage, relPath, dstRelPath) {
      var _a2, _b2, _c, _d, _e, _f;
      const src = await resolveNode(client, storage, relPath);
      const dst = await resolveNode(client, storage, dstRelPath);
      if (((_a2 = src.wps) == null ? void 0 : _a2.kind) !== "file" && ((_b2 = src.wps) == null ? void 0 : _b2.kind) !== "folder") throw new Error("not support");
      if (((_c = dst.wps) == null ? void 0 : _c.kind) !== "group" && ((_d = dst.wps) == null ? void 0 : _d.kind) !== "folder") throw new Error("not support");
      await doJSON(client, storage, "POST", `/api/v3/groups/${src.wps.group_id}/files/batch/move`, {
        fileids: [Number(src.wps.file_id || 0)],
        target_groupid: Number(dst.wps.group_id || 0),
        target_parentid: ((_e = dst.wps) == null ? void 0 : _e.kind) === "folder" && ((_f = dst.wps) == null ? void 0 : _f.has_file) ? Number(dst.wps.file_id || 0) : 0
      }, true);
    },
    async copy(storage, relPath, dstRelPath) {
      var _a2, _b2, _c, _d, _e, _f;
      const src = await resolveNode(client, storage, relPath);
      const dst = await resolveNode(client, storage, dstRelPath);
      if (((_a2 = src.wps) == null ? void 0 : _a2.kind) !== "file" && ((_b2 = src.wps) == null ? void 0 : _b2.kind) !== "folder") throw new Error("not support");
      if (((_c = dst.wps) == null ? void 0 : _c.kind) !== "group" && ((_d = dst.wps) == null ? void 0 : _d.kind) !== "folder") throw new Error("not support");
      await doJSON(client, storage, "POST", `/api/v3/groups/${src.wps.group_id}/files/batch/copy`, {
        duplicated_name_model: 1,
        fileids: [Number(src.wps.file_id || 0)],
        groupid: Number(src.wps.group_id || 0),
        target_groupid: Number(dst.wps.group_id || 0),
        target_parentid: ((_e = dst.wps) == null ? void 0 : _e.kind) === "folder" && ((_f = dst.wps) == null ? void 0 : _f.has_file) ? Number(dst.wps.file_id || 0) : 0
      }, true);
    },
    async remove(storage, relPath) {
      var _a2, _b2;
      const node = await resolveNode(client, storage, relPath);
      if (((_a2 = node.wps) == null ? void 0 : _a2.kind) !== "file" && ((_b2 = node.wps) == null ? void 0 : _b2.kind) !== "folder") throw new Error("not support");
      await doJSON(client, storage, "POST", `/api/v3/groups/${node.wps.group_id}/files/batch/delete`, {
        fileids: [Number(node.wps.file_id || 0)]
      }, true);
    },
    async rename(storage, relPath, newName) {
      var _a2, _b2;
      const node = await resolveNode(client, storage, relPath);
      if (((_a2 = node.wps) == null ? void 0 : _a2.kind) !== "file" && ((_b2 = node.wps) == null ? void 0 : _b2.kind) !== "folder") throw new Error("not support");
      await doJSON(client, storage, "PUT", `/api/v3/groups/${node.wps.group_id}/files/${node.wps.file_id}`, {
        fname: newName
      });
    },
    async details(storage) {
      var _a2, _b2;
      await ensureLogin(client, storage);
      if (isPersonal(storage)) {
        const resp2 = await requestWps(client, storage, `${ENDPOINT_PERSONAL}/api/v3/spaces`);
        return {
          total_space: Number(resp2.total || 0),
          used_space: Number(resp2.used || 0),
          free_space: Math.max(0, Number(resp2.total || 0) - Number(resp2.used || 0))
        };
      }
      const companyID = Number(((_a2 = storage.__wpsLogin) == null ? void 0 : _a2.companyid) || ((_b2 = storage.__wpsLogin) == null ? void 0 : _b2.current_companyid) || 0);
      const resp = await requestWps(client, storage, `${ENDPOINT_BUSINESS}/3rd/plussvr/compose/v1/u/companies/batch/service-space`, {
        query: { comp_ids: companyID }
      });
      const info = (resp.info || []).find((item) => Number(item.id || 0) === companyID) || (resp.info || [])[0];
      if (!info) throw new Error(`service space info not found for company ID: ${companyID}`);
      return {
        total_space: Number(info.space_total || 0),
        used_space: Number(info.space_used || 0),
        free_space: Math.max(0, Number(info.space_total || 0) - Number(info.space_used || 0))
      };
    },
    async put() {
      throw new Error("WPS upload is disabled in the SiYuan kernel JavaScript runtime to avoid blocking SiYuan");
    }
  });
  const parseAddition = (storage) => {
    if (storage.addition_json) return storage.addition_json;
    try {
      return JSON.parse(storage.addition || "{}");
    } catch (_) {
      return {};
    }
  };
  const relPathForMount = (mountPath, path) => {
    const mount = normalizePath(mountPath);
    const current = normalizePath(path);
    if (mount === "/") return current;
    const rest = current === mount ? "" : current.slice(mount.length);
    return normalizePath(rest || "/");
  };
  const createDriverRuntime = ({ client, getSettings, saveStorageAddition, workspaceGet, workspaceList, workspacePublicUrl, workspaceReadText }) => {
    const drivers = {
      SiYuanWorkspace: createSiYuanWorkspaceDriver({ workspaceGet, workspaceList, workspacePublicUrl, workspaceReadText }),
      OpenList: createOpenListDriver({ client }),
      AListV3: createOpenListDriver({ client }),
      "AList V3": createOpenListDriver({ client }),
      S3: createS3Driver({ client }),
      Doge: createS3Driver({ client }),
      WebDav: createWebDavDriver({ client }),
      "115 Cloud": create115Driver({ client }),
      "115": create115Driver({ client }),
      "115 Open": create115OpenDriver({ client }),
      "115Open": create115OpenDriver({ client }),
      "115 Share": create115ShareDriver({ client }),
      "115Share": create115ShareDriver({ client }),
      Onedrive: createOneDriveDriver({ client }),
      OneDrive: createOneDriveDriver({ client }),
      "123Pan": create123PanDriver({ client }),
      "123": create123PanDriver({ client }),
      BaiduNetdisk: createBaiduNetdiskDriver({ client }),
      BaiduNetDisk: createBaiduNetdiskDriver({ client }),
      AliyundriveOpen: createAliyundriveOpenDriver({ client }),
      AliyunDriveOpen: createAliyundriveOpenDriver({ client }),
      "189Cloud": create189CloudDriver({ client }),
      "189CloudPC": create189CloudPCDriver({ client }),
      "189CloudTV": create189CloudTVDriver({ client }),
      Quark: createQuarkDriver({ client }),
      UC: createQuarkDriver({ client }),
      QuarkOpen: createQuarkOpenDriver({ client }),
      QuarkTV: createQuarkUCTVDriver({ client }),
      UCTV: createQuarkUCTVDriver({ client }),
      WPS: createWpsDriver({ client })
    };
    const runtime = {
      drivers,
      canHandle(storage) {
        return !!drivers[storage == null ? void 0 : storage.driver];
      },
      mountEntries(storages, now) {
        const seen = /* @__PURE__ */ new Set();
        return (storages || []).filter((storage) => !storage.disabled && normalizePath(storage.mount_path || "/") !== "/").map((storage) => normalizePath(storage.mount_path)).map((mountPath) => mountPath.split("/").filter(Boolean)[0]).filter((name) => {
          if (!name || seen.has(name)) return false;
          seen.add(name);
          return true;
        }).map((name) => ({
          name,
          path: `/${name}`,
          is_dir: true,
          size: 0,
          modified: now(),
          created: now(),
          provider: "mount"
        }));
      },
      resolve(storages, path) {
        const current = normalizePath(path || "/");
        const candidates = (storages || []).filter((storage2) => !storage2.disabled && runtime.canHandle(storage2)).map((storage2) => {
          const addition = parseAddition(storage2);
          return {
            ...storage2,
            addition_json: addition,
            mount_path: normalizePath(storage2.mount_path || "/"),
            settings: getSettings ? getSettings() : {},
            saveDriverStorage: async (updatedAddition = addition) => {
              if (saveStorageAddition) await saveStorageAddition(storage2, updatedAddition);
            }
          };
        }).filter((storage2) => storage2.mount_path !== "/" && (current === storage2.mount_path || current.startsWith(storage2.mount_path + "/"))).sort((a, b) => b.mount_path.length - a.mount_path.length);
        const storage = candidates[0];
        if (!storage) return null;
        return {
          storage,
          driver: drivers[storage.driver],
          relPath: relPathForMount(storage.mount_path, current)
        };
      },
      async test(driverName, addition, verify) {
        const driver = drivers[driverName];
        if (!(driver == null ? void 0 : driver.test)) throw new Error(`driver [${driverName}] does not expose a test method`);
        return driver.test({
          addition_json: addition || {},
          driver: driverName,
          mount_path: "/",
          settings: getSettings ? getSettings() : {}
        }, verify);
      }
    };
    return runtime;
  };
  const defaultSettings = () => ({
    site_title: "Siyuan Cloud",
    version: OPENLIST_VERSION,
    main_color: "#1890ff",
    logo: "",
    favicon: "",
    announcement: "",
    announcements: "",
    allow_indexed: "false",
    allow_mounted: "true",
    hide_storage_details: "true",
    hide_storage_details_in_manage_page: "true",
    show_disk_usage_in_plain_text: "false",
    text_types: "txt,htm,html,xml,java,properties,sql,js,md,json,conf,ini,vue,php,py,bat,gitignore,yml,go,sh,c,cpp,h,hpp,tsx,vtt,srt,ass,rs,lrc,strm",
    audio_types: "mp3,flac,ogg,m4a,wav,opus,wma",
    video_types: "mp4,mkv,avi,mov,rmvb,webm,flv,m3u8",
    image_types: "jpg,tiff,jpeg,png,gif,bmp,svg,ico,swf,webp,avif",
    proxy_types: "m3u8,url",
    proxy_ignore_headers: "authorization,referer",
    external_previews: "{}",
    audio_autoplay: "true",
    video_autoplay: "true",
    preview_download_by_default: "false",
    preview_archives_by_default: "false",
    share_preview_download_by_default: "false",
    share_preview_archives_by_default: "false",
    readme_autorender: "true",
    filter_readme_scripts: "true",
    non_efs_zip_encoding: "IBM437",
    default_page_size: "30",
    package_download: "true",
    pagination_type: "all",
    robots_txt: "",
    hide_files: "",
    customize_head: "",
    customize_body: "",
    link_expiration: "0",
    sign_all: "true",
    privacy_regs: "",
    ocr_api: "https://api.example.com/ocr/file/json",
    filename_char_mapping: "",
    forward_direct_link_params: "",
    ignore_direct_link_params: "sign,sicloud_ts,raw",
    webauthn_login_enabled: "false",
    share_preview: "false",
    share_archive_preview: "false",
    share_summary_content: "",
    handle_hook_after_writing: "false",
    handle_hook_rate_limit: "0",
    ignore_system_files: "false",
    search_index: "none",
    auto_update_index: "false",
    ignore_paths: "",
    max_index_depth: "20",
    index_progress: "{}",
    sso_login_enabled: "false",
    sso_login_platform: "Github",
    sso_client_id: "",
    sso_client_secret: "",
    sso_oidc_username_key: "name",
    sso_organization_name: "",
    sso_application_name: "",
    sso_endpoint_name: "",
    sso_jwt_public_key: "",
    sso_extra_scopes: "",
    sso_auto_register: "false",
    sso_default_dir: "/",
    sso_default_permission: "0",
    sso_compatibility_mode: "false",
    ldap_login_enabled: "false",
    ldap_server: "",
    ldap_skip_tls_verify: "false",
    ldap_manager_dn: "",
    ldap_manager_password: "",
    ldap_user_search_base: "",
    ldap_user_search_filter: "(uid=%s)",
    ldap_default_dir: "/",
    ldap_default_permission: "0",
    ldap_login_tips: "login with ldap",
    s3_access_key_id: "",
    s3_secret_access_key: "",
    s3_buckets: "[]",
    ftp_public_host: "127.0.0.1",
    ftp_pasv_port_map: "",
    ftp_mandatory_tls: "false",
    ftp_implicit_tls: "false",
    ftp_tls_private_key_path: "",
    ftp_tls_public_cert_path: "",
    sftp_disable_password_login: "false",
    task_offline_download_threads_num: "5",
    task_offline_download_transfer_threads_num: "5",
    task_upload_threads_num: "5",
    task_copy_threads_num: "5",
    task_decompress_download_threads_num: "5",
    task_decompress_upload_threads_num: "5",
    stream_max_client_download_speed: "-1",
    stream_max_client_upload_speed: "-1",
    stream_max_server_download_speed: "-1",
    stream_max_server_upload_speed: "-1",
    aria2_uri: "",
    aria2_secret: "",
    qbittorrent_url: "",
    qbittorrent_seedtime: "",
    transmission_uri: "",
    transmission_seedtime: "",
    "115_temp_dir": "",
    "123_temp_dir": "",
    "115_open_temp_dir": "",
    "123_open_temp_dir": "",
    "123_open_callback_url": "",
    pikpak_temp_dir: "",
    thunder_temp_dir: "",
    thunderx_temp_dir: "",
    thunder_browser_temp_dir: "",
    token: "siyuan-cloud-token"
  });
  const settingMeta = {
    version: { group: SETTING_GROUP.SITE, flag: SETTING_FLAG.READONLY },
    site_title: { group: SETTING_GROUP.SITE },
    announcement: { type: "text", group: SETTING_GROUP.SITE },
    announcements: { type: "text", group: SETTING_GROUP.SITE },
    allow_indexed: { type: "bool", group: SETTING_GROUP.SITE },
    allow_mounted: { type: "bool", group: SETTING_GROUP.SITE },
    robots_txt: { type: "text", group: SETTING_GROUP.SITE },
    logo: { type: "text", group: SETTING_GROUP.STYLE },
    favicon: { group: SETTING_GROUP.STYLE },
    main_color: { group: SETTING_GROUP.STYLE },
    hide_storage_details: { type: "bool", group: SETTING_GROUP.STYLE, flag: SETTING_FLAG.PRIVATE },
    hide_storage_details_in_manage_page: { type: "bool", group: SETTING_GROUP.STYLE, flag: SETTING_FLAG.PRIVATE },
    show_disk_usage_in_plain_text: { type: "bool", group: SETTING_GROUP.STYLE },
    text_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    audio_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    video_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    image_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    proxy_types: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    proxy_ignore_headers: { type: "text", group: SETTING_GROUP.PREVIEW, flag: SETTING_FLAG.PRIVATE },
    external_previews: { type: "text", group: SETTING_GROUP.PREVIEW },
    audio_autoplay: { type: "bool", group: SETTING_GROUP.PREVIEW },
    video_autoplay: { type: "bool", group: SETTING_GROUP.PREVIEW },
    preview_download_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    preview_archives_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    share_preview_download_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    share_preview_archives_by_default: { type: "bool", group: SETTING_GROUP.PREVIEW },
    readme_autorender: { type: "bool", group: SETTING_GROUP.PREVIEW },
    filter_readme_scripts: { type: "bool", group: SETTING_GROUP.PREVIEW },
    non_efs_zip_encoding: { group: SETTING_GROUP.PREVIEW },
    hide_files: { type: "text", group: SETTING_GROUP.GLOBAL },
    customize_head: { type: "text", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    customize_body: { type: "text", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    link_expiration: { type: "number", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    sign_all: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    privacy_regs: { type: "text", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    ocr_api: { group: SETTING_GROUP.GLOBAL },
    filename_char_mapping: { type: "text", group: SETTING_GROUP.GLOBAL },
    forward_direct_link_params: { group: SETTING_GROUP.GLOBAL },
    ignore_direct_link_params: { group: SETTING_GROUP.GLOBAL },
    webauthn_login_enabled: { type: "bool", group: SETTING_GROUP.GLOBAL },
    share_preview: { type: "bool", group: SETTING_GROUP.GLOBAL },
    share_archive_preview: { type: "bool", group: SETTING_GROUP.GLOBAL },
    share_summary_content: { type: "text", group: SETTING_GROUP.GLOBAL },
    handle_hook_after_writing: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    handle_hook_rate_limit: { type: "number", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    ignore_system_files: { type: "bool", group: SETTING_GROUP.GLOBAL, flag: SETTING_FLAG.PRIVATE },
    token: { group: SETTING_GROUP.SINGLE, flag: SETTING_FLAG.PRIVATE },
    search_index: { type: "select", options: "none,bleve", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE },
    auto_update_index: { type: "bool", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE },
    ignore_paths: { type: "text", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE, help: "one path per line" },
    max_index_depth: { type: "number", group: SETTING_GROUP.INDEX, flag: SETTING_FLAG.PRIVATE, help: "max depth of index" },
    index_progress: { type: "text", group: SETTING_GROUP.SINGLE, flag: SETTING_FLAG.PRIVATE },
    sso_login_enabled: { type: "bool", group: SETTING_GROUP.SSO },
    sso_login_platform: { type: "select", options: "Casdoor,Github,Microsoft,Google,Dingtalk,OIDC", group: SETTING_GROUP.SSO },
    sso_client_id: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_client_secret: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_oidc_username_key: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_organization_name: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_application_name: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_endpoint_name: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_jwt_public_key: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_extra_scopes: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_auto_register: { type: "bool", group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_default_dir: { group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_default_permission: { type: "number", group: SETTING_GROUP.SSO, flag: SETTING_FLAG.PRIVATE },
    sso_compatibility_mode: { type: "bool", group: SETTING_GROUP.SSO },
    ldap_login_enabled: { type: "bool", group: SETTING_GROUP.LDAP },
    ldap_server: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_skip_tls_verify: { type: "bool", group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_manager_dn: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_manager_password: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_user_search_base: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_user_search_filter: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_default_dir: { group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_default_permission: { type: "number", group: SETTING_GROUP.LDAP, flag: SETTING_FLAG.PRIVATE },
    ldap_login_tips: { group: SETTING_GROUP.LDAP },
    s3_access_key_id: { group: SETTING_GROUP.S3, flag: SETTING_FLAG.PRIVATE },
    s3_secret_access_key: { group: SETTING_GROUP.S3, flag: SETTING_FLAG.PRIVATE },
    s3_buckets: { group: SETTING_GROUP.S3, flag: SETTING_FLAG.PRIVATE },
    ftp_public_host: { group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_pasv_port_map: { type: "text", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_mandatory_tls: { type: "bool", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_implicit_tls: { type: "bool", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_tls_private_key_path: { group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    ftp_tls_public_cert_path: { group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    sftp_disable_password_login: { type: "bool", group: SETTING_GROUP.FTP, flag: SETTING_FLAG.PRIVATE },
    task_offline_download_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_offline_download_transfer_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_upload_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_copy_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_decompress_download_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    task_decompress_upload_threads_num: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_client_download_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_client_upload_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_server_download_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    stream_max_server_upload_speed: { type: "number", group: SETTING_GROUP.TRAFFIC, flag: SETTING_FLAG.PRIVATE },
    aria2_uri: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    aria2_secret: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    qbittorrent_url: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    qbittorrent_seedtime: { type: "number", group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    transmission_uri: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    transmission_seedtime: { type: "number", group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "115_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "123_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "115_open_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "123_open_temp_dir": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    "123_open_callback_url": { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    pikpak_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    thunder_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    thunderx_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE },
    thunder_browser_temp_dir: { group: SETTING_GROUP.OFFLINE_DOWNLOAD, flag: SETTING_FLAG.PRIVATE }
  };
  const defaultState = (now) => ({
    settings: defaultSettings(),
    users: [
      defaultAdminUser(),
      defaultGuestUser()
    ],
    storages: [],
    entries: {
      "/": {
        name: "",
        path: "/",
        is_dir: true,
        size: 0,
        modified: now(),
        created: now(),
        children: []
      }
    },
    tasks: {},
    metas: [],
    messages: [],
    ssh_keys: [],
    scan: { status: "idle", total: 0, done: 0 },
    webdav_locks: {},
    s3_multipart_uploads: {},
    sharings: [],
    search_nodes: []
  });
  const createVirtualFs = ({ getState, now }) => {
    const byteLengthForBase64 = (value) => {
      const clean = String(value || "").replace(/[\r\n\s]/g, "");
      if (!clean) return 0;
      const padding = clean.endsWith("==") ? 2 : clean.endsWith("=") ? 1 : 0;
      return Math.max(0, Math.floor(clean.length * 3 / 4) - padding);
    };
    const ensureDir = (path) => {
      const state = getState();
      const normalized = normalizePath(path);
      if (!state.entries[normalized]) {
        state.entries[normalized] = {
          name: basename(normalized),
          path: normalized,
          is_dir: true,
          size: 0,
          modified: now(),
          created: now(),
          children: []
        };
      }
      const parentPath = dirname(normalized);
      const parent = state.entries[parentPath];
      if (parent && parent.is_dir && normalized !== "/" && !parent.children.includes(normalized)) {
        parent.children.push(normalized);
        parent.children.sort();
        parent.modified = now();
      }
      return state.entries[normalized];
    };
    const createFile2 = (path, content, mime, options = {}) => {
      var _a2;
      const state = getState();
      const normalized = normalizePath(path);
      const parent = ensureDir(dirname(normalized));
      const bodyEncoding = String(options.bodyEncoding || "text");
      const text2 = content === void 0 || content === null ? "" : String(content);
      const size = Number(options.size || 0) || (bodyEncoding.startsWith("base64") ? byteLengthForBase64(text2) : text2.length);
      state.entries[normalized] = {
        name: basename(normalized),
        path: normalized,
        is_dir: false,
        size,
        modified: now(),
        created: ((_a2 = state.entries[normalized]) == null ? void 0 : _a2.created) || now(),
        content: text2,
        body_encoding: bodyEncoding,
        mime: mime || "text/plain; charset=utf-8"
      };
      if (!parent.children.includes(normalized)) {
        parent.children.push(normalized);
        parent.children.sort();
      }
      parent.modified = now();
      return state.entries[normalized];
    };
    const removeEntry = (path) => {
      const state = getState();
      const entry = state.entries[path];
      if (!entry || path === "/") return;
      if (entry.children) {
        for (const child of [...entry.children]) removeEntry(child);
      }
      const parent = state.entries[dirname(path)];
      if (parent && parent.children) {
        parent.children = parent.children.filter((item) => item !== path);
        parent.modified = now();
      }
      delete state.entries[path];
    };
    const cloneEntryTree = (srcPath, dstPath) => {
      const state = getState();
      const src = state.entries[srcPath];
      if (!src) throw new Error("object not found");
      if (src.is_dir) {
        ensureDir(dstPath);
        for (const child of src.children || []) {
          cloneEntryTree(child, normalizePath(dstPath + "/" + basename(child)));
        }
      } else {
        createFile2(dstPath, src.content || "", src.mime, {
          bodyEncoding: src.body_encoding || "text",
          size: src.size || 0
        });
      }
    };
    const moveEntryTree = (srcPath, dstPath) => {
      cloneEntryTree(srcPath, dstPath);
      removeEntry(srcPath);
    };
    const renameEntryInDir = (dir, srcName, newName, options) => {
      const state = getState();
      const srcPath = normalizePath(dir + "/" + srcName);
      const dstPath = normalizePath(dir + "/" + newName);
      if (!isSafeRelativeName(newName)) throw new Error("relative path is not allowed");
      if (!state.entries[srcPath]) return false;
      if (state.entries[dstPath] && dstPath !== srcPath && !(options == null ? void 0 : options.overwrite)) throw new Error(`file [${newName}] exists`);
      if (state.entries[dstPath] && dstPath !== srcPath) removeEntry(dstPath);
      moveEntryTree(srcPath, dstPath);
      return true;
    };
    const removeEmptyDirs = (rootPath2) => {
      var _a2;
      const state = getState();
      let removed = 0;
      const walk = (path) => {
        const entry = state.entries[path];
        if (!entry || !entry.is_dir || path === "/") return false;
        for (const child of [...entry.children || []]) walk(child);
        if ((entry.children || []).length === 0) {
          removeEntry(path);
          removed += 1;
          return true;
        }
        return false;
      };
      for (const child of [...((_a2 = state.entries[rootPath2]) == null ? void 0 : _a2.children) || []]) walk(child);
      return removed;
    };
    return {
      cloneEntryTree,
      createFile: createFile2,
      ensureDir,
      moveEntryTree,
      removeEmptyDirs,
      removeEntry,
      renameEntryInDir
    };
  };
  const createWorkspaceAdapter = ({
    client,
    extensionType,
    failure: failure2,
    now,
    page,
    toObjResp
  }) => {
    const isWorkspacePath = (path) => normalizePath(path).startsWith("/@workspace");
    const workspaceRelPath = (path) => {
      const normalized = normalizePath(path);
      const rel = normalized.replace(/^\/@workspace\/?/, "");
      return rel.replace(/^\/+/, "");
    };
    const workspacePublicUrl = (path) => {
      const parts = workspaceRelPath(path).split("/").filter(Boolean);
      return parts[0] === "data" && parts.length > 2 ? `/${parts.slice(1).join("/")}` : "";
    };
    const siyuanApiJson = async (apiPath, data) => {
      const response = await client.fetch(apiPath, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data || {})
      });
      const contentType = response.headers && (response.headers["Content-Type"] || response.headers["content-type"] || "");
      if (String(contentType).includes("application/json")) return response.json();
      return {
        code: response.ok ? 0 : response.status,
        msg: response.statusText || "",
        data: await response.text()
      };
    };
    const workspaceObjResp = (item) => ({
      name: item.name,
      size: item.size || 0,
      is_dir: !!(item.isDir || item.is_dir),
      modified: new Date(Number(item.updated || 0) * 1e3 || Date.now()).toISOString(),
      created: new Date(Number(item.updated || 0) * 1e3 || Date.now()).toISOString(),
      sign: "",
      thumb: "",
      type: extensionType(item.name, item.isDir || item.is_dir),
      hashinfo: "",
      hash_info: {},
      provider: "siyuan-workspace"
    });
    const workspaceList = async (path, req) => {
      const rel = workspaceRelPath(path);
      const payload = await siyuanApiJson("/api/file/readDir", { path: rel });
      if (payload.code !== 0) return { error: failure2(payload.msg || "readDir failed", payload.code || 500) };
      const content = (payload.data || []).filter((item) => item && item.name && !String(item.name).startsWith(".")).map(workspaceObjResp);
      return {
        data: {
          content: page(content, req || {}),
          total: content.length,
          readme: "",
          header: "",
          write: true,
          write_content_bypass: false,
          provider: "siyuan-workspace",
          direct_upload_tools: []
        }
      };
    };
    const workspaceGet = async (path) => {
      if (normalizePath(path) === "/@workspace") {
        return {
          data: {
            ...toObjResp({ name: "@workspace", is_dir: true, size: 0, modified: now(), created: now() }),
            raw_url: "",
            readme: "",
            header: "",
            provider: "siyuan-workspace",
            related: []
          }
        };
      }
      const rel = workspaceRelPath(path);
      const parent = workspaceRelPath(dirname(path));
      const payload = await siyuanApiJson("/api/file/readDir", { path: parent });
      if (payload.code !== 0) return { error: failure2(payload.msg || "readDir failed", payload.code || 500) };
      const item = (payload.data || []).find((entry) => entry.name === basename(path));
      if (!item) return { error: failure2("object not found", 404) };
      return {
        data: {
          ...workspaceObjResp(item),
          raw_url: item.isDir ? "" : "/plugin/private/siyuan-cloud/d" + normalizePath("/@workspace/" + rel),
          readme: "",
          header: "",
          provider: "siyuan-workspace",
          related: []
        }
      };
    };
    const workspaceReadText = async (path) => {
      const response = await client.fetch("/api/file/getFile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: workspaceRelPath(path) })
      });
      return {
        ok: response.ok,
        status: response.status || 200,
        text: await response.text(),
        contentType: response.headers && (response.headers["Content-Type"] || response.headers["content-type"]) || "application/octet-stream"
      };
    };
    return {
      isWorkspacePath,
      siyuanApiJson,
      workspaceGet,
      workspaceList,
      workspacePublicUrl,
      workspaceReadText,
      workspaceRelPath
    };
  };
  const DONE_STATES = /* @__PURE__ */ new Set(["canceled", "failed", "succeeded"]);
  const UNDONE_STATES = /* @__PURE__ */ new Set(["pending", "running", "canceling", "errored", "failing", "waiting_retry", "before_retry"]);
  class TaskCancelError extends Error {
    constructor(message = "task canceled") {
      super(message);
      this.name = "TaskCancelError";
    }
  }
  const ensureTaskBuckets = (state) => {
    state.tasks = state.tasks || {};
    for (const type of TASK_TYPES) {
      state.tasks[type] = state.tasks[type] || {};
    }
    return state.tasks;
  };
  const createTaskRecord = ({
    creator,
    error,
    name,
    now,
    status,
    totalBytes,
    type
  }) => {
    const time = now();
    return {
      id: `${type}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
      name: name || type,
      creator: (creator == null ? void 0 : creator.username) || "admin",
      creator_id: Number((creator == null ? void 0 : creator.id) || 1),
      creator_role: (creator == null ? void 0 : creator.role) ?? 2,
      state: error ? "failed" : "succeeded",
      status: status || (error ? "failed" : "completed"),
      progress: error ? 0 : 100,
      start_time: time,
      end_time: time,
      total_bytes: totalBytes || 0,
      error: error || "",
      cancel_requested: false
    };
  };
  const createQueuedTaskRecord = ({
    creator,
    name,
    now,
    totalBytes,
    type
  }) => {
    const time = now();
    return {
      id: `${type}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
      name: name || type,
      creator: (creator == null ? void 0 : creator.username) || "admin",
      creator_id: Number((creator == null ? void 0 : creator.id) || 1),
      creator_role: (creator == null ? void 0 : creator.role) ?? 2,
      state: "pending",
      status: "pending",
      progress: 0,
      start_time: null,
      end_time: null,
      queued_time: time,
      updated_time: time,
      total_bytes: totalBytes || 0,
      error: "",
      cancel_requested: false
    };
  };
  const normalizeTaskRecord = (task = {}) => ({
    id: String(task.id || ""),
    name: String(task.name || ""),
    creator: String(task.creator || "admin"),
    creator_id: Number(task.creator_id || task.creatorId || 1),
    creator_role: Number(task.creator_role ?? 2),
    state: String(task.state || "succeeded"),
    status: String(task.status || ""),
    progress: Number.isFinite(Number(task.progress)) ? Number(task.progress) : 100,
    start_time: task.start_time || null,
    end_time: task.end_time || null,
    queued_time: task.queued_time || task.start_time || null,
    updated_time: task.updated_time || task.end_time || task.start_time || null,
    total_bytes: Number(task.total_bytes || 0),
    error: String(task.error || ""),
    cancel_requested: !!task.cancel_requested
  });
  const createTaskStore = ({
    getState,
    now,
    saveState: saveState2
  }) => {
    const queue = [];
    const workers = /* @__PURE__ */ new Map();
    let running = 0;
    const concurrency = 1;
    const canAccessTask = (task, user) => {
      if (!user || Number(user.role) === 2) return true;
      const normalized = normalizeTaskRecord(task);
      if (normalized.creator_id) return Number(normalized.creator_id) === Number(user.id);
      return normalized.creator === user.username;
    };
    const addTask = async (type, input) => {
      var _a2;
      const state = getState();
      const tasks = ensureTaskBuckets(state);
      const task = createTaskRecord({
        ...input,
        creator: (input == null ? void 0 : input.creator) || ((_a2 = state.users) == null ? void 0 : _a2[0]),
        now,
        type
      });
      tasks[type][task.id] = normalizeTaskRecord(task);
      await saveState2();
      return tasks[type][task.id];
    };
    const getTask = (type, id, user) => {
      var _a2;
      const tasks = ensureTaskBuckets(getState());
      const task = ((_a2 = tasks[type]) == null ? void 0 : _a2[id]) || null;
      return task && canAccessTask(task, user) ? normalizeTaskRecord(task) : null;
    };
    const updateTask = async (type, id, patch = {}) => {
      var _a2;
      const tasks = ensureTaskBuckets(getState());
      const task = (_a2 = tasks[type]) == null ? void 0 : _a2[id];
      if (!task) return null;
      Object.assign(task, patch, { updated_time: now() });
      tasks[type][id] = normalizeTaskRecord(task);
      await saveState2();
      return tasks[type][id];
    };
    const runQueuedTask = async (type, id, worker) => {
      var _a2;
      running += 1;
      const tasks = ensureTaskBuckets(getState());
      const task = (_a2 = tasks[type]) == null ? void 0 : _a2[id];
      if (!task) {
        running -= 1;
        return;
      }
      if (task.cancel_requested) {
        await updateTask(type, id, {
          end_time: now(),
          progress: 0,
          state: "canceled",
          status: "canceled"
        });
        running -= 1;
        drainQueue();
        return;
      }
      await updateTask(type, id, {
        start_time: now(),
        state: "running",
        status: "running"
      });
      const isCanceled = () => {
        var _a3;
        const current = (_a3 = ensureTaskBuckets(getState())[type]) == null ? void 0 : _a3[id];
        return !!(current == null ? void 0 : current.cancel_requested);
      };
      const throwIfCanceled = () => {
        if (isCanceled()) throw new TaskCancelError();
      };
      const progress2 = async (patch = {}) => {
        throwIfCanceled();
        const next = {};
        if (patch.status !== void 0) next.status = String(patch.status);
        if (patch.progress !== void 0) next.progress = Math.max(0, Math.min(100, Number(patch.progress) || 0));
        if (patch.totalBytes !== void 0) next.total_bytes = Number(patch.totalBytes || 0);
        if (patch.error !== void 0) next.error = String(patch.error || "");
        await updateTask(type, id, next);
      };
      try {
        await worker({ id, isCanceled, progress: progress2, task: normalizeTaskRecord(task), throwIfCanceled });
        if (isCanceled()) throw new TaskCancelError();
        await updateTask(type, id, {
          end_time: now(),
          error: "",
          progress: 100,
          state: "succeeded",
          status: "completed"
        });
      } catch (error) {
        const canceled = error instanceof TaskCancelError || isCanceled();
        await updateTask(type, id, {
          end_time: now(),
          error: canceled ? "" : String((error == null ? void 0 : error.message) || error || "task failed"),
          state: canceled ? "canceled" : "failed",
          status: canceled ? "canceled" : "failed"
        });
      } finally {
        running -= 1;
        drainQueue();
      }
    };
    const drainQueue = () => {
      while (running < concurrency && queue.length) {
        const item = queue.shift();
        const worker = workers.get(item.id);
        workers.delete(item.id);
        if (!worker) continue;
        Promise.resolve().then(() => runQueuedTask(item.type, item.id, worker));
      }
    };
    const enqueueTask = async (type, input = {}, worker = async () => {
    }) => {
      var _a2;
      const state = getState();
      const tasks = ensureTaskBuckets(state);
      const task = createQueuedTaskRecord({
        ...input,
        creator: (input == null ? void 0 : input.creator) || ((_a2 = state.users) == null ? void 0 : _a2[0]),
        now,
        type
      });
      tasks[type][task.id] = normalizeTaskRecord(task);
      workers.set(task.id, worker);
      queue.push({ id: task.id, type });
      await saveState2();
      drainQueue();
      return tasks[type][task.id];
    };
    const listTasks = (type, done, user) => {
      const tasks = ensureTaskBuckets(getState());
      return Object.values(tasks[type] || {}).map(normalizeTaskRecord).filter((task) => canAccessTask(task, user)).filter((task) => done ? DONE_STATES.has(task.state) : UNDONE_STATES.has(task.state)).sort((a, b) => String(b.start_time || "").localeCompare(String(a.start_time || "")));
    };
    const removeTask = async (type, id, user) => {
      var _a2;
      const tasks = ensureTaskBuckets(getState());
      if (!((_a2 = tasks[type]) == null ? void 0 : _a2[id]) || !canAccessTask(tasks[type][id], user)) return false;
      delete tasks[type][id];
      await saveState2();
      return true;
    };
    const clearByState = async (type, states, user) => {
      const tasks = ensureTaskBuckets(getState());
      for (const task of Object.values(tasks[type] || {})) {
        if (!canAccessTask(task, user)) continue;
        if (states.has(task.state)) delete tasks[type][task.id];
      }
      await saveState2();
    };
    const markCanceled = async (type, id, user) => {
      var _a2;
      const tasks = ensureTaskBuckets(getState());
      const task = (_a2 = tasks[type]) == null ? void 0 : _a2[id];
      if (!task || !canAccessTask(task, user)) return false;
      if (task.state === "pending") {
        workers.delete(id);
        const queueIndex = queue.findIndex((item) => item.id === id && item.type === type);
        if (queueIndex >= 0) queue.splice(queueIndex, 1);
        task.state = "canceled";
        task.status = "canceled";
        task.end_time = now();
        task.cancel_requested = true;
      } else if (task.state === "running") {
        task.state = "canceling";
        task.status = "canceling";
        task.cancel_requested = true;
      } else {
        task.state = "canceled";
        task.status = "canceled";
        task.end_time = now();
        task.cancel_requested = true;
      }
      task.updated_time = now();
      await saveState2();
      return true;
    };
    const retryTask = async (type, id, user) => {
      var _a2;
      const tasks = ensureTaskBuckets(getState());
      const task = (_a2 = tasks[type]) == null ? void 0 : _a2[id];
      if (!task || !canAccessTask(task, user)) return false;
      task.state = "succeeded";
      task.status = "completed";
      task.progress = 100;
      task.error = "";
      task.cancel_requested = false;
      task.end_time = now();
      task.updated_time = now();
      await saveState2();
      return true;
    };
    const retryFailed = async (type, user) => {
      const tasks = ensureTaskBuckets(getState());
      for (const task of Object.values(tasks[type] || {})) {
        if (!canAccessTask(task, user)) continue;
        if (task.state !== "failed") continue;
        task.state = "succeeded";
        task.status = "completed";
        task.progress = 100;
        task.error = "";
        task.cancel_requested = false;
        task.end_time = now();
        task.updated_time = now();
      }
      await saveState2();
    };
    return {
      addTask,
      clearDone: (type, user) => clearByState(type, DONE_STATES, user),
      clearSucceeded: (type, user) => clearByState(type, /* @__PURE__ */ new Set(["succeeded"]), user),
      enqueueTask,
      getTask,
      listTasks,
      markCanceled,
      removeTask,
      retryFailed,
      retryTask
    };
  };
  const progress = (objCount = 0, isDone = true, error = "", lastDoneTime = null) => ({
    obj_count: Number(objCount || 0),
    is_done: !!isDone,
    last_done_time: lastDoneTime,
    error: error || ""
  });
  const whereInParent = (node, parent) => {
    const normalized = normalizePath(parent || "/");
    if (normalized === "/") return true;
    return node.parent === normalized || node.parent.startsWith(`${normalized}/`);
  };
  const nodePath = (node) => normalizePath(`${node.parent}/${node.name}`);
  const parseIgnorePaths = (value) => String(value || "").split("\n").map((item) => normalizePath(item.trim())).filter((item) => item && item !== "/");
  const isIgnoredPath = (path, ignorePaths) => ignorePaths.some((item) => path.startsWith(item));
  const normalizeNode = (node) => ({
    parent: normalizePath(node.parent || "/"),
    name: String(node.name || ""),
    is_dir: !!node.is_dir,
    size: Number(node.size || 0)
  });
  const ensureSearchState = (state) => {
    if (!Array.isArray(state.search_nodes)) state.search_nodes = [];
    state.search_nodes = state.search_nodes.map(normalizeNode).filter((node) => node.name);
    if (!state.settings) state.settings = {};
    if (!state.settings.index_progress) {
      state.settings.index_progress = JSON.stringify(progress());
    }
  };
  const createSearchIndex = ({
    getObj,
    getState,
    isIndexDisabled,
    listObjs,
    now,
    saveState: saveState2
  }) => {
    const getProgress = () => {
      ensureSearchState(getState());
      try {
        return { ...progress(), ...JSON.parse(getState().settings.index_progress || "{}") };
      } catch (_) {
        return progress();
      }
    };
    const writeProgress = async (value) => {
      getState().settings.index_progress = JSON.stringify({ ...progress(), ...value || {} });
      await saveState2();
    };
    const clear = async () => {
      ensureSearchState(getState());
      getState().search_nodes = [];
      await saveState2();
    };
    const buildStateNodes = (paths, maxDepth) => {
      var _a2, _b2;
      const state = getState();
      const roots = (Array.isArray(paths) && paths.length ? paths : ["/"]).map(normalizePath);
      const ignorePaths = parseIgnorePaths((_a2 = state.settings) == null ? void 0 : _a2.ignore_paths);
      const depthLimit = Math.max(1, Number(maxDepth || ((_b2 = state.settings) == null ? void 0 : _b2.max_index_depth) || 20));
      return Object.values(state.entries || {}).filter((entry) => entry && entry.path && entry.path !== "/").filter((entry) => !isIgnoredPath(normalizePath(entry.path), ignorePaths)).filter((entry) => !(isIndexDisabled == null ? void 0 : isIndexDisabled(normalizePath(entry.path)))).filter((entry) => roots.some((root) => entry.path === root || entry.path.startsWith(`${root === "/" ? "" : root}/`))).filter((entry) => {
        const root = roots.find((item) => entry.path === item || entry.path.startsWith(`${item === "/" ? "" : item}/`)) || "/";
        const rel = entry.path.slice(root === "/" ? 1 : root.length + 1);
        return rel.split("/").filter(Boolean).length <= depthLimit;
      }).map((entry) => normalizeNode({
        parent: dirname(entry.path),
        name: entry.name || basename(entry.path),
        is_dir: entry.is_dir,
        size: entry.size
      }));
    };
    const walkNodes = async (paths, maxDepth, shouldCancel) => {
      var _a2, _b2;
      if (!getObj || !listObjs) return buildStateNodes(paths, maxDepth);
      const roots = (Array.isArray(paths) && paths.length ? paths : ["/"]).map(normalizePath);
      const ignorePaths = parseIgnorePaths((_a2 = getState().settings) == null ? void 0 : _a2.ignore_paths);
      const depthLimit = Math.max(1, Number(maxDepth || ((_b2 = getState().settings) == null ? void 0 : _b2.max_index_depth) || 20));
      const nodes = [];
      const seen = /* @__PURE__ */ new Set();
      const walk = async (path, depth) => {
        if (shouldCancel == null ? void 0 : shouldCancel()) throw new Error("index canceled");
        const normalized = normalizePath(path);
        if (seen.has(normalized) || depth > depthLimit) return;
        seen.add(normalized);
        if (isIgnoredPath(normalized, ignorePaths)) return;
        if (isIndexDisabled == null ? void 0 : isIndexDisabled(normalized)) return;
        const obj = await getObj(normalized);
        if (!obj) return;
        if (normalized !== "/") {
          nodes.push(normalizeNode({
            parent: dirname(normalized),
            name: obj.name || basename(normalized),
            is_dir: obj.is_dir,
            size: obj.size
          }));
        }
        if (!obj.is_dir || depth >= depthLimit) return;
        const children = await listObjs(normalized);
        for (const child of children || []) {
          if (!(child == null ? void 0 : child.name)) continue;
          if (shouldCancel == null ? void 0 : shouldCancel()) throw new Error("index canceled");
          await walk(normalizePath(`${normalized}/${child.name}`), depth + 1);
        }
      };
      for (const root of roots) {
        await walk(root, 0);
      }
      return nodes;
    };
    const build = async ({ clearFirst = true, paths = ["/"], maxDepth, count = true, shouldCancel } = {}) => {
      ensureSearchState(getState());
      await writeProgress(progress(0, false));
      if (clearFirst) getState().search_nodes = [];
      let nodes = [];
      try {
        if (shouldCancel == null ? void 0 : shouldCancel()) throw new Error("index canceled");
        nodes = await walkNodes(paths, maxDepth, shouldCancel);
        if (shouldCancel == null ? void 0 : shouldCancel()) throw new Error("index canceled");
      } catch (error) {
        await writeProgress(progress(0, true, (error == null ? void 0 : error.message) || String(error), now()));
        throw error;
      }
      if (!clearFirst) {
        for (const path of paths) {
          await del(path, { persist: false });
        }
      }
      getState().search_nodes.push(...nodes);
      const doneAt = now();
      if (count) await writeProgress(progress(nodes.length, true, "", doneAt));
      else await writeProgress(progress(getState().search_nodes.length, true, "", doneAt));
      await saveState2();
    };
    const del = async (path, { persist = true } = {}) => {
      ensureSearchState(getState());
      const normalized = normalizePath(path || "/");
      getState().search_nodes = getState().search_nodes.filter((node) => {
        const current = nodePath(node);
        return current !== normalized && !whereInParent(node, normalized);
      });
      if (persist) await saveState2();
    };
    const search = (req) => {
      ensureSearchState(getState());
      const parent = normalizePath(req.parent || "/");
      const keywords = String(req.keywords || "").toLowerCase().split(/\s+/).filter(Boolean);
      const scope = Number(req.scope || 0);
      const page = Math.max(1, Number(req.page || 1));
      const perPage = Math.max(1, Number(req.per_page || req.perPage || 30));
      const filtered = getState().search_nodes.filter((node) => whereInParent(node, parent)).filter((node) => !keywords.length || keywords.every((keyword) => node.name.toLowerCase().includes(keyword))).filter((node) => scope === 0 || (scope === 1 ? node.is_dir : !node.is_dir)).sort((left, right) => left.name.localeCompare(right.name));
      const start = (page - 1) * perPage;
      return {
        content: filtered.slice(start, start + perPage),
        total: filtered.length
      };
    };
    return {
      build,
      clear,
      del,
      getProgress,
      search,
      writeProgress
    };
  };
  const lastWritten = /* @__PURE__ */ new Map();
  const readJson = async (storage, path) => {
    try {
      const file = await storage.get(path);
      if (file == null ? void 0 : file.text) {
        const content = await file.text();
        lastWritten.set(path, content);
        return JSON.parse(content);
      }
      const value = await file.json();
      lastWritten.set(path, JSON.stringify(value, null, 2));
      return value;
    } catch (_) {
      return null;
    }
  };
  const writeJson = async (storage, path, value) => {
    const content = JSON.stringify(value, null, 2);
    if (lastWritten.get(path) === content) return;
    await storage.put(path, content);
    lastWritten.set(path, content);
  };
  const pickConfigState = (state) => ({
    version: 1,
    settings: state.settings || {},
    users: state.users || [],
    storages: state.storages || [],
    metas: state.metas || [],
    sharings: state.sharings || [],
    ssh_keys: state.ssh_keys || []
  });
  const pickRuntimeState = (state) => ({
    version: 1,
    entries: state.entries || {},
    tasks: state.tasks || {},
    messages: state.messages || [],
    scan: state.scan || { status: "idle", total: 0, done: 0 },
    webdav_locks: state.webdav_locks || {},
    s3_multipart_uploads: state.s3_multipart_uploads || {}
  });
  const pickSearchState = (state) => ({
    version: 1,
    search_nodes: state.search_nodes || []
  });
  const normalizeUsers = (users) => {
    const normalized = Array.isArray(users) ? users.map(normalizeUser) : [];
    if (!normalized.some((user) => user.role === USER_ROLE.ADMIN)) {
      normalized.unshift(defaultAdminUser());
    }
    if (!normalized.some((user) => user.role === USER_ROLE.GUEST)) {
      normalized.push(defaultGuestUser());
    }
    return normalized.map((user, index) => ({
      ...user,
      id: Number(user.id || index + 1),
      disabled: user.role === USER_ROLE.ADMIN ? false : !!user.disabled
    }));
  };
  const normalizeStorages = (storages) => (Array.isArray(storages) ? storages : []).filter((storage) => (storage == null ? void 0 : storage.driver) !== "SiYuanKernel");
  const normalizeDomains = (domains) => {
    if (!domains) return ["config", "runtime", "search"];
    if (typeof domains === "string") return [domains];
    if (Array.isArray(domains)) return domains;
    return ["config", "runtime", "search"];
  };
  const saveState = async (storage, state, domains) => {
    const items = new Set(normalizeDomains(domains));
    if (items.has("config")) await writeJson(storage, CONFIG_FILE, pickConfigState(state));
    if (items.has("runtime")) await writeJson(storage, RUNTIME_FILE, pickRuntimeState(state));
    if (items.has("search")) await writeJson(storage, SEARCH_INDEX_FILE, pickSearchState(state));
  };
  const loadConfigState = async ({ storage }) => {
    const config = await readJson(storage, CONFIG_FILE);
    if (!config) return null;
    return {
      settings: { ...defaultSettings(), ...config.settings || {} },
      users: normalizeUsers(config.users),
      storages: normalizeStorages(config.storages),
      metas: config.metas || [],
      sharings: config.sharings || [],
      ssh_keys: config.ssh_keys || []
    };
  };
  const loadState = async ({ now, storage }) => {
    try {
      const config = await loadConfigState({ storage });
      const runtime = await readJson(storage, RUNTIME_FILE);
      const search = await readJson(storage, SEARCH_INDEX_FILE);
      const legacyState = !config && !runtime && !search ? await readJson(storage, LEGACY_STATE_FILE) : null;
      const loaded = legacyState || (config || runtime || search ? {
        ...runtime || {},
        ...config || {},
        ...search || {}
      } : null);
      if (loaded && (loaded.entries || loaded.users || loaded.storages || loaded.sharings)) {
        return {
          shouldSave: !!legacyState,
          state: {
            ...defaultState(now),
            ...loaded,
            settings: { ...defaultSettings(), ...loaded.settings || {} },
            users: normalizeUsers(loaded.users),
            storages: normalizeStorages(loaded.storages),
            tasks: loaded.tasks || {},
            metas: loaded.metas || [],
            messages: loaded.messages || [],
            ssh_keys: loaded.ssh_keys || [],
            scan: loaded.scan || { status: "idle", total: 0, done: 0 },
            webdav_locks: loaded.webdav_locks || {},
            s3_multipart_uploads: loaded.s3_multipart_uploads || {},
            sharings: loaded.sharings || [],
            search_nodes: loaded.search_nodes || []
          }
        };
      }
    } catch (_) {
    }
    return {
      shouldSave: true,
      state: defaultState(now)
    };
  };
  const createTaskHandlers = ({
    currentUser,
    parseJson,
    queryValue,
    taskStore
  }) => {
    const map = {};
    const parseTaskRequest = async (request2) => {
      const req = await parseJson(request2);
      return {
        req,
        tid: queryValue(request2, "tid") || req.tid || req.id || ""
      };
    };
    const taskId = async (request2) => (await parseTaskRequest(request2)).tid;
    const targeted = (type, callback) => async (request2) => {
      const tid = await taskId(request2);
      const user = currentUser == null ? void 0 : currentUser(request2);
      const task = taskStore.getTask(type, tid, user);
      if (!task) return jsonResponse(failure("task not found", 404));
      await callback(task, tid, user);
      return jsonResponse(success());
    };
    const batch = (type, callback) => async (request2) => {
      const req = await parseJson(request2);
      const user = currentUser == null ? void 0 : currentUser(request2);
      if (!Array.isArray(req)) return jsonResponse(failure("invalid request format", 400));
      const tids = req;
      const errors = {};
      for (const tid of tids) {
        if (!taskStore.getTask(type, tid, user)) {
          errors[tid] = "task not found";
          continue;
        }
        await callback(String(tid), user);
      }
      return jsonResponse(success(errors));
    };
    for (const type of TASK_TYPES) {
      map[`GET /api/task/${type}/undone`] = async (request2) => jsonResponse(success(taskStore.listTasks(type, false, currentUser == null ? void 0 : currentUser(request2))));
      map[`GET /api/task/${type}/done`] = async (request2) => jsonResponse(success(taskStore.listTasks(type, true, currentUser == null ? void 0 : currentUser(request2))));
      const infoHandler = async (request2) => {
        const task = taskStore.getTask(type, await taskId(request2), currentUser == null ? void 0 : currentUser(request2));
        return task ? jsonResponse(success(task)) : jsonResponse(failure("task not found", 404));
      };
      map[`POST /api/task/${type}/info`] = infoHandler;
      map[`GET /api/task/${type}/info`] = infoHandler;
      map[`POST /api/task/${type}/retry`] = targeted(type, async (_, tid, user) => taskStore.retryTask(type, tid, user));
      map[`POST /api/task/${type}/retry_failed`] = async (request2) => {
        await taskStore.retryFailed(type, currentUser == null ? void 0 : currentUser(request2));
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/clear_done`] = async (request2) => {
        await taskStore.clearDone(type, currentUser == null ? void 0 : currentUser(request2));
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/clear_succeeded`] = async (request2) => {
        await taskStore.clearSucceeded(type, currentUser == null ? void 0 : currentUser(request2));
        return jsonResponse(success());
      };
      map[`POST /api/task/${type}/cancel`] = targeted(type, async (_, tid, user) => taskStore.markCanceled(type, tid, user));
      map[`POST /api/task/${type}/delete`] = targeted(type, async (_, tid, user) => taskStore.removeTask(type, tid, user));
      map[`POST /api/task/${type}/cancel_some`] = batch(type, async (tid, user) => taskStore.markCanceled(type, tid, user));
      map[`POST /api/task/${type}/delete_some`] = batch(type, async (tid, user) => taskStore.removeTask(type, tid, user));
      map[`POST /api/task/${type}/retry_some`] = batch(type, async (tid, user) => taskStore.retryTask(type, tid, user));
    }
    return map;
  };
  const normalizeMeta = (input, id) => ({
    id: Number(input.id || input.ID || id || 0),
    path: normalizePath(input.path || input.Path || "/"),
    read_users: Array.isArray(input.read_users) ? input.read_users : [],
    read_users_sub: !!input.read_users_sub,
    write_users: Array.isArray(input.write_users) ? input.write_users : [],
    write_users_sub: !!input.write_users_sub,
    password: String(input.password || ""),
    p_sub: !!input.p_sub,
    write: !!input.write,
    w_sub: !!input.w_sub,
    hide: String(input.hide || ""),
    h_sub: !!input.h_sub,
    readme: String(input.readme || ""),
    r_sub: !!input.r_sub,
    header: String(input.header || ""),
    header_sub: !!input.header_sub
  });
  const metaCoversPath = (metaPath, path, includeSub) => {
    const meta = normalizePath(metaPath);
    const target = normalizePath(path);
    if (meta === target) return true;
    return !!includeSub && target.startsWith(meta === "/" ? "/" : meta + "/");
  };
  const nearestMeta = (state, path) => {
    const target = normalizePath(path);
    return (state.metas || []).filter((meta) => metaCoversPath(meta.path, target, true)).sort((a, b) => b.path.length - a.path.length)[0] || null;
  };
  const validateHideRules = (hide) => {
    for (const line of String(hide || "").split(/\r?\n/)) {
      if (!line.trim()) continue;
    }
  };
  const isHiddenByMeta = (meta, path, name) => {
    if (!meta || !meta.hide || !metaCoversPath(meta.path, path, meta.h_sub)) return false;
    for (const line of String(meta.hide).split(/\r?\n/)) {
      if (!line.trim()) continue;
      try {
        const pattern = new RegExp(line);
        if (pattern.test(name) || pattern.test(path)) return true;
      } catch (_) {
        return false;
      }
    }
    return false;
  };
  const metaReadme = (meta, path) => meta && metaCoversPath(meta.path, path, meta.r_sub) ? meta.readme : "";
  const metaHeader = (meta, path) => meta && metaCoversPath(meta.path, path, meta.header_sub) ? meta.header : "";
  const canReadByMeta = (user, meta, path) => {
    var _a2;
    if (!user || !meta || !((_a2 = meta.read_users) == null ? void 0 : _a2.length)) return true;
    const userId = Number(user.id || 0);
    return !metaCoversPath(meta.path, path, meta.read_users_sub) || meta.read_users.map(Number).includes(userId);
  };
  const canWriteByMeta = (user, meta, path) => {
    var _a2;
    if (!user || !meta || !((_a2 = meta.write_users) == null ? void 0 : _a2.length)) return true;
    const userId = Number(user.id || 0);
    return !metaCoversPath(meta.path, path, meta.write_users_sub) || meta.write_users.map(Number).includes(userId);
  };
  const canAccessByMeta = (user, meta, path, password2 = "") => {
    if (!user || !meta) return true;
    if (!canSeeHides(user) && isHiddenByMeta(meta, path, path.split("/").pop() || "")) return false;
    if (!canReadByMeta(user, meta, path)) return false;
    if (canAccessWithoutPassword(user)) return true;
    if (!meta.password || !metaCoversPath(meta.path, path, meta.p_sub)) return true;
    return meta.password === password2;
  };
  const MAX_TORRENT_BASE64_LEN = 14 * 1024 * 1024;
  const bytesToString = (bytes2) => {
    const input = Array.from(bytes2 || [], (byte) => String.fromCharCode(byte)).join("");
    try {
      return decodeURIComponent(escape(input));
    } catch (_) {
      return input;
    }
  };
  const base64ToBytes$1 = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "").replace(/-/g, "+").replace(/_/g, "/");
    const bytes2 = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) throw new Error("invalid Base64 encoding");
      bytes2.push(a << 2 | b >> 4);
      if (c >= 0) bytes2.push((b & 15) << 4 | c >> 2);
      if (d >= 0) bytes2.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(bytes2);
  };
  const arrayBufferFrom = (value) => {
    if (value instanceof Uint8Array) return value;
    if (value instanceof ArrayBuffer) return new Uint8Array(value);
    if (Array.isArray(value)) return Uint8Array.from(value.map((item) => Number(item) & 255));
    if (value && typeof value === "object" && Array.isArray(value.data)) {
      return Uint8Array.from(value.data.map((item) => Number(item) & 255));
    }
    return null;
  };
  const firstFileBytes = (files) => {
    for (const value of Object.values(files || {})) {
      const file = Array.isArray(value) ? value[0] : value;
      const data = (file == null ? void 0 : file.data) ?? (file == null ? void 0 : file.Data);
      const bytes2 = arrayBufferFrom(data);
      if (bytes2) return bytes2;
      if (typeof data === "string") return base64ToBytes$1(data);
    }
    return null;
  };
  const torrentBytesFromRequest = (req = {}, { requireBase64 = false } = {}) => {
    const encoded = req.torrent_data || req.torrent || req.content || "";
    if (encoded) {
      if (String(encoded).length > MAX_TORRENT_BASE64_LEN) throw new Error("torrent data too large (max 10MB)");
      return base64ToBytes$1(encoded);
    }
    if (requireBase64) throw new Error("torrent_data is required");
    const fileBytes = firstFileBytes(req.files);
    if (fileBytes) return fileBytes;
    throw new Error("torrent file is required");
  };
  class BencodeParser {
    constructor(bytes2) {
      this.bytes = bytes2;
      this.index = 0;
    }
    readByte() {
      if (this.index >= this.bytes.length) throw new Error("unexpected end of bencode data");
      return this.bytes[this.index++];
    }
    parseValue() {
      const byte = this.readByte();
      if (byte === 105) return this.parseInteger();
      if (byte === 108) return this.parseList();
      if (byte === 100) return this.parseDict();
      if (byte >= 48 && byte <= 57) {
        this.index -= 1;
        return this.parseBytes();
      }
      throw new Error(`unexpected bencode byte ${byte}`);
    }
    parseInteger() {
      let text2 = "";
      while (true) {
        const byte = this.readByte();
        if (byte === 101) break;
        text2 += String.fromCharCode(byte);
      }
      const number2 = Number(text2);
      if (!Number.isFinite(number2)) throw new Error("invalid bencode integer");
      return number2;
    }
    parseBytes() {
      let lengthText = "";
      while (true) {
        const byte = this.readByte();
        if (byte === 58) break;
        if (byte < 48 || byte > 57) throw new Error("invalid bencode string length");
        lengthText += String.fromCharCode(byte);
      }
      const length = Number(lengthText);
      if (!Number.isSafeInteger(length) || length < 0 || length > 100 * 1024 * 1024) {
        throw new Error("bencode string length out of bounds");
      }
      const end = this.index + length;
      if (end > this.bytes.length) throw new Error("unexpected end of bencode string");
      const value = this.bytes.slice(this.index, end);
      this.index = end;
      return value;
    }
    parseList() {
      const list = [];
      while (this.bytes[this.index] !== 101) list.push(this.parseValue());
      this.index += 1;
      return list;
    }
    parseDict() {
      const dict = {};
      while (this.bytes[this.index] !== 101) {
        const key = bytesToString(this.parseBytes());
        dict[key] = this.parseValue();
      }
      this.index += 1;
      return dict;
    }
  }
  const encodeBytes = (bytes2) => Uint8Array.from([
    ...Array.from(String(bytes2.length), (char) => char.charCodeAt(0)),
    58,
    ...bytes2
  ]);
  const concatBytes = (parts) => {
    const length = parts.reduce((sum, part) => sum + part.length, 0);
    const out = new Uint8Array(length);
    let offset = 0;
    for (const part of parts) {
      out.set(part, offset);
      offset += part.length;
    }
    return out;
  };
  const encodeString = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    return encodeBytes(Uint8Array.from(Array.from(text2, (char) => char.charCodeAt(0))));
  };
  const bencodeEncode = (value) => {
    if (typeof value === "number") return Uint8Array.from(Array.from(`i${Math.trunc(value)}e`, (char) => char.charCodeAt(0)));
    if (value instanceof Uint8Array) return encodeBytes(value);
    if (typeof value === "string") return encodeString(value);
    if (Array.isArray(value)) return concatBytes([
      Uint8Array.from([108]),
      ...value.map(bencodeEncode),
      Uint8Array.from([101])
    ]);
    if (value && typeof value === "object") {
      const parts = [Uint8Array.from([100])];
      for (const key of Object.keys(value).sort()) {
        parts.push(encodeString(key), bencodeEncode(value[key]));
      }
      parts.push(Uint8Array.from([101]));
      return concatBytes(parts);
    }
    throw new Error("unsupported bencode value");
  };
  const hex$1 = (bytes2) => Array.from(bytes2, (byte) => byte.toString(16).padStart(2, "0")).join("");
  const rol = (value, bits2) => value << bits2 | value >>> 32 - bits2;
  const utf8Bytes = (value) => {
    const text2 = unescape(encodeURIComponent(String(value || "")));
    return Uint8Array.from(Array.from(text2, (char) => char.charCodeAt(0)));
  };
  const bytesToBase64$1 = (bytes2) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let output = "";
    for (let index = 0; index < bytes2.length; index += 3) {
      const a = bytes2[index];
      const hasB = index + 1 < bytes2.length;
      const hasC = index + 2 < bytes2.length;
      const b = hasB ? bytes2[index + 1] : 0;
      const c = hasC ? bytes2[index + 2] : 0;
      output += chars2[a >> 2];
      output += chars2[(a & 3) << 4 | b >> 4];
      output += hasB ? chars2[(b & 15) << 2 | c >> 6] : "=";
      output += hasC ? chars2[c & 63] : "=";
    }
    return output;
  };
  const md5Hex = (input) => {
    const source = input instanceof Uint8Array ? input : utf8Bytes(input);
    const bitLen = source.length * 8;
    const paddedLen = source.length + 9 + 63 >> 6 << 6;
    const bytes2 = new Uint8Array(paddedLen);
    bytes2.set(source);
    bytes2[source.length] = 128;
    const view = new DataView(bytes2.buffer);
    view.setUint32(paddedLen - 8, bitLen >>> 0, true);
    view.setUint32(paddedLen - 4, Math.floor(bitLen / 4294967296), true);
    let a0 = 1732584193;
    let b0 = 4023233417;
    let c0 = 2562383102;
    let d0 = 271733878;
    const s = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21];
    const k = Array.from({ length: 64 }, (_, i2) => Math.floor(Math.abs(Math.sin(i2 + 1)) * 4294967296) >>> 0);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      let a = a0;
      let b = b0;
      let c = c0;
      let d = d0;
      for (let i2 = 0; i2 < 64; i2 += 1) {
        let f;
        let g;
        if (i2 < 16) {
          f = b & c | ~b & d;
          g = i2;
        } else if (i2 < 32) {
          f = d & b | ~d & c;
          g = (5 * i2 + 1) % 16;
        } else if (i2 < 48) {
          f = b ^ c ^ d;
          g = (3 * i2 + 5) % 16;
        } else {
          f = c ^ (b | ~d);
          g = 7 * i2 % 16;
        }
        const tmp = d;
        d = c;
        c = b;
        b = b + rol(a + f + k[i2] + view.getUint32(offset + g * 4, true) >>> 0, s[i2]) >>> 0;
        a = tmp;
      }
      a0 = a0 + a >>> 0;
      b0 = b0 + b >>> 0;
      c0 = c0 + c >>> 0;
      d0 = d0 + d >>> 0;
    }
    const out = new Uint8Array(16);
    const outView = new DataView(out.buffer);
    [a0, b0, c0, d0].forEach((value, index) => outView.setUint32(index * 4, value, true));
    return hex$1(out);
  };
  class HashWriter {
    constructor(pieceLength = DEFAULT_TORRENT_PIECE_SIZE) {
      this.pieceLength = Math.max(1, Number(pieceLength || DEFAULT_TORRENT_PIECE_SIZE));
      this.bytes = [];
      this.fileBytes = [];
      this.pieces = [];
      this.sliceMd5s = [];
    }
    write(chunk) {
      const data = chunk instanceof Uint8Array ? chunk : new Uint8Array(chunk || []);
      if (!data.length) return;
      this.fileBytes.push(data);
      for (let offset = 0; offset < data.length; ) {
        const remain = this.pieceLength - this.bytes.length;
        const part = data.slice(offset, offset + remain);
        this.bytes.push(...part);
        offset += part.length;
        if (this.bytes.length >= this.pieceLength) this.finishPiece();
      }
    }
    finishPiece() {
      const piece = Uint8Array.from(this.bytes);
      this.pieces.push(sha1Bytes(piece));
      this.sliceMd5s.push(md5Hex(piece).toUpperCase());
      this.bytes = [];
    }
    finish() {
      if (this.bytes.length || !this.pieces.length) this.finishPiece();
    }
    source() {
      return concatBytes(this.fileBytes);
    }
  }
  const sha1Bytes = (message) => {
    const bitLen = message.length * 8;
    const paddedLen = message.length + 9 + 63 >> 6 << 6;
    const padded = new Uint8Array(paddedLen);
    padded.set(message);
    padded[message.length] = 128;
    const view = new DataView(padded.buffer);
    view.setUint32(paddedLen - 4, bitLen >>> 0);
    view.setUint32(paddedLen - 8, Math.floor(bitLen / 4294967296));
    let h0 = 1732584193;
    let h1 = 4023233417;
    let h2 = 2562383102;
    let h3 = 271733878;
    let h4 = 3285377520;
    const w = new Uint32Array(80);
    for (let offset = 0; offset < paddedLen; offset += 64) {
      for (let i2 = 0; i2 < 16; i2 += 1) w[i2] = view.getUint32(offset + i2 * 4);
      for (let i2 = 16; i2 < 80; i2 += 1) w[i2] = rol(w[i2 - 3] ^ w[i2 - 8] ^ w[i2 - 14] ^ w[i2 - 16], 1) >>> 0;
      let a = h0;
      let b = h1;
      let c = h2;
      let d = h3;
      let e = h4;
      for (let i2 = 0; i2 < 80; i2 += 1) {
        let f;
        let k;
        if (i2 < 20) {
          f = b & c | ~b & d;
          k = 1518500249;
        } else if (i2 < 40) {
          f = b ^ c ^ d;
          k = 1859775393;
        } else if (i2 < 60) {
          f = b & c | b & d | c & d;
          k = 2400959708;
        } else {
          f = b ^ c ^ d;
          k = 3395469782;
        }
        const temp = rol(a, 5) + f + e + k + w[i2] >>> 0;
        e = d;
        d = c;
        c = rol(b, 30) >>> 0;
        b = a;
        a = temp;
      }
      h0 = h0 + a >>> 0;
      h1 = h1 + b >>> 0;
      h2 = h2 + c >>> 0;
      h3 = h3 + d >>> 0;
      h4 = h4 + e >>> 0;
    }
    const out = new Uint8Array(20);
    const outView = new DataView(out.buffer);
    [h0, h1, h2, h3, h4].forEach((value, index) => outView.setUint32(index * 4, value));
    return out;
  };
  const asText = (value) => value instanceof Uint8Array ? bytesToString(value) : String(value || "");
  const asNumber = (value) => Number(value || 0);
  const DEFAULT_TORRENT_PIECE_SIZE = 10 * 1024 * 1024;
  const parseTorrentBytes = (bytes2) => {
    const parser = new BencodeParser(bytes2);
    const root = parser.parseValue();
    if (!root || typeof root !== "object" || Array.isArray(root)) throw new Error("torrent: root is not a dict");
    const info = root.info;
    if (!info || typeof info !== "object" || Array.isArray(info)) throw new Error("torrent: info is not a dict");
    const pieces = info.pieces instanceof Uint8Array ? info.pieces : new Uint8Array();
    if (pieces.length % 20 !== 0) throw new Error("torrent pieces data is invalid: length must be a multiple of 20");
    const files = Array.isArray(info.files) && info.files.length ? info.files.map((file) => ({
      path: Array.isArray(file.path) ? file.path.map(asText).join("/") : "",
      size: asNumber(file.length)
    })) : [{ path: asText(info.name), size: asNumber(info.length) }];
    const totalSize = files.reduce((sum, file) => sum + Number(file.size || 0), 0);
    const cas = root["x-cas"] && typeof root["x-cas"] === "object" ? root["x-cas"] : null;
    const hasCas = !!(cas && cas.file_md5 && cas.slice_md5);
    return {
      name: asText(info.name),
      total_size: totalSize,
      piece_length: asNumber(info["piece length"]),
      piece_count: pieces.length / 20,
      info_hash: hex$1(sha1Bytes(bencodeEncode(info))),
      files,
      has_cas: hasCas,
      ...hasCas ? {
        cas: {
          file_md5: asText(cas.file_md5),
          slice_md5: asText(cas.slice_md5),
          slice_size: asNumber(cas.slice_size),
          cloud: asText(cas.cloud)
        }
      } : {}
    };
  };
  const generateTorrentBytes = (bytes2, {
    createdBy = "OpenList",
    name = "download.bin",
    pieceLength = DEFAULT_TORRENT_PIECE_SIZE,
    withCas = false
  } = {}) => {
    const source = bytes2 instanceof Uint8Array ? bytes2 : new Uint8Array(bytes2 || []);
    const pieceSize = Math.max(1, Number(pieceLength || DEFAULT_TORRENT_PIECE_SIZE));
    const pieces = [];
    const sliceMd5s = [];
    for (let offset = 0; offset < source.length || source.length === 0 && offset === 0; offset += pieceSize) {
      const chunk = source.slice(offset, Math.min(offset + pieceSize, source.length));
      pieces.push(sha1Bytes(chunk));
      sliceMd5s.push(md5Hex(chunk).toUpperCase());
      if (source.length === 0) break;
    }
    const fileMd5 = md5Hex(source).toUpperCase();
    const info = {
      length: source.length,
      md5sum: fileMd5,
      name,
      "piece length": pieceSize,
      pieces: concatBytes(pieces)
    };
    const root = {
      comment: withCas ? "Generated by OpenList with CAS extension" : "Generated by OpenList",
      "created by": createdBy,
      "creation date": Math.floor(Date.now() / 1e3),
      info
    };
    if (withCas) {
      root["x-cas"] = {
        cloud: "189",
        file_md5: fileMd5,
        slice_md5: sliceMd5s.length > 1 ? md5Hex(sliceMd5s.join("\n")).toUpperCase() : fileMd5,
        slice_md5s: sliceMd5s,
        slice_size: pieceSize
      };
    }
    const torrent = bencodeEncode(root);
    return {
      info_hash: hex$1(sha1Bytes(bencodeEncode(info))),
      torrent
    };
  };
  const generateTorrentFromChunks = (chunks, {
    createdBy = "OpenList",
    name = "download.bin",
    pieceLength = DEFAULT_TORRENT_PIECE_SIZE,
    size = 0,
    withCas = false
  } = {}) => {
    const writer = new HashWriter(pieceLength);
    for (const chunk of chunks || []) writer.write(chunk);
    writer.finish();
    const source = writer.source();
    const fileMd5 = md5Hex(source).toUpperCase();
    const pieceSize = Math.max(1, Number(pieceLength || DEFAULT_TORRENT_PIECE_SIZE));
    const info = {
      length: Number(size || source.length),
      md5sum: fileMd5,
      name,
      "piece length": pieceSize,
      pieces: concatBytes(writer.pieces)
    };
    const root = {
      comment: withCas ? "Generated by OpenList with CAS extension" : "Generated by OpenList",
      "created by": createdBy,
      "creation date": Math.floor(Date.now() / 1e3),
      info
    };
    if (withCas) {
      root["x-cas"] = {
        cloud: "189",
        file_md5: fileMd5,
        slice_md5: writer.sliceMd5s.length > 1 ? md5Hex(writer.sliceMd5s.join("\n")).toUpperCase() : fileMd5,
        slice_md5s: writer.sliceMd5s,
        slice_size: pieceSize
      };
    }
    const torrent = bencodeEncode(root);
    return {
      info_hash: hex$1(sha1Bytes(bencodeEncode(info))),
      torrent
    };
  };
  const createFsHandlers = ({
    client,
    cloneEntryTree,
    createFile: createFile2,
    currentUser,
    driverRuntime,
    ensureDir,
    getState,
    isWorkspacePath,
    moveEntryTree,
    now,
    page,
    parseJson,
    removeEmptyDirs,
    removeEntry,
    renameEntryInDir,
    saveConfigState,
    saveState: saveState2,
    searchIndex,
    shareGet,
    shareClientIP: shareClientIP2,
    shareList,
    siyuanApiJson,
    taskStore,
    toFsGetResp,
    toObjResp,
    workspaceGet,
    workspaceList,
    workspaceReadText,
    workspaceRelPath
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const boolValue2 = (value, fallback = false) => {
      if (value === void 0 || value === null || value === "") return fallback;
      return value === true || value === "true" || value === 1 || value === "1";
    };
    const storageShouldProxy = (storage) => {
      var _a2;
      const config = ((_a2 = driverInfoMap()[storage == null ? void 0 : storage.driver]) == null ? void 0 : _a2.config) || {};
      return boolValue2(config.only_proxy) || boolValue2(storage == null ? void 0 : storage.web_proxy, boolValue2(config.prefer_proxy));
    };
    const proxyRawUrl = (path) => `/plugin/private/siyuan-cloud/p${normalizePath(path)}`;
    const rawUrlForStorage = (storage, path, linkUrl = "") => storageShouldProxy(storage) ? proxyRawUrl(path) : linkUrl;
    const motrixNextApiUrl = (value) => {
      const apiUrl = String(value || `http://127.0.0.1:29110`).trim().replace(/\/+$/, "");
      if (!/^https?:\/\/[^/\s]+/i.test(apiUrl)) throw new Error("Motrix Next API URL must start with http:// or https://");
      return apiUrl;
    };
    const requestMeta = (request2) => (request2 == null ? void 0 : request2.request) || (request2 == null ? void 0 : request2.Request) || {};
    const requestHeaders2 = (request2) => {
      var _a2, _b2;
      return ((_a2 = requestMeta(request2)) == null ? void 0 : _a2.headers) || ((_b2 = requestMeta(request2)) == null ? void 0 : _b2.Headers) || {};
    };
    const requestHeader2 = (request2, name) => {
      const target = String(name || "").toLowerCase();
      for (const [key, value] of Object.entries(requestHeaders2(request2))) {
        if (String(key).toLowerCase() !== target) continue;
        return Array.isArray(value) ? String(value[0] || "") : String(value || "");
      }
      return "";
    };
    const requestContentType = (request2) => {
      var _a2, _b2;
      return requestHeader2(request2, "Content-Type") || ((_a2 = requestMeta(request2)) == null ? void 0 : _a2.contentType) || ((_b2 = requestMeta(request2)) == null ? void 0 : _b2.ContentType) || "application/octet-stream";
    };
    const decodePathValue = (value) => {
      const input = String(value || "");
      if (!input) return "";
      try {
        return decodeURIComponent(input);
      } catch (_) {
        return input;
      }
    };
    const requestBodyData = (request2) => {
      var _a2, _b2;
      const body = ((_a2 = requestMeta(request2)) == null ? void 0 : _a2.body) || ((_b2 = requestMeta(request2)) == null ? void 0 : _b2.Body) || {};
      return body.data !== void 0 ? body.data : body.Data;
    };
    const firstFormFile = (files) => {
      for (const value of Object.values(files || {})) {
        if (Array.isArray(value) && value[0]) return value[0];
      }
      return null;
    };
    const arrayBufferFromBytes = (value) => {
      if (value instanceof Uint8Array) return value;
      if (value instanceof ArrayBuffer) return new Uint8Array(value);
      if (Array.isArray(value)) return Uint8Array.from(value.map((item) => Number(item) & 255));
      if (value && typeof value === "object" && Array.isArray(value.data)) {
        return Uint8Array.from(value.data.map((item) => Number(item) & 255));
      }
      return null;
    };
    const bytesToBase642 = (bytes2) => {
      if (!bytes2 || !bytes2.length) return "";
      const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      let output = "";
      for (let index = 0; index < bytes2.length; index += 3) {
        const a = bytes2[index];
        const hasB = index + 1 < bytes2.length;
        const hasC = index + 2 < bytes2.length;
        const b = hasB ? bytes2[index + 1] : 0;
        const c = hasC ? bytes2[index + 2] : 0;
        output += chars2[a >> 2];
        output += chars2[(a & 3) << 4 | b >> 4];
        output += hasB ? chars2[(b & 15) << 2 | c >> 6] : "=";
        output += hasC ? chars2[c & 63] : "=";
      }
      return output;
    };
    const overwriteEnabled = (request2, req) => {
      const header = requestHeader2(request2, "Overwrite");
      if (header) return header !== "false";
      if (req.overwrite === void 0 || req.overwrite === null || req.overwrite === "") return true;
      return boolValue2(req.overwrite, true);
    };
    const uploadTargetExists = async (path) => {
      if (isWorkspacePath(path)) {
        const payload = await siyuanApiJson("/api/file/readDir", { path: workspaceRelPath(dirname(path)) });
        if (payload.code !== 0) return false;
        return (payload.data || []).some((entry) => (entry == null ? void 0 : entry.name) === basename(path));
      }
      const mount = driverRuntime.resolve(state.storages, path);
      if (mount) {
        try {
          await mount.driver.get(mount.storage, mount.relPath, { skipLink: true });
          return true;
        } catch (_) {
          return false;
        }
      }
      return !!state.entries[path];
    };
    const uploadFromRawRequest = async (request2, req, fallbackName) => {
      const rawPath = req.path || req.file_path || req.name || decodePathValue(requestHeader2(request2, "File-Path")) || fallbackName;
      const path = normalizePath(rawPath);
      const mime = req.mime || requestContentType(request2);
      const data = requestBodyData(request2);
      if (typeof data === "string") {
        return { body: data, bodyEncoding: "text", mime, path, size: data.length };
      }
      const bytes2 = arrayBufferFromBytes(data);
      if (bytes2) {
        return {
          body: bytesToBase642(bytes2),
          bodyEncoding: "base64",
          mime,
          path,
          size: bytes2.byteLength
        };
      }
      const content = req.content ?? req.data ?? "";
      const bodyEncoding = String(req.body_encoding || req.bodyEncoding || "").toLowerCase() === "base64" ? "base64" : "text";
      return {
        body: String(content),
        bodyEncoding,
        mime,
        path,
        size: Number(req.size || 0) || (bodyEncoding === "base64" ? Math.floor(String(content).length * 3 / 4) : String(content).length)
      };
    };
    const uploadFromFormRequest = async (request2, req) => {
      var _a2, _b2, _c, _d;
      const file = firstFormFile(req.files);
      const fileData = (file == null ? void 0 : file.data) ?? (file == null ? void 0 : file.Data);
      const bytes2 = arrayBufferFromBytes(fileData);
      const filename = (file == null ? void 0 : file.filename) || (file == null ? void 0 : file.Filename) || req.file_name || req.name || "upload.bin";
      const path = normalizePath(req.path || req.file_path || decodePathValue(requestHeader2(request2, "File-Path")) || joinPath2(req.dir || dirname(req.path || "/"), filename));
      const mime = ((_b2 = (_a2 = file == null ? void 0 : file.headers) == null ? void 0 : _a2["Content-Type"]) == null ? void 0 : _b2[0]) || ((_d = (_c = file == null ? void 0 : file.Headers) == null ? void 0 : _c["Content-Type"]) == null ? void 0 : _d[0]) || req.mime || requestContentType(request2);
      if (bytes2) {
        return {
          body: bytesToBase642(bytes2),
          bodyEncoding: "base64",
          mime,
          path,
          size: bytes2.byteLength
        };
      }
      if (Number((file == null ? void 0 : file.size) || (file == null ? void 0 : file.Size) || 0) > 0) throw new Error("upload file body is empty");
      return {
        body: "",
        bodyEncoding: "text",
        mime,
        path,
        size: Number((file == null ? void 0 : file.size) || (file == null ? void 0 : file.Size) || 0)
      };
    };
    const joinPath2 = (dir, name) => normalizePath(`${normalizePath(dir || "/").replace(/\/+$/, "")}/${String(name).replace(/^\/+/, "")}`);
    const driverPut = async (mount, upload) => {
      await mount.driver.put(mount.storage, mount.relPath, upload.body, upload.mime, {
        bodyEncoding: upload.bodyEncoding,
        size: upload.size
      });
    };
    const sameStorageMount = (left, right) => {
      var _a2, _b2, _c, _d;
      return !!left && !!right && (((_a2 = left.storage) == null ? void 0 : _a2.id) && ((_b2 = right.storage) == null ? void 0 : _b2.id) && left.storage.id === right.storage.id || normalizePath(((_c = left.storage) == null ? void 0 : _c.mount_path) || "/") === normalizePath(((_d = right.storage) == null ? void 0 : _d.mount_path) || "/"));
    };
    const torrentNotImplemented = (operation) => ({
      operation,
      reason: "torrent CAS rapid upload and generation are not implemented in the SiYuan kernel JavaScript port yet.",
      upstream_source: "server/handles/torrent.go + pkg/torrent/* + drivers/189pc/torrent.go",
      next: "Port 189/189PC CAS rapid-upload and RangeReader-backed torrent generation before enabling this route."
    });
    const fsTorrentRequiredError = (field2) => jsonResponse(failure(`${field2} is required`, 400), 400);
    const fsTorrentValidate = (operation, req = {}) => {
      if ((operation === "parse" || operation === "rapid_upload") && !req.torrent_data)
        return fsTorrentRequiredError("torrent_data");
      if ((operation === "rapid_upload" || operation === "generate") && !req.path)
        return fsTorrentRequiredError("path");
      return null;
    };
    const fsTorrentParse = (req, options = {}) => {
      try {
        return jsonResponse(success(parseTorrentBytes(torrentBytesFromRequest(req, options))));
      } catch (error) {
        return jsonResponse(failure(error.message || "parse torrent failed", 400), 400);
      }
    };
    const fsTorrentUploadParse = (req) => {
      try {
        const bytes2 = torrentBytesFromRequest(req);
        return jsonResponse(success({
          info: parseTorrentBytes(bytes2),
          torrent_data: bytesToBase642(bytes2)
        }));
      } catch (error) {
        return jsonResponse(failure(error.message || "parse torrent failed", 400), 400);
      }
    };
    const base64ToBytes2 = (value) => {
      const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      const clean = String(value || "").replace(/[\r\n\s]/g, "").replace(/-/g, "+").replace(/_/g, "/");
      const bytes2 = [];
      for (let i2 = 0; i2 < clean.length; i2 += 4) {
        const a = chars2.indexOf(clean[i2]);
        const b = chars2.indexOf(clean[i2 + 1]);
        const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
        const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
        if (a < 0 || b < 0) continue;
        bytes2.push(a << 2 | b >> 4);
        if (c >= 0) bytes2.push((b & 15) << 4 | c >> 2);
        if (d >= 0) bytes2.push((c & 3) << 6 | d);
      }
      return Uint8Array.from(bytes2);
    };
    const textToBytes = (value) => {
      const text2 = unescape(encodeURIComponent(String(value || "")));
      return Uint8Array.from(Array.from(text2, (char) => char.charCodeAt(0)));
    };
    const bytesFromDriverRead2 = (data) => {
      if (!data || data.link) return null;
      if (String(data.bodyEncoding || data.body_encoding || "").startsWith("base64"))
        return base64ToBytes2(data.body || "");
      if (data.body !== void 0) return textToBytes(data.body || "");
      return null;
    };
    const decodeBase64Error2 = (value) => {
      const input = String(value || "");
      if (!input) return "";
      try {
        return new TextDecoder().decode(base64ToBytes2(input)) || input;
      } catch (_) {
        return input;
      }
    };
    const bytesFromDriverLink2 = async (data) => {
      var _a2, _b2;
      if (!client || !(data == null ? void 0 : data.link)) return null;
      const link2 = linkFromDriverData(data);
      const resp = await forwardProxy(client, link2.url, {
        allowErrorStatus: true,
        contentType: "",
        headers: {
          ...link2.header || ((_a2 = data.link) == null ? void 0 : _a2.headers) || {},
          Range: "bytes=0-"
        },
        method: link2.method || "GET",
        responseEncoding: "base64",
        timeout: 12e4
      });
      if (Number(resp.status || 0) >= 400) throw new Error(`HTTP ${resp.status}: ${String(resp.body || "").slice(0, 200)}`);
      const bytes2 = base64ToBytes2(resp.body || "");
      if (!bytes2.byteLength && Number(link2.content_length || ((_b2 = data.link) == null ? void 0 : _b2.content_length) || 0) > 0) throw new Error("driver link returned empty file body");
      return bytes2;
    };
    const driverLinkChunks = async (data, size, chunkSize = DEFAULT_TORRENT_PIECE_SIZE) => {
      var _a2, _b2;
      const chunks = [];
      if (!client || !(data == null ? void 0 : data.link)) return chunks;
      const link2 = linkFromDriverData(data);
      const total = Number(size || link2.content_length || ((_a2 = data.link) == null ? void 0 : _a2.content_length) || 0);
      if (!total) {
        const bytes2 = await bytesFromDriverLink2(data);
        if (bytes2) chunks.push(bytes2);
        return chunks;
      }
      for (let offset = 0; offset < total; offset += chunkSize) {
        const end = Math.min(offset + chunkSize, total) - 1;
        const resp = await forwardProxy(client, link2.url, {
          allowErrorStatus: true,
          contentType: "",
          headers: {
            ...link2.header || ((_b2 = data.link) == null ? void 0 : _b2.headers) || {},
            Range: `bytes=${offset}-${end}`
          },
          method: link2.method || "GET",
          responseEncoding: "base64",
          timeout: 12e4
        });
        if (Number(resp.status || 0) >= 400) throw new Error(`HTTP ${resp.status}: ${decodeBase64Error2(resp.body || "").slice(0, 300)}`);
        const bytes2 = base64ToBytes2(resp.body || "");
        if (!bytes2.byteLength && end >= offset) throw new Error("driver link returned empty file body");
        chunks.push(bytes2.slice(0, end - offset + 1));
      }
      return chunks;
    };
    const torrentSourceFromPath = async (path) => {
      var _a2, _b2, _c;
      if (isWorkspacePath(path)) {
        const file = await workspaceReadText(path);
        if (!file.ok) throw new Error(file.text || "not found");
        return { bytes: textToBytes(file.text || ""), name: basename(path), size: String(file.text || "").length };
      }
      const mount = driverRuntime.resolve(state.storages, path);
      if ((_a2 = mount == null ? void 0 : mount.driver) == null ? void 0 : _a2.get) {
        const obj = await mount.driver.get(mount.storage, mount.relPath, { skipLink: true });
        if (obj == null ? void 0 : obj.is_dir) throw new Error("directories are not supported for torrent generation");
        if (!mount.driver.read) throw new Error("this storage does not expose a readable file body");
        const readData = await mount.driver.read(mount.storage, mount.relPath, {});
        const inlineBytes = bytesFromDriverRead2(readData);
        if (inlineBytes) return { bytes: inlineBytes, mount, name: (obj == null ? void 0 : obj.name) || basename(path), size: Number((obj == null ? void 0 : obj.size) || inlineBytes.byteLength) };
        if (readData == null ? void 0 : readData.link) return {
          chunks: await driverLinkChunks(readData, Number((obj == null ? void 0 : obj.size) || ((_b2 = readData.link) == null ? void 0 : _b2.content_length) || 0)),
          mount,
          name: (obj == null ? void 0 : obj.name) || basename(path),
          size: Number((obj == null ? void 0 : obj.size) || ((_c = readData.link) == null ? void 0 : _c.content_length) || 0)
        };
        const bytes3 = await bytesFromDriverLink2(readData);
        if (!bytes3 || !bytes3.byteLength) throw new Error("this storage does not expose a readable file body");
        return { bytes: bytes3, mount, name: (obj == null ? void 0 : obj.name) || basename(path), size: Number((obj == null ? void 0 : obj.size) || bytes3.byteLength) };
      }
      const entry = state.entries[path];
      if (!entry || entry.is_dir) throw new Error((entry == null ? void 0 : entry.is_dir) ? "directories are not supported for torrent generation" : "object not found");
      const bytes2 = String(entry.body_encoding || "").startsWith("base64") ? base64ToBytes2(entry.content || "") : textToBytes(entry.content || "");
      return { bytes: bytes2, name: entry.name || basename(path), size: Number(entry.size || bytes2.byteLength) };
    };
    const fsTorrentGenerate = async (req) => {
      var _a2, _b2;
      try {
        const path = normalizePath(req.path || "/");
        const source = await torrentSourceFromPath(path);
        if (source.size > 1024 * 1024 * 1024) return jsonResponse(failure("file too large to generate torrent (max 1GB)", 400), 400);
        if (boolValue2(req.with_cas, false) && !["189Cloud", "189CloudPC"].includes(((_b2 = (_a2 = source.mount) == null ? void 0 : _a2.storage) == null ? void 0 : _b2.driver) || ""))
          return jsonResponse(failure("CAS torrent generation only supports 189Cloud/189CloudPC storage", 400), 400);
        const generated = source.chunks ? generateTorrentFromChunks(source.chunks, {
          name: source.name,
          size: source.size,
          withCas: boolValue2(req.with_cas, false)
        }) : generateTorrentBytes(source.bytes, {
          name: source.name,
          withCas: boolValue2(req.with_cas, false)
        });
        return jsonResponse(success({
          file_name: `${source.name}.torrent`,
          info_hash: generated.info_hash,
          size: generated.torrent.byteLength,
          torrent_data: bytesToBase64$1(generated.torrent),
          with_cas: boolValue2(req.with_cas, false)
        }));
      } catch (error) {
        return jsonResponse(failure(error.message || "generate torrent failed", 400), 400);
      }
    };
    const fsTorrentRapidUpload = async (req) => {
      try {
        const bytes2 = torrentBytesFromRequest(req, { requireBase64: true });
        const info = parseTorrentBytes(bytes2);
        if (!info.has_cas) return jsonResponse(failure("torrent does not contain CAS extension information", 400), 400);
        const mount = driverRuntime.resolve(state.storages, normalizePath(req.path || "/"));
        if (!mount) return jsonResponse(failure("target storage does not support CAS rapid upload", 400), 400);
        if (!mount.driver.rapidUploadFromTorrent)
          return jsonResponse(failure("target storage does not expose CAS rapid upload", 501, torrentNotImplemented("rapid_upload")), 501);
        const obj = await mount.driver.rapidUploadFromTorrent(mount.storage, mount.relPath, bytes2, {
          overwrite: req.overwrite !== false
        });
        return jsonResponse(success({
          file_name: (obj == null ? void 0 : obj.name) || info.name,
          file_size: Number((obj == null ? void 0 : obj.size) || info.total_size || 0),
          message: "rapid upload succeeded"
        }));
      } catch (error) {
        return jsonResponse(failure(error.message || "torrent rapid upload failed", 400), 400);
      }
    };
    const shouldSkipExisting = (req) => boolValue2(req.skip_existing, false);
    const shouldMerge = (req) => boolValue2(req.merge, false);
    const shouldOverwrite = (req) => boolValue2(req.overwrite, false);
    const permissionDenied = () => failure("permission denied", 403);
    const pathWithinBase2 = (path, basePath) => {
      const target = normalizePath(path);
      const base = normalizePath(basePath || "/");
      return base === "/" || target === base || target.startsWith(`${base}/`);
    };
    const requestUser = (request2) => currentUser == null ? void 0 : currentUser(request2);
    const joinUserPath = (user, path) => {
      const target = normalizePath(path || "/");
      if (!user || isAdminUser(user)) return target;
      if (!pathWithinBase2(target, user.base_path)) return null;
      return target;
    };
    const readMeta = (path) => nearestMeta(getState(), path);
    const canAccessFs = (user, path, password2 = "") => {
      const meta = readMeta(path);
      return canAccessByMeta(user, meta, path, password2);
    };
    const canReadFs = (user, path) => canReadByMeta(user, readMeta(path), path);
    const canWriteFs = (user, path) => canWriteByMeta(user, readMeta(path), path);
    const writeContentBypass = (path) => {
      const meta = readMeta(path);
      return !!((meta == null ? void 0 : meta.write) && metaCoversPath(meta.path, path, meta.w_sub));
    };
    const driverTargetIsDir = async (path) => {
      var _a2;
      const mount = driverRuntime.resolve(state.storages, path);
      if (!mount) return false;
      try {
        return !!((_a2 = await mount.driver.get(mount.storage, mount.relPath, { skipLink: true })) == null ? void 0 : _a2.is_dir);
      } catch (_) {
        return false;
      }
    };
    const driverList = async (mount, relPath, refresh = false) => {
      var _a2;
      return ((_a2 = await mount.driver.list(mount.storage, relPath, { page: 1, per_page: 1e5, refresh })) == null ? void 0 : _a2.content) || [];
    };
    const driverRemoveIfExists = async (mount, relPath) => {
      if (!mount.driver.remove) return;
      try {
        await mount.driver.remove(mount.storage, relPath);
      } catch (_) {
      }
    };
    const extensionType = (name, isDir2) => {
      if (isDir2) return 1;
      const ext = String(name).toLowerCase().split(".").pop() || "";
      if (["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif"].includes(ext)) return 2;
      if (["mp4", "mkv", "mov", "avi", "webm", "m4v"].includes(ext)) return 3;
      if (["mp3", "flac", "wav", "ogg", "m4a"].includes(ext)) return 4;
      if (["zip", "7z", "rar", "tar", "gz", "bz2"].includes(ext)) return 5;
      if (["pdf", "epub", "txt", "md", "json", "yaml", "yml", "csv", "log"].includes(ext)) return 6;
      return 0;
    };
    const driverObjResp = (item) => ({
      name: item.name || "",
      size: Number(item.size || 0),
      is_dir: !!item.is_dir,
      modified: item.modified || (/* @__PURE__ */ new Date()).toISOString(),
      created: item.created || item.modified || (/* @__PURE__ */ new Date()).toISOString(),
      sign: item.sign || "",
      thumb: item.thumb || "",
      type: Number(item.type || extensionType(item.name, item.is_dir)),
      hashinfo: item.hashinfo || "",
      hash_info: item.hash_info || {}
    });
    const driverListResp = (data) => {
      const content = (data.content || []).map(driverObjResp);
      return {
        content,
        total: Number(data.total || content.length),
        readme: data.readme || "",
        header: data.header || "",
        write: data.write !== false,
        write_content_bypass: data.write_content_bypass !== false,
        provider: data.provider || "unknown",
        direct_upload_tools: data.direct_upload_tools || []
      };
    };
    const driverGetResp = (data, rawUrl = "") => ({
      ...driverObjResp(data),
      raw_url: rawUrl || data.raw_url || "",
      readme: data.readme || "",
      header: data.header || "",
      provider: data.provider || "unknown",
      related: (data.related || []).map(driverObjResp)
    });
    const handlers = {
      "ANY /api/fs/list": async (request2) => {
        const req = await parseJson(request2);
        const path = normalizePath(req.path);
        const sharing = await shareList({ ...req, client_ip: shareClientIP2 == null ? void 0 : shareClientIP2(request2), path });
        if (sharing == null ? void 0 : sharing.error) return jsonResponse(sharing.error);
        if (sharing == null ? void 0 : sharing.data) return jsonResponse(success(sharing.data));
        const user = requestUser(request2);
        if (!joinUserPath(user, path) || !canAccessFs(user, path, req.password || req.pwd)) return jsonResponse(permissionDenied());
        if (isWorkspacePath(path)) {
          const result = await workspaceList(path, req);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success(result.data));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            const data = await mount.driver.list(mount.storage, mount.relPath, req);
            return jsonResponse(success(driverListResp(data)));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver list failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        const entry = state.entries[path];
        if (!entry || !entry.is_dir) return jsonResponse(failure("directory not found", 404));
        const meta = nearestMeta(getState(), path);
        const canWriteAtPath = canWriteFs(user, path);
        const children = entry.children.map((childPath) => state.entries[childPath]).filter(Boolean).filter((item) => !isHiddenByMeta(meta, item.path, item.name)).map(toObjResp);
        if (path === "/") {
          for (const mountEntry of driverRuntime.mountEntries(state.storages, now)) {
            if (!children.some((item) => item.name === mountEntry.name)) children.unshift(toObjResp(mountEntry));
          }
        }
        const content = page(children, req);
        return jsonResponse(success({
          content,
          total: children.length,
          readme: metaReadme(meta, path),
          header: metaHeader(meta, path),
          write: canWriteAtPath,
          write_content_bypass: writeContentBypass(path),
          provider: "siyuan-storage",
          direct_upload_tools: []
        }));
      },
      "ANY /api/fs/get": async (request2) => {
        const req = await parseJson(request2);
        const path = normalizePath(req.path);
        const sharing = await shareGet({ ...req, client_ip: shareClientIP2 == null ? void 0 : shareClientIP2(request2), path });
        if (sharing == null ? void 0 : sharing.error) return jsonResponse(sharing.error);
        if (sharing == null ? void 0 : sharing.data) return jsonResponse(success(sharing.data));
        const user = requestUser(request2);
        if (!joinUserPath(user, path) || !canAccessFs(user, path, req.password || req.pwd)) return jsonResponse(permissionDenied());
        if (isWorkspacePath(path)) {
          const result = await workspaceGet(path);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success(result.data));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            const shouldProxy2 = storageShouldProxy(mount.storage);
            const data = await mount.driver.get(mount.storage, mount.relPath, { skipLink: shouldProxy2 });
            let rawUrl = data.raw_url || "";
            if (data && !data.is_dir && shouldProxy2 && !rawUrl) {
              rawUrl = rawUrlForStorage(mount.storage, path);
            }
            return jsonResponse(success(driverGetResp(data, rawUrl)));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver get failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        const entry = state.entries[path];
        if (!entry) return jsonResponse(failure("object not found", 404));
        const meta = nearestMeta(getState(), path);
        return jsonResponse(success({
          ...toFsGetResp(entry, path),
          readme: metaReadme(meta, path),
          header: metaHeader(meta, path)
        }));
      },
      "ANY /api/fs/dirs": async (request2) => {
        const req = await parseJson(request2);
        const path = normalizePath(req.path);
        const user = requestUser(request2);
        if (!joinUserPath(user, path) || !canAccessFs(user, path, req.password || req.pwd)) return jsonResponse(permissionDenied());
        if (isWorkspacePath(path)) {
          const result = await workspaceList(path, req);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success(result.data.content.filter((item) => item.is_dir).map((item) => ({
            name: item.name,
            modified: item.modified
          }))));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            const data = await mount.driver.list(mount.storage, mount.relPath, req);
            return jsonResponse(success((data.content || []).filter((item) => item.is_dir).map((item) => ({
              name: item.name,
              modified: item.modified || (/* @__PURE__ */ new Date()).toISOString()
            }))));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver dirs failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        const entry = state.entries[path];
        if (!entry || !entry.is_dir) return jsonResponse(failure("directory not found", 404));
        const dirs = entry.children.map((childPath) => state.entries[childPath]).filter((item) => item && item.is_dir).map((item) => ({ name: item.name, modified: item.modified }));
        return jsonResponse(success(dirs));
      },
      "ANY /api/fs/search": async (request2) => {
        const req = await parseJson(request2);
        const parent = normalizePath(req.parent || req.path || "/");
        const user = requestUser(request2);
        if (!joinUserPath(user, parent)) return jsonResponse(permissionDenied());
        const pageIndex = Number(req.page || 0);
        const perPage = Number(req.per_page || req.perPage || 0);
        if (!Number.isFinite(pageIndex) || pageIndex < 1) return jsonResponse(failure("page can't < 1", 400));
        if (!Number.isFinite(perPage) || perPage < 1) return jsonResponse(failure("per_page can't < 1", 400));
        const result = searchIndex.search({
          keywords: req.keywords || req.keyword || "",
          page: pageIndex,
          parent,
          per_page: perPage,
          scope: req.scope || 0
        });
        const content = result.content.filter((node) => {
          const itemPath = normalizePath(`${node.parent}/${node.name}`);
          return pathWithinBase2(itemPath, (user == null ? void 0 : user.base_path) || "/") && canAccessFs(user, itemPath, req.password || req.pwd);
        });
        return jsonResponse(success(pageResp(content.map((node) => ({
          parent: node.parent,
          name: node.name,
          is_dir: node.is_dir,
          size: node.size,
          type: extensionType(node.name, node.is_dir)
        })), result.total)));
      },
      "POST /api/fs/mkdir": async (request2) => {
        const req = await parseJson(request2);
        const path = normalizePath(req.path || [req.parent, req.name].filter(Boolean).join("/"));
        const user = requestUser(request2);
        const parent = dirname(path);
        if (!joinUserPath(user, path) || !canWriteContent(user) && !writeContentBypass(parent) || !canWriteFs(user, parent)) {
          return jsonResponse(permissionDenied());
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            await mount.driver.mkdir(mount.storage, mount.relPath);
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver mkdir failed", 502));
          }
        }
        ensureDir(dirname(path));
        ensureDir(path);
        await saveState2();
        return jsonResponse(success());
      },
      "PUT /api/fs/put": async (request2) => {
        const req = await parseJson(request2);
        const upload = await uploadFromRawRequest(request2, req, "/untitled.txt");
        const path = upload.path;
        const user = requestUser(request2);
        const parent = dirname(path);
        if (!joinUserPath(user, path) || !canWriteContent(user) && !writeContentBypass(parent) || !canWriteFs(user, parent)) {
          return jsonResponse(permissionDenied());
        }
        if (!overwriteEnabled(request2, req) && await uploadTargetExists(path)) return jsonResponse(failure("file exists", 403));
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            await driverPut({ ...mount, relPath: mount.relPath }, upload);
            return jsonResponse(success({ path }));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver put failed", 502));
          }
        }
        if (isWorkspacePath(path)) {
          return jsonResponse(failure("workspace upload is blocked until /api/file/putFile multipart bridging is proven in the kernel plugin runtime", 501));
        }
        createFile2(path, upload.body, upload.mime, {
          bodyEncoding: upload.bodyEncoding,
          size: upload.size
        });
        await saveState2();
        return jsonResponse(success({ path }));
      },
      "PUT /api/fs/form": async (request2) => {
        const req = await parseJson(request2);
        const upload = await uploadFromFormRequest(request2, req);
        const path = upload.path;
        const user = requestUser(request2);
        const parent = dirname(path);
        if (!joinUserPath(user, path) || !canWriteContent(user) && !writeContentBypass(parent) || !canWriteFs(user, parent)) {
          return jsonResponse(permissionDenied());
        }
        if (!overwriteEnabled(request2, req) && await uploadTargetExists(path)) return jsonResponse(failure("file exists", 403));
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount) {
          try {
            await driverPut({ ...mount, relPath: mount.relPath }, upload);
            return jsonResponse(success({ path }));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver put failed", 502));
          }
        }
        if (isWorkspacePath(path)) {
          return jsonResponse(failure("workspace upload is blocked until /api/file/putFile multipart bridging is proven in the kernel plugin runtime", 501));
        }
        createFile2(path, upload.body, upload.mime, {
          bodyEncoding: upload.bodyEncoding,
          size: upload.size
        });
        await saveState2();
        return jsonResponse(success({ path }));
      },
      "POST /api/fs/remove": async (request2) => {
        const req = await parseJson(request2);
        const names = Array.isArray(req.names) ? req.names : [];
        const dir = normalizePath(req.dir || req.path || "/");
        if (!names.length) return jsonResponse(failure("Empty file names", 400));
        const user = requestUser(request2);
        if (!canRemove(user) || !joinUserPath(user, dir) || !canWriteFs(user, dir)) return jsonResponse(permissionDenied());
        let storageRemoved = false;
        if (isWorkspacePath(dir)) {
          for (const name of names) {
            const payload = await siyuanApiJson("/api/file/removeFile", { path: workspaceRelPath(normalizePath(dir + "/" + name)) });
            if (payload.code !== 0 && payload.code !== 404) return jsonResponse(failure(payload.msg || "removeFile failed", payload.code || 500));
          }
          return jsonResponse(success());
        }
        const mount = driverRuntime.resolve(state.storages, dir);
        if (mount) {
          try {
            for (const name of names) {
              await mount.driver.remove(mount.storage, normalizePath(mount.relPath + "/" + name));
            }
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver remove failed", 502));
          }
        }
        for (const name of names) {
          const path = normalizePath(dir + "/" + name);
          const storage = state.storages.find((item) => normalizePath(item.mount_path || "/") === path);
          if (storage) {
            state.storages = state.storages.filter((item) => item !== storage);
            storageRemoved = true;
          } else {
            removeEntry(path);
          }
        }
        await (storageRemoved ? saveConfigState == null ? void 0 : saveConfigState() : saveState2());
        return jsonResponse(success());
      },
      "POST /api/fs/rename": async (request2) => {
        const req = await parseJson(request2);
        const oldPath = normalizePath(req.path);
        const newName = String(req.name || "").trim();
        const user = requestUser(request2);
        const parent = dirname(oldPath);
        if (!canRename(user) || !joinUserPath(user, oldPath) || !canWriteFs(user, parent)) return jsonResponse(permissionDenied());
        if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
        if (oldPath === "/") return jsonResponse(failure("rename root folder is not allowed", 500));
        if (!boolValue2(req.overwrite, false)) {
          const dstPath = normalizePath(dirname(oldPath) + "/" + newName);
          if (dstPath !== oldPath && await uploadTargetExists(dstPath)) {
            return jsonResponse(failure(`file [${newName}] exists`, 403));
          }
        }
        const mount = driverRuntime.resolve(state.storages, oldPath);
        if (mount) {
          if (mount.relPath === "/") return jsonResponse(failure("rename root folder is not allowed", 500));
          try {
            await mount.driver.rename(mount.storage, mount.relPath, newName);
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver rename failed", 502));
          }
        }
        if (isWorkspacePath(oldPath)) {
          if (normalizePath(workspaceRelPath(oldPath)) === "/") return jsonResponse(failure("rename root folder is not allowed", 500));
          const newPath = normalizePath(dirname(oldPath) + "/" + newName);
          const payload = await siyuanApiJson("/api/file/renameFile", {
            path: workspaceRelPath(oldPath),
            newPath: workspaceRelPath(newPath)
          });
          if (payload.code !== 0) return jsonResponse(failure(payload.msg || "renameFile failed", payload.code || 500));
          return jsonResponse(success());
        }
        const entry = state.entries[oldPath];
        if (!entry) return jsonResponse(failure("object not found", 404));
        try {
          renameEntryInDir(dirname(oldPath), entry.name, newName, { overwrite: req.overwrite });
        } catch (error) {
          return jsonResponse(failure(error.message, error.message.includes("exists") ? 403 : 400));
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/move": async (request2) => {
        const req = await parseJson(request2);
        const creator = currentUser == null ? void 0 : currentUser(request2);
        const names = Array.isArray(req.names) ? req.names : [];
        if (!names.length) return jsonResponse(failure("Empty file names", 400));
        const srcDir = normalizePath(req.src_dir);
        const dstDir = normalizePath(req.dst_dir);
        if (!canMove(creator) || !joinUserPath(creator, srcDir) || !joinUserPath(creator, dstDir) || !canWriteFs(creator, srcDir) || !canWriteFs(creator, dstDir)) {
          return jsonResponse(permissionDenied());
        }
        const srcMount = driverRuntime.resolve(state.storages, srcDir);
        const dstMount = driverRuntime.resolve(state.storages, dstDir);
        if (srcMount || dstMount) {
          if (!srcMount || !dstMount || !sameStorageMount(srcMount, dstMount) || !srcMount.driver.move) {
            return jsonResponse(failure("driver move across mount boundaries is not implemented in the SiYuan kernel port yet", 501));
          }
          for (const name of names) {
            const srcPath = normalizePath(srcDir + "/" + name);
            const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
            if (!shouldOverwrite(req) && await uploadTargetExists(dstPath)) {
              if (!shouldSkipExisting(req)) return jsonResponse(failure(`file [${name}] exists`, 403));
              continue;
            }
            await srcMount.driver.move(srcMount.storage, normalizePath(srcMount.relPath + "/" + name), dstMount.relPath);
          }
          const task2 = await taskStore.addTask("move", {
            creator,
            name: `move ${names.length} item(s)`,
            status: "Move operations completed immediately"
          });
          return jsonResponse(success({ message: "Move operations completed immediately", tasks: [task2] }));
        }
        ensureDir(dstDir);
        for (const name of names) {
          const srcPath = normalizePath(srcDir + "/" + name);
          const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
          if (!state.entries[srcPath]) continue;
          if (!shouldOverwrite(req) && state.entries[dstPath]) {
            if (!shouldSkipExisting(req)) return jsonResponse(failure(`file [${name}] exists`, 403));
            continue;
          }
          if (state.entries[dstPath]) removeEntry(dstPath);
          moveEntryTree(srcPath, dstPath);
        }
        const task = await taskStore.addTask("move", {
          creator,
          name: `move ${names.length} item(s)`,
          status: "Move operations completed immediately"
        });
        return jsonResponse(success({ message: "Move operations completed immediately", tasks: [task] }));
      },
      "POST /api/fs/copy": async (request2) => {
        const req = await parseJson(request2);
        const creator = currentUser == null ? void 0 : currentUser(request2);
        const names = Array.isArray(req.names) ? req.names : [];
        if (!names.length) return jsonResponse(failure("Empty file names", 400));
        const srcDir = normalizePath(req.src_dir);
        const dstDir = normalizePath(req.dst_dir);
        if (!canCopy(creator) || !joinUserPath(creator, srcDir) || !joinUserPath(creator, dstDir) || !canReadFs(creator, srcDir) || !canWriteFs(creator, dstDir)) {
          return jsonResponse(permissionDenied());
        }
        const srcMount = driverRuntime.resolve(state.storages, srcDir);
        const dstMount = driverRuntime.resolve(state.storages, dstDir);
        if (srcMount || dstMount) {
          if (!srcMount || !dstMount || !sameStorageMount(srcMount, dstMount) || !srcMount.driver.copy) {
            return jsonResponse(failure("driver copy across mount boundaries is not implemented in the SiYuan kernel port yet", 501));
          }
          for (const name of names) {
            const srcPath = normalizePath(srcDir + "/" + name);
            const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
            if (!shouldOverwrite(req) && await uploadTargetExists(dstPath)) {
              if (!shouldSkipExisting(req)) return jsonResponse(failure(`file [${name}] exists`, 403));
              if (!shouldMerge(req) || !await driverTargetIsDir(dstPath)) continue;
            }
            await srcMount.driver.copy(srcMount.storage, normalizePath(srcMount.relPath + "/" + name), dstMount.relPath);
          }
          const task2 = await taskStore.addTask("copy", {
            creator,
            name: `copy ${names.length} item(s)`,
            status: "Copy operations completed immediately"
          });
          return jsonResponse(success({ message: "Copy operations completed immediately", tasks: [task2] }));
        }
        ensureDir(dstDir);
        for (const name of names) {
          const srcPath = normalizePath(srcDir + "/" + name);
          const dstPath = normalizePath(dstDir + "/" + basename(srcPath));
          if (!state.entries[srcPath]) continue;
          if (!shouldOverwrite(req) && state.entries[dstPath]) {
            if (!shouldSkipExisting(req)) return jsonResponse(failure(`file [${name}] exists`, 403));
            if (!shouldMerge(req) || !state.entries[dstPath].is_dir) continue;
          }
          if (state.entries[dstPath] && !shouldMerge(req)) removeEntry(dstPath);
          cloneEntryTree(srcPath, dstPath);
        }
        const task = await taskStore.addTask("copy", {
          creator,
          name: `copy ${names.length} item(s)`,
          status: "Copy operations completed immediately"
        });
        return jsonResponse(success({ message: "Copy operations completed immediately", tasks: [task] }));
      },
      "POST /api/fs/batch_rename": async (request2) => {
        const req = await parseJson(request2);
        const srcDir = normalizePath(req.src_dir || "/");
        const renameObjects = Array.isArray(req.rename_objects) ? req.rename_objects : [];
        const user = requestUser(request2);
        if (!canRename(user) || !joinUserPath(user, srcDir) || !canWriteFs(user, srcDir)) return jsonResponse(permissionDenied());
        if (isWorkspacePath(srcDir)) {
          for (const item of renameObjects) {
            const srcName = String(item.src_name || "");
            const newName = String(item.new_name || "");
            if (!srcName || !newName) continue;
            if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
            const srcPath = normalizePath(srcDir + "/" + srcName);
            const newPath = normalizePath(srcDir + "/" + newName);
            const payload = await siyuanApiJson("/api/file/renameFile", {
              path: workspaceRelPath(srcPath),
              newPath: workspaceRelPath(newPath)
            });
            if (payload.code !== 0) return jsonResponse(failure(payload.msg || "renameFile failed", payload.code || 500));
          }
          return jsonResponse(success());
        }
        const mount = driverRuntime.resolve(state.storages, srcDir);
        if (mount) {
          if (!mount.driver.rename) return jsonResponse(failure("not implement", 500));
          for (const item of renameObjects) {
            const srcName = String(item.src_name || "");
            const newName = String(item.new_name || "");
            if (!srcName || !newName) continue;
            if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
            try {
              await mount.driver.rename(mount.storage, normalizePath(mount.relPath + "/" + srcName), newName);
            } catch (error) {
              return jsonResponse(failure(error.message || "driver batch rename failed", 502, {
                driver: mount.storage.driver,
                mount_path: mount.storage.mount_path
              }));
            }
          }
          return jsonResponse(success());
        }
        for (const item of renameObjects) {
          const srcName = String(item.src_name || "");
          const newName = String(item.new_name || "");
          if (!srcName || !newName) continue;
          try {
            renameEntryInDir(srcDir, srcName, newName, { overwrite: !!req.overwrite });
          } catch (error) {
            return jsonResponse(failure(error.message, error.message.includes("exists") ? 403 : 400));
          }
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/regex_rename": async (request2) => {
        const req = await parseJson(request2);
        const srcDir = normalizePath(req.src_dir || "/");
        const user = requestUser(request2);
        if (!canRename(user) || !joinUserPath(user, srcDir) || !canWriteFs(user, srcDir)) return jsonResponse(permissionDenied());
        let pattern;
        try {
          pattern = new RegExp(String(req.src_name_regex || ""));
        } catch (error) {
          return jsonResponse(failure(error.message, 400));
        }
        const replacement = String(req.new_name_regex || "");
        if (isWorkspacePath(srcDir)) {
          const result = await workspaceList(srcDir, { page: 1, per_page: 1e5 });
          if (result.error) return jsonResponse(result.error);
          for (const file of result.data.content || []) {
            if (!pattern.test(file.name)) continue;
            pattern.lastIndex = 0;
            const newName = file.name.replace(pattern, replacement);
            if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
            const payload = await siyuanApiJson("/api/file/renameFile", {
              path: workspaceRelPath(normalizePath(srcDir + "/" + file.name)),
              newPath: workspaceRelPath(normalizePath(srcDir + "/" + newName))
            });
            if (payload.code !== 0) return jsonResponse(failure(payload.msg || "renameFile failed", payload.code || 500));
          }
          return jsonResponse(success());
        }
        const mount = driverRuntime.resolve(state.storages, srcDir);
        if (mount) {
          if (!mount.driver.list || !mount.driver.rename) return jsonResponse(failure("not implement", 500));
          let data;
          try {
            data = await mount.driver.list(mount.storage, mount.relPath, { page: 1, per_page: 1e5 });
          } catch (error) {
            return jsonResponse(failure(error.message || "driver list failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
          for (const file of data.content || []) {
            pattern.lastIndex = 0;
            if (!pattern.test(file.name)) continue;
            pattern.lastIndex = 0;
            const newName = file.name.replace(pattern, replacement);
            if (!isSafeRelativeName(newName)) return jsonResponse(failure("relative path is not allowed", 403));
            try {
              await mount.driver.rename(mount.storage, normalizePath(mount.relPath + "/" + file.name), newName);
            } catch (error) {
              return jsonResponse(failure(error.message || "driver regex rename failed", 502, {
                driver: mount.storage.driver,
                mount_path: mount.storage.mount_path
              }));
            }
          }
          return jsonResponse(success());
        }
        const dir = state.entries[srcDir];
        if (!dir || !dir.is_dir) return jsonResponse(failure("directory not found", 404));
        for (const childPath of [...dir.children || []]) {
          const entry = state.entries[childPath];
          if (!entry || !pattern.test(entry.name)) continue;
          pattern.lastIndex = 0;
          const newName = entry.name.replace(pattern, replacement);
          try {
            renameEntryInDir(srcDir, entry.name, newName, { overwrite: !!req.overwrite });
          } catch (error) {
            return jsonResponse(failure(error.message, error.message.includes("exists") ? 403 : 400));
          }
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/recursive_move": async (request2) => {
        const req = await parseJson(request2);
        const srcDir = normalizePath(req.src_dir || "/");
        const dstDir = normalizePath(req.dst_dir || "/");
        const user = requestUser(request2);
        if (!canMove(user) || !joinUserPath(user, srcDir) || !joinUserPath(user, dstDir) || !canWriteFs(user, srcDir) || !canWriteFs(user, dstDir)) {
          return jsonResponse(permissionDenied());
        }
        const conflictPolicy = String(req.conflict_policy || "skip").toLowerCase();
        if (isWorkspacePath(srcDir) || isWorkspacePath(dstDir)) {
          return jsonResponse(failure("recursive move for /@workspace is not available until workspace upload/move is completed", 501));
        }
        const srcMount = driverRuntime.resolve(state.storages, srcDir);
        const dstMount = driverRuntime.resolve(state.storages, dstDir);
        if (srcMount || dstMount) {
          if (!sameStorageMount(srcMount, dstMount)) {
            return jsonResponse(failure("driver recursive move across mount boundaries is not implemented in the SiYuan kernel port yet", 501));
          }
          if (!srcMount.driver.list || !srcMount.driver.move) return jsonResponse(failure("not implement", 500));
          try {
            const existingNames = [];
            if (conflictPolicy !== "overwrite") {
              existingNames.push(...(await driverList(dstMount, dstMount.relPath)).map((item) => item.name));
            }
            const queue = [{ abs: srcDir, rel: srcMount.relPath }];
            const movingFiles = [];
            while (queue.length) {
              const current = queue.shift();
              for (const item of await driverList(srcMount, current.rel, current.abs !== srcDir)) {
                const absPath = normalizePath(current.abs + "/" + item.name);
                const relPath = normalizePath(current.rel + "/" + item.name);
                if (item.is_dir) {
                  queue.push({ abs: absPath, rel: relPath });
                  continue;
                }
                if (current.abs === dstDir) continue;
                if (existingNames.includes(item.name)) {
                  if (conflictPolicy === "cancel") return jsonResponse(failure(`file [${item.name}] exists`, 403));
                  if (conflictPolicy === "skip") continue;
                } else if (conflictPolicy !== "overwrite") {
                  existingNames.push(item.name);
                }
                movingFiles.push({ name: item.name, rel: relPath });
              }
            }
            for (const file of movingFiles) {
              if (conflictPolicy === "overwrite") await driverRemoveIfExists(dstMount, normalizePath(dstMount.relPath + "/" + file.name));
              await srcMount.driver.move(srcMount.storage, file.rel, dstMount.relPath);
            }
            return jsonResponse(successWithMessage(`Successfully moved ${movingFiles.length} ${movingFiles.length === 1 ? "file" : "files"}`));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver recursive move failed", 502, {
              driver: srcMount.storage.driver,
              mount_path: srcMount.storage.mount_path
            }));
          }
        }
        const src = state.entries[srcDir];
        if (!src || !src.is_dir) return jsonResponse(failure("source directory not found", 404));
        ensureDir(dstDir);
        const files = Object.values(state.entries).filter((entry) => entry.path !== srcDir && entry.path.startsWith(srcDir + "/") && !entry.is_dir).sort((a, b) => a.path.localeCompare(b.path));
        let count = 0;
        for (const file of files) {
          const dstPath = normalizePath(dstDir + "/" + file.name);
          if (dirname(file.path) === dstDir) continue;
          if (state.entries[dstPath]) {
            if (conflictPolicy === "cancel") return jsonResponse(failure(`file [${file.name}] exists`, 403));
            if (conflictPolicy === "skip") continue;
            removeEntry(dstPath);
          }
          moveEntryTree(file.path, dstPath);
          count += 1;
        }
        await saveState2();
        return jsonResponse(successWithMessage(`Successfully moved ${count} ${count === 1 ? "file" : "files"}`));
      },
      "POST /api/fs/remove_empty_directory": async (request2) => {
        const req = await parseJson(request2);
        const srcDir = normalizePath(req.src_dir || "/");
        const user = requestUser(request2);
        if (!canRemove(user) || !joinUserPath(user, srcDir) || !canWriteFs(user, srcDir)) return jsonResponse(permissionDenied());
        const mount = driverRuntime.resolve(state.storages, srcDir);
        if (mount) {
          if (!mount.driver.list || !mount.driver.remove) return jsonResponse(failure("not implement", 500));
          try {
            const removeEmpty = async (relPath) => {
              const content = await driverList(mount, relPath, true);
              let hasNonDir = content.some((item) => !item.is_dir);
              for (const item of content.filter((entry) => entry.is_dir)) {
                const childRel = normalizePath(relPath + "/" + item.name);
                const removed = await removeEmpty(childRel);
                if (!removed) hasNonDir = true;
              }
              if (hasNonDir) return false;
              if (relPath === mount.relPath) return false;
              await mount.driver.remove(mount.storage, relPath);
              return true;
            };
            for (const item of (await driverList(mount, mount.relPath)).filter((entry) => entry.is_dir)) {
              await removeEmpty(normalizePath(mount.relPath + "/" + item.name));
            }
            return jsonResponse(success());
          } catch (error) {
            return jsonResponse(failure(error.message || "driver remove empty directory failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        removeEmptyDirs(srcDir);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/fs/link": async (request2) => {
        var _a2, _b2;
        const req = await parseJson(request2);
        const path = normalizePath(req.path);
        if (isWorkspacePath(path)) {
          const result = await workspaceGet(path);
          if (result.error) return jsonResponse(result.error);
          return jsonResponse(success({ url: "/plugin/private/siyuan-cloud/d" + path }));
        }
        const mount = driverRuntime.resolve(state.storages, path);
        if (mount && (mount.driver.link || mount.driver.read)) {
          try {
            const readOptions = {
              requestHeaders: requestHeaders2(request2),
              userAgent: requestHeader2(request2, "User-Agent")
            };
            const obj = await ((_b2 = (_a2 = mount.driver).get) == null ? void 0 : _b2.call(_a2, mount.storage, mount.relPath, { skipLink: true }));
            const data = mount.driver.link ? await mount.driver.link(mount.storage, mount.relPath, readOptions) : await mount.driver.read(mount.storage, mount.relPath, readOptions);
            const link2 = linkFromDriverData(data);
            const contentLength = Number(link2.content_length || (obj == null ? void 0 : obj.size) || 0);
            return jsonResponse(success({
              url: link2.url,
              header: link2.header,
              method: link2.method,
              content_length: contentLength,
              raw_url: rawUrlForStorage(mount.storage, path, link2.url),
              provider: mount.storage.driver
            }));
          } catch (error) {
            return jsonResponse(failure(error.message || "driver link failed", 502, {
              driver: mount.storage.driver,
              mount_path: mount.storage.mount_path
            }));
          }
        }
        if (!state.entries[path]) return jsonResponse(failure("object not found", 404));
        return jsonResponse(success({ url: "/plugin/private/siyuan-cloud/d" + path }));
      },
      "POST /api/fs/motrix_next/add": async (request2) => {
        const req = await parseJson(request2);
        try {
          const apiUrl = motrixNextApiUrl(req.api_url || req.apiUrl);
          const payload = req.payload || {};
          const resp = await forwardProxy(client, `${apiUrl}/add`, {
            allowErrorStatus: true,
            body: payload,
            headers: req.api_secret || req.apiSecret ? { Authorization: `Bearer ${req.api_secret || req.apiSecret}` } : {},
            method: "POST",
            timeout: 1e4
          });
          if (Number(resp.status) >= 200 && Number(resp.status) < 300) return jsonResponse(success(resp.body || ""));
          return jsonResponse(failure(String(resp.body || `HTTP ${resp.status}`), Number(resp.status) || 502), Number(resp.status) || 502);
        } catch (error) {
          return jsonResponse(failure(error.message || "Motrix Next is unavailable", 502), 502);
        }
      },
      "POST /api/fs/add_offline_download": async (request2) => {
        const req = await parseJson(request2);
        const creator = currentUser == null ? void 0 : currentUser(request2);
        if (!canAddOfflineDownloadTasks(creator)) return jsonResponse(permissionDenied());
        const urls = (Array.isArray(req.urls) ? req.urls : [req.url]).map((url) => String(url || "").trim()).filter(Boolean);
        const tasks = [];
        for (const url of urls) {
          tasks.push(await taskStore.addTask("offline_download", {
            creator,
            delete_policy: req.delete_policy || "",
            dst_dir_path: normalizePath(req.path || "/"),
            error: "offline download is not implemented in the SiYuan kernel port yet",
            name: url,
            status: "not implemented",
            tool: req.tool || "",
            url
          }));
        }
        return jsonResponse(failure(
          "offline download is not implemented in the SiYuan kernel port yet",
          501,
          { tasks }
        ), 501);
      },
      "POST /api/fs/get_direct_upload_info": async (request2) => {
        var _a2;
        const req = await parseJson(request2);
        const path = normalizePath(req.path || req.file_path || "/");
        if (!overwriteEnabled(request2, req) && await uploadTargetExists(path)) return jsonResponse(failure("file exists", 403));
        const mount = driverRuntime.resolve(state.storages, path);
        if ((_a2 = mount == null ? void 0 : mount.driver) == null ? void 0 : _a2.getDirectUploadInfo) {
          try {
            const data = await mount.driver.getDirectUploadInfo(mount.storage, mount.relPath, req);
            return jsonResponse(success(data));
          } catch (error) {
            return jsonResponse(failure(error.message || "get direct upload info failed", 502));
          }
        }
        return jsonResponse(success(null));
      },
      "ANY /api/fs/other": async (request2) => {
        const req = await parseJson(request2);
        const path = normalizePath(req.path || "/");
        const mount = driverRuntime.resolve(state.storages, path);
        if (!mount) return jsonResponse(failure("not implement", 500));
        if (!mount.driver.other) return jsonResponse(failure("not implement", 500));
        try {
          const data = await mount.driver.other(mount.storage, mount.relPath, {
            data: req.data,
            method: req.method || ""
          });
          return jsonResponse(success(data));
        } catch (error) {
          return jsonResponse(failure(error.message || "not implement", 500));
        }
      }
    };
    handlers["POST /api/fs/torrent/parse"] = async (request2) => {
      const req = await parseJson(request2);
      return fsTorrentValidate("parse", req) || fsTorrentParse(req, { requireBase64: true });
    };
    handlers["POST /api/fs/torrent/upload_parse"] = async (request2) => {
      const req = await parseJson(request2);
      return fsTorrentUploadParse(req);
    };
    handlers["POST /api/fs/torrent/rapid_upload"] = async (request2) => {
      const req = await parseJson(request2);
      const user = requestUser(request2);
      const path = normalizePath(req.path || "/");
      if (req.path && (!joinUserPath(user, path) || !canWriteFs(user, path))) return jsonResponse(permissionDenied());
      return fsTorrentValidate("rapid_upload", req) || fsTorrentRapidUpload(req);
    };
    handlers["POST /api/fs/torrent/generate"] = async (request2) => {
      const req = await parseJson(request2);
      const user = requestUser(request2);
      const path = normalizePath(req.path || "/");
      if (req.path && (!joinUserPath(user, path) || !canReadFs(user, path))) return jsonResponse(permissionDenied());
      return fsTorrentValidate("generate", req) || fsTorrentGenerate(req);
    };
    return handlers;
  };
  const randomShareId = () => Math.random().toString(36).slice(2, 10);
  const validSharingID = /^[\w\u4e00-\u9fff-]+$/u;
  const shareIdOf = (share) => String((share == null ? void 0 : share.id) || "");
  const sharePwdOf = (share) => String((share == null ? void 0 : share.pwd) ?? "");
  const shareFilesOf = (share) => Array.isArray(share == null ? void 0 : share.files) ? share.files.map(normalizePath).filter(Boolean) : [];
  const accessCache = /* @__PURE__ */ new Map();
  const accessCountDelay = 30 * 60 * 1e3;
  const pathWithinBase$1 = (path, basePath) => {
    const target = normalizePath(path);
    const base = normalizePath(basePath || "/");
    return base === "/" || target === base || target.startsWith(`${base}/`);
  };
  const shareCreatorUser = (state, share) => {
    const normalized = normalizeShare(share);
    const users = (state.users || []).map(normalizeUser);
    return users.find((user) => Number(user.id) === Number(normalized.creator_id)) || users.find((user) => user.username === normalized.creator) || null;
  };
  const canCreatorReadSharePath = (state, share, targetPath) => {
    const creator = shareCreatorUser(state, share);
    if (!creator || creator.disabled) return false;
    if (!pathWithinBase$1(targetPath, creator.base_path)) return false;
    const meta = nearestMeta(state, targetPath);
    return canAccessByMeta(creator, meta, targetPath, "");
  };
  const canCreatorReadShareTargets = (state, share, targetPath) => {
    const normalized = normalizeShare(share);
    if (targetPath !== "/") return canCreatorReadSharePath(state, share, targetPath);
    return normalized.files.length > 0 && normalized.files.every((file) => canCreatorReadSharePath(state, share, file));
  };
  const shareTargetPath = (share, inner) => {
    const normalized = normalizeShare(share);
    if (normalized.files.length === 1 || inner !== "/") {
      const base = normalized.files.length === 1 ? normalized.files[0] : normalized.files.find((file) => basename(file) === inner.replace(/^\/+/, "").split("/")[0]);
      if (!base) return "";
      const rest = normalized.files.length === 1 ? inner : normalizePath("/" + inner.replace(/^\/+/, "").split("/").slice(1).join("/"));
      return rest === "/" ? normalizePath(base) : normalizePath(`${base}/${rest.replace(/^\/+/, "")}`);
    }
    return "/";
  };
  const normalizeShare = (share = {}, now) => {
    const files = shareFilesOf(share);
    const id = shareIdOf(share) || randomShareId();
    return {
      id,
      files,
      expires: share.expires || null,
      pwd: sharePwdOf(share),
      accessed: Number(share.accessed || 0),
      max_accessed: Number(share.max_accessed || 0),
      disabled: !!share.disabled,
      remark: share.remark || "",
      readme: share.readme || "",
      header: share.header || "",
      order_by: share.order_by || "",
      order_direction: share.order_direction || "",
      extract_folder: share.extract_folder || "",
      creator: share.creator || share.creator_name || "admin",
      creator_id: Number(share.creator_id || share.creatorId || 1),
      creator_role: Number(share.creator_role ?? 2),
      created: share.created || (now == null ? void 0 : now()) || "",
      modified: share.modified || (now == null ? void 0 : now()) || ""
    };
  };
  const shareResp = (share) => {
    const normalized = normalizeShare(share);
    return {
      ...normalized
    };
  };
  const validShare = (share, password2) => {
    const normalized = normalizeShare(share);
    if (!share || share.disabled) return false;
    if (normalized.max_accessed > 0 && normalized.accessed >= normalized.max_accessed) return false;
    if (normalized.pwd && normalized.pwd !== password2) return false;
    if (normalized.expires && !Number.isNaN(Date.parse(normalized.expires)) && Date.parse(normalized.expires) < Date.now()) return false;
    return true;
  };
  const shareNeedsPassword = ({ path, password: password2, state }) => {
    const normalized = normalizePath(path);
    const [sid] = normalized.replace(/^\/+/, "").split("/");
    if (!sid) return null;
    const source = state.sharings.find((item) => shareIdOf(item) === sid);
    if (!source) return null;
    const share = normalizeShare(source);
    if (source.disabled) return null;
    if (share.max_accessed > 0 && share.accessed >= share.max_accessed) return null;
    if (share.expires && !Number.isNaN(Date.parse(share.expires)) && Date.parse(share.expires) < Date.now()) return null;
    const targetPath = shareTargetPath(source, normalizePath("/" + normalized.replace(/^\/+/, "").split("/").slice(1).join("/")));
    if (!targetPath || !canCreatorReadShareTargets(state, source, targetPath)) return null;
    if (!share.pwd || share.pwd === password2) return null;
    return { sid, share: source, normalizedShare: share };
  };
  const sharePathInfo = ({ path, password: password2, state }) => {
    const normalized = normalizePath(path);
    const [sid, ...innerParts] = normalized.replace(/^\/+/, "").split("/");
    if (!sid) return null;
    const source = state.sharings.find((item) => shareIdOf(item) === sid);
    if (!validShare(source, password2)) return null;
    const share = normalizeShare(source);
    const inner = normalizePath("/" + innerParts.join("/"));
    if (share.files.length === 1 || inner !== "/") {
      const targetPath = shareTargetPath(source, inner);
      if (!targetPath) return null;
      if (!canCreatorReadShareTargets(state, source, targetPath)) return null;
      return { inner, share: source, normalizedShare: share, targetPath };
    }
    if (!canCreatorReadShareTargets(state, source, "/")) return null;
    return { inner, share: source, normalizedShare: share, targetPath: "/" };
  };
  const validateSharingID = (id) => {
    if (!id) return "";
    if ([...String(id)].length > 64) throw new Error("share id must be at most 64 characters");
    if (!validSharingID.test(String(id))) throw new Error("share id can only contain letters, numbers, underscores, hyphens, and CJK characters");
    return String(id);
  };
  const resolveShareCreator = (state, reqUser, creatorName = "") => {
    if (isAdminUser(reqUser) && creatorName) {
      return (state.users || []).map(normalizeUser).find((user) => user.username === creatorName) || null;
    }
    if (isAdminUser(reqUser) && !creatorName) return reqUser;
    return reqUser;
  };
  const validateShareWriteRequest = ({ customId, files, reqUser, state, targetUser }) => {
    if (!isAdminUser(reqUser)) {
      if (!canShare(targetUser) || customId && !canCustomizeShareID(targetUser)) {
        return failure("permission denied", 403);
      }
      for (const file of files) {
        if (!pathWithinBase$1(file, targetUser.base_path)) {
          return failure(`permission denied to share path [${file}]`, 500);
        }
        const meta = nearestMeta(state, file);
        if (!canAccessByMeta(targetUser, meta, file, "")) {
          return failure(`permission denied to share path [${file}]`, 500);
        }
      }
      return null;
    }
    if (customId && !canCustomizeShareID(reqUser)) return failure("permission denied", 403);
    return null;
  };
  const shareClientIP = (request2) => {
    const meta = (request2 == null ? void 0 : request2.request) || (request2 == null ? void 0 : request2.Request) || {};
    const headers = meta.headers || meta.Headers || {};
    for (const name of ["X-Forwarded-For", "x-forwarded-for", "X-Real-IP", "x-real-ip"]) {
      const value = headers[name];
      const ip = Array.isArray(value) ? value[0] : value;
      if (ip) return String(ip).split(",")[0].trim();
    }
    return "127.0.0.1";
  };
  const countShareAccess = async ({ info, ip, saveState: saveState2 }) => {
    if (!(info == null ? void 0 : info.share)) return;
    const key = `${shareIdOf(info.share)}:${ip || "127.0.0.1"}`;
    const expires = accessCache.get(key);
    if (expires && expires > Date.now()) return;
    accessCache.set(key, Date.now() + accessCountDelay);
    info.share.accessed = Number(info.share.accessed || 0) + 1;
    await (saveState2 == null ? void 0 : saveState2());
  };
  const createShareReader = ({
    driverRuntime,
    getState,
    isWorkspacePath,
    page,
    toFsGetResp,
    toObjResp,
    workspaceGet,
    workspaceList,
    saveState: saveState2
  }) => {
    const extensionType = (name, isDir2) => {
      if (isDir2) return 1;
      const ext = String(name).toLowerCase().split(".").pop() || "";
      if (["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif"].includes(ext)) return 2;
      if (["mp4", "mkv", "mov", "avi", "webm", "m4v"].includes(ext)) return 3;
      if (["mp3", "flac", "wav", "ogg", "m4a"].includes(ext)) return 4;
      if (["zip", "7z", "rar", "tar", "gz", "bz2"].includes(ext)) return 5;
      if (["pdf", "epub", "txt", "md", "json", "yaml", "yml", "csv", "log"].includes(ext)) return 6;
      return 0;
    };
    const driverObjResp = (item) => ({
      name: item.name || "",
      size: Number(item.size || 0),
      is_dir: !!item.is_dir,
      modified: item.modified || (/* @__PURE__ */ new Date()).toISOString(),
      created: item.created || item.modified || (/* @__PURE__ */ new Date()).toISOString(),
      sign: item.sign || "",
      thumb: item.thumb || "",
      type: Number(item.type || extensionType(item.name, item.is_dir)),
      hashinfo: item.hashinfo || "",
      hash_info: item.hash_info || {}
    });
    const driverListResp = (data) => {
      const content = (data.content || []).map(driverObjResp);
      return {
        content,
        total: Number(data.total || content.length),
        readme: data.readme || "",
        header: data.header || "",
        write: false,
        write_content_bypass: false,
        provider: data.provider || "unknown",
        direct_upload_tools: data.direct_upload_tools || []
      };
    };
    const objForPath = async (state, path) => {
      if (isWorkspacePath(path)) {
        const result = await workspaceGet(path);
        return result.error ? null : result.data;
      }
      const mount = driverRuntime == null ? void 0 : driverRuntime.resolve(state.storages, path);
      if (mount) {
        try {
          return driverObjResp(await mount.driver.get(mount.storage, mount.relPath, { skipLink: true }));
        } catch (_) {
          return null;
        }
      }
      const entry = state.entries[path];
      return entry ? toObjResp(entry) : null;
    };
    const shareList = async (req) => {
      const state = getState();
      const info = sharePathInfo({ path: req.path, password: req.password || req.pwd, state });
      if (!info) return null;
      await countShareAccess({ info, ip: req.client_ip, saveState: saveState2 });
      if (info.normalizedShare.files.length > 1 && info.inner === "/") {
        const content = [];
        for (const file of info.normalizedShare.files) {
          const obj = await objForPath(state, file);
          if (obj) content.push({ ...obj, name: basename(file) });
        }
        return {
          data: {
            content: page(content, req),
            total: content.length,
            readme: info.normalizedShare.readme || "",
            header: info.normalizedShare.header || "",
            write: false,
            write_content_bypass: false,
            provider: "unknown",
            direct_upload_tools: []
          }
        };
      }
      if (isWorkspacePath(info.targetPath)) {
        const result = await workspaceList(info.targetPath, req);
        if (result.error) return { error: result.error };
        return {
          data: {
            ...result.data,
            readme: info.normalizedShare.readme || "",
            header: info.normalizedShare.header || "",
            write: false
          }
        };
      }
      const mount = driverRuntime == null ? void 0 : driverRuntime.resolve(state.storages, info.targetPath);
      if (mount) {
        try {
          const data = await mount.driver.list(mount.storage, mount.relPath, req);
          return {
            data: {
              ...driverListResp(data),
              readme: info.normalizedShare.readme || data.readme || "",
              header: info.normalizedShare.header || data.header || ""
            }
          };
        } catch (error) {
          return { error: failure(error.message || "driver list failed", 502) };
        }
      }
      const entry = state.entries[info.targetPath];
      if (!entry) return { error: failure("object not found", 404) };
      const children = entry.is_dir ? (entry.children || []).map((childPath) => state.entries[childPath]).filter(Boolean).map(toObjResp) : [toObjResp(entry)];
      return {
        data: {
          content: page(children, req),
          total: children.length,
          readme: info.normalizedShare.readme || "",
          header: info.normalizedShare.header || "",
          write: false,
          write_content_bypass: false,
          provider: "unknown",
          direct_upload_tools: []
        }
      };
    };
    const shareGet = async (req) => {
      const state = getState();
      const info = sharePathInfo({ path: req.path, password: req.password || req.pwd, state });
      if (!info) return null;
      await countShareAccess({ info, ip: req.client_ip, saveState: saveState2 });
      if (info.normalizedShare.files.length > 1 && info.inner === "/") {
        return {
          data: {
            name: shareIdOf(info.share),
            size: 0,
            is_dir: true,
            modified: "",
            created: "",
            sign: "",
            thumb: "",
            type: 1,
            raw_url: "",
            readme: info.normalizedShare.readme || "",
            header: info.normalizedShare.header || "",
            provider: "unknown",
            related: []
          }
        };
      }
      if (isWorkspacePath(info.targetPath)) {
        const result = await workspaceGet(info.targetPath);
        if (result.error) return { error: result.error };
        return {
          data: {
            ...result.data,
            raw_url: result.data.is_dir ? "" : `/plugin/private/siyuan-cloud/sd/${shareIdOf(info.share)}${info.inner}${info.normalizedShare.pwd ? `?pwd=${info.normalizedShare.pwd}` : ""}`,
            readme: info.normalizedShare.readme || "",
            header: info.normalizedShare.header || "",
            provider: "unknown"
          }
        };
      }
      const mount = driverRuntime == null ? void 0 : driverRuntime.resolve(state.storages, info.targetPath);
      if (mount) {
        try {
          const data = await mount.driver.get(mount.storage, mount.relPath, { skipLink: true });
          return {
            data: {
              ...driverObjResp(data),
              raw_url: data.is_dir ? "" : `/plugin/private/siyuan-cloud/sd/${shareIdOf(info.share)}${info.inner}${info.normalizedShare.pwd ? `?pwd=${info.normalizedShare.pwd}` : ""}`,
              readme: info.normalizedShare.readme || "",
              header: info.normalizedShare.header || "",
              provider: data.provider || mount.storage.driver || "unknown",
              related: []
            }
          };
        } catch (error) {
          return { error: failure(error.message || "driver get failed", 502) };
        }
      }
      const entry = state.entries[info.targetPath];
      if (!entry) return { error: failure("object not found", 404) };
      return {
        data: {
          ...toFsGetResp(entry, info.targetPath),
          raw_url: entry.is_dir ? "" : `/plugin/private/siyuan-cloud/sd/${shareIdOf(info.share)}${info.inner}${info.normalizedShare.pwd ? `?pwd=${info.normalizedShare.pwd}` : ""}`,
          readme: info.normalizedShare.readme || "",
          header: info.normalizedShare.header || "",
          provider: "unknown"
        }
      };
    };
    return { shareGet, shareList };
  };
  const createShareHandlers = ({
    currentUser = () => normalizeUser({ id: 2, username: "guest", role: USER_ROLE.GUEST, disabled: true }, 1),
    driverRuntime,
    getState,
    isWorkspacePath,
    now,
    page,
    parseJson,
    queryValue,
    saveState: saveState2,
    workspaceGet
  }) => ({
    "ANY /api/share/list": async (request2) => {
      const req = await parseJson(request2);
      const state = getState();
      const user = currentUser(request2);
      state.sharings = state.sharings.map((share) => normalizeShare(share, now));
      const visible = isAdminUser(user) ? state.sharings : state.sharings.filter((share) => Number(normalizeShare(share).creator_id) === Number(user.id));
      const content = page(visible.map(shareResp), req);
      return jsonResponse(success(pageResp(content, visible.length)));
    },
    "GET /api/share/get": async (request2) => {
      const state = getState();
      const user = currentUser(request2);
      const id = queryValue(request2, "id");
      const share = state.sharings.find((item) => shareIdOf(item) === id);
      if (!share || !isAdminUser(user) && Number(normalizeShare(share).creator_id) !== Number(user.id)) {
        return jsonResponse(failure("sharing not found", 404));
      }
      return jsonResponse(success(shareResp(share)));
    },
    "POST /api/share/create": async (request2) => {
      const req = await parseJson(request2);
      const state = getState();
      const reqUser = currentUser(request2);
      let customId = "";
      try {
        customId = validateSharingID(req.id || "");
      } catch (error) {
        return jsonResponse(failure(error.message, 400));
      }
      const files = (Array.isArray(req.files) ? req.files : []).map(normalizePath).filter(Boolean);
      if (!files.length) return jsonResponse(failure("must add at least 1 object", 400));
      const creator = resolveShareCreator(state, reqUser, req.creator || req.creator_name);
      if (!creator) return jsonResponse(failure("no such a user", 400));
      const permissionError = validateShareWriteRequest({ customId, files, reqUser, state, targetUser: creator });
      if (permissionError) return jsonResponse(permissionError);
      const id = customId || randomShareId();
      if (state.sharings.some((item) => shareIdOf(item) === id)) return jsonResponse(failure("UNIQUE constraint failed: sharings.id", 500));
      const share = normalizeShare({
        id,
        files,
        pwd: req.pwd ?? "",
        expires: req.expires || "",
        accessed: req.accessed || 0,
        max_accessed: req.max_accessed || 0,
        disabled: !!req.disabled,
        remark: req.remark || "",
        readme: req.readme || "",
        header: req.header || "",
        order_by: req.order_by || "",
        order_direction: req.order_direction || "",
        extract_folder: req.extract_folder || "",
        creator: creator.username,
        creator_id: creator.id,
        creator_role: creator.role,
        created: now(),
        modified: now()
      }, now);
      state.sharings.push(share);
      await saveState2();
      return jsonResponse(success(shareResp(share)));
    },
    "POST /api/share/update": async (request2) => {
      const req = await parseJson(request2);
      const state = getState();
      const reqUser = currentUser(request2);
      const share = state.sharings.find((item) => shareIdOf(item) === String(req.id || ""));
      if (!share || !isAdminUser(reqUser) && Number(normalizeShare(share).creator_id) !== Number(reqUser.id)) {
        return jsonResponse(failure("sharing not found", 404));
      }
      const files = Array.isArray(req.files) && req.files.length ? req.files.map(normalizePath) : shareFilesOf(share);
      if (!files.length) return jsonResponse(failure("must add at least 1 object", 400));
      const nextCreator = isAdminUser(reqUser) && (req.creator || req.creator_name) ? resolveShareCreator(state, reqUser, req.creator || req.creator_name) : resolveShareCreator(state, reqUser, normalizeShare(share).creator);
      if (!nextCreator) return jsonResponse(failure("no such a user", 400));
      const permissionError = validateShareWriteRequest({
        customId: req.new_id && req.new_id !== shareIdOf(share) ? req.new_id : "",
        files,
        reqUser,
        state,
        targetUser: nextCreator
      });
      if (permissionError) return jsonResponse(permissionError);
      Object.assign(share, {
        files,
        pwd: req.pwd ?? sharePwdOf(share),
        expires: req.expires ?? share.expires,
        accessed: Number(req.accessed ?? share.accessed ?? 0),
        max_accessed: Number(req.max_accessed ?? share.max_accessed ?? 0),
        disabled: req.disabled ?? share.disabled,
        remark: req.remark ?? share.remark,
        readme: req.readme ?? share.readme,
        header: req.header ?? share.header,
        order_by: req.order_by ?? share.order_by,
        order_direction: req.order_direction ?? share.order_direction,
        extract_folder: req.extract_folder ?? share.extract_folder,
        creator: nextCreator.username,
        creator_id: nextCreator.id,
        creator_role: nextCreator.role,
        modified: now()
      });
      if (req.new_id && req.new_id !== shareIdOf(share)) {
        let candidateId = "";
        try {
          candidateId = validateSharingID(req.new_id);
        } catch (error) {
          return jsonResponse(failure(error.message, 400));
        }
        if (state.sharings.some((item) => item !== share && shareIdOf(item) === candidateId)) {
          return jsonResponse(failure("UNIQUE constraint failed: sharings.id", 500));
        }
        share.id = candidateId;
      }
      await saveState2();
      return jsonResponse(success(shareResp(share)));
    },
    "POST /api/share/delete": async (request2) => {
      const req = await parseJson(request2);
      const state = getState();
      const user = currentUser(request2);
      const queryId = queryValue(request2, "id");
      const ids = Array.isArray(req.ids) ? req.ids.map(String) : [String(queryId || req.id || "")];
      const matches = state.sharings.filter((item) => ids.includes(shareIdOf(item)));
      if (!matches.length || !isAdminUser(user) && matches.some((share) => Number(normalizeShare(share).creator_id) !== Number(user.id))) {
        return jsonResponse(failure("sharing not found", 404));
      }
      state.sharings = state.sharings.filter((item) => !ids.includes(shareIdOf(item)));
      await saveState2();
      return jsonResponse(success());
    },
    "POST /api/share/enable": async (request2) => {
      const req = await parseJson(request2);
      const state = getState();
      const user = currentUser(request2);
      const share = state.sharings.find((item) => shareIdOf(item) === String(queryValue(request2, "id") || req.id || ""));
      if (!share || !isAdminUser(user) && Number(normalizeShare(share).creator_id) !== Number(user.id)) {
        return jsonResponse(failure("sharing not found", 404));
      }
      share.disabled = false;
      share.modified = now();
      await saveState2();
      return jsonResponse(success());
    },
    "POST /api/share/disable": async (request2) => {
      const req = await parseJson(request2);
      const state = getState();
      const user = currentUser(request2);
      const share = state.sharings.find((item) => shareIdOf(item) === String(queryValue(request2, "id") || req.id || ""));
      if (!share || !isAdminUser(user) && Number(normalizeShare(share).creator_id) !== Number(user.id)) {
        return jsonResponse(failure("sharing not found", 404));
      }
      share.disabled = true;
      share.modified = now();
      await saveState2();
      return jsonResponse(success());
    }
  });
  const createAdminHandlers = ({
    driverRuntime,
    getState,
    isWorkspacePath,
    listSettings,
    now,
    pageSlice,
    parseJson,
    queryValue,
    reloadConfigState,
    requireAdmin,
    saveState: saveState2,
    saveToolSettings,
    settingItem,
    storageResp,
    workspaceGet
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const refreshConfig = async () => {
      await (reloadConfigState == null ? void 0 : reloadConfigState());
    };
    const storageAddition = (reqAddition, currentAddition = "{}") => {
      if (typeof reqAddition === "string") return reqAddition;
      if (reqAddition !== void 0) return JSON.stringify(reqAddition || {});
      return currentAddition || "{}";
    };
    const exportConfig = () => ({
      version: 1,
      exported_at: (/* @__PURE__ */ new Date()).toISOString(),
      source: "siyuan-cloud",
      settings: { ...state.settings },
      users: state.users.map((user) => ({ ...user })),
      storages: state.storages.map((storage) => ({ ...storage })),
      metas: (state.metas || []).map((meta) => ({ ...meta })),
      sharings: (state.sharings || []).map((share) => ({ ...share }))
    });
    const asArray = (value, fallback = []) => Array.isArray(value) ? value : fallback;
    const boolValue2 = (value, fallback = false) => {
      if (value === void 0 || value === null || value === "") return fallback;
      return value === true || value === "true" || value === 1 || value === "1";
    };
    const parseAddition2 = (value) => {
      if (!value) return {};
      if (typeof value === "object") return value;
      try {
        return JSON.parse(String(value || "{}"));
      } catch (_) {
        return {};
      }
    };
    const driverConfig = (driver) => {
      var _a2;
      return ((_a2 = driverInfoMap()[driver]) == null ? void 0 : _a2.config) || {};
    };
    const verifyDataFromError = (error, driver, addition) => {
      var _a2, _b2, _c, _d, _e;
      const message = (error == null ? void 0 : error.message) || "driver test failed";
      if (error == null ? void 0 : error.verify) {
        return {
          driver,
          addition: error.addition || addition,
          verify: error.verify
        };
      }
      const html = String(((_a2 = message.match(/need verify:\s*([\s\S]*)/i)) == null ? void 0 : _a2[1]) || "");
      const qrSrc = ((_b2 = html.match(/<img[^>]+src=["']([^"']+)["']/i)) == null ? void 0 : _b2[1]) || "";
      const qrText = ((_c = html.match(/<a[^>]+href=["']([^"']+)["']/i)) == null ? void 0 : _c[1]) || "";
      const qrData = ((_d = qrSrc.match(/base64,([^"')\s<]+)/i)) == null ? void 0 : _d[1]) || ((_e = html.match(/base64,([^"')\s<]+)/i)) == null ? void 0 : _e[1]) || "";
      return {
        driver,
        addition,
        verify: html ? {
          html,
          qr_data: qrData,
          qr_src: qrSrc,
          qr_text: qrText,
          type: "qrcode"
        } : null
      };
    };
    const proxyDefaults = (driver, source = {}) => {
      const config = driverConfig(driver);
      const addition = parseAddition2(source.addition);
      const quarkWebProxy = driver === "Quark" && !boolValue2(addition.use_transcoding_address);
      const preferProxy2 = boolValue2(config.prefer_proxy) || quarkWebProxy;
      return {
        web_proxy: boolValue2(source.web_proxy, preferProxy2),
        webdav_policy: source.webdav_policy || (preferProxy2 ? "native_proxy" : "302_redirect"),
        proxy_range: boolValue2(source.proxy_range),
        down_proxy_url: source.down_proxy_url || "",
        disable_proxy_sign: boolValue2(source.disable_proxy_sign)
      };
    };
    const normalizeStorageForImport = (storage, index) => {
      const driver = storage.driver || "SiYuanWorkspace";
      return {
        id: Number(storage.id || index + 1),
        mount_path: normalizePath(storage.mount_path || storage.mountPath || "/"),
        order: Number(storage.order ?? 0),
        driver,
        cache_expiration: Number(storage.cache_expiration ?? 30),
        custom_cache_policies: storage.custom_cache_policies || "",
        status: storage.status || "work",
        addition: storageAddition(storage.addition),
        remark: storage.remark || "",
        modified: Number(storage.modified || now()),
        disabled: !!storage.disabled,
        disable_index: boolValue2(storage.disable_index),
        ...proxyDefaults(driver, storage)
      };
    };
    const isLegacyKernelStorage = (storage) => (storage == null ? void 0 : storage.driver) === "SiYuanKernel";
    const mountPathExists = (mountPath, exceptId = 0) => {
      const target = normalizePath(mountPath || "/");
      return state.storages.some((item) => Number(item.id) !== Number(exceptId) && normalizePath(item.mount_path || "/") === target);
    };
    const nextUserId = () => Math.max(0, ...state.users.map((item) => Number(item.id || 0))) + 1;
    const userById = (id) => state.users.find((item) => Number(item.id) === Number(id));
    const userList = () => state.users.map(sanitizeUser);
    const withAdmin = (handler) => async (request2) => {
      const ctx = requireAdmin == null ? void 0 : requireAdmin(request2);
      if (ctx == null ? void 0 : ctx.error) return jsonResponse(ctx.error, ctx.error.code);
      return handler(request2, ctx == null ? void 0 : ctx.user);
    };
    const handlers = {
      "GET /api/admin/user/list": async (request2) => {
        await refreshConfig();
        return jsonResponse(success(pageSlice(userList(), request2)));
      },
      "GET /api/admin/user/get": async (request2) => {
        await refreshConfig();
        const id = Number(queryValue(request2, "id") || 1);
        const user = userById(id);
        if (!user) return jsonResponse(failure("user not found", 404));
        return jsonResponse(success(sanitizeUser(user)));
      },
      "POST /api/admin/user/update": async (request2) => {
        const req = await parseJson(request2);
        const index = state.users.findIndex((item) => item.id === Number(req.id));
        if (index < 0) return jsonResponse(failure("user not found", 404));
        const current = state.users[index];
        const role = Number(req.role ?? current.role);
        if (role !== Number(current.role)) return jsonResponse(failure("role can not be changed", 400));
        if (req.disabled && current.role === USER_ROLE.ADMIN) return jsonResponse(failure("admin user can not be disabled", 400));
        const next = normalizeUser({
          ...current,
          ...req,
          id: current.id,
          role: current.role,
          pwd_ts: req.password ? passwordTimestamp() : current.pwd_ts,
          otp_secret: req.otp_secret || current.otp_secret || ""
        }, index);
        if (req.password) setUserPassword(next, req.password, next.pwd_ts);
        state.users[index] = next;
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/user/create": async (request2) => {
        const req = await parseJson(request2);
        if (!req.username) return jsonResponse(failure("username is required", 400));
        if (state.users.some((item) => item.username === req.username)) return jsonResponse(failure("user already exists", 409));
        const role = Number(req.role ?? USER_ROLE.GENERAL);
        if (role === USER_ROLE.ADMIN || role === USER_ROLE.GUEST) return jsonResponse(failure("admin or guest user can not be created", 400));
        const user = normalizeUser({
          ...req,
          id: nextUserId(),
          role: USER_ROLE.GENERAL,
          pwd_ts: passwordTimestamp(),
          base_path: req.base_path || "/",
          permission: Number(req.permission ?? 0)
        }, state.users.length);
        if (req.password) setUserPassword(user, req.password, user.pwd_ts);
        state.users.push(user);
        await saveState2();
        return jsonResponse(success(sanitizeUser(user)));
      },
      "POST /api/admin/user/delete": async (request2) => {
        const req = await parseJson(request2);
        const id = Number(queryValue(request2, "id") || req.id);
        const user = userById(id);
        if (!user) return jsonResponse(failure("user not found", 404));
        if (user.role === USER_ROLE.ADMIN || user.role === USER_ROLE.GUEST) return jsonResponse(failure("admin or guest user can not be deleted", 400));
        state.users = state.users.filter((item) => item.id !== id);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/user/cancel_2fa": async (request2) => {
        const req = await parseJson(request2);
        const user = state.users.find((item) => item.id === Number(req.id));
        if (!user) return jsonResponse(failure("user not found", 404));
        user.otp = false;
        user.otp_secret = "";
        await saveState2();
        return jsonResponse(success());
      },
      "GET /api/admin/storage/list": async (request2) => {
        await refreshConfig();
        return jsonResponse(success(pageSlice(state.storages.map(storageResp), request2)));
      },
      "GET /api/admin/storage/get": async (request2) => {
        await refreshConfig();
        const id = Number(queryValue(request2, "id") || 1);
        return jsonResponse(success(storageResp(state.storages.find((item) => item.id === id) || state.storages[0])));
      },
      "POST /api/admin/storage/create": async (request2) => {
        await refreshConfig();
        const req = await parseJson(request2);
        const id = Math.max(0, ...state.storages.map((item) => item.id || 0)) + 1;
        const mountPath = normalizePath(req.mount_path || req.mountPath || `/mount-${id}`);
        if (mountPathExists(mountPath)) return jsonResponse(failure("mount path already exists", 409), 409);
        const driver = req.driver || "SiYuanWorkspace";
        const storage = {
          id,
          mount_path: mountPath,
          order: Number(req.order || 0),
          driver,
          cache_expiration: Number(req.cache_expiration ?? 30),
          custom_cache_policies: req.custom_cache_policies || "",
          status: req.status || "work",
          addition: storageAddition(req.addition),
          remark: req.remark || "",
          modified: now(),
          disabled: !!req.disabled,
          disable_index: boolValue2(req.disable_index),
          ...proxyDefaults(driver, req)
        };
        state.storages.push(storage);
        await saveState2();
        return jsonResponse(success({ id }));
      },
      "POST /api/admin/storage/update": async (request2) => {
        await refreshConfig();
        const req = await parseJson(request2);
        const storage = state.storages.find((item) => item.id === Number(req.id));
        if (!storage) return jsonResponse(failure("storage not found", 404));
        const mountPath = normalizePath(req.mount_path || storage.mount_path);
        if (mountPathExists(mountPath, storage.id)) return jsonResponse(failure("mount path already exists", 409), 409);
        Object.assign(storage, {
          ...req,
          mount_path: mountPath,
          addition: storageAddition(req.addition, storage.addition),
          cache_expiration: Number(req.cache_expiration ?? storage.cache_expiration ?? 30),
          disabled: !!req.disabled,
          disable_index: boolValue2(req.disable_index, storage.disable_index),
          modified: now(),
          ...proxyDefaults(req.driver || storage.driver, { ...storage, ...req })
        });
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/delete": async (request2) => {
        await refreshConfig();
        const req = await parseJson(request2);
        const id = Number(req.id);
        state.storages = state.storages.filter((item) => item.id !== id);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/enable": async (request2) => {
        await refreshConfig();
        const req = await parseJson(request2);
        const storage = state.storages.find((item) => item.id === Number(req.id));
        if (!storage) return jsonResponse(failure("storage not found", 404));
        storage.disabled = false;
        storage.status = "work";
        storage.modified = now();
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/disable": async (request2) => {
        await refreshConfig();
        const req = await parseJson(request2);
        const storage = state.storages.find((item) => item.id === Number(req.id));
        if (!storage) return jsonResponse(failure("storage not found", 404));
        storage.disabled = true;
        storage.status = "disabled";
        storage.modified = now();
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/storage/load_all": async () => jsonResponse(success()),
      "GET /api/admin/config/export": async () => jsonResponse(success(exportConfig())),
      "POST /api/admin/config/import": async (request2) => {
        const req = await parseJson(request2);
        const payload = (req == null ? void 0 : req.config) || req;
        const mode = (req == null ? void 0 : req.mode) || "replace";
        if (!payload || typeof payload !== "object") return jsonResponse(failure("config is required", 400));
        if (payload.settings && typeof payload.settings === "object") {
          state.settings = mode === "merge" ? { ...state.settings, ...payload.settings } : { ...defaultSettings(), ...payload.settings };
        }
        if (payload.users) {
          const importedUsers = asArray(payload.users).map(normalizeUser);
          state.users = importedUsers.length ? importedUsers : state.users;
        }
        if (payload.storages) {
          const importedStorages = asArray(payload.storages).map(normalizeStorageForImport).filter((storage) => !isLegacyKernelStorage(storage));
          state.storages = importedStorages;
        }
        if (payload.metas) state.metas = asArray(payload.metas).map((meta, index) => ({ ...meta, id: Number(meta.id || index + 1) }));
        if (payload.sharings) state.sharings = asArray(payload.sharings).map((share) => normalizeShare(share, now));
        await saveState2();
        return jsonResponse(success({
          users: state.users.length,
          storages: state.storages.length,
          metas: state.metas.length,
          sharings: state.sharings.length
        }));
      },
      "GET /api/admin/driver/names": async () => jsonResponse(success(driverNames())),
      "GET /api/admin/driver/list": async () => jsonResponse(success(driverInfoMap())),
      "GET /api/admin/driver/info": async (request2) => {
        const driver = queryValue(request2, "driver") || "SiYuanWorkspace";
        const info = driverInfoMap()[driver];
        if (!info) return jsonResponse(failure(`driver [${driver}] not found`, 404));
        return jsonResponse(success(info));
      },
      "POST /api/admin/driver/test": async (request2) => {
        var _a2, _b2;
        const req = await parseJson(request2);
        const driver = req.driver || "SiYuanWorkspace";
        let addition;
        try {
          addition = typeof req.addition === "string" ? JSON.parse(req.addition || "{}") : req.addition || {};
        } catch (error) {
          return jsonResponse(failure(error.message || "invalid addition JSON", 400));
        }
        if (!((_a2 = driverRuntime == null ? void 0 : driverRuntime.drivers) == null ? void 0 : _a2[driver])) return jsonResponse(failure(`driver [${driver}] not found`, 404));
        if (!driverRuntime.drivers[driver].test) return jsonResponse(failure(`driver [${driver}] does not expose a test method yet`, 501));
        try {
          if (((_b2 = req.verify) == null ? void 0 : _b2.type) === "sms") {
            if (!driverRuntime.drivers[driver].verify) return jsonResponse(failure(`driver [${driver}] does not expose a verify method yet`, 501));
            return jsonResponse(success(await driverRuntime.drivers[driver].verify({
              addition_json: addition,
              driver,
              mount_path: "/",
              settings: state.settings || {}
            }, req.verify)));
          }
          return jsonResponse(success(await driverRuntime.test(driver, addition, req.verify)));
        } catch (error) {
          return jsonResponse(failure(error.message || "driver test failed", 502, verifyDataFromError(error, driver, addition)));
        }
      },
      "GET /api/admin/setting/get": async (request2) => {
        const key = queryValue(request2, "key");
        const keys = queryValue(request2, "keys");
        if (key) return jsonResponse(success(settingItem(key, state.settings[key] || "")));
        return jsonResponse(success(keys.split(",").filter(Boolean).map((item, index) => settingItem(item, state.settings[item] || "", index))));
      },
      "GET /api/admin/setting/list": async (request2) => jsonResponse(success(listSettings(request2))),
      "POST /api/admin/setting/default": async (request2) => jsonResponse(success(listSettings(request2, defaultSettings()))),
      "POST /api/admin/setting/save": async (request2) => {
        const req = await parseJson(request2);
        const items = Array.isArray(req) ? req : [req];
        for (const item of items) {
          if (item && item.key) state.settings[item.key] = String(item.value ?? "");
        }
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/setting/delete": async (request2) => {
        const key = queryValue(request2, "key") || (await parseJson(request2)).key;
        if (key) delete state.settings[key];
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/setting/reset_token": async () => {
        state.settings.token = "siyuan-cloud-token-" + Math.random().toString(36).slice(2);
        await saveState2();
        return jsonResponse(success(state.settings.token));
      },
      "POST /api/admin/setting/set_aria2": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { aria2_uri: "uri", aria2_secret: "secret" }, "siyuan-cloud-aria2-placeholder");
      },
      "POST /api/admin/setting/set_qbit": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { qbittorrent_url: "url", qbittorrent_seedtime: "seedtime" });
      },
      "POST /api/admin/setting/set_transmission": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { transmission_uri: "uri", transmission_seedtime: "seedtime" });
      },
      "POST /api/admin/setting/set_115": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { "115_temp_dir": "temp_dir" });
      },
      "POST /api/admin/setting/set_115_open": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { "115_open_temp_dir": "temp_dir" });
      },
      "POST /api/admin/setting/set_123_pan": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { "123_temp_dir": "temp_dir" });
      },
      "POST /api/admin/setting/set_123_open": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { "123_open_temp_dir": "temp_dir", "123_open_callback_url": "callback_url" });
      },
      "POST /api/admin/setting/set_pikpak": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { pikpak_temp_dir: "temp_dir" });
      },
      "POST /api/admin/setting/set_thunder": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { thunder_temp_dir: "temp_dir" });
      },
      "POST /api/admin/setting/set_thunderx": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { thunderx_temp_dir: "temp_dir" });
      },
      "POST /api/admin/setting/set_thunder_browser": async (request2) => {
        const req = await parseJson(request2);
        return saveToolSettings(req, { thunder_browser_temp_dir: "temp_dir" });
      }
    };
    return Object.fromEntries(Object.entries(handlers).map(([key, handler]) => [key, withAdmin(handler)]));
  };
  const tokenResp = (user, settings) => ({
    token: generateAuthToken(user, (settings == null ? void 0 : settings.token) || "siyuan-cloud-token"),
    username: (user == null ? void 0 : user.username) || "admin"
  });
  const requestToken = (request2) => {
    var _a2, _b2;
    const headers = ((_a2 = request2 == null ? void 0 : request2.request) == null ? void 0 : _a2.headers) || ((_b2 = request2 == null ? void 0 : request2.Request) == null ? void 0 : _b2.Headers) || {};
    for (const [key, value] of Object.entries(headers)) {
      if (!["authorization", "x-siyuan-cloud-authorization"].includes(String(key).toLowerCase())) continue;
      return String(Array.isArray(value) ? value[0] || "" : value || "").replace(/^Bearer\s+/i, "");
    }
    return "";
  };
  const rememberLoggedOutToken = async ({ currentUser, getState, request: request2, saveState: saveState2 }) => {
    const ctx = currentUser(request2, { allowDisabledGuest: true });
    if (!ctx.user || ctx.error || ctx.auth !== "jwt") return;
    const token = requestToken(request2);
    if (!token) return;
    const user = getState().users.find((item) => Number(item.id) === Number(ctx.user.id));
    if (!user) return;
    const tokens = Array.isArray(user.logout_tokens) ? user.logout_tokens : [];
    const fingerprint = tokenFingerprint(token);
    user.logout_tokens = [fingerprint, ...tokens.filter((item) => item !== fingerprint)].slice(0, 32);
    await saveState2();
  };
  const createAuthHandlers = ({
    currentUser,
    getState,
    parseJson,
    saveState: saveState2
  }) => ({
    "POST /api/auth/login": async (request2) => {
      const req = await parseJson(request2);
      const user = getState().users.find((item) => item.username === req.username);
      if (!user || user.disabled) return jsonResponse(failure("Invalid username or password", 401));
      if (!verifyPassword(user, req.password)) return jsonResponse(failure("Invalid username or password", 401));
      if (!user.pwd_hash && req.password !== void 0) setUserPassword(user, req.password);
      if (!user.pwd_ts) {
        user.pwd_ts = passwordTimestamp();
      }
      await saveState2();
      return jsonResponse(success(tokenResp(user, getState().settings)));
    },
    "POST /api/auth/login/hash": async (request2) => {
      const req = await parseJson(request2);
      const user = getState().users.find((item) => item.username === req.username);
      if (!user || user.disabled) return jsonResponse(failure("Invalid username or password", 401));
      if (!verifyStaticPasswordHash(user, req.password)) return jsonResponse(failure("Invalid username or password", 401));
      if (!user.pwd_hash && user.password !== void 0) setUserPassword(user, user.password);
      if (!user.pwd_ts) {
        user.pwd_ts = passwordTimestamp();
      }
      await saveState2();
      return jsonResponse(success(tokenResp(user, getState().settings)));
    },
    "POST /api/auth/login/ldap": async () => jsonResponse(failure("LDAP login is not implemented in the SiYuan kernel runtime", 501, {
      upstream: "OpenList server/handles/ldap_login.go",
      reason: "The JavaScript kernel plugin runtime has no LDAP server bind/search implementation yet."
    })),
    "GET /api/auth/logout": async (request2) => {
      await rememberLoggedOutToken({ currentUser, getState, request: request2, saveState: saveState2 });
      return jsonResponse(success());
    },
    "POST /api/auth/logout": async (request2) => {
      await rememberLoggedOutToken({ currentUser, getState, request: request2, saveState: saveState2 });
      return jsonResponse(success());
    },
    "GET /api/me": async (request2) => {
      const ctx = currentUser(request2, { allowDisabledGuest: true });
      if (ctx.error) return jsonResponse(failure(ctx.error, 401));
      return jsonResponse(success(sanitizeUser(ctx.user)));
    },
    "POST /api/me/update": async (request2) => {
      const req = await parseJson(request2);
      const state = getState();
      const ctx = currentUser(request2, { allowDisabledGuest: true });
      if (ctx.error) return jsonResponse(failure(ctx.error, 401));
      const current = ctx.user;
      const index = state.users.findIndex((item) => Number(item.id) === Number(current == null ? void 0 : current.id));
      if (!current || current.role === USER_ROLE.GUEST) return jsonResponse(failure("Guest user can not update profile", 403));
      const next = {
        ...current,
        username: req.username || current.username,
        pwd_ts: req.password ? passwordTimestamp() : current.pwd_ts,
        sso_id: req.sso_id || current.sso_id || ""
      };
      if (req.password) setUserPassword(next, req.password, next.pwd_ts);
      state.users[index >= 0 ? index : 0] = next;
      await saveState2();
      return jsonResponse(success());
    }
  });
  const notImplemented = (name) => jsonResponse(failure(`${name} is not implemented in the SiYuan kernel port yet`, 501));
  const createCompatHandlers = () => ({
    "GET /api/auth/sso": async () => notImplemented("sso login"),
    "GET /api/auth/sso_callback": async () => notImplemented("sso callback"),
    "GET /api/auth/get_sso_id": async () => notImplemented("sso id lookup"),
    "GET /api/auth/sso_get_token": async () => notImplemented("sso token lookup"),
    "GET /api/authn/webauthn_begin_login": async () => notImplemented("webauthn login"),
    "POST /api/authn/webauthn_finish_login": async () => notImplemented("webauthn login"),
    "GET /api/authn/webauthn_begin_registration": async () => notImplemented("webauthn registration"),
    "POST /api/authn/webauthn_finish_registration": async () => notImplemented("webauthn registration"),
    "POST /api/authn/delete_authn": async () => jsonResponse(success()),
    "GET /api/authn/getcredentials": async () => jsonResponse(success([])),
    "POST /api/admin/user/del_cache": async () => jsonResponse(success())
  });
  const createIndexHandlers = ({
    currentUser,
    parseJson,
    requireAdmin,
    searchIndex,
    taskStore
  }) => {
    let activeIndexTaskId = "";
    const withAdmin = (handler) => async (request2) => {
      const ctx = requireAdmin == null ? void 0 : requireAdmin(request2);
      if (ctx == null ? void 0 : ctx.error) return jsonResponse(ctx.error, ctx.error.code);
      return handler(request2, ctx == null ? void 0 : ctx.user);
    };
    const shouldRunAsync = (req) => req.async === true || req.task === true || req.queued === true;
    const queueIndexTask = async (request2, req, user, taskName, buildOptions) => {
      if (!(taskStore == null ? void 0 : taskStore.enqueueTask)) return null;
      const task = await taskStore.enqueueTask("index", {
        creator: (currentUser == null ? void 0 : currentUser(request2)) || user,
        name: taskName,
        status: "queued"
      }, async ({ id, isCanceled, progress: progress2, throwIfCanceled }) => {
        activeIndexTaskId = id;
        await progress2({ progress: 5, status: "clearing" });
        throwIfCanceled();
        if (buildOptions.clearFirst) await searchIndex.clear();
        await progress2({ progress: 15, status: "indexing" });
        await searchIndex.build({ ...buildOptions, shouldCancel: isCanceled });
        throwIfCanceled();
        await progress2({ progress: 95, status: "finalizing" });
      });
      return task;
    };
    const currentIndexTask = (user) => {
      var _a2;
      const undone = ((_a2 = taskStore == null ? void 0 : taskStore.listTasks) == null ? void 0 : _a2.call(taskStore, "index", false, user)) || [];
      return undone.find((task) => task.state === "running" || task.state === "canceling") || undone[0] || null;
    };
    const handlers = {
      "POST /api/admin/index/build": async (request2, user) => {
        const req = await parseJson(request2);
        if (shouldRunAsync(req)) {
          const task = await queueIndexTask(request2, req, user, "index build", { clearFirst: true, count: true, paths: ["/"] });
          return jsonResponse(success({ task }));
        }
        await searchIndex.clear();
        await searchIndex.build({ clearFirst: true, count: true, paths: ["/"] });
        return jsonResponse(success());
      },
      "POST /api/admin/index/update": async (request2, user) => {
        const req = await parseJson(request2);
        const paths = Array.isArray(req.paths) && req.paths.length ? req.paths : ["/"];
        if (shouldRunAsync(req)) {
          const task = await queueIndexTask(request2, req, user, "index update", { clearFirst: false, count: false, maxDepth: req.max_depth, paths });
          return jsonResponse(success({ task }));
        }
        await searchIndex.build({ clearFirst: false, count: false, maxDepth: req.max_depth, paths });
        return jsonResponse(success());
      },
      "POST /api/admin/index/stop": async (_request, user) => {
        var _a2;
        const activeTask = activeIndexTaskId ? (_a2 = taskStore == null ? void 0 : taskStore.getTask) == null ? void 0 : _a2.call(taskStore, "index", activeIndexTaskId, user) : currentIndexTask(user);
        const task = activeTask && !["succeeded", "failed", "canceled"].includes(activeTask.state) ? activeTask : currentIndexTask(user);
        if (!task || task.state === "succeeded" || task.state === "failed" || task.state === "canceled") {
          return jsonResponse(failure("index is not running", 400));
        }
        await taskStore.markCanceled("index", task.id, user);
        await searchIndex.writeProgress({
          error: "index canceled",
          is_done: true,
          task_id: task.id
        });
        return jsonResponse(success({ task_id: task.id }));
      },
      "POST /api/admin/index/clear": async () => {
        await searchIndex.clear();
        await searchIndex.writeProgress({
          error: "",
          is_done: true,
          last_done_time: null,
          obj_count: 0
        });
        return jsonResponse(success());
      },
      "GET /api/admin/index/progress": async () => {
        const task = currentIndexTask();
        return jsonResponse(success({
          ...searchIndex.getProgress(),
          task: task || null,
          task_id: (task == null ? void 0 : task.id) || ""
        }));
      }
    };
    return Object.fromEntries(Object.entries(handlers).map(([key, handler]) => [key, withAdmin(handler)]));
  };
  const createMetaHandlers = ({
    getState,
    pageSlice,
    parseJson,
    queryValue,
    requireAdmin,
    saveState: saveState2
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const nextId = () => Math.max(0, ...(state.metas || []).map((item) => item.id || 0)) + 1;
    const withAdmin = (handler) => async (request2) => {
      const ctx = requireAdmin == null ? void 0 : requireAdmin(request2);
      if (ctx == null ? void 0 : ctx.error) return jsonResponse(ctx.error, ctx.error.code);
      return handler(request2, ctx == null ? void 0 : ctx.user);
    };
    const handlers = {
      "GET /api/admin/meta/list": async (request2) => {
        state.metas = state.metas || [];
        return jsonResponse(success(pageSlice([...state.metas].sort((a, b) => a.id - b.id), request2)));
      },
      "GET /api/admin/meta/get": async (request2) => {
        const id = Number(queryValue(request2, "id"));
        const meta = (state.metas || []).find((item) => item.id === id);
        return meta ? jsonResponse(success(meta)) : jsonResponse(failure("meta not found", 404));
      },
      "POST /api/admin/meta/create": async (request2) => {
        const req = await parseJson(request2);
        try {
          validateHideRules(req.hide);
        } catch (error) {
          return jsonResponse(failure(`${req.hide || ""} is illegal: ${error.message}`, 400));
        }
        state.metas = state.metas || [];
        const meta = normalizeMeta(req, nextId());
        if (state.metas.some((item) => item.path === meta.path)) return jsonResponse(failure("meta path already exists", 409));
        state.metas.push(meta);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/meta/update": async (request2) => {
        const req = await parseJson(request2);
        try {
          validateHideRules(req.hide);
        } catch (error) {
          return jsonResponse(failure(`${req.hide || ""} is illegal: ${error.message}`, 400));
        }
        state.metas = state.metas || [];
        const index = state.metas.findIndex((item) => item.id === Number(req.id));
        if (index < 0) return jsonResponse(failure("meta not found", 404));
        state.metas[index] = normalizeMeta({ ...state.metas[index], ...req }, state.metas[index].id);
        await saveState2();
        return jsonResponse(success());
      },
      "POST /api/admin/meta/delete": async (request2) => {
        const req = await parseJson(request2);
        const id = Number(queryValue(request2, "id") || req.id);
        state.metas = (state.metas || []).filter((item) => item.id !== id);
        await saveState2();
        return jsonResponse(success());
      }
    };
    return Object.fromEntries(Object.entries(handlers).map(([key, handler]) => [key, withAdmin(handler)]));
  };
  const createMessageHandlers = ({
    getState,
    now,
    parseJson,
    requireAdmin,
    saveState: saveState2
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const withAdmin = (handler) => async (request2) => {
      const ctx = requireAdmin == null ? void 0 : requireAdmin(request2);
      if (ctx == null ? void 0 : ctx.error) return jsonResponse(ctx.error, ctx.error.code);
      return handler(request2, ctx == null ? void 0 : ctx.user);
    };
    const handlers = {
      "POST /api/admin/message/get": async () => {
        state.messages = state.messages || [];
        return jsonResponse(success(pageResp([...state.messages].reverse(), state.messages.length)));
      },
      "POST /api/admin/message/send": async (request2) => {
        const req = await parseJson(request2);
        state.messages = state.messages || [];
        state.messages.push({
          id: `message-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`,
          title: req.title || req.Title || "",
          content: req.content || req.message || req.Message || "",
          type: req.type || "info",
          created: now()
        });
        await saveState2();
        return jsonResponse(success());
      }
    };
    return Object.fromEntries(Object.entries(handlers).map(([key, handler]) => [key, withAdmin(handler)]));
  };
  const createScanHandlers = ({
    getState,
    now,
    requireAdmin,
    saveState: saveState2
  }) => {
    const setScan = async (scan) => {
      getState().scan = {
        updated: now(),
        ...scan
      };
      await saveState2();
      return jsonResponse(success());
    };
    const withAdmin = (handler) => async (request2) => {
      const ctx = requireAdmin == null ? void 0 : requireAdmin(request2);
      if (ctx == null ? void 0 : ctx.error) return jsonResponse(ctx.error, ctx.error.code);
      return handler(request2, ctx == null ? void 0 : ctx.user);
    };
    const handlers = {
      "POST /api/admin/scan/start": async () => setScan({ status: "done", total: 1, done: 1 }),
      "POST /api/admin/scan/stop": async () => setScan({ status: "idle", total: 0, done: 0 }),
      "GET /api/admin/scan/progress": async () => jsonResponse(success(getState().scan || { status: "idle", total: 0, done: 0 }))
    };
    return Object.fromEntries(Object.entries(handlers).map(([key, handler]) => [key, withAdmin(handler)]));
  };
  const createSecurityHandlers = ({
    currentUser,
    getState,
    now,
    parseJson,
    queryValue,
    requireAdmin,
    saveState: saveState2
  }) => {
    const state = new Proxy({}, {
      get: (_, prop) => getState()[prop],
      set: (_, prop, value) => {
        getState()[prop] = value;
        return true;
      }
    });
    const publicKeysForUser = (userId) => (state.ssh_keys || []).filter((item) => item.user_id === userId);
    const notGuest = (request2) => {
      var _a2;
      const ctx = currentUser(request2, { allowDisabledGuest: true });
      if (ctx.error) return { error: failure(ctx.error, 401), user: ctx.user };
      if (Number((_a2 = ctx.user) == null ? void 0 : _a2.role) === 1) return { error: failure("You are a guest", 403), user: ctx.user };
      return ctx;
    };
    const adminOnly = (handler) => async (request2) => {
      const ctx = requireAdmin == null ? void 0 : requireAdmin(request2);
      if (ctx == null ? void 0 : ctx.error) return jsonResponse(ctx.error, ctx.error.code);
      return handler(request2, ctx == null ? void 0 : ctx.user);
    };
    const addKey = async (request2, userId) => {
      const req = await parseJson(request2);
      state.ssh_keys = state.ssh_keys || [];
      const id = Math.max(0, ...state.ssh_keys.map((item) => item.id || 0)) + 1;
      state.ssh_keys.push({
        id,
        user_id: Number(req.user_id || userId || 1),
        title: req.title || req.name || `key-${id}`,
        key: req.key || req.public_key || "",
        created: now()
      });
      await saveState2();
      return jsonResponse(success({ id }));
    };
    const deleteKey = async (request2, userId) => {
      const req = await parseJson(request2);
      const id = Number(queryValue(request2, "id") || req.id);
      state.ssh_keys = (state.ssh_keys || []).filter((item) => item.id !== id || userId && item.user_id !== userId);
      await saveState2();
      return jsonResponse(success());
    };
    return {
      "GET /api/me/sshkey/list": async (request2) => {
        const ctx = notGuest(request2);
        if (ctx.error) return jsonResponse(ctx.error);
        return jsonResponse(success(publicKeysForUser(Number(ctx.user.id))));
      },
      "POST /api/me/sshkey/add": async (request2) => {
        const ctx = notGuest(request2);
        if (ctx.error) return jsonResponse(ctx.error);
        return addKey(request2, Number(ctx.user.id));
      },
      "POST /api/me/sshkey/delete": async (request2) => {
        const ctx = notGuest(request2);
        if (ctx.error) return jsonResponse(ctx.error);
        return deleteKey(request2, Number(ctx.user.id));
      },
      "GET /api/admin/user/sshkey/list": adminOnly(async (request2) => {
        const userId = Number(queryValue(request2, "user_id") || queryValue(request2, "id") || 1);
        return jsonResponse(success(publicKeysForUser(userId)));
      }),
      "POST /api/admin/user/sshkey/delete": adminOnly(async (request2) => deleteKey(request2, 0)),
      "POST /api/auth/2fa/generate": async (request2) => {
        const ctx = notGuest(request2);
        if (ctx.error) return jsonResponse(ctx.error);
        const user = state.users.find((item) => Number(item.id) === Number(ctx.user.id));
        if (!user) return jsonResponse(failure("user not found", 404));
        user.otp_secret = `siyuan-cloud-${Math.random().toString(36).slice(2, 12)}`;
        await saveState2();
        return jsonResponse(success({
          otp_secret: user.otp_secret,
          qr: ""
        }));
      },
      "POST /api/auth/2fa/verify": async (request2) => {
        const ctx = notGuest(request2);
        if (ctx.error) return jsonResponse(ctx.error);
        const user = state.users.find((item) => Number(item.id) === Number(ctx.user.id));
        if (!user) return jsonResponse(failure("user not found", 404));
        user.otp = true;
        await saveState2();
        return jsonResponse(success());
      }
    };
  };
  var u8 = Uint8Array, u16 = Uint16Array, i32 = Int32Array;
  var fleb = new u8([
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    0,
    1,
    1,
    1,
    1,
    2,
    2,
    2,
    2,
    3,
    3,
    3,
    3,
    4,
    4,
    4,
    4,
    5,
    5,
    5,
    5,
    0,
    /* unused */
    0,
    0,
    /* impossible */
    0
  ]);
  var fdeb = new u8([
    0,
    0,
    0,
    0,
    1,
    1,
    2,
    2,
    3,
    3,
    4,
    4,
    5,
    5,
    6,
    6,
    7,
    7,
    8,
    8,
    9,
    9,
    10,
    10,
    11,
    11,
    12,
    12,
    13,
    13,
    /* unused */
    0,
    0
  ]);
  var clim = new u8([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);
  var freb = function(eb, start) {
    var b = new u16(31);
    for (var i2 = 0; i2 < 31; ++i2) {
      b[i2] = start += 1 << eb[i2 - 1];
    }
    var r = new i32(b[30]);
    for (var i2 = 1; i2 < 30; ++i2) {
      for (var j = b[i2]; j < b[i2 + 1]; ++j) {
        r[j] = j - b[i2] << 5 | i2;
      }
    }
    return { b, r };
  };
  var _a = freb(fleb, 2), fl = _a.b, revfl = _a.r;
  fl[28] = 258, revfl[258] = 28;
  var _b = freb(fdeb, 0), fd = _b.b;
  var rev = new u16(32768);
  for (var i = 0; i < 32768; ++i) {
    var x = (i & 43690) >> 1 | (i & 21845) << 1;
    x = (x & 52428) >> 2 | (x & 13107) << 2;
    x = (x & 61680) >> 4 | (x & 3855) << 4;
    rev[i] = ((x & 65280) >> 8 | (x & 255) << 8) >> 1;
  }
  var hMap = (function(cd, mb, r) {
    var s = cd.length;
    var i2 = 0;
    var l = new u16(mb);
    for (; i2 < s; ++i2) {
      if (cd[i2])
        ++l[cd[i2] - 1];
    }
    var le = new u16(mb);
    for (i2 = 1; i2 < mb; ++i2) {
      le[i2] = le[i2 - 1] + l[i2 - 1] << 1;
    }
    var co;
    if (r) {
      co = new u16(1 << mb);
      var rvb = 15 - mb;
      for (i2 = 0; i2 < s; ++i2) {
        if (cd[i2]) {
          var sv = i2 << 4 | cd[i2];
          var r_1 = mb - cd[i2];
          var v = le[cd[i2] - 1]++ << r_1;
          for (var m = v | (1 << r_1) - 1; v <= m; ++v) {
            co[rev[v] >> rvb] = sv;
          }
        }
      }
    } else {
      co = new u16(s);
      for (i2 = 0; i2 < s; ++i2) {
        if (cd[i2]) {
          co[i2] = rev[le[cd[i2] - 1]++] >> 15 - cd[i2];
        }
      }
    }
    return co;
  });
  var flt = new u8(288);
  for (var i = 0; i < 144; ++i)
    flt[i] = 8;
  for (var i = 144; i < 256; ++i)
    flt[i] = 9;
  for (var i = 256; i < 280; ++i)
    flt[i] = 7;
  for (var i = 280; i < 288; ++i)
    flt[i] = 8;
  var fdt = new u8(32);
  for (var i = 0; i < 32; ++i)
    fdt[i] = 5;
  var flrm = /* @__PURE__ */ hMap(flt, 9, 1);
  var fdrm = /* @__PURE__ */ hMap(fdt, 5, 1);
  var max = function(a) {
    var m = a[0];
    for (var i2 = 1; i2 < a.length; ++i2) {
      if (a[i2] > m)
        m = a[i2];
    }
    return m;
  };
  var bits = function(d, p, m) {
    var o = p / 8 | 0;
    return (d[o] | d[o + 1] << 8) >> (p & 7) & m;
  };
  var bits16 = function(d, p) {
    var o = p / 8 | 0;
    return (d[o] | d[o + 1] << 8 | d[o + 2] << 16) >> (p & 7);
  };
  var shft = function(p) {
    return (p + 7) / 8 | 0;
  };
  var slc = function(v, s, e) {
    if (e == null || e > v.length)
      e = v.length;
    return new u8(v.subarray(s, e));
  };
  var ec = [
    "unexpected EOF",
    "invalid block type",
    "invalid length/literal",
    "invalid distance",
    "stream finished",
    "no stream handler",
    ,
    // determined by compression function
    "no callback",
    "invalid UTF-8 data",
    "extra field too long",
    "date not in range 1980-2099",
    "filename too long",
    "stream finishing",
    "invalid zip data"
    // determined by unknown compression method
  ];
  var err = function(ind, msg, nt) {
    var e = new Error(msg || ec[ind]);
    e.code = ind;
    if (Error.captureStackTrace)
      Error.captureStackTrace(e, err);
    if (!nt)
      throw e;
    return e;
  };
  var inflt = function(dat, st, buf, dict) {
    var sl = dat.length, dl = 0;
    if (!sl || st.f && !st.l)
      return buf || new u8(0);
    var noBuf = !buf;
    var resize = noBuf || st.i != 2;
    var noSt = st.i;
    if (noBuf)
      buf = new u8(sl * 3);
    var cbuf = function(l2) {
      var bl = buf.length;
      if (l2 > bl) {
        var nbuf = new u8(Math.max(bl * 2, l2));
        nbuf.set(buf);
        buf = nbuf;
      }
    };
    var final = st.f || 0, pos = st.p || 0, bt = st.b || 0, lm = st.l, dm = st.d, lbt = st.m, dbt = st.n;
    var tbts = sl * 8;
    do {
      if (!lm) {
        final = bits(dat, pos, 1);
        var type = bits(dat, pos + 1, 3);
        pos += 3;
        if (!type) {
          var s = shft(pos) + 4, l = dat[s - 4] | dat[s - 3] << 8, t = s + l;
          if (t > sl) {
            if (noSt)
              err(0);
            break;
          }
          if (resize)
            cbuf(bt + l);
          buf.set(dat.subarray(s, t), bt);
          st.b = bt += l, st.p = pos = t * 8, st.f = final;
          continue;
        } else if (type == 1)
          lm = flrm, dm = fdrm, lbt = 9, dbt = 5;
        else if (type == 2) {
          var hLit = bits(dat, pos, 31) + 257, hcLen = bits(dat, pos + 10, 15) + 4;
          var tl = hLit + bits(dat, pos + 5, 31) + 1;
          pos += 14;
          var ldt = new u8(tl);
          var clt = new u8(19);
          for (var i2 = 0; i2 < hcLen; ++i2) {
            clt[clim[i2]] = bits(dat, pos + i2 * 3, 7);
          }
          pos += hcLen * 3;
          var clb = max(clt), clbmsk = (1 << clb) - 1;
          var clm = hMap(clt, clb, 1);
          for (var i2 = 0; i2 < tl; ) {
            var r = clm[bits(dat, pos, clbmsk)];
            pos += r & 15;
            var s = r >> 4;
            if (s < 16) {
              ldt[i2++] = s;
            } else {
              var c = 0, n = 0;
              if (s == 16)
                n = 3 + bits(dat, pos, 3), pos += 2, c = ldt[i2 - 1];
              else if (s == 17)
                n = 3 + bits(dat, pos, 7), pos += 3;
              else if (s == 18)
                n = 11 + bits(dat, pos, 127), pos += 7;
              while (n--)
                ldt[i2++] = c;
            }
          }
          var lt = ldt.subarray(0, hLit), dt = ldt.subarray(hLit);
          lbt = max(lt);
          dbt = max(dt);
          lm = hMap(lt, lbt, 1);
          dm = hMap(dt, dbt, 1);
        } else
          err(1);
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
      }
      if (resize)
        cbuf(bt + 131072);
      var lms = (1 << lbt) - 1, dms = (1 << dbt) - 1;
      var lpos = pos;
      for (; ; lpos = pos) {
        var c = lm[bits16(dat, pos) & lms], sym = c >> 4;
        pos += c & 15;
        if (pos > tbts) {
          if (noSt)
            err(0);
          break;
        }
        if (!c)
          err(2);
        if (sym < 256)
          buf[bt++] = sym;
        else if (sym == 256) {
          lpos = pos, lm = null;
          break;
        } else {
          var add = sym - 254;
          if (sym > 264) {
            var i2 = sym - 257, b = fleb[i2];
            add = bits(dat, pos, (1 << b) - 1) + fl[i2];
            pos += b;
          }
          var d = dm[bits16(dat, pos) & dms], dsym = d >> 4;
          if (!d)
            err(3);
          pos += d & 15;
          var dt = fd[dsym];
          if (dsym > 3) {
            var b = fdeb[dsym];
            dt += bits16(dat, pos) & (1 << b) - 1, pos += b;
          }
          if (pos > tbts) {
            if (noSt)
              err(0);
            break;
          }
          if (resize)
            cbuf(bt + 131072);
          var end = bt + add;
          if (bt < dt) {
            var shift = dl - dt, dend = Math.min(dt, end);
            if (shift + bt < 0)
              err(3);
            for (; bt < dend; ++bt)
              buf[bt] = dict[shift + bt];
          }
          for (; bt < end; ++bt)
            buf[bt] = buf[bt - dt];
        }
      }
      st.l = lm, st.p = lpos, st.b = bt, st.f = final;
      if (lm)
        final = 1, st.m = lbt, st.d = dm, st.n = dbt;
    } while (!final);
    return bt != buf.length && noBuf ? slc(buf, 0, bt) : buf.subarray(0, bt);
  };
  var et = /* @__PURE__ */ new u8(0);
  var gzs = function(d) {
    if (d[0] != 31 || d[1] != 139 || d[2] != 8)
      err(6, "invalid gzip data");
    var flg = d[3];
    var st = 10;
    if (flg & 4)
      st += (d[10] | d[11] << 8) + 2;
    for (var zs = (flg >> 3 & 1) + (flg >> 4 & 1); zs > 0; zs -= !d[st++])
      ;
    return st + (flg & 2);
  };
  var gzl = function(d) {
    var l = d.length;
    return (d[l - 4] | d[l - 3] << 8 | d[l - 2] << 16 | d[l - 1] << 24) >>> 0;
  };
  function inflateSync(data, opts) {
    return inflt(data, { i: 2 }, opts, opts);
  }
  function gunzipSync(data, opts) {
    var st = gzs(data);
    if (st + 8 > data.length)
      err(6, "invalid gzip data");
    return inflt(data.subarray(st, -8), { i: 2 }, new u8(gzl(data)), opts);
  }
  var td = typeof TextDecoder != "undefined" && /* @__PURE__ */ new TextDecoder();
  var tds = 0;
  try {
    td.decode(et, { stream: true });
    tds = 1;
  } catch (e) {
  }
  const GBK_TABLE = [
    `丂丄丅丆丏丒丗丟丠両丣並丩丮丯丱丳丵丷丼乀乁乂乄乆乊乑乕乗乚乛乢乣乤乥乧乨乪乫乬乭乮乯乲乴乵乶乷乸乹乺乻乼乽乿亀亁亂亃亄亅亇亊亐亖亗亙亜亝亞亣亪亯亰亱亴亶亷亸亹亼亽亾仈仌仏仐仒仚仛仜仠仢仦仧仩仭仮仯仱仴仸仹仺仼仾伀伂伃伄伅伆伇伈伋伌伒伓伔伕伖伜伝伡伣伨伩伬伭伮伱伳伵伷伹伻伾伿佀佁佂佄佅佇佈佉佊佋佌佒佔佖佡佢佦佨佪佫佭佮佱佲併佷佸佹佺佽侀侁侂侅來侇侊侌侎侐侒侓侕侖侘侙侚侜侞侟価侢侤侫侭侰侱侲侳侴侶侷侸侹侺侻侼侽侾俀俁係俆俇俈俉俋俌俍俒俓俔俕俖俙俛俠俢俤俥俧俫俬俰俲俴俵俶俷俹俻俼俽俿倀倁倂倃倄倅倆倇倈倉倊個倎倐們倓倕倖倗倛倝倞倠倢倣値倧倫倯倰倱倲倳倴倵倶倷倸倹倻倽倿偀偁偂偄偅偆偉偊偋偍偐偑偒偓偔偖偗偘偙偛偝偞偟偠偡偢偣偤偦偧偨偩偪偫偭偮偯偰偱偲偳側偵偸偹偺偼偽傁傂傃傄傆傇傉傊傋傌傎傏傐傑傒傓傔傕傖傗傘備傚傛傜傝傞傟傠傡傢傤傦傪傫傭傮傯傰傱傳傴債傶傷傸傹傼傽傾傿僀僁僂僃僄僅僆僇僈僉僊僋僌働僎僐僑僒僓僔僕僗僘僙僛僜僝僞僟僠僡僢僣僤僥僨僩僪僫僯僰僱僲僴僶僷僸價僺僼僽僾僿儀儁儂儃億儅儈儉儊儌儍儎儏儐儑儓儔儕儖儗儘儙儚儛儜儝儞償儠儢儣儤儥儦儧儨儩優儫儬儭儮儯儰儱儲儳儴儵儶儷儸儹儺儻儼儽儾兂兇兊兌兎兏児兒兓兗兘兙兛兝兞兟兠兡兣兤兦內兩兪兯兲兺兾兿冃冄円冇冊冋冎冏冐冑冓冔冘冚冝冞冟冡冣冦冧冨冩冪冭冮冴冸冹冺冾冿凁凂凃凅凈凊凍凎凐凒凓凔凕凖凗凘凙凚凜凞凟凢凣凥処凧凨凩凪凬凮凱凲凴凷凾刄刅刉刋刌刏刐刓刔刕刜刞刟刡刢刣別刦刧刪刬刯刱刲刴刵刼刾剄剅剆則剈剉剋剎剏剒剓剕剗剘剙剚剛剝剟剠剢剣剤剦剨剫剬剭剮剰剱剳剴創剶剷剸剹剺剻剼剾劀劃劄劅劆劇劉劊劋劌劍劎劏劑劒劔劕劖劗劘劙劚劜劤劥劦劧劮劯劰労劵劶劷劸効劺劻劼劽勀勁勂勄勅勆勈勊勌勍勎勏勑勓勔動勗務勚勛勜勝勞勠勡勢勣勥勦勧勨勩勪勫勬勭勮勯勱勲勳勴勵勶勷勸勻勼勽匁匂匃匄匇匉匊匋匌匎匑匒匓匔匘匛匜匞匟匢匤匥匧匨匩匫匬匭匯匰匱匲匳匴匵匶匷匸匼匽區卂卄卆卋卌卍卐協単卙卛卝卥卨卪卬卭卲卶卹卻卼卽卾厀厁厃厇厈厊厎厏厐厑厒厓厔厖厗厙厛厜厞厠厡厤厧厪厫厬厭厯厰厱厲厳厴厵厷厸厹厺厼厽厾叀參叄叅叆叇収叏叐叒叓叕叚叜叝叞叡叢叧叴叺叾叿吀吂吅吇吋吔吘吙吚吜吢吤吥吪吰吳吶吷吺吽吿呁呂呄呅呇呉呌呍呎呏呑呚呝呞呟呠呡呣呥呧呩呪呫呬呭呮呯呰呴呹呺呾呿咁咃咅咇咈咉咊咍咑咓咗咘咜咞咟咠咡咢咥咮咰咲咵咶咷咹咺咼咾哃哅哊哋哖哘哛哠員哢哣哤哫哬哯哰哱哴哵哶哷哸哹哻哾唀唂唃唄唅唈唊唋唌唍唎唒唓唕唖唗唘唙唚唜唝唞唟唡唥唦唨唩唫唭唲唴唵唶唸唹唺唻唽啀啂啅啇啈啋啌啍啎問啑啒啓啔啗啘啙啚啛啝啞啟啠啢啣啨啩啫啯啰啱啲啳啴啹啺啽啿喅喆喌喍喎喐喒喓喕喖喗喚喛喞喠喡喢喣喤喥喦喨喩喪喫喬喭單喯喰喲喴営喸喺喼喿嗀嗁嗂嗃嗆嗇嗈嗊嗋嗎嗏嗐嗕嗗嗘嗙嗚嗛嗞嗠嗢嗧嗩嗭嗮嗰嗱嗴嗶嗸嗹嗺嗻嗼嗿嘂嘃嘄嘅嘆嘇嘊嘋嘍嘐嘑嘒嘓嘔嘕嘖嘗嘙嘚嘜嘝嘠嘡嘢嘥嘦嘨嘩嘪嘫嘮嘯嘰嘳嘵嘷嘸嘺嘼嘽嘾噀噁噂噃噄噅噆噇噈噉噊噋噏噐噑噒噓噕噖噚噛噝噞噟噠噡噣噥噦噧噭噮噯噰噲噳噴噵噷噸噹噺噽噾噿嚀嚁嚂嚃嚄嚇嚈嚉嚊嚋嚌嚍嚐嚑嚒嚔嚕嚖嚗嚘嚙嚚嚛嚜嚝嚞嚟嚠嚡嚢嚤嚥嚦嚧嚨嚩嚪嚫嚬嚭嚮嚰嚱嚲嚳嚴嚵嚶嚸嚹嚺嚻嚽嚾嚿囀囁囂囃囄囅囆囇囈囉囋囌囍囎囏囐囑囒囓囕囖囘囙囜団囥囦囧囨囩囪囬囮囯囲図囶囷囸囻囼圀圁圂圅圇國圌圍圎圏圐圑園圓圔圕圖圗團圙圚圛圝圞圠圡圢圤圥圦圧圫圱圲圴圵圶圷圸圼圽圿坁坃坄坅坆坈坉坋坒坓坔坕坖坘坙坢坣坥坧坬坮坰坱坲坴坵坸坹坺坽坾坿垀垁垇垈垉垊垍垎垏垐垑垔垕垖垗垘垙垚垜垝垞垟垥垨垪垬垯垰垱垳垵垶垷垹垺垻垼垽垾垿埀埁埄埅埆埇埈埉埊埌埍埐埑埓埖埗埛埜埞埡埢埣埥埦埧埨埩埪埫埬埮埰埱埲埳埵埶執埻埼埾埿堁堃堄堅堈堉堊堌堎堏堐堒堓堔堖堗堘堚堛堜堝堟堢堣堥堦堧堨堩堫堬堭堮堯報堲堳場堶堷堸堹堺堻堼堽堾堿塀塁塂塃塅塆塇塈塉塊塋塎塏塐塒塓塕塖塗塙塚塛塜塝塟塠塡塢塣塤塦塧塨塩塪塭塮塯塰塱塲塳塴塵塶塷塸塹塺塻塼塽塿墂墄墆墇墈墊墋墌墍墎墏墐墑墔墕墖増墘墛墜墝墠墡墢墣墤墥墦墧墪墫墬墭墮墯墰墱墲墳墴墵墶墷墸墹墺墻墽墾墿壀壂壃壄壆壇壈壉壊壋壌壍壎壏壐壒壓壔壖壗壘壙壚壛壜壝壞壟壠壡壢壣壥壦壧壨壩壪壭壯壱売壴壵壷壸壺壻壼壽壾壿夀夁夃夅夆夈変夊夋夌夎夐夑夒夓夗夘夛夝夞夠夡夢夣夦夨夬夰夲夳夵夶夻夽夾夿奀奃奅奆奊奌奍奐奒奓奙奛奜奝奞奟奡奣奤奦奧奨奩奪奫奬奭奮奯奰奱奲奵奷奺奻奼奾奿妀妅妉妋妌妎妏妐妑妔妕妘妚妛妜妝妟妠妡妢妦妧妬妭妰妱妳妴妵妶妷妸妺妼妽妿姀姁姂姃姄姅姇姈姉姌姍姎`,
    `姏姕姖姙姛姞姟姠姡姢姤姦姧姩姪姫姭姮姯姰姱姲姳姴姵姶姷姸姺姼姽姾娀娂娊娋娍娎娏娐娒娔娕娖娗娙娚娛娝娞娡娢娤娦娧娨娪娫娬娭娮娯娰娳娵娷娸娹娺娻娽娾娿婁婂婃婄婅婇婈婋婌婍婎婏婐婑婒婓婔婖婗婘婙婛婜婝婞婟婠婡婣婤婥婦婨婩婫婬婭婮婯婰婱婲婳婸婹婻婼婽婾媀媁媂媃媄媅媆媇媈媉媊媋媌媍媎媏媐媑媓媔媕媖媗媘媙媜媝媞媟媠媡媢媣媤媥媦媧媨媩媫媬媭媮媯媰媱媴媶媷媹媺媻媼媽媿嫀嫃嫄嫅嫆嫇嫈嫊嫋嫍嫎嫏嫐嫑嫓嫕嫗嫙嫚嫛嫝嫞嫟嫢嫤嫥嫧嫨嫪嫬嫭嫮嫯嫰嫲嫳嫴嫵嫶嫷嫸嫹嫺嫻嫼嫽嫾嫿嬀嬁嬂嬃嬄嬅嬆嬇嬈嬊嬋嬌嬍嬎嬏嬐嬑嬒嬓嬔嬕嬘嬙嬚嬛嬜嬝嬞嬟嬠嬡嬢嬣嬤嬥嬦嬧嬨嬩嬪嬫嬬嬭嬮嬯嬰嬱嬳嬵嬶嬸嬹嬺嬻嬼嬽嬾嬿孁孂孃孄孅孆孇孈孉孊孋孌孍孎孏孒孖孞孠孡孧孨孫孭孮孯孲孴孶孷學孹孻孼孾孿宂宆宊宍宎宐宑宒宔宖実宧宨宩宬宭宮宯宱宲宷宺宻宼寀寁寃寈寉寊寋寍寎寏寑寔寕寖寗寘寙寚寛寜寠寢寣實寧審寪寫寬寭寯寱寲寳寴寵寶寷寽対尀専尃尅將專尋尌對導尐尒尓尗尙尛尞尟尠尡尣尦尨尩尪尫尭尮尯尰尲尳尵尶尷屃屄屆屇屌屍屒屓屔屖屗屘屚屛屜屝屟屢層屧屨屩屪屫屬屭屰屲屳屴屵屶屷屸屻屼屽屾岀岃岄岅岆岇岉岊岋岎岏岒岓岕岝岞岟岠岡岤岥岦岧岨岪岮岯岰岲岴岶岹岺岻岼岾峀峂峃峅峆峇峈峉峊峌峍峎峏峐峑峓峔峕峖峗峘峚峛峜峝峞峟峠峢峣峧峩峫峬峮峯峱峲峳峴峵島峷峸峹峺峼峽峾峿崀崁崄崅崈崉崊崋崌崍崏崐崑崒崓崕崗崘崙崚崜崝崟崠崡崢崣崥崨崪崫崬崯崰崱崲崳崵崶崷崸崹崺崻崼崿嵀嵁嵂嵃嵄嵅嵆嵈嵉嵍嵎嵏嵐嵑嵒嵓嵔嵕嵖嵗嵙嵚嵜嵞嵟嵠嵡嵢嵣嵤嵥嵦嵧嵨嵪嵭嵮嵰嵱嵲嵳嵵嵶嵷嵸嵹嵺嵻嵼嵽嵾嵿嶀嶁嶃嶄嶅嶆嶇嶈嶉嶊嶋嶌嶍嶎嶏嶐嶑嶒嶓嶔嶕嶖嶗嶘嶚嶛嶜嶞嶟嶠嶡嶢嶣嶤嶥嶦嶧嶨嶩嶪嶫嶬嶭嶮嶯嶰嶱嶲嶳嶴嶵嶶嶸嶹嶺嶻嶼嶽嶾嶿巀巁巂巃巄巆巇巈巉巊巋巌巎巏巐巑巒巓巔巕巖巗巘巙巚巜巟巠巣巤巪巬巭巰巵巶巸巹巺巻巼巿帀帄帇帉帊帋帍帎帒帓帗帞帟帠帡帢帣帤帥帨帩帪師帬帯帰帲帳帴帵帶帹帺帾帿幀幁幃幆幇幈幉幊幋幍幎幏幐幑幒幓幖幗幘幙幚幜幝幟幠幣幤幥幦幧幨幩幪幫幬幭幮幯幰幱幵幷幹幾庁庂広庅庈庉庌庍庎庒庘庛庝庡庢庣庤庨庩庪庫庬庮庯庰庱庲庴庺庻庼庽庿廀廁廂廃廄廅廆廇廈廋廌廍廎廏廐廔廕廗廘廙廚廜廝廞廟廠廡廢廣廤廥廦廧廩廫廬廭廮廯廰廱廲廳廵廸廹廻廼廽弅弆弇弉弌弍弎弐弒弔弖弙弚弜弝弞弡弢弣弤弨弫弬弮弰弲弳弴張弶強弸弻弽弾弿彁彂彃彄彅彆彇彈彉彊彋彌彍彎彏彑彔彙彚彛彜彞彟彠彣彥彧彨彫彮彯彲彴彵彶彸彺彽彾彿徃徆徍徎徏徑従徔徖徚徛徝從徟徠徢徣徤徥徦徧復徫徬徯徰徱徲徳徴徶徸徹徺徻徾徿忀忁忂忇忈忊忋忎忓忔忕忚忛応忞忟忢忣忥忦忨忩忬忯忰忲忳忴忶忷忹忺忼怇怈怉怋怌怐怑怓怗怘怚怞怟怢怣怤怬怭怮怰怱怲怳怴怶怷怸怹怺怽怾恀恄恅恆恇恈恉恊恌恎恏恑恓恔恖恗恘恛恜恞恟恠恡恥恦恮恱恲恴恵恷恾悀悁悂悅悆悇悈悊悋悎悏悐悑悓悕悗悘悙悜悞悡悢悤悥悧悩悪悮悰悳悵悶悷悹悺悽悾悿惀惁惂惃惄惇惈惉惌惍惎惏惐惒惓惔惖惗惙惛惞惡惢惣惤惥惪惱惲惵惷惸惻惼惽惾惿愂愃愄愅愇愊愋愌愐愑愒愓愔愖愗愘愙愛愜愝愞愡愢愥愨愩愪愬愭愮愯愰愱愲愳愴愵愶愷愸愹愺愻愼愽愾慀慁慂慃慄慅慆慇慉態慍慏慐慒慓慔慖慗慘慙慚慛慜慞慟慠慡慣慤慥慦慩慪慫慬慭慮慯慱慲慳慴慶慸慹慺慻慼慽慾慿憀憁憂憃憄憅憆憇憈憉憊憌憍憏憐憑憒憓憕憖憗憘憙憚憛憜憞憟憠憡憢憣憤憥憦憪憫憭憮憯憰憱憲憳憴憵憶憸憹憺憻憼憽憿懀懁懃懄懅懆懇應懌懍懎懏懐懓懕懖懗懘懙懚懛懜懝懞懟懠懡懢懣懤懥懧懨懩懪懫懬懭懮懯懰懱懲懳懴懶懷懸懹懺懻懼懽懾戀戁戂戃戄戅戇戉戓戔戙戜戝戞戠戣戦戧戨戩戫戭戯戰戱戲戵戶戸戹戺戻戼扂扄扅扆扊扏扐払扖扗扙扚扜扝扞扟扠扡扢扤扥扨扱扲扴扵扷扸扺扻扽抁抂抃抅抆抇抈抋抌抍抎抏抐抔抙抜抝択抣抦抧抩抪抭抮抯抰抲抳抴抶抷抸抺抾拀拁拃拋拏拑拕拝拞拠拡拤拪拫拰拲拵拸拹拺拻挀挃挄挅挆挊挋挌挍挏挐挒挓挔挕挗挘挙挜挦挧挩挬挭挮挰挱挳挴挵挶挷挸挻挼挾挿捀捁捄捇捈捊捑捒捓捔捖捗捘捙捚捛捜捝捠捤捥捦捨捪捫捬捯捰捲捳捴捵捸捹捼捽捾捿掁掃掄掅掆掋掍掑掓掔掕掗掙掚掛掜掝掞掟採掤掦掫掯掱掲掵掶掹掻掽掿揀揁揂揃揅揇揈揊揋揌揑揓揔揕揗揘揙揚換揜揝揟揢揤揥揦揧揨揫揬揮揯揰揱揳揵揷揹揺揻揼揾搃搄搆搇搈搉搊損搎搑搒搕搖搗搘搙搚搝搟搢搣搤搥搧搨搩搫搮搯搰搱搲搳搵搶搷搸搹搻搼搾摀摂摃摉摋摌摍摎摏摐摑摓摕摖摗摙摚摛摜摝摟摠摡摢摣摤摥摦摨摪摫摬摮摯摰摱摲摳摴摵摶摷摻摼摽摾摿撀撁撃撆撈撉撊撋撌撍撎撏撐撓撔撗撘撚撛撜撝撟撠撡撢撣撥撦撧撨撪撫撯撱撲撳撴撶撹撻撽撾撿擁擃擄擆擇擈擉擊`,
    `擋擌擏擑擓擔擕擖擙據擛擜擝擟擠擡擣擥擧擨擩擪擫擬擭擮擯擰擱擲擳擴擵擶擷擸擹擺擻擼擽擾擿攁攂攃攄攅攆攇攈攊攋攌攍攎攏攐攑攓攔攕攖攗攙攚攛攜攝攞攟攠攡攢攣攤攦攧攨攩攪攬攭攰攱攲攳攷攺攼攽敀敁敂敃敄敆敇敊敋敍敎敐敒敓敔敗敘敚敜敟敠敡敤敥敧敨敩敪敭敮敯敱敳敵敶數敹敺敻敼敽敾敿斀斁斂斃斄斅斆斈斉斊斍斎斏斒斔斕斖斘斚斝斞斠斢斣斦斨斪斬斮斱斲斳斴斵斶斷斸斺斻斾斿旀旂旇旈旉旊旍旐旑旓旔旕旘旙旚旛旜旝旞旟旡旣旤旪旫旲旳旴旵旸旹旻旼旽旾旿昁昄昅昇昈昉昋昍昐昑昒昖昗昘昚昛昜昞昡昢昣昤昦昩昪昫昬昮昰昲昳昷昸昹昺昻昽昿晀時晄晅晆晇晈晉晊晍晎晐晑晘晙晛晜晝晞晠晢晣晥晧晩晪晫晬晭晱晲晳晵晸晹晻晼晽晿暀暁暃暅暆暈暉暊暋暍暎暏暐暒暓暔暕暘暙暚暛暜暞暟暠暡暢暣暤暥暦暩暪暫暬暭暯暰暱暲暳暵暶暷暸暺暻暼暽暿曀曁曂曃曄曅曆曇曈曉曊曋曌曍曎曏曐曑曒曓曔曕曖曗曘曚曞曟曠曡曢曣曤曥曧曨曪曫曬曭曮曯曱曵曶書曺曻曽朁朂會朄朅朆朇朌朎朏朑朒朓朖朘朙朚朜朞朠朡朢朣朤朥朧朩朮朰朲朳朶朷朸朹朻朼朾朿杁杄杅杇杊杋杍杒杔杕杗杘杙杚杛杝杢杣杤杦杧杫杬杮東杴杶杸杹杺杻杽枀枂枃枅枆枈枊枌枍枎枏枑枒枓枔枖枙枛枟枠枡枤枦枩枬枮枱枲枴枹枺枻枼枽枾枿柀柂柅柆柇柈柉柊柋柌柍柎柕柖柗柛柟柡柣柤柦柧柨柪柫柭柮柲柵柶柷柸柹柺査柼柾栁栂栃栄栆栍栐栒栔栕栘栙栚栛栜栞栟栠栢栣栤栥栦栧栨栫栬栭栮栯栰栱栴栵栶栺栻栿桇桋桍桏桒桖桗桘桙桚桛桜桝桞桟桪桬桭桮桯桰桱桲桳桵桸桹桺桻桼桽桾桿梀梂梄梇梈梉梊梋梌梍梎梐梑梒梔梕梖梘梙梚梛梜條梞梟梠梡梣梤梥梩梪梫梬梮梱梲梴梶梷梸梹梺梻梼梽梾梿棁棃棄棅棆棇棈棊棌棎棏棐棑棓棔棖棗棙棛棜棝棞棟棡棢棤棥棦棧棨棩棪棫棬棭棯棲棳棴棶棷棸棻棽棾棿椀椂椃椄椆椇椈椉椊椌椏椑椓椔椕椖椗椘椙椚椛検椝椞椡椢椣椥椦椧椨椩椪椫椬椮椯椱椲椳椵椶椷椸椺椻椼椾楀楁楃楄楅楆楇楈楉楊楋楌楍楎楏楐楑楒楓楕楖楘楙楛楜楟楡楢楤楥楧楨楩楪楬業楯楰楲楳楴極楶楺楻楽楾楿榁榃榅榊榋榌榎榏榐榑榒榓榖榗榙榚榝榞榟榠榡榢榣榤榥榦榩榪榬榮榯榰榲榳榵榶榸榹榺榼榽榾榿槀槂槃槄槅槆槇槈槉構槍槏槑槒槓槕槖槗様槙槚槜槝槞槡槢槣槤槥槦槧槨槩槪槫槬槮槯槰槱槳槴槵槶槷槸槹槺槻槼槾樀樁樂樃樄樅樆樇樈樉樋樌樍樎樏樐樑樒樓樔樕樖標樚樛樜樝樞樠樢樣樤樥樦樧権樫樬樭樮樰樲樳樴樶樷樸樹樺樻樼樿橀橁橂橃橅橆橈橉橊橋橌橍橎橏橑橒橓橔橕橖橗橚橜橝橞機橠橢橣橤橦橧橨橩橪橫橬橭橮橯橰橲橳橴橵橶橷橸橺橻橽橾橿檁檂檃檅檆檇檈檉檊檋檌檍檏檒檓檔檕檖檘檙檚檛檜檝檞檟檡檢檣檤檥檦檧檨檪檭檮檯檰檱檲檳檴檵檶檷檸檹檺檻檼檽檾檿櫀櫁櫂櫃櫄櫅櫆櫇櫈櫉櫊櫋櫌櫍櫎櫏櫐櫑櫒櫓櫔櫕櫖櫗櫘櫙櫚櫛櫜櫝櫞櫟櫠櫡櫢櫣櫤櫥櫦櫧櫨櫩櫪櫫櫬櫭櫮櫯櫰櫱櫲櫳櫴櫵櫶櫷櫸櫹櫺櫻櫼櫽櫾櫿欀欁欂欃欄欅欆欇欈欉權欋欌欍欎欏欐欑欒欓欔欕欖欗欘欙欚欛欜欝欞欟欥欦欨欩欪欫欬欭欮欯欰欱欳欴欵欶欸欻欼欽欿歀歁歂歄歅歈歊歋歍歎歏歐歑歒歓歔歕歖歗歘歚歛歜歝歞歟歠歡歨歩歫歬歭歮歯歰歱歲歳歴歵歶歷歸歺歽歾歿殀殅殈殌殎殏殐殑殔殕殗殘殙殜殝殞殟殠殢殣殤殥殦殧殨殩殫殬殭殮殯殰殱殲殶殸殹殺殻殼殽殾毀毃毄毆毇毈毉毊毌毎毐毑毘毚毜毝毞毟毠毢毣毤毥毦毧毨毩毬毭毮毰毱毲毴毶毷毸毺毻毼毾毿氀氁氂氃氄氈氉氊氋氌氎氒気氜氝氞氠氣氥氫氬氭氱氳氶氷氹氺氻氼氾氿汃汄汅汈汋汌汍汎汏汑汒汓汖汘汙汚汢汣汥汦汧汫汬汭汮汯汱汳汵汷汸決汻汼汿沀沄沇沊沋沍沎沑沒沕沖沗沘沚沜沝沞沠沢沨沬沯沰沴沵沶沷沺泀況泂泃泆泇泈泋泍泎泏泑泒泘泙泚泜泝泟泤泦泧泩泬泭泲泴泹泿洀洂洃洅洆洈洉洊洍洏洐洑洓洔洕洖洘洜洝洟洠洡洢洣洤洦洨洩洬洭洯洰洴洶洷洸洺洿浀浂浄浉浌浐浕浖浗浘浛浝浟浡浢浤浥浧浨浫浬浭浰浱浲浳浵浶浹浺浻浽浾浿涀涁涃涄涆涇涊涋涍涏涐涒涖涗涘涙涚涜涢涥涬涭涰涱涳涴涶涷涹涺涻涼涽涾淁淂淃淈淉淊淍淎淏淐淒淓淔淕淗淚淛淜淟淢淣淥淧淨淩淪淭淯淰淲淴淵淶淸淺淽淾淿渀渁渂渃渄渆渇済渉渋渏渒渓渕渘渙減渜渞渟渢渦渧渨渪測渮渰渱渳渵渶渷渹渻渼渽渾渿湀湁湂湅湆湇湈湉湊湋湌湏湐湑湒湕湗湙湚湜湝湞湠湡湢湣湤湥湦湧湨湩湪湬湭湯湰湱湲湳湴湵湶湷湸湹湺湻湼湽満溁溂溄溇溈溊溋溌溍溎溑溒溓溔溕準溗溙溚溛溝溞溠溡溣溤溦溨溩溫溬溭溮溰溳溵溸溹溼溾溿滀滃滄滅滆滈滉滊滌滍滎滐滒滖滘滙滛滜滝滣滧滪滫滬滭滮滯滰滱滲滳滵滶滷滸滺滻滼滽滾滿漀漁漃漄漅漇漈漊漋漌漍漎漐漑漒漖漗漘漙漚漛漜漝漞漟漡漢漣漥漦漧漨漬漮漰漲漴漵漷漸漹漺漻漼漽漿潀潁潂潃潄潅潈潉潊潌潎潏潐潑潒潓潔潕潖潗`,
    `潙潚潛潝潟潠潡潣潤潥潧潨潩潪潫潬潯潰潱潳潵潶潷潹潻潽潾潿澀澁澂澃澅澆澇澊澋澏澐澑澒澓澔澕澖澗澘澙澚澛澝澞澟澠澢澣澤澥澦澨澩澪澫澬澭澮澯澰澱澲澴澵澷澸澺澻澼澽澾澿濁濃濄濅濆濇濈濊濋濌濍濎濏濐濓濔濕濖濗濘濙濚濛濜濝濟濢濣濤濥濦濧濨濩濪濫濬濭濰濱濲濳濴濵濶濷濸濹濺濻濼濽濾濿瀀瀁瀂瀃瀄瀅瀆瀇瀈瀉瀊瀋瀌瀍瀎瀏瀐瀒瀓瀔瀕瀖瀗瀘瀙瀜瀝瀞瀟瀠瀡瀢瀤瀥瀦瀧瀨瀩瀪瀫瀬瀭瀮瀯瀰瀱瀲瀳瀴瀶瀷瀸瀺瀻瀼瀽瀾瀿灀灁灂灃灄灅灆灇灈灉灊灋灍灎灐灑灒灓灔灕灖灗灘灙灚灛灜灝灟灠灡灢灣灤灥灦灧灨灩灪灮灱灲灳灴灷灹灺灻災炁炂炃炄炆炇炈炋炌炍炏炐炑炓炗炘炚炛炞炟炠炡炢炣炤炥炦炧炨炩炪炰炲炴炵炶為炾炿烄烅烆烇烉烋烌烍烎烏烐烑烒烓烔烕烖烗烚烜烝烞烠烡烢烣烥烪烮烰烱烲烳烴烵烶烸烺烻烼烾烿焀焁焂焃焄焅焆焇焈焋焌焍焎焏焑焒焔焗焛焜焝焞焟焠無焢焣焤焥焧焨焩焪焫焬焭焮焲焳焴焵焷焸焹焺焻焼焽焾焿煀煁煂煃煄煆煇煈煉煋煍煏煐煑煒煓煔煕煖煗煘煙煚煛煝煟煠煡煢煣煥煩煪煫煬煭煯煰煱煴煵煶煷煹煻煼煾煿熀熁熂熃熅熆熇熈熉熋熌熍熎熐熑熒熓熕熖熗熚熛熜熝熞熡熢熣熤熥熦熧熩熪熫熭熮熯熰熱熲熴熶熷熸熺熻熼熽熾熿燀燁燂燄燅燆燇燈燉燊燋燌燍燏燐燑燒燓燖燗燘燙燚燛燜燝燞營燡燢燣燤燦燨燩燪燫燬燭燯燰燱燲燳燴燵燶燷燸燺燻燼燽燾燿爀爁爂爃爄爅爇爈爉爊爋爌爍爎爏爐爑爒爓爔爕爖爗爘爙爚爛爜爞爟爠爡爢爣爤爥爦爧爩爫爭爮爯爲爳爴爺爼爾牀牁牂牃牄牅牆牉牊牋牎牏牐牑牓牔牕牗牘牚牜牞牠牣牤牥牨牪牫牬牭牰牱牳牴牶牷牸牻牼牽犂犃犅犆犇犈犉犌犎犐犑犓犔犕犖犗犘犙犚犛犜犝犞犠犡犢犣犤犥犦犧犨犩犪犫犮犱犲犳犵犺犻犼犽犾犿狀狅狆狇狉狊狋狌狏狑狓狔狕狖狘狚狛　、。·ˉˇ¨〃々—～‖…‘’“”〔〕〈〉《》「」『』〖〗【】±×÷∶∧∨∑∏∪∩∈∷√⊥∥∠⌒⊙∫∮≡≌≈∽∝≠≮≯≤≥∞∵∴♂♀°′″℃＄¤￠￡‰§№☆★○●◎◇◆□■△▲※→←↑↓〓ⅰⅱⅲⅳⅴⅵⅶⅷⅸⅹ⒈⒉⒊⒋⒌⒍⒎⒏⒐⒑⒒⒓⒔⒕⒖⒗⒘⒙⒚⒛⑴⑵⑶⑷⑸⑹⑺⑻⑼⑽⑾⑿⒀⒁⒂⒃⒄⒅⒆⒇①②③④⑤⑥⑦⑧⑨⑩€㈠㈡㈢㈣㈤㈥㈦㈧㈨㈩ⅠⅡⅢⅣⅤⅥⅦⅧⅨⅩⅪⅫ　！＂＃￥％＆＇（）＊＋，－．／０１２３４５６７８９：；＜＝＞？＠ＡＢＣＤＥＦＧＨＩＪＫＬＭＮＯＰＱＲＳＴＵＶＷＸＹＺ［＼］＾＿｀ａｂｃｄｅｆｇｈｉｊｋｌｍｎｏｐｑｒｓｔｕｖｗｘｙｚ｛｜｝￣ぁあぃいぅうぇえぉおかがきぎくぐけげこごさざしじすずせぜそぞただちぢっつづてでとどなにぬねのはばぱひびぴふぶぷへべぺほぼぽまみむめもゃやゅゆょよらりるれろゎわゐゑをんァアィイゥウェエォオカガキギクグケゲコゴサザシジスズセゼソゾタダチヂッツヅテデトドナニヌネノハバパヒビピフブプヘベペホボポマミムメモャヤュユョヨラリルレロヮワヰヱヲンヴヵヶΑΒΓΔΕΖΗΘΙΚΛΜΝΞΟΠΡΣΤΥΦΧΨΩαβγδεζηθικλμνξοπρστυφχψω︐︒︑︓︔︕︖︵︶︹︺︿﹀︽︾﹁﹂﹃`,
    `﹄︗︘︻︼︷︸︱︙︳︴АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюяˊˋ˙–―‥‵℅℉↖↗↘↙∕∟∣≒≦≧⊿═║╒╓╔╕╖╗╘╙╚╛╜╝╞╟╠╡╢╣╤╥╦╧╨╩╪╫╬╭╮╯╰╱╲╳▁▂▃▄▅▆▇█▉▊▋▌▍▎▏▓▔▕▼▽◢◣◤◥☉⊕〒〝〞āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜüêɑḿńňǹɡㄅㄆㄇㄈㄉㄊㄋㄌㄍㄎㄏㄐㄑㄒㄓㄔㄕㄖㄗㄘㄙㄚㄛㄜㄝㄞㄟㄠㄡㄢㄣㄤㄥㄦㄧㄨㄩ〡〢〣〤〥〦〧〨〩㊣㎎㎏㎜㎝㎞㎡㏄㏎㏑㏒㏕︰￢￤℡㈱‐ー゛゜ヽヾ〆ゝゞ﹉﹊﹋﹌﹍﹎﹏﹐﹑﹒﹔﹕﹖﹗﹙﹚﹛﹜﹝﹞﹟﹠﹡﹢﹣﹤﹥﹦﹨﹩﹪﹫〾⿰⿱⿲⿳⿴⿵⿶⿷⿸⿹⿺⿻〇─━│┃┄┅┆┇┈┉┊┋┌┍┎┏┐┑┒┓└┕┖┗┘┙┚┛├┝┞┟┠┡┢┣┤┥┦┧┨┩┪┫┬┭┮┯┰┱┲┳┴┵┶┷┸┹┺┻┼┽┾┿╀╁╂╃╄╅╆╇╈╉╊╋狜狝狟狢狣狤狥狦狧狪狫狵狶狹狽狾狿猀猂猄猅猆猇猈猉猋猌猍猏猐猑猒猔猘猙猚猟猠猣猤猦猧猨猭猯猰猲猳猵猶猺猻猼猽獀獁獂獃獄獅獆獇獈獉獊獋獌獎獏獑獓獔獕獖獘獙獚獛獜獝獞獟獡獢獣獤獥獦獧獨獩獪獫獮獰獱獲獳獴獵獶獷獸獹獺獻獼獽獿玀玁玂玃玅玆玈玊玌玍玏玐玒玓玔玕玗玘玙玚玜玝玞玠玡玣玤玥玦玧玨玪玬玭玱玴玵玶玸玹玼玽玾玿珁珃珄珅珆珇珋珌珎珒珓珔珕珖珗珘珚珛珜珝珟珡珢珣珤珦珨珪珫珬珮珯珰珱珳珴珵珶珷珸珹珺珻珼珽現珿琀琁琂琄琇琈琋琌琍琎琑琒琓琔琕琖琗琘琙琜琝琞琟琠琡琣琤琧琩琫琭琯琱琲琷琸琹琺琻琽琾琿瑀瑂瑃瑄瑅瑆瑇瑈瑉瑊瑋瑌瑍瑎瑏瑐瑑瑒瑓瑔瑖瑘瑝瑠瑡瑢瑣瑤瑥瑦瑧瑨瑩瑪瑫瑬瑮瑯瑱瑲瑳瑴瑵瑸瑹瑺瑻瑼瑽瑿璂璄璅璆璈璉璊璌璍璏璑璒璓璔璕璖璗璘璙璚璛璝璟璠璡璢璣璤璥璦璪璫璬璭璮璯環璱璲璳璴璵璶璷璸璹璻璼璽璾璿瓀瓁瓂瓃瓄瓅瓆瓇瓈瓉瓊瓋瓌瓍瓎瓏瓐瓑瓓瓔瓕瓖瓗瓘瓙瓚瓛瓝瓟瓡瓥瓧瓨瓩瓪瓫瓬瓭瓰瓱瓲瓳瓵瓸瓹瓺瓻瓼瓽瓾甀甁甂甃甅甆甇甈甉甊甋甌甎甐甒甔甕甖甗甛甝甞甠甡產産甤甦甧甪甮甴甶甹甼甽甿畁畂畃畄畆畇畉畊畍畐畑畒畓畕畖畗畘畝畞畟畠畡畢畣畤畧畨畩畫畬畭畮畯異畱畳畵當畷畺畻畼畽畾疀疁疂疄疅疇疈疉疊疌疍疎疐疓疕疘疛疜疞疢疦疧疨疩疪疭疶疷疺疻疿痀痁痆痋痌痎痏痐痑痓痗痙痚痜痝痟痠痡痥痩痬痭痮痯痲痳痵痶痷痸痺痻痽痾瘂瘄瘆瘇瘈瘉瘋瘍瘎瘏瘑瘒瘓瘔瘖瘚瘜瘝瘞瘡瘣瘧瘨瘬瘮瘯瘱瘲瘶瘷瘹瘺瘻瘽癁療癄癅癆癇癈癉癊癋癎癏癐癑癒癓癕癗癘癙癚癛癝癟癠癡癢癤癥癦癧癨癩癪癬癭癮癰癱癲癳癴癵癶癷癹発發癿皀皁皃皅皉皊皌皍皏皐皒皔皕皗皘皚皛皜皝皞皟皠皡皢`,
    `皣皥皦皧皨皩皪皫皬皭皯皰皳皵皶皷皸皹皺皻皼皽皾盀盁盃啊阿埃挨哎唉哀皑癌蔼矮艾碍爱隘鞍氨安俺按暗岸胺案肮昂盎凹敖熬翱袄傲奥懊澳芭捌扒叭吧笆八疤巴拔跋靶把耙坝霸罢爸白柏百摆佰败拜稗斑班搬扳般颁板版扮拌伴瓣半办绊邦帮梆榜膀绑棒磅蚌镑傍谤苞胞包褒剥盄盇盉盋盌盓盕盙盚盜盝盞盠盡盢監盤盦盧盨盩盪盫盬盭盰盳盵盶盷盺盻盽盿眀眂眃眅眆眊県眎眏眐眑眒眓眔眕眖眗眘眛眜眝眞眡眣眤眥眧眪眫眬眮眰眱眲眳眴眹眻眽眾眿睂睄睅睆睈睉睊睋睌睍睎睏睒睓睔睕睖睗睘睙睜薄雹保堡饱宝抱报暴豹鲍爆杯碑悲卑北辈背贝钡倍狈备惫焙被奔苯本笨崩绷甭泵蹦迸逼鼻比鄙笔彼碧蓖蔽毕毙毖币庇痹闭敝弊必辟壁臂避陛鞭边编贬扁便变卞辨辩辫遍标彪膘表鳖憋别瘪彬斌濒滨宾摈兵冰柄丙秉饼炳睝睞睟睠睤睧睩睪睭睮睯睰睱睲睳睴睵睶睷睸睺睻睼瞁瞂瞃瞆瞇瞈瞉瞊瞋瞏瞐瞓瞔瞕瞖瞗瞘瞙瞚瞛瞜瞝瞞瞡瞣瞤瞦瞨瞫瞭瞮瞯瞱瞲瞴瞶瞷瞸瞹瞺瞼瞾矀矁矂矃矄矅矆矇矈矉矊矋矌矎矏矐矑矒矓矔矕矖矘矙矚矝矞矟矠矡矤病并玻菠播拨钵波博勃搏铂箔伯帛舶脖膊渤泊驳捕卜哺补埠不布步簿部怖擦猜裁材才财睬踩采彩菜蔡餐参蚕残惭惨灿苍舱仓沧藏操糙槽曹草厕策侧册测层蹭插叉茬茶查碴搽察岔差诧拆柴豺搀掺蝉馋谗缠铲产阐颤昌猖矦矨矪矯矰矱矲矴矵矷矹矺矻矼砃砄砅砆砇砈砊砋砎砏砐砓砕砙砛砞砠砡砢砤砨砪砫砮砯砱砲砳砵砶砽砿硁硂硃硄硆硈硉硊硋硍硏硑硓硔硘硙硚硛硜硞硟硠硡硢硣硤硥硦硧硨硩硯硰硱硲硳硴硵硶硸硹硺硻硽硾硿碀碁碂碃场尝常长偿肠厂敞畅唱倡超抄钞朝嘲潮巢吵炒车扯撤掣彻澈郴臣辰尘晨忱沉陈趁衬撑称城橙成呈乘程惩澄诚承逞骋秤吃痴持匙池迟弛驰耻齿侈尺赤翅斥炽充冲虫崇宠抽酬畴踌稠愁筹仇绸瞅丑臭初出橱厨躇锄雏滁除楚碄碅碆碈碊碋碏碐碒碔碕碖碙碝碞碠碢碤碦碨碩碪碫碬碭碮碯碵碶碷碸確碻碼碽碿磀磂磃磄磆磇磈磌磍磎磏磑磒磓磖磗磘磚磛磜磝磞磟磠磡磢磣磤磥磦磧磩磪磫磭磮磯磰磱磳磵磶磸磹磻磼磽磾磿礀礂礃礄礆礇礈礉礊礋礌础储矗搐触处揣川穿椽传船喘串疮窗幢床闯创吹炊捶锤垂春椿醇唇淳纯蠢戳绰疵茨磁雌辞慈瓷词此刺赐次聪葱囱匆从丛凑粗醋簇促蹿篡窜摧崔催脆瘁粹淬翠村存寸磋撮搓措挫错搭达答瘩打大呆歹傣戴带殆代贷袋待逮礍礎礏礐礑礒礔礕礖礗礘礙礚礛礜礝礟礠礡礢礣礥礦礧礨礩礪礫礬礭礮礯礰礱礲礳礵礶礷礸礹礽礿祂祃祄祅祇祊祋祌祍祎祏祐祑祒祔祕祘祙祡祣祤祦祩祪祫祬祮祰祱祲祳祴祵祶祹祻祼祽祾祿禂禃禆禇禈禉禋禌禍禎禐禑禒怠耽担丹单郸掸胆旦氮但惮淡诞弹蛋当挡党荡档刀捣蹈倒岛祷导到稻悼道盗德得的蹬灯登等瞪凳邓堤低滴迪敌笛狄涤翟嫡抵底地蒂第帝弟递缔颠掂滇碘点典靛垫电佃甸店惦奠淀殿碉叼雕凋刁掉吊钓调跌爹碟蝶迭谍叠禓禔禕禖禗禘禙禛禜禝禞禟禠禡禢禣禤禥禦禨禩禪禫禬禭禮禯禰禱禲禴禵禶禷禸禼禿秂秄秅秇秈秊秌秎秏秐秓秔秖秗秙秚秛秜秝秞秠秡秢秥秨秪秬秮秱秲秳秴秵秶秷秹秺秼秾秿稁稄稅稇稈稉稊稌稏稐稑稒稓稕稖稘稙稛稜丁盯叮钉顶鼎锭定订丢东冬董懂动栋侗恫冻洞兜抖斗陡豆逗痘都督毒犊独读堵睹赌杜镀肚度渡妒端短锻段断缎堆兑队对墩吨蹲敦顿囤钝盾遁掇哆多夺垛躲朵跺舵剁惰堕蛾峨鹅俄额讹娥恶厄扼遏鄂饿恩而儿耳尔饵洱二稝稟稡稢稤稥稦稧稨稩稪稫稬稭種稯稰稱稲稴稵稶稸稺稾穀穁穂穃穄穅穇穈穉穊穋穌積穎穏穐穒穓穔穕穖穘穙穚穛穜穝穞穟穠穡穢穣穤穥穦穧穨穩穪穫穬穭穮穯穱穲穳穵穻穼穽穾窂窅窇窉窊窋窌窎窏窐窓窔窙窚窛窞窡窢贰发罚筏伐乏阀法珐藩帆番翻樊矾钒繁凡烦反返范贩犯饭泛坊芳方肪房防妨仿访纺放菲非啡飞肥匪诽吠肺废沸费芬酚吩氛分纷坟焚汾粉奋份忿愤粪丰封枫蜂峰锋风疯烽逢冯缝讽奉凤佛否夫敷肤孵扶拂辐幅氟符伏俘服窣窤窧窩窪窫窮窯窰窱窲窴窵窶窷窸窹窺窻窼窽窾竀竁竂竃竄竅竆竇竈竉竊竌竍竎竏竐竑竒竓竔竕竗竘竚竛竜竝竡竢竤竧竨竩竪竫竬竮竰竱竲竳竴竵競竷竸竻竼竾笀笁笂笅笇笉笌笍笎笐笒笓笖笗笘笚笜笝笟笡笢笣笧笩笭浮涪福袱弗甫抚辅俯釜斧脯腑府腐赴副覆赋复傅付阜父腹负富讣附妇缚咐噶嘎该改概钙盖溉干甘杆柑竿肝赶感秆敢赣冈刚钢缸肛纲岗港杠篙皋高膏羔糕搞镐稿告哥歌搁戈鸽胳疙割革葛格蛤阁隔铬个各给根跟耕更庚羹笯笰笲笴笵笶笷笹笻笽笿筀筁筂筃筄筆筈筊筍筎筓筕筗筙筜筞筟筡筣筤筥筦筧筨筩筪筫筬筭筯筰筳筴筶筸筺筼筽筿箁箂箃箄箆箇箈箉箊箋箌箎箏箑箒箓箖箘箙箚箛箞箟箠箣箤箥箮箯箰箲箳箵箶箷箹箺箻箼箽箾箿節篂篃範埂耿梗工攻功恭龚供躬公宫弓巩汞拱贡共钩勾沟苟狗垢构购够辜菇咕箍估沽孤姑鼓古蛊骨谷股故顾固雇刮瓜剐寡挂褂乖拐怪棺关官冠观管馆罐惯灌`,
    `贯光广逛瑰规圭硅归龟闺轨鬼诡癸桂柜跪贵刽辊滚棍锅郭国果裹过哈篅篈築篊篋篍篎篏篐篒篔篕篖篗篘篛篜篞篟篠篢篣篤篧篨篩篫篬篭篯篰篲篳篴篵篶篸篹篺篻篽篿簀簁簂簃簄簅簆簈簉簊簍簎簐簑簒簓簔簕簗簘簙簚簛簜簝簞簠簡簢簣簤簥簨簩簫簬簭簮簯簰簱簲簳簴簵簶簷簹簺簻簼簽簾籂骸孩海氦亥害骇酣憨邯韩含涵寒函喊罕翰撼捍旱憾悍焊汗汉夯杭航壕嚎豪毫郝好耗号浩呵喝荷菏核禾和何合盒貉阂河涸赫褐鹤贺嘿黑痕很狠恨哼亨横衡恒轰哄烘虹鸿洪宏弘红喉侯猴吼厚候后呼乎忽瑚壶葫胡蝴狐糊湖籃籄籅籆籇籈籉籊籋籌籎籏籐籑籒籓籔籕籖籗籘籙籚籛籜籝籞籟籠籡籢籣籤籥籦籧籨籩籪籫籬籭籮籯籰籱籲籵籶籷籸籹籺籾籿粀粁粂粃粄粅粆粇粈粊粋粌粍粎粏粐粓粔粖粙粚粛粠粡粣粦粧粨粩粫粬粭粯粰粴粵粶粷粸粺粻弧虎唬护互沪户花哗华猾滑画划化话槐徊怀淮坏欢环桓还缓换患唤痪豢焕涣宦幻荒慌黄磺蝗簧皇凰惶煌晃幌恍谎灰挥辉徽恢蛔回毁悔慧卉惠晦贿秽会烩汇讳诲绘荤昏婚魂浑混豁活伙火获或惑霍货祸击圾基机畸稽积箕粿糀糂糃糄糆糉糋糎糏糐糑糒糓糔糘糚糛糝糞糡糢糣糤糥糦糧糩糪糫糬糭糮糰糱糲糳糴糵糶糷糹糺糼糽糾糿紀紁紂紃約紅紆紇紈紉紋紌納紎紏紐紑紒紓純紕紖紗紘紙級紛紜紝紞紟紡紣紤紥紦紨紩紪紬紭紮細紱紲紳紴紵紶肌饥迹激讥鸡姬绩缉吉极棘辑籍集及急疾汲即嫉级挤几脊己蓟技冀季伎祭剂悸济寄寂计记既忌际妓继纪嘉枷夹佳家加荚颊贾甲钾假稼价架驾嫁歼监坚尖笺间煎兼肩艰奸缄茧检柬碱硷拣捡简俭剪减荐槛鉴践贱见键箭件紷紸紹紺紻紼紽紾紿絀絁終絃組絅絆絇絈絉絊絋経絍絎絏結絑絒絓絔絕絖絗絘絙絚絛絜絝絞絟絠絡絢絣絤絥給絧絨絩絪絫絬絭絯絰統絲絳絴絵絶絸絹絺絻絼絽絾絿綀綁綂綃綄綅綆綇綈綉綊綋綌綍綎綏綐綑綒經綔綕綖綗綘健舰剑饯渐溅涧建僵姜将浆江疆蒋桨奖讲匠酱降蕉椒礁焦胶交郊浇骄娇嚼搅铰矫侥脚狡角饺缴绞剿教酵轿较叫窖揭接皆秸街阶截劫节桔杰捷睫竭洁结解姐戒藉芥界借介疥诫届巾筋斤金今津襟紧锦仅谨进靳晋禁近烬浸継続綛綜綝綞綟綠綡綢綣綤綥綧綨綩綪綫綬維綯綰綱網綳綴綵綶綷綸綹綺綻綼綽綾綿緀緁緂緃緄緅緆緇緈緉緊緋緌緍緎総緐緑緒緓緔緕緖緗緘緙線緛緜緝緞緟締緡緢緣緤緥緦緧編緩緪緫緬緭緮緯緰緱緲緳練緵緶緷緸緹緺尽劲荆兢茎睛晶鲸京惊精粳经井警景颈静境敬镜径痉靖竟竞净炯窘揪究纠玖韭久灸九酒厩救旧臼舅咎就疚鞠拘狙疽居驹菊局咀矩举沮聚拒据巨具距踞锯俱句惧炬剧捐鹃娟倦眷卷绢撅攫抉掘倔爵觉决诀绝均菌钧军君峻緻緼緽緾緿縀縁縂縃縄縅縆縇縈縉縊縋縌縍縎縏縐縑縒縓縔縕縖縗縘縙縚縛縜縝縞縟縠縡縢縣縤縥縦縧縨縩縪縫縬縭縮縯縰縱縲縳縴縵縶縷縸縹縺縼總績縿繀繂繃繄繅繆繈繉繊繋繌繍繎繏繐繑繒繓織繕繖繗繘繙繚繛繜繝俊竣浚郡骏喀咖卡咯开揩楷凯慨刊堪勘坎砍看康慷糠扛抗亢炕考拷烤靠坷苛柯棵磕颗科壳咳可渴克刻客课肯啃垦恳坑吭空恐孔控抠口扣寇枯哭窟苦酷库裤夸垮挎跨胯块筷侩快宽款匡筐狂框矿眶旷况亏盔岿窥葵奎魁傀繞繟繠繡繢繣繤繥繦繧繨繩繪繫繬繭繮繯繰繱繲繳繴繵繶繷繸繹繺繻繼繽繾繿纀纁纃纄纅纆纇纈纉纊纋續纍纎纏纐纑纒纓纔纕纖纗纘纙纚纜纝纞纮纴纻纼绖绤绬绹缊缐缞缷缹缻缼缽缾缿罀罁罃罆罇罈罉罊罋罌罍罎罏罒罓馈愧溃坤昆捆困括扩廓阔垃拉喇蜡腊辣啦莱来赖蓝婪栏拦篮阑兰澜谰揽览懒缆烂滥琅榔狼廊郎朗浪捞劳牢老佬姥酪烙涝勒乐雷镭蕾磊累儡垒擂肋类泪棱楞冷厘梨犁黎篱狸离漓理李里鲤礼莉荔吏栗丽厉励砾历利傈例俐罖罙罛罜罝罞罠罣罤罥罦罧罫罬罭罯罰罳罵罶罷罸罺罻罼罽罿羀羂羃羄羅羆羇羈羉羋羍羏羐羑羒羓羕羖羗羘羙羛羜羠羢羣羥羦羨義羪羫羬羭羮羱羳羴羵羶羷羺羻羾翀翂翃翄翆翇翈翉翋翍翏翐翑習翓翖翗翙翚翛翜翝翞翢翣痢立粒沥隶力璃哩俩联莲连镰廉怜涟帘敛脸链恋炼练粮凉梁粱良两辆量晾亮谅撩聊僚疗燎寥辽潦了撂镣廖料列裂烈劣猎琳林磷霖临邻鳞淋凛赁吝拎玲菱零龄铃伶羚凌灵陵岭领另令溜琉榴硫馏留刘瘤流柳六龙聋咙笼窿翤翧翨翪翫翬翭翯翲翴翵翶翷翸翹翺翽翾翿耂耇耈耉耊耎耏耑耓耚耛耝耞耟耡耣耤耫耬耭耮耯耰耲耴耹耺耼耾聀聁聄聅聇聈聉聎聏聐聑聓聕聖聗聙聛聜聝聞聟聠聡聢聣聤聥聦聧聨聫聬聭聮聯聰聲聳聴聵聶職聸聹聺聻聼聽隆垄拢陇楼娄搂篓漏陋芦卢颅庐炉掳卤虏鲁麓碌露路赂鹿潞禄录陆戮驴吕铝侣旅履屡缕虑氯律率滤绿峦挛孪滦卵乱掠略抡轮伦仑沦纶论萝螺罗逻锣箩骡裸落洛骆络妈麻玛码蚂马骂嘛吗埋买麦卖迈脉瞒馒蛮满蔓曼慢漫聾肁肂肅肈肊肍肎肏肐肑肒肔肕肗肙肞肣肦肧肨肬肰肳肵肶肸肹肻胅胇胈胉胊胋胏胐胑胒胓胔胕胘胟胠胢胣胦胮胵胷胹胻胾胿脀脁脃脄脅`,
    `脇脈脋脌脕脗脙脛脜脝脟脠脡脢脣脤脥脦脧脨脩脪脫脭脮脰脳脴脵脷脹脺脻脼脽脿谩芒茫盲氓忙莽猫茅锚毛矛铆卯茂冒帽貌贸么玫枚梅酶霉煤没眉媒镁每美昧寐妹媚门闷们萌蒙檬盟锰猛梦孟眯醚靡糜迷谜弥米秘觅泌蜜密幂棉眠绵冕免勉娩缅面苗描瞄藐秒渺庙妙蔑灭民抿皿敏悯闽明螟鸣铭名命谬摸腀腁腂腃腄腅腇腉腍腎腏腒腖腗腘腛腜腝腞腟腡腢腣腤腦腨腪腫腬腯腲腳腵腶腷腸膁膃膄膅膆膇膉膋膌膍膎膐膒膓膔膕膖膗膙膚膞膟膠膡膢膤膥膧膩膫膬膭膮膯膰膱膲膴膵膶膷膸膹膼膽膾膿臄臅臇臈臉臋臍臎臏臐臑臒臓摹蘑模膜磨摩魔抹末莫墨默沫漠寞陌谋牟某拇牡亩姆母墓暮幕募慕木目睦牧穆拿哪呐钠那娜纳氖乃奶耐奈南男难囊挠脑恼闹淖呢馁内嫩能妮霓倪泥尼拟你匿腻逆溺蔫拈年碾撵捻念娘酿鸟尿捏聂孽啮镊镍涅您柠狞凝宁臔臕臖臗臘臙臚臛臜臝臞臟臠臡臢臤臥臦臨臩臫臮臯臰臱臲臵臶臷臸臹臺臽臿舃與興舉舊舋舎舏舑舓舕舖舗舘舙舚舝舠舤舥舦舧舩舮舲舺舼舽舿艀艁艂艃艅艆艈艊艌艍艎艐艑艒艓艔艕艖艗艙艛艜艝艞艠艡艢艣艤艥艦艧艩拧泞牛扭钮纽脓浓农弄奴努怒女暖虐疟挪懦糯诺哦欧鸥殴藕呕偶沤啪趴爬帕怕琶拍排牌徘湃派攀潘盘磐盼畔判叛乓庞旁耪胖抛咆刨炮袍跑泡呸胚培裴赔陪配佩沛喷盆砰抨烹澎彭蓬棚硼篷膨朋鹏捧碰坯砒霹批披劈琵毗艪艫艬艭艱艵艶艷艸艻艼芀芁芃芅芆芇芉芌芐芓芔芕芖芚芛芞芠芢芣芧芲芵芶芺芻芼芿苀苂苃苅苆苉苐苖苙苚苝苢苧苨苩苪苬苭苮苰苲苳苵苶苸苺苼苽苾苿茀茊茋茍茐茒茓茖茘茙茝茞茟茠茡茢茣茤茥茦茩茪茮茰茲茷茻茽啤脾疲皮匹痞僻屁譬篇偏片骗飘漂瓢票撇瞥拼频贫品聘乒坪苹萍平凭瓶评屏坡泼颇婆破魄迫粕剖扑铺仆莆葡菩蒲埔朴圃普浦谱曝瀑期欺栖戚妻七凄漆柒沏其棋奇歧畦崎脐齐旗祈祁骑起岂乞企启契砌器气迄弃汽泣讫掐茾茿荁荂荄荅荈荊荋荌荍荎荓荕荖荗荘荙荝荢荰荱荲荳荴荵荶荹荺荾荿莀莁莂莃莄莇莈莊莋莌莍莏莐莑莔莕莖莗莙莚莝莟莡莢莣莤莥莦莧莬莭莮莯莵莻莾莿菂菃菄菆菈菉菋菍菎菐菑菒菓菕菗菙菚菛菞菢菣菤菦菧菨菫菬菭恰洽牵扦钎铅千迁签仟谦乾黔钱钳前潜遣浅谴堑嵌欠歉枪呛腔羌墙蔷强抢橇锹敲悄桥瞧乔侨巧鞘撬翘峭俏窍切茄且怯窃钦侵亲秦琴勤芹擒禽寝沁青轻氢倾卿清擎晴氰情顷请庆琼穷秋丘邱球求囚酋泅趋区蛆曲躯屈驱渠菮華菳菴菵菶菷菺菻菼菾菿萀萂萅萇萈萉萊萐萒萓萔萕萖萗萙萚萛萞萟萠萡萢萣萩萪萫萬萭萮萯萰萲萳萴萵萶萷萹萺萻萾萿葀葁葂葃葄葅葇葈葉葊葋葌葍葎葏葐葒葓葔葕葖葘葝葞葟葠葢葤葥葦葧葨葪葮葯葰葲葴葷葹葻葼取娶龋趣去圈颧权醛泉全痊拳犬券劝缺炔瘸却鹊榷确雀裙群然燃冉染瓤壤攘嚷让饶扰绕惹热壬仁人忍韧任认刃妊纫扔仍日戎茸蓉荣融熔溶容绒冗揉柔肉茹蠕儒孺如辱乳汝入褥软阮蕊瑞锐闰润若弱撒洒萨腮鳃塞赛三叁葽葾葿蒀蒁蒃蒄蒅蒆蒊蒍蒏蒐蒑蒒蒓蒔蒕蒖蒘蒚蒛蒝蒞蒟蒠蒢蒣蒤蒥蒦蒧蒨蒩蒪蒫蒬蒭蒮蒰蒱蒳蒵蒶蒷蒻蒼蒾蓀蓂蓃蓅蓆蓇蓈蓋蓌蓎蓏蓒蓔蓕蓗蓘蓙蓚蓛蓜蓞蓡蓢蓤蓧蓨蓩蓪蓫蓭蓮蓯蓱蓲蓳蓴蓵蓶蓷蓸蓹蓺蓻蓽蓾蔀蔁蔂伞散桑嗓丧搔骚扫嫂瑟色涩森僧莎砂杀刹沙纱傻啥煞筛晒珊苫杉山删煽衫闪陕擅赡膳善汕扇缮墒伤商赏晌上尚裳梢捎稍烧芍勺韶少哨邵绍奢赊蛇舌舍赦摄射慑涉社设砷申呻伸身深娠绅神沈审婶甚肾慎渗声生甥牲升绳蔃蔄蔅蔆蔇蔈蔉蔊蔋蔍蔎蔏蔐蔒蔔蔕蔖蔘蔙蔛蔜蔝蔞蔠蔢蔣蔤蔥蔦蔧蔨蔩蔪蔭蔮蔯蔰蔱蔲蔳蔴蔵蔶蔾蔿蕀蕁蕂蕄蕅蕆蕇蕋蕌蕍蕎蕏蕐蕑蕒蕓蕔蕕蕗蕘蕚蕛蕜蕝蕟蕠蕡蕢蕣蕥蕦蕧蕩蕪蕫蕬蕭蕮蕯蕰蕱蕳蕵蕶蕷蕸蕼蕽蕿薀薁省盛剩胜圣师失狮施湿诗尸虱十石拾时什食蚀实识史矢使屎驶始式示士世柿事拭誓逝势是嗜噬适仕侍释饰氏市恃室视试收手首守寿授售受瘦兽蔬枢梳殊抒输叔舒淑疏书赎孰熟薯暑曙署蜀黍鼠属术述树束戍竖墅庶数漱薂薃薆薈薉薊薋薌薍薎薐薑薒薓薔薕薖薗薘薙薚薝薞薟薠薡薢薣薥薦薧薩薫薬薭薱薲薳薴薵薶薸薺薻薼薽薾薿藀藂藃藄藅藆藇藈藊藋藌藍藎藑藒藔藖藗藘藙藚藛藝藞藟藠藡藢藣藥藦藧藨藪藫藬藭藮藯藰藱藲藳藴藵藶藷藸恕刷耍摔衰甩帅栓拴霜双爽谁水睡税吮瞬顺舜说硕朔烁斯撕嘶思私司丝死肆寺嗣四伺似饲巳松耸怂颂送宋讼诵搜艘擞嗽苏酥俗素速粟僳塑溯宿诉肃酸蒜算虽隋随绥髓碎岁穗遂隧祟孙损笋蓑梭唆缩琐索锁所塌他它她塔藹藺藼藽藾蘀蘁蘂蘃蘄蘆蘇蘈蘉蘊蘋蘌蘍蘎蘏蘐蘒蘓蘔蘕蘗蘘蘙蘚蘛蘜蘝蘞蘟蘠蘡蘢蘣蘤蘥蘦蘨蘪蘫蘬蘭蘮蘯蘰蘱蘲蘳蘴蘵蘶蘷蘹蘺蘻蘽蘾蘿虀虁虂虃虄虅虆虇虈虉虊虋虌虒虓處虖虗虘虙虛虜虝號虠虡虣虤虥虦虧虨虩虪獭挞蹋踏胎苔抬台泰酞太态汰坍摊贪瘫滩坛檀痰潭谭谈坦毯袒碳探叹炭汤塘搪堂棠膛唐糖倘躺淌趟烫掏涛滔绦萄桃逃淘陶讨`,
    `套特藤腾疼誊梯剔踢锑提题蹄啼体替嚏惕涕剃屉天添填田甜恬舔腆挑条迢眺跳贴铁帖厅听烃虭虯虰虲虳虴虵虶虷虸蚃蚄蚅蚆蚇蚈蚉蚎蚏蚐蚑蚒蚔蚖蚗蚘蚙蚚蚛蚞蚟蚠蚡蚢蚥蚦蚫蚭蚮蚲蚳蚷蚸蚹蚻蚼蚽蚾蚿蛁蛂蛃蛅蛈蛌蛍蛒蛓蛕蛖蛗蛚蛜蛝蛠蛡蛢蛣蛥蛦蛧蛨蛪蛫蛬蛯蛵蛶蛷蛺蛻蛼蛽蛿蜁蜄蜅蜆蜋蜌蜎蜏蜐蜑蜔蜖汀廷停亭庭挺艇通桐酮瞳同铜彤童桶捅筒统痛偷投头透凸秃突图徒途涂屠土吐兔湍团推颓腿蜕褪退吞屯臀拖托脱鸵陀驮驼椭妥拓唾挖哇蛙洼娃瓦袜歪外豌弯湾玩顽丸烷完碗挽晚皖惋宛婉万腕汪王亡枉网往旺望忘妄威蜙蜛蜝蜟蜠蜤蜦蜧蜨蜪蜫蜬蜭蜯蜰蜲蜳蜵蜶蜸蜹蜺蜼蜽蝀蝁蝂蝃蝄蝅蝆蝊蝋蝍蝏蝐蝑蝒蝔蝕蝖蝘蝚蝛蝜蝝蝞蝟蝡蝢蝦蝧蝨蝩蝪蝫蝬蝭蝯蝱蝲蝳蝵蝷蝸蝹蝺蝿螀螁螄螆螇螉螊螌螎螏螐螑螒螔螕螖螘螙螚螛螜螝螞螠螡螢螣螤巍微危韦违桅围唯惟为潍维苇萎委伟伪尾纬未蔚味畏胃喂魏位渭谓尉慰卫瘟温蚊文闻纹吻稳紊问嗡翁瓮挝蜗涡窝我斡卧握沃巫呜钨乌污诬屋无芜梧吾吴毋武五捂午舞伍侮坞戊雾晤物勿务悟误昔熙析西硒矽晰嘻吸锡牺螥螦螧螩螪螮螰螱螲螴螶螷螸螹螻螼螾螿蟁蟂蟃蟄蟅蟇蟈蟉蟌蟍蟎蟏蟐蟔蟕蟖蟗蟘蟙蟚蟜蟝蟞蟟蟡蟢蟣蟤蟦蟧蟨蟩蟫蟬蟭蟯蟰蟱蟲蟳蟴蟵蟶蟷蟸蟺蟻蟼蟽蟿蠀蠁蠂蠄蠅蠆蠇蠈蠉蠋蠌蠍蠎蠏蠐蠑蠒蠔蠗蠘蠙蠚蠜蠝蠞蠟蠠蠣稀息希悉膝夕惜熄烯溪汐犀檄袭席习媳喜铣洗系隙戏细瞎虾匣霞辖暇峡侠狭下厦夏吓掀锨先仙鲜纤咸贤衔舷闲涎弦嫌显险现献县腺馅羡宪陷限线相厢镶香箱襄湘乡翔祥详想响享项巷橡像向象萧硝霄削哮嚣销消宵淆晓蠤蠥蠦蠧蠨蠩蠪蠫蠬蠭蠮蠯蠰蠱蠳蠴蠵蠶蠷蠸蠺蠻蠽蠾蠿衁衂衃衆衇衈衉衊衋衎衏衐衑衒術衕衖衘衚衛衜衝衞衟衠衦衧衪衭衯衱衳衴衵衶衸衹衺衻衼袀袃袆袇袉袊袌袎袏袐袑袓袔袕袗袘袙袚袛袝袞袟袠袡袣袥袦袧袨袩袪小孝校肖啸笑效楔些歇蝎鞋协挟携邪斜胁谐写械卸蟹懈泄泻谢屑薪芯锌欣辛新忻心信衅星腥猩惺兴刑型形邢行醒幸杏性姓兄凶胸匈汹雄熊休修羞朽嗅锈秀袖绣墟戌需虚嘘须徐许蓄酗叙旭序畜恤絮婿绪续轩喧宣悬旋玄袬袮袯袰袲袳袴袵袶袸袹袺袻袽袾袿裀裃裄裇裈裊裋裌裍裏裐裑裓裖裗裚裛補裝裞裠裡裦裧裩裪裫裬裭裮裯裲裵裶裷裺裻製裿褀褁褃褄褅褆複褈褉褋褌褍褎褏褑褔褕褖褗褘褜褝褞褟褠褢褣褤褦褧褨褩褬褭褮褯褱褲褳褵褷选癣眩绚靴薛学穴雪血勋熏循旬询寻驯巡殉汛训讯逊迅压押鸦鸭呀丫芽牙蚜崖衙涯雅哑亚讶焉咽阉烟淹盐严研蜒岩延言颜阎炎沿奄掩眼衍演艳堰燕厌砚雁唁彦焰宴谚验殃央鸯秧杨扬佯疡羊洋阳氧仰痒养样漾邀腰妖瑶褸褹褺褻褼褽褾褿襀襂襃襅襆襇襈襉襊襋襌襍襎襏襐襑襒襓襔襕襖襗襘襙襚襛襜襝襠襡襢襣襤襥襧襨襩襪襫襬襭襮襯襰襱襲襳襴襵襶襷襸襹襺襼襽襾覀覂覄覅覇覈覉覊見覌覍覎規覐覑覒覓覔覕視覗覘覙覚覛覜覝覞覟覠覡摇尧遥窑谣姚咬舀药要耀椰噎耶爷野冶也页掖业叶曳腋夜液一壹医揖铱依伊衣颐夷遗移仪胰疑沂宜姨彝椅蚁倚已乙矣以艺抑易邑屹亿役臆逸肄疫亦裔意毅忆义益溢诣议谊译异翼翌绎茵荫因殷音阴姻吟银淫寅饮尹引隐覢覣覤覥覦覧覨覩親覫覬覭覮覯覰覱覲観覴覵覶覷覸覹覺覻覼覽覾覿觀觃觍觓觔觕觗觘觙觛觝觟觠觡觢觤觧觨觩觪觬觭觮觰觱觲觴觵觶觷觸觹觺觻觼觽觾觿訁訂訃訄訅訆計訉訊訋訌訍討訏訐訑訒訓訔訕訖託記訙訚訛訜訝印英樱婴鹰应缨莹萤营荧蝇迎赢盈影颖硬映哟拥佣臃痈庸雍踊蛹咏泳涌永恿勇用幽优悠忧尤由邮铀犹油游酉有友右佑釉诱又幼迂淤于盂榆虞愚舆余俞逾鱼愉渝渔隅予娱雨与屿禹宇语羽玉域芋郁吁遇喻峪御愈欲狱育誉訞訟訠訡訢訣訤訥訦訧訨訩訪訫訬設訮訯訰許訲訳訴訵訶訷訸訹診註証訽訿詀詁詂詃詄詅詆詇詉詊詋詌詍詎詏詐詑詒詓詔評詖詗詘詙詚詛詜詝詞詟詠詡詢詣詤詥試詧詨詩詪詫詬詭詮詯詰話該詳詴詵詶詷詸詺詻詼詽詾詿誀浴寓裕预豫驭鸳渊冤元垣袁原援辕园员圆猿源缘远苑愿怨院曰约越跃钥岳粤月悦阅耘云郧匀陨允运蕴酝晕韵孕匝砸杂栽哉灾宰载再在咱攒暂赞赃脏葬遭糟凿藻枣早澡蚤躁噪造皂灶燥责择则泽贼怎增憎曾赠扎喳渣札轧誁誂誃誄誅誆誇誈誋誌認誎誏誐誑誒誔誕誖誗誘誙誚誛誜誝語誟誠誡誢誣誤誥誦誧誨誩說誫説読誮誯誰誱課誳誴誵誶誷誸誹誺誻誼誽誾調諀諁諂諃諄諅諆談諈諉諊請諌諍諎諏諐諑諒諓諔諕論諗諘諙諚諛諜諝諞諟諠諡諢諣铡闸眨栅榨咋乍炸诈摘斋宅窄债寨瞻毡詹粘沾盏斩辗崭展蘸栈占战站湛绽樟章彰漳张掌涨杖丈帐账仗胀瘴障招昭找沼赵照罩兆肇召遮折哲蛰辙者锗蔗这浙珍斟真甄砧臻贞针侦枕疹诊震振镇阵蒸挣睁征狰争怔整拯正政諤諥諦諧諨諩諪諫諬諭諮諯諰諱諲諳諴諵諶諷諸諹諺諻諼諽諾諿謀謁謂謃謄謅謆謈謉謊謋謌謍謎謏謐謑謒謓謔謕謖`,
    `謗謘謙謚講謜謝謞謟謠謡謢謣謤謥謧謨謩謪謫謬謭謮謯謰謱謲謳謴謵謶謷謸謹謺謻謼謽謾謿譀譁譂譃譄譅帧症郑证芝枝支吱蜘知肢脂汁之织职直植殖执值侄址指止趾只旨纸志挚掷至致置帜峙制智秩稚质炙痔滞治窒中盅忠钟衷终种肿重仲众舟周州洲诌粥轴肘帚咒皱宙昼骤珠株蛛朱猪诸诛逐竹烛煮拄瞩嘱主著柱助蛀贮铸筑譆譇譈證譊譋譌譍譎譏譐譑譒譓譔譕譖譗識譙譚譛譜譝譞譟譠譡譢譣譤譥譧譨譩譪譫譭譮譯議譱譲譳譴譵譶護譸譹譺譻譼譽譾譿讀讁讂讃讄讅讆讇讈讉變讋讌讍讎讏讐讑讒讓讔讕讖讗讘讙讚讛讜讝讞讟讬讱讻诇诐诪谉谞住注祝驻抓爪拽专砖转撰赚篆桩庄装妆撞壮状椎锥追赘坠缀谆准捉拙卓桌琢茁酌啄着灼浊兹咨资姿滋淄孜紫仔籽滓子自渍字鬃棕踪宗综总纵邹走奏揍租足卒族祖诅阻组钻纂嘴醉最罪尊遵昨左佐柞做作坐座谸谹谺谻谼谽谾谿豀豂豃豄豅豈豊豋豍豎豏豐豑豒豓豔豖豗豘豙豛豜豝豞豟豠豣豤豥豦豧豨豩豬豭豮豯豰豱豲豴豵豶豷豻豼豽豾豿貀貁貃貄貆貇貈貋貍貎貏貐貑貒貓貕貖貗貙貚貛貜貝貞貟負財貢貣貤貥貦貧貨販貪貫責貭亍丌兀丐廿卅丕亘丞鬲孬噩丨禺丿匕乇夭爻卮氐囟胤馗毓睾鼗丶亟鼐乜乩亓芈孛啬嘏仄厍厝厣厥厮靥赝匚叵匦匮匾赜卦卣刂刈刎刭刳刿剀剌剞剡剜蒯剽劂劁劐劓冂罔亻仃仉仂仨仡仫仞伛仳伢佤仵伥伧伉伫佞佧攸佚佝貮貯貰貱貲貳貴貵貶買貸貹貺費貼貽貾貿賀賁賂賃賄賅賆資賈賉賊賋賌賍賎賏賐賑賒賓賔賕賖賗賘賙賚賛賜賝賞賟賠賡賢賣賤賥賦賧賨賩質賫賬賭賮賯賰賱賲賳賴賵賶賷賸賹賺賻購賽賾賿贀贁贂贃贄贅贆贇贈贉贊贋贌贍佟佗伲伽佶佴侑侉侃侏佾佻侪佼侬侔俦俨俪俅俚俣俜俑俟俸倩偌俳倬倏倮倭俾倜倌倥倨偾偃偕偈偎偬偻傥傧傩傺僖儆僭僬僦僮儇儋仝氽佘佥俎龠汆籴兮巽黉馘冁夔勹匍訇匐凫夙兕亠兖亳衮袤亵脔裒禀嬴蠃羸冫冱冽冼贎贏贐贑贒贓贔贕贖贗贘贙贚贛贜贠赑赒赗赟赥赨赩赪赬赮赯赱赲赸赹赺赻赼赽赾赿趀趂趃趆趇趈趉趌趍趎趏趐趒趓趕趖趗趘趙趚趛趜趝趞趠趡趢趤趥趦趧趨趩趪趫趬趭趮趯趰趲趶趷趹趻趽跀跁跂跅跇跈跉跊跍跐跒跓跔凇冖冢冥讠讦讧讪讴讵讷诂诃诋诏诎诒诓诔诖诘诙诜诟诠诤诨诩诮诰诳诶诹诼诿谀谂谄谇谌谏谑谒谔谕谖谙谛谘谝谟谠谡谥谧谪谫谮谯谲谳谵谶卩卺阝阢阡阱阪阽阼陂陉陔陟陧陬陲陴隈隍隗隰邗邛邝邙邬邡邴邳邶邺跕跘跙跜跠跡跢跥跦跧跩跭跮跰跱跲跴跶跼跾跿踀踁踂踃踄踆踇踈踋踍踎踐踑踒踓踕踖踗踘踙踚踛踜踠踡踤踥踦踧踨踫踭踰踲踳踴踶踷踸踻踼踾踿蹃蹅蹆蹌蹍蹎蹏蹐蹓蹔蹕蹖蹗蹘蹚蹛蹜蹝蹞蹟蹠蹡蹢蹣蹤蹥蹧蹨蹪蹫蹮蹱邸邰郏郅邾郐郄郇郓郦郢郜郗郛郫郯郾鄄鄢鄞鄣鄱鄯鄹酃酆刍奂劢劬劭劾哿勐勖勰叟燮矍廴凵凼鬯厶弁畚巯坌垩垡塾墼壅壑圩圬圪圳圹圮圯坜圻坂坩垅坫垆坼坻坨坭坶坳垭垤垌垲埏垧垴垓垠埕埘埚埙埒垸埴埯埸埤埝蹳蹵蹷蹸蹹蹺蹻蹽蹾躀躂躃躄躆躈躉躊躋躌躍躎躑躒躓躕躖躗躘躙躚躛躝躟躠躡躢躣躤躥躦躧躨躩躪躭躮躰躱躳躴躵躶躷躸躹躻躼躽躾躿軀軁軂軃軄軅軆軇軈軉車軋軌軍軏軐軑軒軓軔軕軖軗軘軙軚軛軜軝軞軟軠軡転軣軤堋堍埽埭堀堞堙塄堠塥塬墁墉墚墀馨鼙懿艹艽艿芏芊芨芄芎芑芗芙芫芸芾芰苈苊苣芘芷芮苋苌苁芩芴芡芪芟苄苎芤苡茉苷苤茏茇苜苴苒苘茌苻苓茑茚茆茔茕苠苕茜荑荛荜茈莒茼茴茱莛荞茯荏荇荃荟荀茗荠茭茺茳荦荥軥軦軧軨軩軪軫軬軭軮軯軰軱軲軳軴軵軶軷軸軹軺軻軼軽軾軿輀輁輂較輄輅輆輇輈載輊輋輌輍輎輏輐輑輒輓輔輕輖輗輘輙輚輛輜輝輞輟輠輡輢輣輤輥輦輧輨輩輪輫輬輭輮輯輰輱輲輳輴輵輶輷輸輹輺輻輼輽輾輿轀轁轂轃轄荨茛荩荬荪荭荮莰荸莳莴莠莪莓莜莅荼莶莩荽莸荻莘莞莨莺莼菁萁菥菘堇萘萋菝菽菖萜萸萑萆菔菟萏萃菸菹菪菅菀萦菰菡葜葑葚葙葳蒇蒈葺蒉葸萼葆葩葶蒌蒎萱葭蓁蓍蓐蓦蒽蓓蓊蒿蒺蓠蒡蒹蒴蒗蓥蓣蔌甍蔸蓰蔹蔟蔺轅轆轇轈轉轊轋轌轍轎轏轐轑轒轓轔轕轖轗轘轙轚轛轜轝轞轟轠轡轢轣轤轥轪辀辌辒辝辠辡辢辤辥辦辧辪辬辭辮辯農辳辴辵辷辸辺辻込辿迀迃迆迉迊迋迌迍迏迒迖迗迚迠迡迣迧迬迯迱迲迴迵迶迺迻迼迾迿逇逈逌逎逓逕逘蕖蔻蓿蓼蕙蕈蕨蕤蕞蕺瞢蕃蕲蕻薤薨薇薏蕹薮薜薅薹薷薰藓藁藜藿蘧蘅蘩蘖蘼廾弈夼奁耷奕奚奘匏尢尥尬尴扌扪抟抻拊拚拗拮挢拶挹捋捃掭揶捱捺掎掴捭掬掊捩掮掼揲揸揠揿揄揞揎摒揆掾摅摁搋搛搠搌搦搡摞撄摭撖這逜連逤逥逧逨逩逪逫逬逰週進逳逴逷逹逺逽逿遀遃遅遆遈遉遊運遌過達違遖遙遚遜遝遞遟遠遡遤遦遧適遪遫遬遯遰遱遲遳遶遷選遹遺遻遼遾邁還邅邆邇邉邊邌邍邎邏邐邒邔邖邘邚邜邞邟邠邤邥邧邨邩邫邭邲邷邼邽邿郀摺撷撸撙撺擀擐擗擤擢攉攥攮弋忒甙弑卟叱叽叩叨叻吒吖吆呋呒呓呔呖呃吡呗呙吣吲咂咔呷呱呤咚咛`,
    `咄呶呦咝哐咭哂咴哒咧咦哓哔呲咣哕咻咿哌哙哚哜咩咪咤哝哏哞唛哧唠哽唔哳唢唣唏唑唧唪啧喏喵啉啭啁啕唿啐唼郂郃郆郈郉郋郌郍郒郔郕郖郘郙郚郞郟郠郣郤郥郩郪郬郮郰郱郲郳郵郶郷郹郺郻郼郿鄀鄁鄃鄅鄆鄇鄈鄉鄊鄋鄌鄍鄎鄏鄐鄑鄒鄓鄔鄕鄖鄗鄘鄚鄛鄜鄝鄟鄠鄡鄤鄥鄦鄧鄨鄩鄪鄫鄬鄭鄮鄰鄲鄳鄴鄵鄶鄷鄸鄺鄻鄼鄽鄾鄿酀酁酂酄唷啖啵啶啷唳唰啜喋嗒喃喱喹喈喁喟啾嗖喑啻嗟喽喾喔喙嗪嗷嗉嘟嗑嗫嗬嗔嗦嗝嗄嗯嗥嗲嗳嗌嗍嗨嗵嗤辔嘞嘈嘌嘁嘤嘣嗾嘀嘧嘭噘嘹噗嘬噍噢噙噜噌噔嚆噤噱噫噻噼嚅嚓嚯囔囗囝囡囵囫囹囿圄圊圉圜帏帙帔帑帱帻帼酅酇酈酑酓酔酕酖酘酙酛酜酟酠酦酧酨酫酭酳酺酻酼醀醁醂醃醄醆醈醊醎醏醓醔醕醖醗醘醙醜醝醞醟醠醡醤醥醦醧醨醩醫醬醰醱醲醳醶醷醸醹醻醼醽醾醿釀釁釂釃釄釅釆釈釋釐釒釓釔釕釖釗釘釙釚釛針釞釟釠釡釢釣釤釥帷幄幔幛幞幡岌屺岍岐岖岈岘岙岑岚岜岵岢岽岬岫岱岣峁岷峄峒峤峋峥崂崃崧崦崮崤崞崆崛嵘崾崴崽嵬嵛嵯嵝嵫嵋嵊嵩嵴嶂嶙嶝豳嶷巅彳彷徂徇徉後徕徙徜徨徭徵徼衢彡犭犰犴犷犸狃狁狎狍狒狨狯狩狲狴狷猁狳猃狺釦釧釨釩釪釫釬釭釮釯釰釱釲釳釴釵釶釷釸釹釺釻釼釽釾釿鈀鈁鈂鈃鈄鈅鈆鈇鈈鈉鈊鈋鈌鈍鈎鈏鈐鈑鈒鈓鈔鈕鈖鈗鈘鈙鈚鈛鈜鈝鈞鈟鈠鈡鈢鈣鈤鈥鈦鈧鈨鈩鈪鈫鈬鈭鈮鈯鈰鈱鈲鈳鈴鈵鈶鈷鈸鈹鈺鈻鈼鈽鈾鈿鉀鉁鉂鉃鉄鉅狻猗猓猡猊猞猝猕猢猹猥猬猸猱獐獍獗獠獬獯獾舛夥飧夤夂饣饧饨饩饪饫饬饴饷饽馀馄馇馊馍馐馑馓馔馕庀庑庋庖庥庠庹庵庾庳赓廒廑廛廨廪膺忄忉忖忏怃忮怄忡忤忾怅怆忪忭忸怙怵怦怛怏怍怩怫怊怿怡恸恹恻恺恂鉆鉇鉈鉉鉊鉋鉌鉍鉎鉏鉐鉑鉒鉓鉔鉕鉖鉗鉘鉙鉚鉛鉜鉝鉞鉟鉠鉡鉢鉣鉤鉥鉦鉧鉨鉩鉪鉫鉬鉭鉮鉯鉰鉱鉲鉳鉵鉶鉷鉸鉹鉺鉻鉼鉽鉾鉿銀銁銂銃銄銅銆銇銈銉銊銋銌銍銏銐銑銒銓銔銕銖銗銘銙銚銛銜銝銞銟銠銡銢銣銤銥銦銧恪恽悖悚悭悝悃悒悌悛惬悻悱惝惘惆惚悴愠愦愕愣惴愀愎愫慊慵憬憔憧憷懔懵忝隳闩闫闱闳闵闶闼闾阃阄阆阈阊阋阌阍阏阒阕阖阗阙阚丬爿戕氵汔汜汊沣沅沐沔沌汨汩汴汶沆沩泐泔沭泷泸泱泗沲泠泖泺泫泮沱泓泯泾銨銩銪銫銬銭銯銰銱銲銳銴銵銶銷銸銹銺銻銼銽銾銿鋀鋁鋂鋃鋄鋅鋆鋇鋉鋊鋋鋌鋍鋎鋏鋐鋑鋒鋓鋔鋕鋖鋗鋘鋙鋚鋛鋜鋝鋞鋟鋠鋡鋢鋣鋤鋥鋦鋧鋨鋩鋪鋫鋬鋭鋮鋯鋰鋱鋲鋳鋴鋵鋶鋷鋸鋹鋺鋻鋼鋽鋾鋿錀錁錂錃錄錅錆錇錈錉洹洧洌浃浈洇洄洙洎洫浍洮洵洚浏浒浔洳涑浯涞涠浞涓涔浜浠浼浣渚淇淅淞渎涿淠渑淦淝淙渖涫渌涮渫湮湎湫溲湟溆湓湔渲渥湄滟溱溘滠漭滢溥溧溽溻溷滗溴滏溏滂溟潢潆潇漤漕滹漯漶潋潴漪漉漩澉澍澌潸潲潼潺濑錊錋錌錍錎錏錐錑錒錓錔錕錖錗錘錙錚錛錜錝錞錟錠錡錢錣錤錥錦錧錨錩錪錫錬錭錮錯錰錱録錳錴錵錶錷錸錹錺錻錼錽錿鍀鍁鍂鍃鍄鍅鍆鍇鍈鍉鍊鍋鍌鍍鍎鍏鍐鍑鍒鍓鍔鍕鍖鍗鍘鍙鍚鍛鍜鍝鍞鍟鍠鍡鍢鍣鍤鍥鍦鍧鍨鍩鍫濉澧澹澶濂濡濮濞濠濯瀚瀣瀛瀹瀵灏灞宀宄宕宓宥宸甯骞搴寤寮褰寰蹇謇辶迓迕迥迮迤迩迦迳迨逅逄逋逦逑逍逖逡逵逶逭逯遄遑遒遐遨遘遢遛暹遴遽邂邈邃邋彐彗彖彘尻咫屐屙孱屣屦羼弪弩弭艴弼鬻屮妁妃妍妩妪妣鍬鍭鍮鍯鍰鍱鍲鍳鍴鍵鍶鍷鍸鍹鍺鍻鍼鍽鍾鍿鎀鎁鎂鎃鎄鎅鎆鎇鎈鎉鎊鎋鎌鎍鎎鎐鎑鎒鎓鎔鎕鎖鎗鎘鎙鎚鎛鎜鎝鎞鎟鎠鎡鎢鎣鎤鎥鎦鎧鎨鎩鎪鎫鎬鎭鎮鎯鎰鎱鎲鎳鎴鎵鎶鎷鎸鎹鎺鎻鎼鎽鎾鎿鏀鏁鏂鏃鏄鏅鏆鏇鏈鏉鏋鏌鏍妗姊妫妞妤姒妲妯姗妾娅娆姝娈姣姘姹娌娉娲娴娑娣娓婀婧婊婕娼婢婵胬媪媛婷婺媾嫫媲嫒嫔媸嫠嫣嫱嫖嫦嫘嫜嬉嬗嬖嬲嬷孀尕尜孚孥孳孑孓孢驵驷驸驺驿驽骀骁骅骈骊骐骒骓骖骘骛骜骝骟骠骢骣骥骧纟纡纣纥纨纩鏎鏏鏐鏑鏒鏓鏔鏕鏗鏘鏙鏚鏛鏜鏝鏞鏟鏠鏡鏢鏣鏤鏥鏦鏧鏨鏩鏪鏫鏬鏭鏮鏯鏰鏱鏲鏳鏴鏵鏶鏷鏸鏹鏺鏻鏼鏽鏾鏿鐀鐁鐂鐃鐄鐅鐆鐇鐈鐉鐊鐋鐌鐍鐎鐏鐐鐑鐒鐓鐔鐕鐖鐗鐘鐙鐚鐛鐜鐝鐞鐟鐠鐡鐢鐣鐤鐥鐦鐧鐨鐩鐪鐫鐬鐭鐮纭纰纾绀绁绂绉绋绌绐绔绗绛绠绡绨绫绮绯绱绲缍绶绺绻绾缁缂缃缇缈缋缌缏缑缒缗缙缜缛缟缡缢缣缤缥缦缧缪缫缬缭缯缰缱缲缳缵幺畿巛甾邕玎玑玮玢玟珏珂珑玷玳珀珉珈珥珙顼琊珩珧珞玺珲琏琪瑛琦琥琨琰琮琬鐯鐰鐱鐲鐳鐴鐵鐶鐷鐸鐹鐺鐻鐼鐽鐿鑀鑁鑂鑃鑄鑅鑆鑇鑈鑉鑊鑋鑌鑍鑎鑏鑐鑑鑒鑓鑔鑕鑖鑗鑘鑙鑚鑛鑜鑝鑞鑟鑠鑡鑢鑣鑤鑥鑦鑧鑨鑩鑪鑬鑭鑮鑯鑰鑱鑲鑳鑴鑵鑶鑷鑸鑹鑺鑻鑼鑽鑾鑿钀钁钂钃钄钑钖钘铇铏铓铔铚铦铻锜锠琛琚瑁瑜瑗瑕瑙瑷瑭瑾璜璎璀璁璇璋璞璨璩璐璧瓒璺韪韫韬杌杓杞杈杩枥枇杪杳枘枧杵枨枞枭枋杷杼柰栉柘栊柩枰栌柙枵柚枳柝栀柃枸柢栎柁柽栲栳桠桡桎桢桄桤梃栝桕桦桁桧桀栾桊桉栩梵梏桴桷梓桫棂楮棼椟椠棹锧锳锽镃镈镋镕镚镠镮镴镵長镸镹镺镻镼镽镾門閁閂閃閄閅閆閇閈閉閊開閌閍閎閏閐閑閒間`,
    `閔閕閖閗閘閙閚閛閜閝閞閟閠閡関閣閤閥閦閧閨閩閪閫閬閭閮閯閰閱閲閳閴閵閶閷閸閹閺閻閼閽閾閿闀闁闂闃闄闅闆闇闈闉闊闋椤棰椋椁楗棣椐楱椹楠楂楝榄楫榀榘楸椴槌榇榈槎榉楦楣楹榛榧榻榫榭槔榱槁槊槟榕槠榍槿樯槭樗樘橥槲橄樾檠橐橛樵檎橹樽樨橘橼檑檐檩檗檫猷獒殁殂殇殄殒殓殍殚殛殡殪轫轭轱轲轳轵轶轸轷轹轺轼轾辁辂辄辇辋闌闍闎闏闐闑闒闓闔闕闖闗闘闙闚闛關闝闞闟闠闡闢闣闤闥闦闧闬闿阇阓阘阛阞阠阣阤阥阦阧阨阩阫阬阭阯阰阷阸阹阺阾陁陃陊陎陏陑陒陓陖陗陘陙陚陜陝陞陠陣陥陦陫陭陮陯陰陱陳陸陹険陻陼陽陾陿隀隁隂隃隄隇隉隊辍辎辏辘辚軎戋戗戛戟戢戡戥戤戬臧瓯瓴瓿甏甑甓攴旮旯旰昊昙杲昃昕昀炅曷昝昴昱昶昵耆晟晔晁晏晖晡晗晷暄暌暧暝暾曛曜曦曩贲贳贶贻贽赀赅赆赈赉赇赍赕赙觇觊觋觌觎觏觐觑牮犟牝牦牯牾牿犄犋犍犏犒挈挲掰隌階隑隒隓隕隖隚際隝隞隟隠隡隢隣隤隥隦隨隩險隫隬隭隮隯隱隲隴隵隷隸隺隻隿雂雃雈雊雋雐雑雓雔雖雗雘雙雚雛雜雝雞雟雡離難雤雥雦雧雫雬雭雮雰雱雲雴雵雸雺電雼雽雿霂霃霅霊霋霌霐霑霒霔霕霗霘霙霚霛霝霟霠搿擘耄毪毳毽毵毹氅氇氆氍氕氘氙氚氡氩氤氪氲攵敕敫牍牒牖爰虢刖肟肜肓肼朊肽肱肫肭肴肷胧胨胩胪胛胂胄胙胍胗朐胝胫胱胴胭脍脎胲胼朕脒豚脶脞脬脘脲腈腌腓腴腙腚腱腠腩腼腽腭腧塍媵膈膂膑滕膣膪臌朦臊膻霡霢霣霤霥霦霧霨霩霫霬霮霯霱霳霴霵霶霷霺霻霼霽霿靀靁靂靃靄靅靆靇靈靉靊靋靌靍靎靏靐靑靔靕靗靘靚靜靝靟靣靤靦靧靨靪靫靬靭靮靯靰靱靲靵靷靸靹靺靻靽靾靿鞀鞁鞂鞃鞄鞆鞇鞈鞉鞊鞌鞎鞏鞐鞓鞕鞖鞗鞙鞚鞛鞜鞝臁膦欤欷欹歃歆歙飑飒飓飕飙飚殳彀毂觳斐齑斓於旆旄旃旌旎旒旖炀炜炖炝炻烀炷炫炱烨烊焐焓焖焯焱煳煜煨煅煲煊煸煺熘熳熵熨熠燠燔燧燹爝爨灬焘煦熹戾戽扃扈扉礻祀祆祉祛祜祓祚祢祗祠祯祧祺禅禊禚禧禳忑忐鞞鞟鞡鞢鞤鞥鞦鞧鞨鞩鞪鞬鞮鞰鞱鞳鞵鞶鞷鞸鞹鞺鞻鞼鞽鞾鞿韀韁韂韃韄韅韆韇韈韉韊韋韌韍韎韏韐韑韒韓韔韕韖韗韘韙韚韛韜韝韞韟韠韡韢韣韤韥韨韮韯韰韱韲韴韷韸韹韺韻韼韽韾響頀頁頂頃頄項順頇須頉頊頋頌頍頎怼恝恚恧恁恙恣悫愆愍慝憩憝懋懑戆肀聿沓泶淼矶矸砀砉砗砘砑斫砭砜砝砹砺砻砟砼砥砬砣砩硎硭硖硗砦硐硇硌硪碛碓碚碇碜碡碣碲碹碥磔磙磉磬磲礅磴礓礤礞礴龛黹黻黼盱眄眍盹眇眈眚眢眙眭眦眵眸睐睑睇睃睚睨頏預頑頒頓頔頕頖頗領頙頚頛頜頝頞頟頠頡頢頣頤頥頦頧頨頩頪頫頬頭頮頯頰頱頲頳頴頵頶頷頸頹頺頻頼頽頾頿顀顁顂顃顄顅顆顇顈顉顊顋題額顎顏顐顑顒顓顔顕顖顗願顙顚顛顜顝類顟顠顡顢顣顤顥顦顧顨顩顪顫顬顭顮睢睥睿瞍睽瞀瞌瞑瞟瞠瞰瞵瞽町畀畎畋畈畛畲畹疃罘罡罟詈罨罴罱罹羁罾盍盥蠲钅钆钇钋钊钌钍钏钐钔钗钕钚钛钜钣钤钫钪钭钬钯钰钲钴钶钷钸钹钺钼钽钿铄铈铉铊铋铌铍铎铐铑铒铕铖铗铙铘铛铞铟铠铢铤铥铧铨铪顯顰顱顲顳顴颋颎颒颕颙颣風颩颪颫颬颭颮颯颰颱颲颳颴颵颶颷颸颹颺颻颼颽颾颿飀飁飂飃飄飅飆飇飈飉飊飋飌飍飏飐飔飖飗飛飜飝飠飡飢飣飤飥飦飩飪飫飬飭飮飯飰飱飲飳飴飵飶飷飸飹飺飻飼飽飾飿餀餁餂餃餄餅餆餇铩铫铮铯铳铴铵铷铹铼铽铿锃锂锆锇锉锊锍锎锏锒锓锔锕锖锘锛锝锞锟锢锪锫锩锬锱锲锴锶锷锸锼锾锿镂锵镄镅镆镉镌镎镏镒镓镔镖镗镘镙镛镞镟镝镡镢镤镥镦镧镨镩镪镫镬镯镱镲镳锺矧矬雉秕秭秣秫稆嵇稃稂稞稔餈餉養餋餌餎餏餑餒餓餔餕餖餗餘餙餚餛餜餝餞餟餠餡餢餣餤餥餦餧館餩餪餫餬餭餯餰餱餲餳餴餵餶餷餸餹餺餻餼餽餾餿饀饁饂饃饄饅饆饇饈饉饊饋饌饍饎饏饐饑饒饓饖饗饘饙饚饛饜饝饞饟饠饡饢饤饦饳饸饹饻饾馂馃馉稹稷穑黏馥穰皈皎皓皙皤瓞瓠甬鸠鸢鸨鸩鸪鸫鸬鸲鸱鸶鸸鸷鸹鸺鸾鹁鹂鹄鹆鹇鹈鹉鹋鹌鹎鹑鹕鹗鹚鹛鹜鹞鹣鹦鹧鹨鹩鹪鹫鹬鹱鹭鹳疒疔疖疠疝疬疣疳疴疸痄疱疰痃痂痖痍痣痨痦痤痫痧瘃痱痼痿瘐瘀瘅瘌瘗瘊瘥瘘瘕瘙馌馎馚馛馜馝馞馟馠馡馢馣馤馦馧馩馪馫馬馭馮馯馰馱馲馳馴馵馶馷馸馹馺馻馼馽馾馿駀駁駂駃駄駅駆駇駈駉駊駋駌駍駎駏駐駑駒駓駔駕駖駗駘駙駚駛駜駝駞駟駠駡駢駣駤駥駦駧駨駩駪駫駬駭駮駯駰駱駲駳駴駵駶駷駸駹瘛瘼瘢瘠癀瘭瘰瘿瘵癃瘾瘳癍癞癔癜癖癫癯翊竦穸穹窀窆窈窕窦窠窬窨窭窳衤衩衲衽衿袂袢裆袷袼裉裢裎裣裥裱褚裼裨裾裰褡褙褓褛褊褴褫褶襁襦襻疋胥皲皴矜耒耔耖耜耠耢耥耦耧耩耨耱耋耵聃聆聍聒聩聱覃顸颀颃駺駻駼駽駾駿騀騁騂騃騄騅騆騇騈騉騊騋騌騍騎騏騐騑騒験騔騕騖騗騘騙騚騛騜騝騞騟騠騡騢騣騤騥騦騧騨騩騪騫騬騭騮騯騰騱騲騳騴騵騶騷騸騹騺騻騼騽騾騿驀驁驂驃驄驅驆驇驈驉驊驋驌驍驎驏驐驑驒驓驔驕驖驗驘驙颉颌颍颏颔颚颛颞颟颡颢颥颦虍虔虬虮虿虺虼虻蚨蚍蚋蚬蚝蚧蚣蚪蚓蚩蚶蛄蚵`,
    `蛎蚰蚺蚱蚯蛉蛏蚴蛩蛱蛲蛭蛳蛐蜓蛞蛴蛟蛘蛑蜃蜇蛸蜈蜊蜍蜉蜣蜻蜞蜥蜮蜚蜾蝈蜴蜱蜩蜷蜿螂蜢蝽蝾蝻蝠蝰蝌蝮螋蝓蝣蝼蝤蝙蝥螓螯螨蟒驚驛驜驝驞驟驠驡驢驣驤驥驦驧驨驩驪驫驲骃骉骍骎骔骕骙骦骩骪骫骬骭骮骯骲骳骴骵骹骻骽骾骿髃髄髆髇髈髉髊髍髎髏髐髒體髕髖髗髙髚髛髜髝髞髠髢髣髤髥髧髨髩髪髬髮髰髱髲髳髴髵髶髷髸髺髼髽髾髿鬀鬁鬂鬄鬅鬆蟆螈螅螭螗螃螫蟥螬螵螳蟋蟓螽蟑蟀蟊蟛蟪蟠蟮蠖蠓蟾蠊蠛蠡蠹蠼缶罂罄罅舐竺竽笈笃笄笕笊笫笏筇笸笪笙笮笱笠笥笤笳笾笞筘筚筅筵筌筝筠筮筻筢筲筱箐箦箧箸箬箝箨箅箪箜箢箫箴篑篁篌篝篚篥篦篪簌篾篼簏簖簋鬇鬉鬊鬋鬌鬍鬎鬐鬑鬒鬔鬕鬖鬗鬘鬙鬚鬛鬜鬝鬞鬠鬡鬢鬤鬥鬦鬧鬨鬩鬪鬫鬬鬭鬮鬰鬱鬳鬴鬵鬶鬷鬸鬹鬺鬽鬾鬿魀魆魊魋魌魎魐魒魓魕魖魗魘魙魚魛魜魝魞魟魠魡魢魣魤魥魦魧魨魩魪魫魬魭魮魯魰魱魲魳魴魵魶魷魸魹魺魻簟簪簦簸籁籀臾舁舂舄臬衄舡舢舣舭舯舨舫舸舻舳舴舾艄艉艋艏艚艟艨衾袅袈裘裟襞羝羟羧羯羰羲籼敉粑粝粜粞粢粲粼粽糁糇糌糍糈糅糗糨艮暨羿翎翕翥翡翦翩翮翳糸絷綦綮繇纛麸麴赳趄趔趑趱赧赭豇豉酊酐酎酏酤魼魽魾魿鮀鮁鮂鮃鮄鮅鮆鮇鮈鮉鮊鮋鮌鮍鮎鮏鮐鮑鮒鮓鮔鮕鮖鮗鮘鮙鮚鮛鮜鮝鮞鮟鮠鮡鮢鮣鮤鮥鮦鮧鮨鮩鮪鮫鮬鮭鮮鮯鮰鮱鮲鮳鮴鮵鮶鮷鮸鮹鮺鮻鮼鮽鮾鮿鯀鯁鯂鯃鯄鯅鯆鯇鯈鯉鯊鯋鯌鯍鯎鯏鯐鯑鯒鯓鯔鯕鯖鯗鯘鯙鯚鯛酢酡酰酩酯酽酾酲酴酹醌醅醐醍醑醢醣醪醭醮醯醵醴醺豕鹾趸跫踅蹙蹩趵趿趼趺跄跖跗跚跞跎跏跛跆跬跷跸跣跹跻跤踉跽踔踝踟踬踮踣踯踺蹀踹踵踽踱蹉蹁蹂蹑蹒蹊蹰蹶蹼蹯蹴躅躏躔躐躜躞豸貂貊貅貘貔斛觖觞觚觜鯜鯝鯞鯟鯠鯡鯢鯣鯤鯥鯦鯧鯨鯩鯪鯫鯬鯭鯮鯯鯰鯱鯲鯳鯴鯵鯶鯷鯸鯹鯺鯻鯼鯽鯾鯿鰀鰁鰂鰃鰄鰅鰆鰇鰈鰉鰊鰋鰌鰍鰎鰏鰐鰑鰒鰓鰔鰕鰖鰗鰘鰙鰚鰛鰜鰝鰞鰟鰠鰡鰢鰣鰤鰥鰦鰧鰨鰩鰪鰫鰬鰭鰮鰯鰰鰱鰲鰳鰴鰵鰶鰷鰸鰹鰺鰻觥觫觯訾謦靓雩雳雯霆霁霈霏霎霪霭霰霾龀龃龅龆龇龈龉龊龌黾鼋鼍隹隼隽雎雒瞿雠銎銮鋈錾鍪鏊鎏鐾鑫鱿鲂鲅鲆鲇鲈稣鲋鲎鲐鲑鲒鲔鲕鲚鲛鲞鲟鲠鲡鲢鲣鲥鲦鲧鲨鲩鲫鲭鲮鲰鲱鲲鲳鲴鲵鲶鲷鲺鲻鲼鲽鳄鳅鳆鳇鳊鳋鰼鰽鰾鰿鱀鱁鱂鱃鱄鱅鱆鱇鱈鱉鱊鱋鱌鱍鱎鱏鱐鱑鱒鱓鱔鱕鱖鱗鱘鱙鱚鱛鱜鱝鱞鱟鱠鱡鱢鱣鱤鱥鱦鱧鱨鱩鱪鱫鱬鱭鱮鱯鱰鱱鱲鱳鱴鱵鱶鱷鱸鱹鱺鱻鱽鱾鲀鲃鲄鲉鲊鲌鲏鲓鲖鲗鲘鲙鲝鲪鲬鲯鲹鲾鲿鳀鳁鳂鳈鳉鳑鳒鳚鳛鳠鳡鳌鳍鳎鳏鳐鳓鳔鳕鳗鳘鳙鳜鳝鳟鳢靼鞅鞑鞒鞔鞯鞫鞣鞲鞴骱骰骷鹘骶骺骼髁髀髅髂髋髌髑魅魃魇魉魈魍魑飨餍餮饕饔髟髡髦髯髫髻髭髹鬈鬏鬓鬟鬣麽麾縻麂麇麈麋麒鏖麝麟黛黜黝黠黟黢黩黧黥黪黯鼢鼬鼯鼹鼷鼽鼾齄鳣鳤鳥鳦鳧鳨鳩鳪鳫鳬鳭鳮鳯鳰鳱鳲鳳鳴鳵鳶鳷鳸鳹鳺鳻鳼鳽鳾鳿鴀鴁鴂鴃鴄鴅鴆鴇鴈鴉鴊鴋鴌鴍鴎鴏鴐鴑鴒鴓鴔鴕鴖鴗鴘鴙鴚鴛鴜鴝鴞鴟鴠鴡鴢鴣鴤鴥鴦鴧鴨鴩鴪鴫鴬鴭鴮鴯鴰鴱鴲鴳鴴鴵鴶鴷鴸鴹鴺鴻鴼鴽鴾鴿鵀鵁鵂鵃鵄鵅鵆鵇鵈鵉鵊鵋鵌鵍鵎鵏鵐鵑鵒鵓鵔鵕鵖鵗鵘鵙鵚鵛鵜鵝鵞鵟鵠鵡鵢鵣鵤鵥鵦鵧鵨鵩鵪鵫鵬鵭鵮鵯鵰鵱鵲鵳鵴鵵鵶鵷鵸鵹鵺鵻鵼鵽鵾鵿鶀鶁鶂鶃鶄鶅鶆鶇鶈鶉鶊鶋鶌鶍鶎鶏鶐鶑鶒鶓鶔鶕鶖鶗鶘鶙鶚鶛鶜鶝鶞鶟鶠鶡鶢鶣鶤鶥鶦鶧鶨鶩鶪鶫鶬鶭鶮鶯鶰鶱鶲鶳鶴鶵鶶鶷鶸鶹鶺鶻鶼鶽鶾鶿鷀鷁鷂鷃鷄鷅鷆鷇鷈鷉鷊鷋鷌鷍鷎鷏鷐鷑鷒鷓鷔鷕鷖鷗鷘鷙鷚鷛鷜鷝鷞鷟鷠鷡鷢鷣鷤鷥鷦鷧鷨鷩鷪鷫鷬鷭鷮鷯鷰鷱鷲鷳鷴鷵鷶鷷鷸鷹鷺鷻鷼鷽鷾鷿鸀鸁鸂鸃鸄鸅鸆鸇鸈鸉鸊鸋鸌鸍鸎鸏鸐鸑鸒鸓鸔鸕鸖鸗鸘鸙鸚鸛鸜鸝鸞鸤鸧鸮鸰鸴鸻鸼鹀鹍鹐鹒鹓鹔鹖鹙鹝鹟鹠鹡鹢鹥鹮鹯鹲鹴鹵鹶鹷鹸鹹鹺鹻鹼鹽麀麁麃麄麅麆麉麊麌麍麎麏麐麑麔麕麖麗麘麙麚麛麜麞麠麡麢麣麤麥麧麨麩麪麫麬麭麮麯麰麱麲麳麵麶麷麹麺麼麿黀黁黂黃黅黆黇黈黊黋黌黐黒黓`,
    `黕黖黗黙黚點黡黣黤黦黨黫黬黭黮黰黱黲黳黴黵黶黷黸黺黽黿鼀鼁鼂鼃鼄鼅鼆鼇鼈鼉鼊鼌鼏鼑鼒鼔鼕鼖鼘鼚鼛鼜鼝鼞鼟鼡鼣鼤鼥鼦鼧鼨鼩鼪鼫鼭鼮鼰鼱鼲鼳鼴鼵鼶鼸鼺鼼鼿齀齁齂齃齅齆齇齈齉齊齋齌齍齎齏齒齓齔齕齖齗齘齙齚齛齜齝齞齟齠齡齢齣齤齥齦齧齨齩齪齫齬齭齮齯齰齱齲齳齴齵齶齷齸齹齺齻齼齽齾龁龂龍龎龏龐龑龒龓龔龕龖龗龘龜龝龞龡龢龣龤龥郎凉秊裏隣兀嗀﨎﨏﨑﨓﨔礼﨟蘒﨡﨣﨤﨧﨨﨩⺁⺄㑳㑇⺈⺋龴㖞㘚㘎⺌⺗㥮㤘龵㧏㧟㩳㧐龶龷㭎㱮㳠⺧龸⺪䁖䅟⺮䌷⺳⺶⺷䎱䎬⺻䏝䓖䙡䙌龹䜣䜩䝼䞍⻊䥇䥺䥽䦂䦃䦅䦆䦟䦛䦷䦶龺䲣䲟䲠䲡䱷䲢䴓䴔䴕䴖䴗䴘䴙䶮龻`
  ].join("");
  const gbkTableIndex = (lead, trail) => {
    if (lead < 129 || lead > 254 || trail < 64 || trail > 254 || trail === 127) return -1;
    return (lead - 129) * 190 + (trail < 127 ? trail - 64 : trail - 65);
  };
  const decodeGbk = (bytes2) => {
    const input = bytes2 instanceof Uint8Array ? bytes2 : new Uint8Array(bytes2 || []);
    let output = "";
    for (let index = 0; index < input.length; index += 1) {
      const first = input[index];
      if (first < 128) {
        output += String.fromCharCode(first);
        continue;
      }
      if (first === 128) {
        output += "?";
        continue;
      }
      const second = input[index + 1];
      const tableIndex = second === void 0 ? -1 : gbkTableIndex(first, second);
      const decoded = tableIndex >= 0 ? GBK_TABLE[tableIndex] : "";
      if (decoded && decoded !== "\0") {
        output += decoded;
        index += 1;
      } else {
        output += "�";
      }
    }
    return output;
  };
  const acceptedArchiveExtensions = () => [
    ".7z",
    ".7z.001",
    ".br",
    ".bz2",
    ".gz",
    ".iso",
    ".lz",
    ".lz4",
    ".mz",
    ".part1.rar",
    ".rar",
    ".s2",
    ".sz",
    ".tar",
    ".tbz2",
    ".tgz",
    ".tlz",
    ".tlz4",
    ".txz",
    ".tzst",
    ".xz",
    ".zip",
    ".zip.001",
    ".zst",
    ".zz"
  ];
  const base64ToBytes = (value) => {
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    const clean = String(value || "").replace(/[\r\n\s]/g, "").replace(/-/g, "+").replace(/_/g, "/");
    const bytes2 = [];
    for (let i2 = 0; i2 < clean.length; i2 += 4) {
      const a = chars2.indexOf(clean[i2]);
      const b = chars2.indexOf(clean[i2 + 1]);
      const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
      const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
      if (a < 0 || b < 0) continue;
      bytes2.push(a << 2 | b >> 4);
      if (c >= 0) bytes2.push((b & 15) << 4 | c >> 2);
      if (d >= 0) bytes2.push((c & 3) << 6 | d);
    }
    return Uint8Array.from(bytes2);
  };
  const encodeUtf8 = (value) => {
    const bytes2 = [];
    for (const char of String(value || "")) {
      const code = char.codePointAt(0) || 0;
      if (code <= 127) {
        bytes2.push(code);
      } else if (code <= 2047) {
        bytes2.push(192 | code >> 6, 128 | code & 63);
      } else if (code <= 65535) {
        bytes2.push(224 | code >> 12, 128 | code >> 6 & 63, 128 | code & 63);
      } else {
        bytes2.push(
          240 | code >> 18,
          128 | code >> 12 & 63,
          128 | code >> 6 & 63,
          128 | code & 63
        );
      }
    }
    return Uint8Array.from(bytes2);
  };
  const decodeUtf8 = (bytes2) => {
    const input = bytes2 instanceof Uint8Array ? bytes2 : new Uint8Array(bytes2 || []);
    let result = "";
    for (let i2 = 0; i2 < input.length; ) {
      const first = input[i2++];
      if (first < 128) {
        result += String.fromCharCode(first);
      } else if ((first & 224) === 192 && i2 < input.length && (input[i2] & 192) === 128) {
        const second = input[i2++];
        result += String.fromCharCode((first & 31) << 6 | second & 63);
      } else if ((first & 240) === 224 && i2 + 1 < input.length && (input[i2] & 192) === 128 && (input[i2 + 1] & 192) === 128) {
        const second = input[i2++];
        const third = input[i2++];
        result += String.fromCharCode((first & 15) << 12 | (second & 63) << 6 | third & 63);
      } else if ((first & 248) === 240 && i2 + 2 < input.length && (input[i2] & 192) === 128 && (input[i2 + 1] & 192) === 128 && (input[i2 + 2] & 192) === 128) {
        const second = input[i2++];
        const third = input[i2++];
        const fourth = input[i2++];
        const code = (first & 7) << 18 | (second & 63) << 12 | (third & 63) << 6 | fourth & 63;
        result += code <= 1114111 ? String.fromCodePoint(code) : "�";
      } else {
        result += "�";
      }
    }
    return result;
  };
  const dosDateTimeToIso = (date, time) => {
    const day = date & 31;
    const month = date >> 5 & 15;
    const year = (date >> 9 & 127) + 1980;
    const second = (time & 31) * 2;
    const minute = time >> 5 & 63;
    const hour = time >> 11 & 31;
    if (!day || !month) return (/* @__PURE__ */ new Date(0)).toISOString();
    return new Date(Date.UTC(year, month - 1, day, hour, minute, second)).toISOString();
  };
  const zipFilenameDecoder = (bytes2, options = {}) => {
    if (!options.utf8) return decodeGbk(bytes2);
    return decodeUtf8(bytes2);
  };
  const decodeZipName = (bytes2, utf82, decoder) => {
    if (decoder) {
      try {
        const decoded = decoder(bytes2, { utf8: utf82 });
        if (decoded) return decoded;
      } catch (_) {
      }
    }
    return zipFilenameDecoder(bytes2, { utf8: utf82 });
  };
  const normalizeArchiveInnerPath = (path) => {
    const parts = String(path || "").replace(/\\/g, "/").split("/").filter((part) => part && part !== "." && part !== "..");
    return parts.join("/");
  };
  const findEndOfCentralDirectory = (view) => {
    const min = Math.max(0, view.byteLength - 65535 - 22);
    for (let offset = view.byteLength - 22; offset >= min; offset -= 1) {
      if (view.getUint32(offset, true) === 101010256) return offset;
    }
    throw new Error("invalid zip: end of central directory not found");
  };
  const objType = (name, isDir2) => {
    if (isDir2) return 1;
    const ext = String(name || "").toLowerCase().split(".").pop() || "";
    if (["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif"].includes(ext)) return 2;
    if (["mp4", "mkv", "mov", "avi", "webm", "m4v"].includes(ext)) return 3;
    if (["mp3", "flac", "wav", "ogg", "m4a"].includes(ext)) return 4;
    if (["zip", "7z", "rar", "tar", "gz", "bz2"].includes(ext)) return 5;
    if (["pdf", "epub", "txt", "md", "json", "yaml", "yml", "csv", "log"].includes(ext)) return 6;
    return 0;
  };
  const toArchiveObjResp = (node) => ({
    name: node.name,
    size: node.size || 0,
    is_dir: !!node.is_dir,
    modified: node.modified,
    created: node.created || node.modified,
    sign: "",
    thumb: "",
    type: objType(node.name, node.is_dir),
    hashinfo: "",
    hash_info: {}
  });
  const sortNodes = (nodes) => nodes.sort((a, b) => {
    if (a.is_dir !== b.is_dir) return a.is_dir ? -1 : 1;
    return a.name.localeCompare(b.name);
  });
  const nodeToContent = (node) => ({
    ...toArchiveObjResp(node),
    children: node.children ? sortNodes([...node.children.values()]).map(nodeToContent) : []
  });
  const entryBytes = (entry) => {
    if (!entry || entry.is_dir) throw new Error("object not found");
    if (String(entry.body_encoding || "").startsWith("base64")) {
      return base64ToBytes(entry.content || "");
    }
    return encodeUtf8(entry.content || "");
  };
  const octal = (bytes2) => {
    const text2 = decodeUtf8(bytes2).replace(/\0.*$/, "").trim();
    return text2 ? Number.parseInt(text2, 8) || 0 : 0;
  };
  const trimNull = (bytes2) => decodeUtf8(bytes2).replace(/\0.*$/, "");
  const parseTarArchive = (bytes2, options = {}) => {
    const source = bytes2 instanceof Uint8Array ? bytes2 : new Uint8Array(bytes2 || []);
    const data = options.gzip ? gunzipSync(source) : source;
    const root = {
      name: "",
      is_dir: true,
      size: 0,
      modified: (/* @__PURE__ */ new Date(0)).toISOString(),
      created: (/* @__PURE__ */ new Date(0)).toISOString(),
      children: /* @__PURE__ */ new Map()
    };
    const files = [];
    const filesByPath = /* @__PURE__ */ new Map();
    const ensureDir = (parts, modified) => {
      let current = root;
      for (const part of parts) {
        if (!current.children.has(part)) {
          current.children.set(part, {
            name: part,
            is_dir: true,
            size: 0,
            modified,
            created: modified,
            children: /* @__PURE__ */ new Map()
          });
        }
        current = current.children.get(part);
      }
      return current;
    };
    for (let offset = 0; offset + 512 <= data.length; ) {
      const header = data.slice(offset, offset + 512);
      if (header.every((byte) => byte === 0)) break;
      const name = trimNull(header.slice(0, 100));
      const prefix = trimNull(header.slice(345, 500));
      const fullName = normalizeArchiveInnerPath(prefix ? `${prefix}/${name}` : name);
      const size = octal(header.slice(124, 136));
      const mtime = octal(header.slice(136, 148));
      const typeflag = header[156];
      const modified = new Date((mtime || 0) * 1e3).toISOString();
      const bodyStart = offset + 512;
      const isDir2 = typeflag === 53 || fullName.endsWith("/");
      if (fullName) {
        const parts = fullName.split("/");
        const leaf = parts.pop();
        const parent = ensureDir(parts, modified);
        if (isDir2) {
          ensureDir([...parts, leaf], modified);
        } else if (typeflag === 0 || typeflag === 48) {
          const node = {
            name: leaf,
            is_dir: false,
            size,
            modified,
            created: modified,
            archive_path: [...parts, leaf].join("/"),
            body_offset: bodyStart,
            method: "tar"
          };
          parent.children.set(leaf, node);
          files.push(node);
          filesByPath.set(node.archive_path, node);
        }
      }
      offset = bodyStart + Math.ceil(size / 512) * 512;
    }
    return {
      comment: "",
      encrypted: false,
      files,
      tree: sortNodes([...root.children.values()]).map(nodeToContent),
      list(innerPath = "/") {
        const parts = normalizeArchiveInnerPath(innerPath).split("/").filter(Boolean);
        let current = root;
        for (const part of parts) {
          current = current.children.get(part);
          if (!current || !current.is_dir) return [];
        }
        return sortNodes([...current.children.values()]).map(toArchiveObjResp);
      },
      file_count: files.length,
      entry(innerPath) {
        return filesByPath.get(normalizeArchiveInnerPath(innerPath));
      },
      bytesFor(entry) {
        return data.slice(entry.body_offset, entry.body_offset + entry.size);
      }
    };
  };
  const archiveKind = (path) => {
    const lower = String(path || "").toLowerCase();
    if (lower.endsWith(".zip")) return "zip";
    if (lower.endsWith(".tar")) return "tar";
    if (lower.endsWith(".tgz") || lower.endsWith(".tar.gz")) return "tgz";
    return "";
  };
  const canReadArchive = (path) => !!archiveKind(path);
  const parseArchive = (bytes2, path, options = {}) => {
    const kind = archiveKind(path);
    if (kind === "zip") return parseZipArchive(bytes2, options);
    if (kind === "tar") return parseTarArchive(bytes2, options);
    if (kind === "tgz") return parseTarArchive(bytes2, { ...options, gzip: true });
    throw new Error("archive preview is not implemented in the SiYuan kernel port yet");
  };
  const parseZipArchive = (bytes2, options = {}) => {
    const data = bytes2 instanceof Uint8Array ? bytes2 : new Uint8Array(bytes2 || []);
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    const eocdOffset = findEndOfCentralDirectory(view);
    const total = view.getUint16(eocdOffset + 10, true);
    const centralOffset = view.getUint32(eocdOffset + 16, true);
    const centralOffsetBase = Number(options.centralOffsetBase || 0);
    let offset = options.forcedCentralOffset !== void 0 ? Number(options.forcedCentralOffset || 0) : centralOffset - centralOffsetBase;
    const root = {
      name: "",
      is_dir: true,
      size: 0,
      modified: (/* @__PURE__ */ new Date(0)).toISOString(),
      created: (/* @__PURE__ */ new Date(0)).toISOString(),
      children: /* @__PURE__ */ new Map()
    };
    const files = [];
    const filesByPath = /* @__PURE__ */ new Map();
    let encrypted = false;
    const ensureDir = (parts, modified) => {
      let current = root;
      for (const part of parts) {
        if (!current.children.has(part)) {
          current.children.set(part, {
            name: part,
            is_dir: true,
            size: 0,
            modified,
            created: modified,
            children: /* @__PURE__ */ new Map()
          });
        }
        current = current.children.get(part);
      }
      return current;
    };
    for (let index = 0; index < total; index += 1) {
      if (view.getUint32(offset, true) !== 33639248) throw new Error("invalid zip: central directory is corrupt");
      const flags = view.getUint16(offset + 8, true);
      const method = view.getUint16(offset + 10, true);
      const modTime = view.getUint16(offset + 12, true);
      const modDate = view.getUint16(offset + 14, true);
      const compressedSize = view.getUint32(offset + 20, true);
      const uncompressedSize = view.getUint32(offset + 24, true);
      const nameLength = view.getUint16(offset + 28, true);
      const extraLength = view.getUint16(offset + 30, true);
      const commentLength = view.getUint16(offset + 32, true);
      const externalAttrs = view.getUint32(offset + 38, true);
      const localHeaderOffset = view.getUint32(offset + 42, true);
      const nameStart = offset + 46;
      const rawName = decodeZipName(data.slice(nameStart, nameStart + nameLength), (flags & 2048) !== 0, options.filenameDecoder);
      const cleanName = normalizeArchiveInnerPath(rawName);
      const modified = dosDateTimeToIso(modDate, modTime);
      const isDir2 = rawName.endsWith("/") || (externalAttrs >>> 16 & 16384) === 16384;
      encrypted = encrypted || (flags & 1) === 1;
      if (cleanName) {
        const parts = cleanName.split("/");
        const name = parts.pop();
        const parent = ensureDir(parts, modified);
        if (isDir2) {
          ensureDir([...parts, name], modified);
        } else if (!parent.children.has(name)) {
          const node = {
            name,
            is_dir: false,
            size: uncompressedSize,
            modified,
            created: modified,
            archive_path: [...parts, name].join("/"),
            compressed_size: compressedSize,
            encrypted: (flags & 1) === 1,
            local_header_offset: localHeaderOffset,
            method
          };
          parent.children.set(name, node);
          files.push(node);
          filesByPath.set(node.archive_path, node);
        }
      }
      offset = nameStart + nameLength + extraLength + commentLength;
    }
    return {
      comment: decodeZipName(data.slice(eocdOffset + 22, eocdOffset + 22 + view.getUint16(eocdOffset + 20, true)), true, options.filenameDecoder),
      encrypted,
      eocd_offset: eocdOffset,
      files,
      tree: sortNodes([...root.children.values()]).map(nodeToContent),
      list(innerPath = "/") {
        const parts = normalizeArchiveInnerPath(innerPath).split("/").filter(Boolean);
        let current = root;
        for (const part of parts) {
          current = current.children.get(part);
          if (!current || !current.is_dir) return [];
        }
        return sortNodes([...current.children.values()]).map(toArchiveObjResp);
      },
      file_count: files.length,
      entry(innerPath) {
        return filesByPath.get(normalizeArchiveInnerPath(innerPath));
      }
    };
  };
  const parseContentRangeSize = (value) => {
    const match = String(value || "").match(/\/(\d+|\*)\s*$/);
    return match && match[1] !== "*" ? Number(match[1]) : 0;
  };
  const headerValue$1 = (headers = {}, name) => {
    const target = String(name || "").toLowerCase();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== target) continue;
      return Array.isArray(value) ? String(value[0] || "") : String(value || "");
    }
    return "";
  };
  const parseZipArchiveAsync = async (reader, options = {}) => {
    if (!(reader == null ? void 0 : reader.rangeRead)) throw new Error("archive reader is not seekable");
    let size = Number(reader.size || 0);
    let tailStart = 0;
    if (size > 0) {
      tailStart = Math.max(0, size - 65557);
    } else {
      tailStart = Math.max(0, Number(options.probeSize || 1048576) - 65557);
    }
    let tail = await reader.rangeRead(tailStart, size > 0 ? size - 1 : void 0);
    if (!size) {
      size = parseContentRangeSize(headerValue$1(tail.headers, "Content-Range")) || Number(headerValue$1(tail.headers, "Content-Length")) || tail.bytes.byteLength;
      tailStart = Math.max(0, size - tail.bytes.byteLength);
    }
    const view = new DataView(tail.bytes.buffer, tail.bytes.byteOffset, tail.bytes.byteLength);
    const eocdOffset = findEndOfCentralDirectory(view);
    const centralOffset = view.getUint32(eocdOffset + 16, true);
    const centralSize = view.getUint32(eocdOffset + 12, true);
    const commentLength = view.getUint16(eocdOffset + 20, true);
    const eocdBytes = tail.bytes.slice(eocdOffset, eocdOffset + 22 + commentLength);
    const centralInTail = centralOffset >= tailStart && centralOffset + centralSize <= tailStart + tail.bytes.byteLength;
    if (centralInTail) {
      return parseZipArchive(tail.bytes, {
        ...options,
        centralOffsetBase: tailStart
      });
    }
    const central = await reader.rangeRead(centralOffset, centralOffset + centralSize - 1);
    const merged = new Uint8Array(central.bytes.byteLength + eocdBytes.byteLength);
    merged.set(central.bytes, 0);
    merged.set(eocdBytes, central.bytes.byteLength);
    const archive = parseZipArchive(merged, {
      ...options,
      centralOffsetBase: centralOffset,
      forcedCentralOffset: 0
    });
    return archive;
  };
  const extractZipArchiveEntryReaderAsync = async (reader, innerPath, options = {}) => {
    if (!(reader == null ? void 0 : reader.rangeRead)) throw new Error("archive reader is not seekable");
    const archive = options.archive || await parseZipArchiveAsync(reader, options);
    const entry = archive.entry(innerPath);
    if (!entry) throw new Error("archive inner object not found");
    if (entry.encrypted) throw new Error("wrong archive password");
    const header = await reader.rangeRead(entry.local_header_offset, entry.local_header_offset + 29);
    const view = new DataView(header.bytes.buffer, header.bytes.byteOffset, header.bytes.byteLength);
    if (view.getUint32(0, true) !== 67324752) throw new Error("invalid zip: local file header is corrupt");
    const nameLength = view.getUint16(26, true);
    const extraLength = view.getUint16(28, true);
    const dataStart = entry.local_header_offset + 30 + nameLength + extraLength;
    const compressed = entry.compressed_size > 0 ? (await reader.rangeRead(dataStart, dataStart + entry.compressed_size - 1)).bytes : new Uint8Array();
    if (entry.method === 0) {
      return {
        bytes: compressed,
        entry
      };
    }
    if (entry.method === 8) {
      return {
        bytes: inflateSync(compressed),
        entry
      };
    }
    throw new Error(`zip compression method ${entry.method} is not supported yet`);
  };
  const extractZipArchiveEntry = (bytes2, innerPath, options = {}) => {
    const data = bytes2 instanceof Uint8Array ? bytes2 : new Uint8Array(bytes2 || []);
    const archive = options.archive || parseZipArchive(data, options);
    const entry = archive.entry(innerPath);
    if (!entry) throw new Error("archive inner object not found");
    if (entry.encrypted) throw new Error("encrypted archive entry is not implemented in the SiYuan kernel port yet");
    const view = new DataView(data.buffer, data.byteOffset, data.byteLength);
    const offset = entry.local_header_offset;
    if (view.getUint32(offset, true) !== 67324752) throw new Error("invalid zip: local file header is corrupt");
    const nameLength = view.getUint16(offset + 26, true);
    const extraLength = view.getUint16(offset + 28, true);
    const dataStart = offset + 30 + nameLength + extraLength;
    const compressed = data.slice(dataStart, dataStart + entry.compressed_size);
    if (entry.method === 0) {
      return {
        bytes: compressed,
        entry
      };
    }
    if (entry.method === 8) {
      return {
        bytes: inflateSync(compressed),
        entry
      };
    }
    throw new Error(`zip compression method ${entry.method} is not supported yet`);
  };
  const extractZipArchiveEntryAsync = async (bytes2, innerPath, options = {}) => {
    const data = bytes2 instanceof Uint8Array ? bytes2 : new Uint8Array(bytes2 || []);
    const archive = options.archive || parseZipArchive(data, options);
    const entry = archive.entry(innerPath);
    if (!entry) throw new Error("archive inner object not found");
    if (!entry.encrypted) return extractZipArchiveEntry(data, innerPath, { ...options, archive });
    throw new Error("wrong archive password");
  };
  const extractArchiveEntry = (bytes2, path, innerPath, options = {}) => {
    const kind = archiveKind(path);
    if (kind === "zip") return extractZipArchiveEntry(bytes2, innerPath, options);
    const archive = options.archive || parseArchive(bytes2, path, options);
    const entry = archive.entry(innerPath);
    if (!entry) throw new Error("archive inner object not found");
    return {
      bytes: archive.bytesFor(entry),
      entry
    };
  };
  const extractArchiveEntryAsync = async (bytes2, path, innerPath, options = {}) => {
    const kind = archiveKind(path);
    if (kind === "zip") return extractZipArchiveEntryAsync(bytes2, innerPath, options);
    return extractArchiveEntry(bytes2, path, innerPath, options);
  };
  const extractArchiveEntriesAsync = async (bytes2, path, options = {}) => {
    const archive = parseArchive(bytes2, path, options);
    const inner = normalizeArchiveInnerPath(options.innerPath || "");
    const prefix = inner ? `${inner}/` : "";
    const paths = [];
    for (const file of archive.files) {
      if (!inner || file.archive_path === inner || file.archive_path.startsWith(prefix)) paths.push(file.archive_path);
    }
    if (inner && !paths.length) throw new Error("archive inner object not found");
    return Promise.all(paths.map((innerPath) => extractArchiveEntryAsync(bytes2, path, innerPath, { ...options, archive })));
  };
  const archiveNotImplemented = (operation) => ({
    operation,
    reason: "SiYuan kernel JavaScript runtime has no archive reader wired yet.",
    upstream_source: "server/handles/archive.go + internal/op/archive.go + internal/archive/*",
    next: "Port a JS archive reader or expose a kernel-side archive primitive before enabling this route."
  });
  const sharingArchiveNotImplemented = (operation) => ({
    operation,
    reason: "SiYuan kernel JavaScript runtime has no sharing archive reader wired yet.",
    upstream_source: "server/handles/sharing.go + internal/sharing/archive.go",
    next: "Port OpenList sharing archive preview/extract before enabling this route."
  });
  const parseArchiveRequest = async (request2, parseJson) => {
    if (request2.method === "GET" || request2.method === "HEAD")
      return Object.fromEntries(new URL(request2.url).searchParams.entries());
    return parseJson(request2);
  };
  const isSharingArchivePath = (path) => typeof path === "string" && path.startsWith("/@s");
  const requestArchivePass = (req = {}) => req.archive_pass || req.archivePass || req.pass || "";
  const rawArchiveUrl = (path) => `/plugin/private/siyuan-cloud/ae${normalizePath(path)}`;
  const rawShareArchiveUrl = (path, pwd = "") => `/plugin/private/siyuan-cloud/sad${normalizePath(path)}${pwd ? `?pwd=${encodeURIComponent(pwd)}` : ""}`;
  const joinPath = (dir, name) => normalizePath(`${normalizePath(dir || "/").replace(/\/+$/, "")}/${String(name || "").replace(/^\/+/, "")}`);
  const pathWithinBase = (path, basePath) => {
    const target = normalizePath(path);
    const base = normalizePath(basePath || "/");
    return base === "/" || target === base || target.startsWith(`${base}/`);
  };
  const canUsePath = (user, path) => !user || isAdminUser(user) || pathWithinBase(path, user.base_path);
  const canAccessArchivePath = (state, user, path, password2 = "") => canUsePath(user, path) && canAccessByMeta(user, nearestMeta(state, path), path, password2);
  const canWriteArchivePath = (state, user, path) => canUsePath(user, path) && canWriteByMeta(user, nearestMeta(state, path), path);
  const relativeArchivePath = (archivePath, innerPath) => {
    const inner = String(innerPath || "").replace(/^\/+|\/+$/g, "");
    const path = String(archivePath || "");
    if (!inner) return path;
    if (path === inner) return basename(path);
    return path.startsWith(`${inner}/`) ? path.slice(inner.length + 1) : path;
  };
  const mimeType = (name) => {
    const ext = String(name || "").toLowerCase().split(".").pop() || "";
    const types = {
      css: "text/css; charset=utf-8",
      csv: "text/csv; charset=utf-8",
      html: "text/html; charset=utf-8",
      jpeg: "image/jpeg",
      jpg: "image/jpeg",
      js: "application/javascript; charset=utf-8",
      json: "application/json; charset=utf-8",
      md: "text/markdown; charset=utf-8",
      png: "image/png",
      svg: "image/svg+xml",
      txt: "text/plain; charset=utf-8",
      webp: "image/webp"
    };
    return types[ext] || "application/octet-stream";
  };
  const archiveMountedNotImplemented = (operation, mount, error = "") => {
    var _a2, _b2;
    return {
      ...archiveNotImplemented(operation),
      reason: "Archive preview for mounted driver files requires a readable archive byte stream; this driver path is not wired yet.",
      error,
      storage: {
        driver: ((_a2 = mount == null ? void 0 : mount.storage) == null ? void 0 : _a2.driver) || "",
        mount_path: ((_b2 = mount == null ? void 0 : mount.storage) == null ? void 0 : _b2.mount_path) || ""
      }
    };
  };
  const bytesFromDriverRead = (data) => {
    if (!data || data.link) return null;
    if (String(data.bodyEncoding || data.body_encoding || "").startsWith("base64")) {
      return base64EntryBytes(data.body || "");
    }
    if (data.body !== void 0) {
      return entryBytes({
        content: data.body || "",
        body_encoding: "text",
        is_dir: false
      });
    }
    return null;
  };
  const base64EntryBytes = (content) => entryBytes({
    content,
    body_encoding: "base64",
    is_dir: false
  });
  const driverLink = (data) => {
    var _a2, _b2, _c;
    const link2 = linkFromDriverData(data);
    return {
      ...link2,
      headers: link2.header || ((_a2 = data.link) == null ? void 0 : _a2.headers) || {},
      size: Number(link2.content_length || link2.contentLength || ((_b2 = data.link) == null ? void 0 : _b2.content_length) || ((_c = data.link) == null ? void 0 : _c.contentLength) || 0)
    };
  };
  const fetchDriverLink = async (client, link2, headers) => {
    const resp = await forwardProxy(client, link2.url, {
      allowErrorStatus: true,
      contentType: "",
      headers,
      method: link2.method || "GET",
      responseEncoding: "base64",
      timeout: 12e4
    });
    if (Number(resp.status || 0) >= 400) throw new Error(`HTTP ${resp.status}: ${decodeBase64Error(resp.body || "").slice(0, 300)}`);
    return resp;
  };
  const bytesFromDriverLink = async (client, data) => {
    if (!client || !(data == null ? void 0 : data.link)) return null;
    const link2 = driverLink(data);
    const resp = await fetchDriverLink(client, link2, link2.headers);
    return base64EntryBytes(resp.body || "");
  };
  const driverLinkReader = (client, data) => {
    if (!client || !(data == null ? void 0 : data.link)) return null;
    const link2 = driverLink(data);
    return {
      size: link2.size,
      async rangeRead(start = 0, end) {
        const offset = Math.max(0, Number(start || 0));
        const boundedEnd = end === void 0 || end === null ? null : Math.max(offset, Number(end || 0));
        const resp = await fetchDriverLink(client, link2, {
          ...link2.headers,
          Range: `bytes=${offset}-`
        });
        let bytes2 = base64EntryBytes(resp.body || "");
        if (Number(resp.status || 0) === 200 && offset > 0) bytes2 = bytes2.slice(offset);
        return {
          bytes: boundedEnd === null ? bytes2 : bytes2.slice(0, boundedEnd - offset + 1),
          headers: resp.headers || {},
          status: resp.status
        };
      }
    };
  };
  const archiveSourceFromDriverRead = async (client, path, readData) => {
    const bytes2 = bytesFromDriverRead(readData);
    if (bytes2) return { bytes: bytes2, archive: parseArchive(bytes2, path) };
    if (archiveKind(path) === "zip") {
      const reader = driverLinkReader(client, readData);
      if (reader) return { reader, archive: await parseZipArchiveAsync(reader) };
    }
    const linkedBytes = await bytesFromDriverLink(client, readData);
    return linkedBytes ? { bytes: linkedBytes, archive: parseArchive(linkedBytes, path) } : {};
  };
  const decodeBase64Error = (value) => {
    const input = String(value || "");
    if (!input) return "";
    try {
      const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
      const clean = input.replace(/[\r\n\s]/g, "").replace(/-/g, "+").replace(/_/g, "/");
      const bytes2 = [];
      for (let i2 = 0; i2 < clean.length; i2 += 4) {
        const a = chars2.indexOf(clean[i2]);
        const b = chars2.indexOf(clean[i2 + 1]);
        const c = clean[i2 + 2] === "=" ? -1 : chars2.indexOf(clean[i2 + 2]);
        const d = clean[i2 + 3] === "=" ? -1 : chars2.indexOf(clean[i2 + 3]);
        if (a < 0 || b < 0) return input;
        bytes2.push(a << 2 | b >> 4);
        if (c >= 0) bytes2.push((b & 15) << 4 | c >> 2);
        if (d >= 0) bytes2.push((c & 3) << 6 | d);
      }
      return new TextDecoder().decode(Uint8Array.from(bytes2)) || input;
    } catch (_) {
      return input;
    }
  };
  const bytesToBase64 = (bytes2) => {
    if (!bytes2 || !bytes2.length) return "";
    const chars2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let output = "";
    for (let index = 0; index < bytes2.length; index += 3) {
      const a = bytes2[index];
      const hasB = index + 1 < bytes2.length;
      const hasC = index + 2 < bytes2.length;
      const b = hasB ? bytes2[index + 1] : 0;
      const c = hasC ? bytes2[index + 2] : 0;
      output += chars2[a >> 2];
      output += chars2[(a & 3) << 4 | b >> 4];
      output += hasB ? chars2[(b & 15) << 2 | c >> 6] : "=";
      output += hasC ? chars2[c & 63] : "=";
    }
    return output;
  };
  const loadArchive = async ({ client, driverRuntime, getState, operation, req }) => {
    var _a2;
    const path = normalizePath(req.path || "/");
    const entry = getState().entries[path];
    if (!canReadArchive(path)) {
      return {
        error: failure(
          "archive preview is not implemented in the SiYuan kernel port yet",
          501,
          archiveNotImplemented(operation)
        ),
        status: 501
      };
    }
    if (entry && !entry.is_dir) {
      const bytes2 = entryBytes(entry);
      return {
        path,
        bytes: bytes2,
        archive: parseArchive(bytes2, path)
      };
    }
    const mount = driverRuntime == null ? void 0 : driverRuntime.resolve(getState().storages, path);
    if (mount) {
      let lastError = "";
      if ((_a2 = mount.driver) == null ? void 0 : _a2.read) {
        try {
          const readData = await mount.driver.read(mount.storage, mount.relPath, {});
          const source = await archiveSourceFromDriverRead(client, path, readData);
          if (source.bytes || source.reader) return { path, ...source };
        } catch (error) {
          lastError = (error == null ? void 0 : error.message) || String(error);
        }
      }
      return {
        error: failure(
          "archive preview for mounted driver files is not implemented in the SiYuan kernel port yet",
          501,
          archiveMountedNotImplemented(operation, mount, lastError)
        ),
        status: 501
      };
    }
    return {
      error: failure("object not found", 404),
      status: 404
    };
  };
  const loadShareArchive = async ({ client, driverRuntime, getState, operation, request: request2, req, saveState: saveState2 }) => {
    const sharePath = normalizePath(String(req.path || "").replace(/^\/@s/, ""));
    const info = sharePathInfo({ path: sharePath, password: req.password || req.pwd, state: getState() });
    if (!info) {
      return {
        error: failure("the share does not exist", 500, sharingArchiveNotImplemented(operation)),
        status: 500
      };
    }
    await countShareAccess({ info, ip: shareClientIP(request2), saveState: saveState2 });
    const loaded = await loadArchive({
      client,
      driverRuntime,
      getState,
      operation,
      req: { ...req, path: info.targetPath }
    });
    return {
      ...loaded,
      shareInfo: info,
      sharePath
    };
  };
  const createArchiveHandlers = ({
    client,
    createFile: createFile2,
    currentUser,
    driverRuntime,
    ensureDir,
    getState,
    page,
    parseJson,
    saveState: saveState2,
    taskStore
  }) => ({
    "ANY /api/fs/archive/meta": async (request2) => {
      var _a2, _b2;
      const req = await parseArchiveRequest(request2, parseJson);
      if (isSharingArchivePath(req.path)) {
        const loaded2 = await loadShareArchive({ client, driverRuntime, getState, operation: "share_meta", request: request2, req, saveState: saveState2 });
        if (loaded2.error) return jsonResponse(loaded2.error, loaded2.status);
        return jsonResponse(success({
          comment: loaded2.archive.comment,
          encrypted: loaded2.archive.encrypted,
          content: loaded2.archive.tree,
          raw_url: rawShareArchiveUrl(loaded2.sharePath, ((_b2 = (_a2 = loaded2.shareInfo) == null ? void 0 : _a2.normalizedShare) == null ? void 0 : _b2.pwd) || ""),
          sign: ""
        }));
      }
      const user = currentUser == null ? void 0 : currentUser(request2);
      const path = normalizePath(req.path || "/");
      if (!canReadArchives(user) || !canAccessArchivePath(getState(), user, path, req.password || req.pwd)) {
        return jsonResponse(failure("permission denied", 403));
      }
      const loaded = await loadArchive({ client, driverRuntime, getState, operation: "meta", req });
      if (loaded.error) return jsonResponse(loaded.error, loaded.status);
      return jsonResponse(success({
        comment: loaded.archive.comment,
        encrypted: loaded.archive.encrypted,
        content: loaded.archive.tree,
        raw_url: rawArchiveUrl(loaded.path),
        sign: ""
      }));
    },
    "ANY /api/fs/archive/list": async (request2) => {
      const req = await parseArchiveRequest(request2, parseJson);
      if (isSharingArchivePath(req.path)) {
        const loaded2 = await loadShareArchive({ client, driverRuntime, getState, operation: "share_list", request: request2, req, saveState: saveState2 });
        if (loaded2.error) return jsonResponse(loaded2.error, loaded2.status);
        const items2 = loaded2.archive.list(req.inner_path || "/");
        return jsonResponse(success(pageResp(page(items2, req), items2.length)));
      }
      const user = currentUser == null ? void 0 : currentUser(request2);
      const path = normalizePath(req.path || "/");
      if (!canReadArchives(user) || !canAccessArchivePath(getState(), user, path, req.password || req.pwd)) {
        return jsonResponse(failure("permission denied", 403));
      }
      const loaded = await loadArchive({ client, driverRuntime, getState, operation: "list", req });
      if (loaded.error) return jsonResponse(loaded.error, loaded.status);
      const items = loaded.archive.list(req.inner_path || "/");
      return jsonResponse(success(pageResp(page(items, req), items.length)));
    },
    "POST /api/fs/archive/decompress": async (request2) => {
      var _a2;
      const req = await parseJson(request2);
      const creator = currentUser == null ? void 0 : currentUser(request2);
      const names = Array.isArray(req.name) ? req.name : Array.isArray(req.names) ? req.names : [];
      const srcPaths = names.length ? names.map((name) => joinPath(req.src_dir || dirname(req.src_path || req.path || "/"), name)) : [normalizePath(req.src_path || req.path || joinPath(req.src_dir || "/", req.name || ""))];
      const dstDir = normalizePath(req.dst_dir || req.dst_path || "/");
      if (!canDecompress(creator) || srcPaths.some((srcPath) => !canUsePath(creator, srcPath)) || !canWriteArchivePath(getState(), creator, dstDir)) {
        return jsonResponse(failure("permission denied", 403));
      }
      const dstMount = driverRuntime == null ? void 0 : driverRuntime.resolve(getState().storages, dstDir);
      if (dstMount && !((_a2 = dstMount.driver) == null ? void 0 : _a2.put))
        return jsonResponse(failure("driver put is not implemented", 501, archiveNotImplemented("decompress_upload")), 501);
      const tasks = [];
      try {
        for (const srcPath of srcPaths) {
          const loaded = await loadArchive({ client, driverRuntime, getState, operation: "decompress", req: { ...req, path: srcPath } });
          if (loaded.error) return jsonResponse(loaded.error, loaded.status);
          const base = basename(srcPath).replace(/\.[^.]+$/, "") || basename(srcPath);
          const targetRoot = req.put_into_new_dir ? joinPath(dstDir, base) : dstDir;
          ensureDir(targetRoot);
          const bytes2 = loaded.bytes || getState().entries[srcPath] && entryBytes(getState().entries[srcPath]);
          const entries = await extractArchiveEntriesAsync(bytes2, srcPath, {
            archive_pass: requestArchivePass(req),
            innerPath: req.inner_path || "/"
          });
          for (const item of entries) {
            const relative = relativeArchivePath(item.entry.archive_path, req.inner_path);
            const outPath = joinPath(targetRoot, relative || item.entry.name);
            const body = bytesToBase64(item.bytes);
            if (dstMount) {
              const outMount = driverRuntime.resolve(getState().storages, outPath);
              if (!outMount || outMount.storage !== dstMount.storage) throw new Error("cross-storage archive decompress is not supported");
              await outMount.driver.put(outMount.storage, outMount.relPath, body, mimeType(item.entry.name), {
                bodyEncoding: "base64",
                overwrite: !!req.overwrite,
                size: item.bytes.byteLength
              });
            } else {
              if (!req.overwrite && getState().entries[outPath]) throw new Error(`file [${basename(outPath)}] exists`);
              createFile2(outPath, body, mimeType(item.entry.name), {
                bodyEncoding: "base64",
                size: item.bytes.byteLength
              });
            }
          }
          tasks.push(await taskStore.addTask(dstMount ? "decompress_upload" : "decompress", {
            creator,
            name: `decompress ${srcPath} to ${targetRoot}`,
            status: "completed",
            totalBytes: entries.reduce((sum, item) => sum + Number(item.bytes.byteLength || 0), 0)
          }));
        }
        await saveState2();
        return jsonResponse(success({ task: tasks }));
      } catch (error) {
        const message = (error == null ? void 0 : error.message) || "archive decompress failed";
        const status = /encrypted archive entry|wrong archive password|not implemented/i.test(message) ? 501 : 500;
        const task = await taskStore.addTask("decompress", {
          creator,
          error: message,
          name: srcPaths.join(", "),
          status: "failed"
        });
        return jsonResponse(failure(message, status, { task }), status);
      }
    }
  });
  const createArchiveDownloadResponse = ({ client, driverRuntime, getState }) => async ({ archivePath, download, innerPath, pass }) => {
    var _a2;
    const path = normalizePath(archivePath || "/");
    if (!canReadArchive(path)) return textResponse("archive download is not implemented in the SiYuan kernel port yet", 501);
    const entry = getState().entries[path];
    let bytes2 = null;
    let reader = null;
    let archive = null;
    if (entry && !entry.is_dir) {
      bytes2 = entryBytes(entry);
    } else {
      const mount = driverRuntime == null ? void 0 : driverRuntime.resolve(getState().storages, path);
      let lastError = "";
      if ((_a2 = mount == null ? void 0 : mount.driver) == null ? void 0 : _a2.read) {
        try {
          const readData = await mount.driver.read(mount.storage, mount.relPath, {});
          ({ bytes: bytes2 = null, reader = null, archive = null } = await archiveSourceFromDriverRead(client, path, readData));
        } catch (error) {
          lastError = (error == null ? void 0 : error.message) || String(error);
          bytes2 = null;
          reader = null;
          archive = null;
        }
      }
      if (!bytes2 && !reader && mount) return textResponse(lastError || "archive download for mounted driver files is not implemented in the SiYuan kernel port yet", 501);
    }
    if (!bytes2 && !reader) return textResponse("object not found", 404);
    try {
      const extracted = reader ? await extractZipArchiveEntryReaderAsync(reader, innerPath || "/", { archive, pass }) : await extractArchiveEntryAsync(bytes2, path, innerPath || "/", { pass });
      return rawResponse(
        extracted.bytes,
        200,
        mimeType(extracted.entry.name),
        download ? {
          "Content-Disposition": [`attachment; filename="${encodeURIComponent(extracted.entry.name)}"`]
        } : {}
      );
    } catch (error) {
      const message = (error == null ? void 0 : error.message) || "archive download is not implemented in the SiYuan kernel port yet";
      const status = /not found/.test(message) ? 404 : 501;
      return textResponse(message, status);
    }
  };
  const STATUS = {
    DONE: "done",
    PARTIAL: "partial",
    PLACEHOLDER: "placeholder",
    UNSUPPORTED: "unsupported"
  };
  const CAPABILITY_ITEMS = [
    { key: "openlist.http-api", status: STATUS.DONE, area: "base", summary: "OpenList-style route table and response envelope." },
    { key: "openlist.fs", status: STATUS.DONE, area: "fs", summary: "List/get/link/upload/manage routes are wired for virtual FS and runtime mounts." },
    { key: "openlist.admin", status: STATUS.DONE, area: "admin", summary: "Settings, users, storages, metas, messages, scan, config import/export, and driver metadata routes are available." },
    { key: "openlist.public", status: STATUS.DONE, area: "public", summary: "Public discovery routes expose routes, settings, archive extensions, and capability metadata." },
    { key: "openlist.share", status: STATUS.DONE, area: "share", summary: "OpenList-style share management and private-route share reads/downloads are available." },
    { key: "openlist.share.multi-file", status: STATUS.DONE, area: "share", summary: "Share roots can contain multiple files and directories." },
    { key: "openlist.webdav", status: STATUS.PARTIAL, area: "protocol", summary: "WebDAV read/write surface is available; full lock/etag/condition compatibility is still pending.", next: "Align WebDAV conditional headers, lock persistence, and edge-client behavior." },
    { key: "openlist.s3", status: STATUS.PARTIAL, area: "protocol", summary: "S3 bucket/object/multipart surface and SigV4 checks are available; full S3 semantics are still pending.", next: "Align metadata, multipart completion details, ranges, and delete-marker behavior." },
    { key: "openlist.search.local-index", status: STATUS.PARTIAL, area: "search", summary: "Local persisted search_nodes index, OpenList-style search route, optional async index task mode, and stop cancellation are available.", next: "Add auto incremental update hooks and keep full OpenList search backend matrix as a later migration." },
    { key: "openlist.task", status: STATUS.PARTIAL, area: "task", summary: "Task routes, TaskInfo shapes, lightweight persisted records, and a single-worker queue base are available.", next: "Wire heavy operations into the queue and add retry scheduling plus group coordinators." },
    { key: "openlist.task.manager-shape", status: STATUS.DONE, area: "task", summary: "done/undone/info/cancel/delete/retry/batch/clear response shapes match the ported OpenList handlers." },
    { key: "openlist.security.request-context", status: STATUS.PARTIAL, area: "security", summary: "JWT request context, PwdHash/Salt password storage, logout token invalidation, and permission checks cover major FS/share/task/protocol/archive/torrent/search entrances.", next: "Port real 2FA/WebAuthn/SSO/LDAP challenge flows and broader secret migration/desensitization." },
    { key: "openlist.fs.torrent.parse", status: STATUS.DONE, area: "torrent", summary: "Torrent parse and upload_parse use a JS bencode reader." },
    { key: "openlist.fs.torrent.generate", status: STATUS.DONE, area: "torrent", summary: "Single-file torrent generation is available for readable virtual/workspace/mounted files." },
    { key: "openlist.fs.torrent.rapid-upload.driver-boundary", status: STATUS.PARTIAL, area: "torrent", summary: "Rapid upload validates CAS torrents and delegates to driver methods when present.", next: "Port real 189/189PC rapidUploadFromTorrent implementations." },
    { key: "openlist.fs.offline-download", status: STATUS.PLACEHOLDER, area: "offline", summary: "add_offline_download keeps OpenList request/response shape but no real tool runner is ported.", next: "Port aria2/qbit/transmission/SimpleHttp/ed2k behind the task manager." },
    { key: "openlist.fs.archive.zip-list", status: STATUS.DONE, area: "archive", summary: "ZIP meta/list supports virtual files and mounted range readers." },
    { key: "openlist.fs.archive.zip-extract-stored", status: STATUS.DONE, area: "archive", summary: "ZIP stored entries can be extracted." },
    { key: "openlist.fs.archive.zip-extract-deflate", status: STATUS.DONE, area: "archive", summary: "ZIP deflate entries can be extracted." },
    { key: "openlist.fs.archive.zip-encrypted-detect", status: STATUS.DONE, area: "archive", summary: "Encrypted ZIP entries are detected and fail with an explicit 501 boundary." },
    { key: "openlist.fs.archive.zip-decrypt", status: STATUS.UNSUPPORTED, area: "archive", summary: "Encrypted ZIP decryption is not implemented." },
    { key: "openlist.fs.archive.zip-decompress-virtual", status: STATUS.DONE, area: "archive", summary: "ZIP entries can decompress into virtual FS targets." },
    { key: "openlist.fs.archive.decompress-upload-mounted", status: STATUS.PARTIAL, area: "archive", summary: "Archive decompress can upload into mounted targets with put() support.", next: "Move decompress into a cancellable task with progress and overwrite policy." },
    { key: "openlist.fs.archive.tar-list", status: STATUS.DONE, area: "archive", summary: "tar meta/list is available." },
    { key: "openlist.fs.archive.tar-extract", status: STATUS.DONE, area: "archive", summary: "tar entry extract is available." },
    { key: "openlist.fs.archive.tgz-list", status: STATUS.DONE, area: "archive", summary: "tgz/tar.gz meta/list is available." },
    { key: "openlist.fs.archive.tgz-extract", status: STATUS.DONE, area: "archive", summary: "tgz/tar.gz entry extract is available." },
    { key: "openlist.fs.archive.rar-7z-iso", status: STATUS.PLACEHOLDER, area: "archive", summary: "RAR/7z/ISO are advertised only as unsupported archive tool placeholders.", next: "Choose reader, verify license/wasm packaging, and add smoke fixtures before enabling." },
    { key: "openlist.share.archive.zip-extract", status: STATUS.DONE, area: "archive", summary: "Shared ZIP entries can be extracted through /sad after share checks." },
    { key: "openlist.share.archive.meta-list", status: STATUS.DONE, area: "archive", summary: "Share archive meta/list supports OpenList /@s split paths." },
    { key: "openlist.fs.archive.driver-paths", status: STATUS.DONE, area: "archive", summary: "/ad and /ap archive path extraction routes are available." },
    { key: "openlist.fs.archive.entry-range", status: STATUS.PLACEHOLDER, area: "archive", summary: "Archive entry extraction is not a seekable media Range proxy yet.", next: "Implement archive entry Range responses before treating archive videos like normal /p playback." }
  ];
  const CAPABILITIES = CAPABILITY_ITEMS.filter((item) => item.status !== STATUS.UNSUPPORTED).map((item) => item.key);
  const METHOD_NAMES = [
    "list",
    "get",
    "link",
    "read",
    "mkdir",
    "rename",
    "move",
    "copy",
    "remove",
    "put",
    "direct_upload",
    "other",
    "details",
    "rapid_upload",
    "torrent",
    "offline"
  ];
  const methodRow = (methods, note = "") => ({
    methods: Object.fromEntries(METHOD_NAMES.map((name) => [name, methods[name] || STATUS.UNSUPPORTED])),
    note
  });
  const baseManage = {
    list: STATUS.DONE,
    get: STATUS.DONE,
    link: STATUS.DONE,
    read: STATUS.DONE,
    mkdir: STATUS.DONE,
    rename: STATUS.DONE,
    move: STATUS.DONE,
    copy: STATUS.DONE,
    remove: STATUS.DONE,
    put: STATUS.DONE
  };
  const DRIVER_CAPABILITIES = {
    SiYuanWorkspace: methodRow({ list: STATUS.DONE, get: STATUS.DONE, link: STATUS.DONE, read: STATUS.DONE, rename: STATUS.PARTIAL, remove: STATUS.PARTIAL }, "Workspace adapter is intentionally conservative; upload stays guarded."),
    Local: methodRow({ ...baseManage, link: STATUS.UNSUPPORTED, read: STATUS.DONE }, "Desktop frontend Electron runtime only; kernel HTTP does not proxy local disks."),
    WebDav: methodRow({ ...baseManage }, "Runtime WebDAV driver is available; protocol-server compatibility is tracked separately."),
    OpenList: methodRow({ ...baseManage, other: STATUS.DONE }, "Upstream OpenList/AList proxy driver."),
    AListV3: methodRow({ ...baseManage, other: STATUS.DONE }, "Upstream OpenList/AList proxy driver."),
    "AList V3": methodRow({ ...baseManage, other: STATUS.DONE }, "Alias for AListV3."),
    S3: methodRow({ ...baseManage, direct_upload: STATUS.DONE }, "S3/Doge runtime supports presigned direct upload info."),
    Doge: methodRow({ ...baseManage, direct_upload: STATUS.DONE }, "S3-compatible Doge runtime."),
    "115 Cloud": methodRow({ ...baseManage, put: STATUS.PLACEHOLDER, details: STATUS.DONE, offline: STATUS.PLACEHOLDER }, "Upload/offline remain blocked on 115 rapid/ECDH and OSS multipart work."),
    "115 Open": methodRow({ ...baseManage, put: STATUS.PLACEHOLDER, details: STATUS.DONE, offline: STATUS.PARTIAL }, "115 Open token/list/link/basic management/details are ported; upload remains blocked on OSS multipart work."),
    "115 Share": methodRow({ list: STATUS.DONE, get: STATUS.DONE, link: STATUS.DONE, read: STATUS.DONE, mkdir: STATUS.UNSUPPORTED, rename: STATUS.UNSUPPORTED, move: STATUS.UNSUPPORTED, copy: STATUS.UNSUPPORTED, remove: STATUS.UNSUPPORTED, put: STATUS.UNSUPPORTED }, "OpenList marks 115 Share management/upload methods as NotSupport."),
    "123Pan": methodRow({ ...baseManage, copy: STATUS.UNSUPPORTED }, "123Pan upload path is ported; copy is not exposed by the current runtime."),
    "189Cloud": methodRow({ ...baseManage, rapid_upload: STATUS.PLACEHOLDER, torrent: STATUS.PLACEHOLDER }, "Normal login/list/upload have smoke coverage; real-account SMS and large upload validation remain pending."),
    "189CloudPC": methodRow({ ...baseManage, put: STATUS.PLACEHOLDER, rapid_upload: STATUS.PLACEHOLDER, torrent: STATUS.PLACEHOLDER }, "PC QR login/session refresh, family-cloud ID refill, list/link/basic management are ported; upload/CAS/torrent remain placeholders."),
    "189CloudTV": methodRow({ ...baseManage, put: STATUS.PLACEHOLDER, rapid_upload: STATUS.PLACEHOLDER }, "TV QR login/session refresh, family-cloud ID refill, list/link/basic management are ported; upload remains a placeholder."),
    AliyundriveOpen: methodRow({ ...baseManage, other: STATUS.DONE }, "AliyundriveOpen includes video_preview other() and upload."),
    BaiduNetdisk: methodRow({ ...baseManage, move: STATUS.UNSUPPORTED, copy: STATUS.UNSUPPORTED }, "Baidu list/link/upload/basic management are ported; move/copy are not exposed by the current runtime."),
    Onedrive: methodRow({ ...baseManage, direct_upload: STATUS.DONE, details: STATUS.DONE }, "OneDrive small/big upload and direct upload info are ported."),
    OneDrive: methodRow({ ...baseManage, direct_upload: STATUS.DONE, details: STATUS.DONE }, "Alias for Onedrive."),
    Quark: methodRow({ ...baseManage, copy: STATUS.UNSUPPORTED, details: STATUS.DONE }, "Quark/UC upload, details, and basic management are ported; copy is not implemented upstream here."),
    UC: methodRow({ ...baseManage, copy: STATUS.UNSUPPORTED, details: STATUS.DONE }, "UC shares the Quark runtime boundary."),
    QuarkOpen: methodRow({ ...baseManage, copy: STATUS.UNSUPPORTED }, "QuarkOpen upload and basic management are ported; copy is not exposed."),
    QuarkTV: methodRow({ list: STATUS.DONE, get: STATUS.DONE, link: STATUS.DONE, read: STATUS.DONE, mkdir: STATUS.UNSUPPORTED, rename: STATUS.UNSUPPORTED, move: STATUS.UNSUPPORTED, copy: STATUS.UNSUPPORTED, remove: STATUS.UNSUPPORTED, put: STATUS.UNSUPPORTED }, "OpenList marks QuarkTV management/upload methods as NotImplement."),
    UCTV: methodRow({ list: STATUS.DONE, get: STATUS.DONE, link: STATUS.DONE, read: STATUS.DONE, mkdir: STATUS.UNSUPPORTED, rename: STATUS.UNSUPPORTED, move: STATUS.UNSUPPORTED, copy: STATUS.UNSUPPORTED, remove: STATUS.UNSUPPORTED, put: STATUS.UNSUPPORTED }, "OpenList marks UCTV management/upload methods as NotImplement."),
    WPS: methodRow({ ...baseManage, put: STATUS.PLACEHOLDER, details: STATUS.DONE }, "WPS login/list/link/basic management/details are ported; upload remains a structured placeholder.")
  };
  const capabilityMatrix = () => CAPABILITY_ITEMS.map((item) => ({ ...item }));
  const capabilitySummary = () => CAPABILITY_ITEMS.reduce((acc, item) => {
    acc[item.status] = (acc[item.status] || 0) + 1;
    return acc;
  }, {});
  const driverCapabilityMatrix = () => Object.fromEntries(driverNames().map((name) => {
    const row = DRIVER_CAPABILITIES[name] || methodRow({}, "Driver is exposed without a completed method matrix.");
    return [name, { ...row, methods: { ...row.methods } }];
  }));
  const ENDPOINTS = {
    api: "/plugin/private/siyuan-cloud/api",
    download: "/plugin/private/siyuan-cloud/d/{path}",
    proxy: "/plugin/private/siyuan-cloud/p/{path}",
    webdav: "/plugin/private/siyuan-cloud/dav",
    s3: "/plugin/private/siyuan-cloud/s3",
    share_download: "/plugin/private/siyuan-cloud/sd/{id}/{path}",
    archive_extract: "/plugin/private/siyuan-cloud/ae/{archive_path}?inner={entry_path}"
  };
  const createPublicHandlers = ({
    getState,
    handlersRef,
    settingItem
  }) => {
    const publicSettings = () => {
      const result = {};
      for (const [key, value] of Object.entries(getState().settings)) {
        const item = settingItem(key, value, 0);
        if (item.flag !== SETTING_FLAG.PRIVATE) result[key] = item.value;
      }
      result.version = OPENLIST_VERSION;
      return result;
    };
    const routeEntries = () => Object.keys(handlersRef ? handlersRef() : {}).sort().map((route) => {
      const [method, ...pathParts] = route.split(" ");
      return { method, path: pathParts.join(" ") };
    });
    const apiIndex = () => ({
      name: "Siyuan Cloud",
      upstream: "OpenList",
      version: OPENLIST_VERSION,
      base_url: "/plugin/private/siyuan-cloud",
      api_base: "/plugin/private/siyuan-cloud/api",
      envelope: { code: 200, message: "success", data: null },
      endpoints: ENDPOINTS,
      capabilities: CAPABILITIES,
      capability_summary: capabilitySummary(),
      capability_matrix: capabilityMatrix(),
      driver_capabilities: driverCapabilityMatrix(),
      routes: routeEntries()
    });
    return {
      "ANY /api/public/api": async () => jsonResponse(success(apiIndex())),
      "ANY /api/public/routes": async () => jsonResponse(success(apiIndex())),
      "ANY /api/public/settings": async () => jsonResponse(success(publicSettings())),
      "ANY /api/public/offline_download_tools": async () => jsonResponse(success([])),
      "ANY /api/public/archive_extensions": async () => jsonResponse(success(acceptedArchiveExtensions()))
    };
  };
  const ADAPTERS = [
    "siyuan-storage",
    "siyuan-workspace",
    "openlist",
    "alist_v3",
    "webdav",
    "s3",
    "115_cloud",
    "onedrive",
    "123pan",
    "baidu_netdisk",
    "aliyundrive_open",
    "189cloud",
    "189cloud_pc",
    "189cloud_tv",
    "quark",
    "uc",
    "quark_open",
    "quark_tv",
    "uc_tv",
    "wps"
  ];
  const STAGES = [
    ["kernel", "done"],
    ["auth", "done"],
    ["fs", "done"],
    ["search-index", "active"],
    ["torrent", "active"],
    ["archive", "active"],
    ["streaming-proxy", "done"],
    ["admin", "done"],
    ["meta", "done"],
    ["security", "active"],
    ["share", "done"],
    ["task", "active"],
    ["real-adapter", "active"],
    ["webdav", "active"],
    ["s3", "active"]
  ];
  const getSyncInfo = async (client) => {
    let syncignore = "";
    try {
      const response = await client.fetch("/api/file/getFile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ path: ".siyuan/syncignore" })
      });
      if (response.ok) syncignore = await response.text();
    } catch (_) {
      syncignore = "";
    }
    const lines = syncignore.replace(/\r\n/g, "\n").split("\n").map((line) => line.trim()).filter((line) => line && !line.startsWith("#"));
    const storageBase = "/storage/petal/siyuan-cloud";
    const configPath = `${storageBase}/${CONFIG_FILE}`;
    const runtimePath = `${storageBase}/${RUNTIME_FILE}`;
    const searchIndexPath = `${storageBase}/${SEARCH_INDEX_FILE}`;
    const ignored = lines.some((line) => line === "/storage/petal/**/*" || line === "/storage/petal/**" || line === "/storage/petal/siyuan-cloud/**/*" || line === "/storage/petal/siyuan-cloud/**" || line === configPath || line === runtimePath || line === searchIndexPath);
    return {
      persistent: true,
      syncable_by_default: true,
      ignored_by_syncignore: ignored,
      state_file: configPath,
      config_file: configPath,
      runtime_file: runtimePath,
      search_index_file: searchIndexPath,
      source: "kernel/plugin/plugin.go + kernel/model/repository.go + kernel/model/sync.go"
    };
  };
  const createStatusPayload = async ({
    client,
    getState,
    handlersRef
  }) => {
    const state = getState();
    const handlers = handlersRef();
    return {
      ok: true,
      version: OPENLIST_VERSION,
      users: state.users.length,
      entries: Object.keys(state.entries).length,
      storages: state.storages.length,
      sharings: state.sharings.length,
      adapters: [...ADAPTERS],
      storage: await getSyncInfo(client),
      routes: Object.keys(handlers).sort(),
      stages: STAGES.map(([key, status]) => ({ key, status })),
      capability_summary: capabilitySummary(),
      driver_capabilities: driverCapabilityMatrix()
    };
  };
  const createStatusHandlers = ({
    client,
    getState,
    handlersRef
  }) => {
    return {
      "GET /ping": async () => textResponse("pong"),
      "ANY /ping": async () => textResponse("pong"),
      "GET /siyuan-cloud/status": async () => jsonResponse(success(await createStatusPayload({ client, getState, handlersRef })))
    };
  };
  const ORIGIN_IGNORE_HEADERS = /* @__PURE__ */ new Set([
    "authorization",
    "cookie",
    "connection",
    "host",
    "proxy-authorization",
    "proxy-connection",
    "referer",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade"
  ]);
  const HOP_BY_HOP_HEADERS = /* @__PURE__ */ new Set([
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "proxy-connection",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade"
  ]);
  const connectionHeaders = (headers = {}) => {
    const result = /* @__PURE__ */ new Set();
    for (const [key, value] of Object.entries(headers || {})) {
      if (String(key).toLowerCase() !== "connection") continue;
      const values = Array.isArray(value) ? value : [value];
      for (const item of values) {
        for (const part of String(item || "").split(",")) {
          const name = part.trim().toLowerCase();
          if (name) result.add(name);
        }
      }
    }
    return result;
  };
  const headerValues = (value) => Array.isArray(value) ? value.map(String) : [String(value)];
  const setHeader = (headers, key, value) => {
    const lower = String(key).toLowerCase();
    for (const existing of Object.keys(headers)) {
      if (existing.toLowerCase() === lower) delete headers[existing];
    }
    headers[key] = headerValues(value);
  };
  const processHeader = (origin = {}, override = {}) => {
    const result = {};
    const originConnectionHeaders = connectionHeaders(origin);
    for (const [key, value] of Object.entries(origin || {})) {
      const lower = String(key).toLowerCase();
      if (ORIGIN_IGNORE_HEADERS.has(lower) || originConnectionHeaders.has(lower)) continue;
      setHeader(result, key, value);
    }
    const overrideConnectionHeaders = connectionHeaders(override);
    for (const [key, value] of Object.entries(override || {})) {
      if (value === void 0 || value === null || value === "") continue;
      const lower = String(key).toLowerCase();
      if (HOP_BY_HOP_HEADERS.has(lower) || overrideConnectionHeaders.has(lower)) continue;
      setHeader(result, key, value);
    }
    return result;
  };
  const requestHeader = (request2) => {
    const requestMeta = (request2 == null ? void 0 : request2.request) || (request2 == null ? void 0 : request2.Request) || {};
    return requestMeta.headers || requestMeta.Headers || {};
  };
  const proxy = (_ctx, link2, file, _proxyRange) => {
    return proxyResponse(link2.url, processHeader((file == null ? void 0 : file.request_header) || {}, link2.header), link2.method || "GET");
  };
  const proxyReadOptions = (request2) => {
    var _a2;
    const headers = requestHeader(request2);
    const userAgent = (_a2 = Object.entries(headers || {}).find(([key]) => String(key).toLowerCase() === "user-agent")) == null ? void 0 : _a2[1];
    return {
      headers: {},
      proxyHeaders: {},
      requestHeaders: headers,
      userAgent: Array.isArray(userAgent) ? String(userAgent[0] || "") : String(userAgent || "")
    };
  };
  const shouldProxy = (storage, config = {}, filename = "") => {
    if (config.only_proxy || config.no_link_url || config.prefer_proxy || (storage == null ? void 0 : storage.web_proxy)) return true;
    const ext = String(basename(filename || "")).split(".").pop().toLowerCase();
    return ["m3u8", "url"].includes(ext);
  };
  const privateBase = "/plugin/private/siyuan-cloud";
  const escapeHtml = (value) => String(value || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const htmlResponse = (html) => rawResponse(html, 200, "text/html; charset=utf-8");
  const shareText = (request2) => {
    const meta = (request2 == null ? void 0 : request2.request) || (request2 == null ? void 0 : request2.Request) || {};
    const headers = meta.headers || meta.Headers || {};
    const zh = String(headers["accept-language"] || headers["Accept-Language"] || "").toLowerCase().includes("zh");
    const keys = "download notFound notFoundMessage open password passwordTitle retry tryAgain verified wrongPassword".split(" ");
    const values = zh ? ["下载", "分享不存在", "分享不存在或不可用。", "打开", "密码", "请输入分享密码", "重试", "密码错误，请重试。", "已验证", "密码错误"] : ["Download", "Share not found", "The share does not exist or is unavailable.", "Open", "Password", "Share password", "Retry", "Password is incorrect. Please try again.", "Access verified", "Password is incorrect"];
    return Object.fromEntries(keys.map((key, index) => [key, values[index]]));
  };
  const shareShell = (body) => htmlResponse(`<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Siyuan Cloud Share</title>
  <style>
    body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f6f6f7;color:#202124;font:14px/1.5 system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
    main{width:min(760px,calc(100vw - 32px));display:grid;gap:12px}
    h1{margin:0;font-size:18px;font-weight:600}
    form{display:grid;gap:10px}
    input{height:36px;padding:0 10px;border:1px solid #d0d0d0;border-radius:6px;background:#fff;font:inherit}
    a,button{height:36px;display:inline-grid;place-items:center;padding:0 14px;border:0;border-radius:6px;background:#3575f0;color:#fff;font:inherit;text-decoration:none;cursor:pointer}
    p{margin:0;color:#5f6368}
    .error{color:#d23f31}
  </style>
</head>
<body><main>${body}</main></body>
</html>`);
  const sharePasswordPage = ({ action, message, text: text2, title }) => shareShell(`<h1>${escapeHtml(title || text2.passwordTitle)}</h1>
  ${message ? `<p class="error" role="alert">${escapeHtml(message)}</p>` : ""}
  <form method="get" action="${escapeHtml(privateBase + action)}" onsubmit="document.querySelector('.error')?.remove()">
    <input name="pwd" type="password" autofocus autocomplete="current-password" placeholder="${escapeHtml(text2.password)}">
    <button type="submit">${message ? escapeHtml(text2.retry) : escapeHtml(text2.open)}</button>
  </form>`);
  const sharePreviewPage = ({ info, path, pwd, text: text2 }) => {
    const name = basename(info.targetPath) || basename(path) || info.normalizedShare.id;
    const query = `download=1${pwd ? `&pwd=${encodeURIComponent(pwd)}` : ""}`;
    const url = `${privateBase}${path}?${query}`;
    return shareShell(`<h1>${escapeHtml(name)}</h1><p>${escapeHtml(text2.verified)}</p><a href="${escapeHtml(url)}">${escapeHtml(text2.download)}</a>`);
  };
  const createRouter = ({
    archiveDownloadResponse,
    getState,
    handleWebDav,
    handleS3,
    handlers,
    isWorkspacePath,
    pick,
    queryValue,
    readFileResponse: externalReadFileResponse,
    requestPath,
    saveState: saveState2,
    warn,
    workspaceReadText
  }) => {
    const sharePasswordAction = (path, request2, keys = []) => {
      const params = new URLSearchParams();
      for (const key of keys) {
        const value = queryValue(request2, key);
        if (value) params.set(key, value);
      }
      const query = params.toString();
      return query ? `${path}?${query}` : path;
    };
    const fallbackReadFileResponse = async (filePath) => {
      const state = getState();
      if (isWorkspacePath(filePath)) {
        const file = await workspaceReadText(filePath);
        if (!file.ok) return textResponse(file.text || "not found", file.status || 404);
        return textResponse(file.text, 200, file.contentType);
      }
      const entry = state.entries[filePath];
      if (!entry || entry.is_dir) return textResponse("not found", 404);
      return textResponse(entry.content || "", 200, entry.mime || "application/octet-stream");
    };
    const readFileResponse = externalReadFileResponse || fallbackReadFileResponse;
    const dispatch = async (request2) => {
      const requestMeta = pick(request2, "request", "Request");
      const method = String(pick(requestMeta, "method", "Method") || "GET").toUpperCase();
      const path = requestPath(request2);
      const key = method + " " + path;
      const anyKey = "ANY " + path;
      const handler = handlers[key] || handlers[anyKey];
      if (handler) return handler(request2);
      if (path === "/" || path === "/@manage") {
        return jsonResponse(success({
          name: "Siyuan Cloud",
          version: OPENLIST_VERSION,
          message: "OpenList compatibility layer is running.",
          private_base: privateBase,
          routes: Object.keys(handlers).sort()
        }));
      }
      if (path === "/dav" || path.startsWith("/dav/")) {
        return handleWebDav(request2);
      }
      if (path === "/s3" || path.startsWith("/s3/")) {
        return handleS3(request2);
      }
      if (path.startsWith("/sd/")) {
        const sharePath = normalizePath(path.replace(/^\/sd/, ""));
        const pwd = queryValue(request2, "pwd");
        const state = getState();
        const info = sharePathInfo({ path: sharePath, password: pwd, state });
        const needsPassword = shareNeedsPassword({ path: sharePath, password: pwd, state });
        const text2 = shareText(request2);
        const passwordAction = sharePasswordAction(path, request2, ["download"]);
        if (!info && needsPassword) return sharePasswordPage({ action: passwordAction, message: pwd ? text2.tryAgain : "", text: text2 });
        if (!info) return sharePasswordPage({ action: passwordAction, message: text2.notFoundMessage, text: text2, title: text2.notFound });
        await countShareAccess({ info, ip: shareClientIP(request2), saveState: saveState2 });
        return queryValue(request2, "download") ? readFileResponse(info.targetPath, request2, { shareDownload: true }) : sharePreviewPage({ info, path, pwd, text: text2 });
      }
      if (path.startsWith("/d/") || path.startsWith("/p/")) {
        return readFileResponse(normalizePath(path.replace(/^\/[dp]/, "")), request2, { directDownload: path.startsWith("/d/") });
      }
      if (path === "/sad" || path.startsWith("/sad/")) {
        const sharePath = normalizePath(path.replace(/^\/sad/, ""));
        const pwd = queryValue(request2, "pwd");
        const state = getState();
        const info = sharePathInfo({ path: sharePath, password: pwd, state });
        const needsPassword = shareNeedsPassword({ path: sharePath, password: pwd, state });
        const text2 = shareText(request2);
        const passwordAction = sharePasswordAction(path, request2, ["download", "inner", "pass"]);
        if (!info && needsPassword) return sharePasswordPage({ action: passwordAction, message: pwd ? text2.tryAgain : "", text: text2 });
        if (!info) return sharePasswordPage({ action: passwordAction, message: text2.notFoundMessage, text: text2, title: text2.notFound });
        await countShareAccess({ info, ip: shareClientIP(request2), saveState: saveState2 });
        if (!archiveDownloadResponse) return textResponse("sharing archive extract is not implemented in the SiYuan kernel port yet", 501);
        return archiveDownloadResponse({
          archivePath: info.targetPath,
          download: queryValue(request2, "download") === "1",
          innerPath: queryValue(request2, "inner"),
          pass: queryValue(request2, "pass")
        });
      }
      if ((path.startsWith("/ae/") || path.startsWith("/ad/") || path.startsWith("/ap/")) && archiveDownloadResponse) {
        const archivePath = normalizePath(path.replace(/^\/a[edp]/, ""));
        return archiveDownloadResponse({
          archivePath,
          download: queryValue(request2, "download") === "1",
          innerPath: queryValue(request2, "inner"),
          pass: queryValue(request2, "pass")
        });
      }
      return jsonResponse(failure("route not implemented: " + key, 404), 404);
    };
    return async (request2) => {
      try {
        return await dispatch(request2);
      } catch (error) {
        await warn("request failed", String(error && error.stack || error));
        return jsonResponse(failure(String(error && error.message || error), 500), 500);
      }
    };
  };
  const DEFAULT_BUCKET = "siyuan-cloud";
  const DEFAULT_REGION = "us-east-1";
  const hex = (bytes2) => Array.from(bytes2, (b) => b.toString(16).padStart(2, "0")).join("");
  const encodeRfc3986 = (value) => encodeURIComponent(value).replace(/[!'()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
  const escapeXml$1 = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const xmlResponse = (xml, statusCode = 200) => textResponse(xml, statusCode, "application/xml; charset=utf-8");
  const s3PathParts = (path) => {
    const clean = path.replace(/^\/s3\/?/, "").replace(/^\/+/, "");
    const [bucket, ...objectParts] = clean.split("/").filter(Boolean);
    return {
      bucket: bucket || "",
      object: objectParts.join("/")
    };
  };
  const requestBodyText = async (requestMeta) => {
    const body = requestMeta.body || requestMeta.Body || {};
    if (body.data !== void 0 && body.data !== null) {
      if (typeof body.data === "string") return body.data;
      if (typeof body.data.text === "function") return body.data.text();
      if (body.data instanceof ArrayBuffer) return String.fromCharCode(...new Uint8Array(body.data));
      if (typeof body.data === "object") return JSON.stringify(body.data);
    }
    if (body.string && Array.isArray(body.string.values)) return body.string.values.join("");
    return "";
  };
  const headerValue = (requestMeta, name) => {
    const headers = requestMeta.headers || requestMeta.Headers || {};
    const lower = name.toLowerCase();
    for (const [key, value] of Object.entries(headers)) {
      if (String(key).toLowerCase() !== lower) continue;
      if (Array.isArray(value)) return value[0] || "";
      return String(value || "");
    }
    return "";
  };
  const objectPath = (bucket, object) => normalizePath(`${normalizePath(bucket.path || "/")}/${String(object || "").replace(/^\/+/, "")}`);
  const parseBuckets = (settings = {}) => {
    try {
      const buckets = JSON.parse(settings.s3_buckets || "[]");
      if (Array.isArray(buckets) && buckets.length) {
        return buckets.filter((item) => item && item.name).map((item) => ({
          name: String(item.name),
          path: normalizePath(item.path || "/")
        }));
      }
    } catch (_) {
    }
    return [{ name: DEFAULT_BUCKET, path: "/" }];
  };
  const s3Credential = (settings = {}) => {
    const accessKeyId = String(settings.s3_access_key_id || "");
    const secretAccessKey = String(settings.s3_secret_access_key || "");
    if (!accessKeyId && !secretAccessKey) return null;
    return { accessKeyId, secretAccessKey };
  };
  const parseAuthParams = (authorization) => {
    const match = String(authorization || "").match(/^AWS4-HMAC-SHA256\s+(.+)$/);
    if (!match) return null;
    const result = {};
    for (const part of match[1].split(",")) {
      const [key, ...rest] = part.trim().split("=");
      if (key) result[key] = rest.join("=");
    }
    return result.Credential && result.SignedHeaders && result.Signature ? result : null;
  };
  const canonicalQuery = (params, skipSignature = false) => [...params.entries()].filter(([key]) => !(skipSignature && key === "X-Amz-Signature")).sort(([a, av], [b, bv]) => a === b ? av.localeCompare(bv) : a.localeCompare(b)).map(([key, value]) => `${encodeRfc3986(key)}=${encodeRfc3986(value)}`).join("&");
  const signedHeaderValue = (requestMeta, name) => {
    if (name === "host") return headerValue(requestMeta, "Host") || "localhost";
    if (name === "x-amz-content-sha256") return headerValue(requestMeta, name);
    return headerValue(requestMeta, name);
  };
  const signingKey = (secretAccessKey, date, region, service) => {
    const kDate = hmacSha256(`AWS4${secretAccessKey}`, date);
    const kRegion = hmacSha256(kDate, region || DEFAULT_REGION);
    const kService = hmacSha256(kRegion, service || "s3");
    return hmacSha256(kService, "aws4_request");
  };
  const expectedSignature = ({ bodyText, credential, dateTime, method, params, path, payloadHash, requestMeta, secretAccessKey, signedHeaders, skipQuerySignature = false }) => {
    const headers = signedHeaders.split(";").filter(Boolean).map((item) => item.toLowerCase()).sort();
    const canonicalHeaders = headers.map((name) => `${name}:${String(signedHeaderValue(requestMeta, name) || "").trim()}
`).join("");
    const canonicalRequest = [
      method,
      path || "/",
      canonicalQuery(params, skipQuerySignature),
      canonicalHeaders,
      headers.join(";"),
      payloadHash || sha256Hex(bodyText || "")
    ].join("\n");
    const [, date, region, service, terminal] = credential.split("/");
    if (!date || terminal !== "aws4_request") return "";
    const scope = `${date}/${region || DEFAULT_REGION}/${service || "s3"}/aws4_request`;
    const stringToSign = [
      "AWS4-HMAC-SHA256",
      dateTime,
      scope,
      sha256Hex(canonicalRequest)
    ].join("\n");
    return hex(hmacSha256(signingKey(secretAccessKey, date, region, service), stringToSign));
  };
  const listBucketsXml = (buckets) => xmlResponse([
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<ListAllMyBucketsResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
    `<Owner><ID>siyuan-cloud</ID><DisplayName>Siyuan Cloud</DisplayName></Owner>`,
    `<Buckets>`,
    ...buckets.map((bucket) => `<Bucket><Name>${escapeXml$1(bucket.name)}</Name><CreationDate>${(/* @__PURE__ */ new Date()).toISOString()}</CreationDate></Bucket>`),
    `</Buckets>`,
    `</ListAllMyBucketsResult>`
  ].join(""));
  const errorXml = (code, message, statusCode) => xmlResponse([
    `<?xml version="1.0" encoding="UTF-8"?>`,
    `<Error><Code>${escapeXml$1(code)}</Code><Message>${escapeXml$1(message)}</Message></Error>`
  ].join(""), statusCode);
  const createS3Server = ({
    cloneEntryTree,
    createFile: createFile2,
    currentUser,
    ensureDir,
    getState,
    removeEntry,
    requestPath,
    saveState: saveState2
  }) => {
    const authHeader = (requestMeta) => headerValue(requestMeta, "Authorization");
    const shouldApplyUserPermission = (requestMeta) => authHeader(requestMeta).startsWith("siyuan-cloud-port:");
    const bucketByName = (name) => parseBuckets(getState().settings || {}).find((item) => item.name === name);
    const verifyS3Auth = async (requestMeta, method, path, params) => {
      const credential = s3Credential(getState().settings || {});
      if (!credential || shouldApplyUserPermission(requestMeta)) return null;
      const bodyText = await requestBodyText(requestMeta);
      const queryCredential = params.get("X-Amz-Credential");
      if (params.get("X-Amz-Algorithm") === "AWS4-HMAC-SHA256" && queryCredential) {
        const accessKeyId2 = queryCredential.split("/")[0] || "";
        if (accessKeyId2 !== credential.accessKeyId) return errorXml("InvalidAccessKeyId", "invalid access key id", 403);
        const signature3 = expectedSignature({
          bodyText,
          credential: queryCredential,
          dateTime: params.get("X-Amz-Date") || "",
          method,
          params,
          path,
          payloadHash: params.get("X-Amz-Content-Sha256") || "UNSIGNED-PAYLOAD",
          requestMeta,
          secretAccessKey: credential.secretAccessKey,
          signedHeaders: params.get("X-Amz-SignedHeaders") || "host",
          skipQuerySignature: true
        });
        return signature3 && signature3 === params.get("X-Amz-Signature") ? null : errorXml("SignatureDoesNotMatch", "signature does not match", 403);
      }
      const auth = parseAuthParams(authHeader(requestMeta));
      if (!auth) return errorXml("AccessDenied", "access denied", 403);
      const accessKeyId = auth.Credential.split("/")[0] || "";
      if (accessKeyId !== credential.accessKeyId) return errorXml("InvalidAccessKeyId", "invalid access key id", 403);
      const payloadHeader = headerValue(requestMeta, "x-amz-content-sha256");
      const signature2 = expectedSignature({
        bodyText,
        credential: auth.Credential,
        dateTime: headerValue(requestMeta, "x-amz-date"),
        method,
        params,
        path,
        payloadHash: payloadHeader === "UNSIGNED-PAYLOAD" ? "UNSIGNED-PAYLOAD" : payloadHeader || sha256Hex(bodyText || ""),
        requestMeta,
        secretAccessKey: credential.secretAccessKey,
        signedHeaders: auth.SignedHeaders
      });
      return signature2 && signature2 === auth.Signature ? null : errorXml("SignatureDoesNotMatch", "signature does not match", 403);
    };
    const isWriteMethod = (method, params) => ["PUT", "DELETE"].includes(method) || method === "POST" && (params.has("delete") || params.has("uploads") || params.has("uploadId"));
    const listBucketXml = (bucket, options) => {
      const state = getState();
      const normalizedPrefix = String(options.prefix || "").replace(/^\/+/, "");
      const delimiter = options.delimiter || "";
      const maxKeys = Math.max(1, Number(options.maxKeys));
      const allObjects = Object.values(state.entries).filter((entry) => entry.path !== "/" && !entry.is_dir).filter((entry) => bucket.path === "/" || entry.path === bucket.path || entry.path.startsWith(`${bucket.path}/`)).map((entry) => ({
        key: bucket.path === "/" ? entry.path.replace(/^\//, "") : entry.path.slice(bucket.path.length).replace(/^\/+/, ""),
        entry
      })).filter((item) => !normalizedPrefix || item.key.startsWith(normalizedPrefix)).sort((a, b) => a.key.localeCompare(b.key));
      const commonPrefixes = /* @__PURE__ */ new Set();
      const contents = [];
      for (const item of allObjects) {
        const rest = item.key.slice(normalizedPrefix.length);
        if (delimiter && rest.includes(delimiter)) {
          commonPrefixes.add(normalizedPrefix + rest.slice(0, rest.indexOf(delimiter) + delimiter.length));
          continue;
        }
        contents.push(item);
      }
      const contentXml = contents.slice(0, maxKeys).map(({ key, entry }) => [
        `<Contents>`,
        `<Key>${escapeXml$1(key)}</Key>`,
        `<LastModified>${escapeXml$1(entry.modified || (/* @__PURE__ */ new Date()).toISOString())}</LastModified>`,
        `<ETag>"${escapeXml$1(String(entry.size || 0))}"</ETag>`,
        `<Size>${Number(entry.size || 0)}</Size>`,
        `<StorageClass>STANDARD</StorageClass>`,
        `</Contents>`
      ].join("")).join("");
      const prefixXml = [...commonPrefixes].sort((a, b) => a.localeCompare(b)).slice(0, maxKeys).map((prefix) => `<CommonPrefixes><Prefix>${escapeXml$1(prefix)}</Prefix></CommonPrefixes>`).join("");
      return xmlResponse([
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<ListBucketResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
        `<Name>${escapeXml$1(bucket)}</Name>`,
        `<Prefix>${escapeXml$1(normalizedPrefix)}</Prefix>`,
        `<Delimiter>${escapeXml$1(delimiter)}</Delimiter>`,
        `<Marker></Marker><MaxKeys>${maxKeys}</MaxKeys><IsTruncated>false</IsTruncated>`,
        contentXml,
        prefixXml,
        `</ListBucketResult>`
      ].join(""));
    };
    const objectResponse = (entry, headOnly = false) => {
      const response = textResponse(headOnly ? "" : entry.content || "", 200, entry.mime || "application/octet-stream");
      response.headers["Content-Length"] = [String(entry.size || 0)];
      response.headers.ETag = [`"${entry.size || 0}"`];
      response.headers["Last-Modified"] = [new Date(entry.modified || Date.now()).toUTCString()];
      return response;
    };
    const copySource = (requestMeta) => {
      const raw = decodeURIComponent(headerValue(requestMeta, "x-amz-copy-source").replace(/^\/+/, ""));
      if (!raw) return null;
      const [sourceBucketName, ...objectParts] = raw.split("/");
      const sourceBucket = bucketByName(sourceBucketName);
      if (!sourceBucket) return null;
      return objectPath(sourceBucket, objectParts.join("/"));
    };
    const copyResultXml = () => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<CopyObjectResult>`,
      `<LastModified>${(/* @__PURE__ */ new Date()).toISOString()}</LastModified>`,
      `<ETag>"0"</ETag>`,
      `</CopyObjectResult>`
    ].join(""));
    const multiDeleteXml = (objects) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<DeleteResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      ...objects.map((key) => `<Deleted><Key>${escapeXml$1(key)}</Key></Deleted>`),
      `</DeleteResult>`
    ].join(""));
    const parseDeleteObjects = async (requestMeta) => {
      const text2 = await requestBodyText(requestMeta);
      return [...text2.matchAll(/<Key>([^<]+)<\/Key>/g)].map((match) => match[1]);
    };
    const ensureMultipartState = () => {
      const state = getState();
      state.s3_multipart_uploads = state.s3_multipart_uploads || {};
      return state.s3_multipart_uploads;
    };
    const initiateMultipartXml = (bucket, object, uploadId) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<InitiateMultipartUploadResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      `<Bucket>${escapeXml$1(bucket)}</Bucket><Key>${escapeXml$1(object)}</Key><UploadId>${escapeXml$1(uploadId)}</UploadId>`,
      `</InitiateMultipartUploadResult>`
    ].join(""));
    const completeMultipartXml = (bucket, object, entry) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<CompleteMultipartUploadResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      `<Location>/s3/${escapeXml$1(bucket)}/${escapeXml$1(object)}</Location>`,
      `<Bucket>${escapeXml$1(bucket)}</Bucket><Key>${escapeXml$1(object)}</Key><ETag>"${escapeXml$1(String((entry == null ? void 0 : entry.size) || 0))}"</ETag>`,
      `</CompleteMultipartUploadResult>`
    ].join(""));
    const listMultipartXml = (bucket, object, uploadId, upload) => xmlResponse([
      `<?xml version="1.0" encoding="UTF-8"?>`,
      `<ListPartsResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
      `<Bucket>${escapeXml$1(bucket)}</Bucket><Key>${escapeXml$1(object)}</Key><UploadId>${escapeXml$1(uploadId)}</UploadId>`,
      ...Object.entries((upload == null ? void 0 : upload.parts) || {}).sort(([a], [b]) => Number(a) - Number(b)).map(([partNumber, part]) => `<Part><PartNumber>${Number(partNumber)}</PartNumber><ETag>"${part.size}"</ETag><Size>${part.size}</Size></Part>`),
      `</ListPartsResult>`
    ].join(""));
    const listMultipartUploadsXml = (bucket, uploads, options = {}) => {
      const prefix = String(options.prefix || "").replace(/^\/+/, "");
      const uploadXml = Object.entries(uploads).filter(([, upload]) => upload.bucket === bucket && (!prefix || upload.object.startsWith(prefix))).sort(([, a], [, b]) => String(a.object).localeCompare(String(b.object))).map(([uploadId, upload]) => [
        `<Upload>`,
        `<Key>${escapeXml$1(upload.object)}</Key>`,
        `<UploadId>${escapeXml$1(uploadId)}</UploadId>`,
        `<Initiator><ID>siyuan-cloud</ID><DisplayName>Siyuan Cloud</DisplayName></Initiator>`,
        `<Owner><ID>siyuan-cloud</ID><DisplayName>Siyuan Cloud</DisplayName></Owner>`,
        `<StorageClass>STANDARD</StorageClass>`,
        `<Initiated>${escapeXml$1(upload.started || (/* @__PURE__ */ new Date()).toISOString())}</Initiated>`,
        `</Upload>`
      ].join("")).join("");
      return xmlResponse([
        `<?xml version="1.0" encoding="UTF-8"?>`,
        `<ListMultipartUploadsResult xmlns="http://s3.amazonaws.com/doc/2006-03-01/">`,
        `<Bucket>${escapeXml$1(bucket)}</Bucket>`,
        `<KeyMarker></KeyMarker><UploadIdMarker></UploadIdMarker>`,
        `<NextKeyMarker></NextKeyMarker><NextUploadIdMarker></NextUploadIdMarker>`,
        `<Prefix>${escapeXml$1(prefix)}</Prefix><Delimiter></Delimiter>`,
        `<MaxUploads>1000</MaxUploads><IsTruncated>false</IsTruncated>`,
        uploadXml,
        `</ListMultipartUploadsResult>`
      ].join(""));
    };
    return async (request2) => {
      var _a2;
      const requestMeta = request2.request || request2.Request || {};
      const method = String(requestMeta.method || requestMeta.Method || "GET").toUpperCase();
      const path = requestPath(request2);
      const { bucket, object } = s3PathParts(path);
      const requestUrl2 = request2.url || request2.URL || {};
      const query = requestUrl2.query || requestUrl2.Query || "";
      const params = new URLSearchParams(query);
      const authError = await verifyS3Auth(requestMeta, method, path, params);
      if (authError) return authError;
      if (shouldApplyUserPermission(requestMeta)) {
        const user = currentUser == null ? void 0 : currentUser(request2);
        if (!canWebdavRead(user) || isWriteMethod(method, params) && !canWebdavManage(user)) {
          return errorXml("AccessDenied", "access denied", 403);
        }
      }
      if (method === "OPTIONS") {
        const response = textResponse("", 204);
        response.headers.Allow = ["OPTIONS, GET, HEAD, PUT, DELETE"];
        return response;
      }
      const buckets = parseBuckets(getState().settings || {});
      if (!bucket) {
        if (method === "GET" || method === "HEAD") return listBucketsXml(buckets);
        return errorXml("MethodNotAllowed", "method not allowed", 405);
      }
      const bucketInfo = buckets.find((item) => item.name === bucket);
      if (!bucketInfo) return errorXml("NoSuchBucket", "bucket does not exist", 404);
      if (!object) {
        if (method === "POST") {
          if (new URLSearchParams(query).has("delete")) {
            const objects = await parseDeleteObjects(requestMeta);
            for (const key of objects) removeEntry(objectPath(bucketInfo, key));
            await saveState2();
            return multiDeleteXml(objects);
          }
        }
        if (method === "GET" || method === "HEAD") {
          if (params.has("uploads")) {
            return listMultipartUploadsXml(bucket, ensureMultipartState(), {
              prefix: params.get("prefix") || ""
            });
          }
          return listBucketXml(bucketInfo, {
            delimiter: params.get("delimiter") || "",
            maxKeys: params.get("max-keys") || params.get("maxKeys") || 1e3,
            prefix: params.get("prefix") || ""
          });
        }
        if (method === "PUT") return textResponse("", 200);
        if (method === "DELETE") return textResponse("", 204);
        return errorXml("MethodNotAllowed", "method not allowed", 405);
      }
      const fsPath = objectPath(bucketInfo, object);
      const state = getState();
      const entry = state.entries[fsPath];
      if (method === "GET" || method === "HEAD") {
        if (params.has("uploadId")) {
          const uploadId = params.get("uploadId");
          const upload = ensureMultipartState()[uploadId];
          if (!upload) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
          return listMultipartXml(bucket, object, params.get("uploadId"), upload);
        }
        if (!entry || entry.is_dir) return errorXml("NoSuchKey", "object does not exist", 404);
        return objectResponse(entry, method === "HEAD");
      }
      if (method === "POST" && params.has("uploads")) {
        const uploadId = `upload-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
        ensureMultipartState()[uploadId] = { bucket, object, parts: {}, started: (/* @__PURE__ */ new Date()).toISOString() };
        await saveState2();
        return initiateMultipartXml(bucket, object, uploadId);
      }
      if (method === "POST" && params.has("uploadId")) {
        const uploadId = params.get("uploadId");
        const uploads = ensureMultipartState();
        const upload = uploads[uploadId];
        if (!upload) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
        const content = Object.entries(upload.parts || {}).sort(([a], [b]) => Number(a) - Number(b)).map(([, part]) => part.content || "").join("");
        ensureDir(dirname(fsPath));
        createFile2(fsPath, content, "application/octet-stream");
        delete uploads[uploadId];
        await saveState2();
        return completeMultipartXml(bucket, object, getState().entries[fsPath]);
      }
      if (method === "PUT") {
        if (params.has("uploadId") && params.has("partNumber")) {
          const upload = ensureMultipartState()[params.get("uploadId")];
          if (!upload) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
          const content = await requestBodyText(requestMeta);
          upload.parts[String(params.get("partNumber"))] = {
            content,
            size: content.length
          };
          await saveState2();
          const response2 = textResponse("", 200);
          response2.headers.ETag = [`"${content.length}"`];
          return response2;
        }
        const srcPath = copySource(requestMeta);
        if (srcPath) {
          if (!state.entries[srcPath]) return errorXml("NoSuchKey", "copy source does not exist", 404);
          ensureDir(dirname(fsPath));
          cloneEntryTree(srcPath, fsPath);
          await saveState2();
          return copyResultXml();
        }
        const isDir2 = object.endsWith("/");
        if (isDir2) {
          ensureDir(fsPath);
        } else {
          ensureDir(dirname(fsPath));
          createFile2(fsPath, await requestBodyText(requestMeta), headerValue(requestMeta, "Content-Type") || "application/octet-stream");
        }
        await saveState2();
        const response = textResponse("", 200);
        response.headers.ETag = [`"${((_a2 = getState().entries[fsPath]) == null ? void 0 : _a2.size) || 0}"`];
        return response;
      }
      if (method === "DELETE") {
        if (params.has("uploadId")) {
          const uploadId = params.get("uploadId");
          const uploads = ensureMultipartState();
          if (!uploads[uploadId]) return errorXml("NoSuchUpload", "multipart upload does not exist", 404);
          delete uploads[uploadId];
          await saveState2();
          return textResponse("", 204);
        }
        removeEntry(fsPath);
        await saveState2();
        return textResponse("", 204);
      }
      return errorXml("MethodNotAllowed", "method not allowed", 405);
    };
  };
  const escapeXml = (value) => String(value ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  const webdavPath = (path) => normalizePath(path.replace(/^\/dav\/?/, "/"));
  const propResponse = ({ href, item }) => {
    const collection = item.is_dir ? "<D:resourcetype><D:collection/></D:resourcetype>" : "<D:resourcetype/>";
    const length = item.is_dir ? "" : `<D:getcontentlength>${Number(item.size || 0)}</D:getcontentlength>`;
    return [
      "<D:response>",
      `<D:href>${escapeXml(href)}</D:href>`,
      "<D:propstat><D:prop>",
      `<D:displayname>${escapeXml(item.name || "")}</D:displayname>`,
      collection,
      length,
      `<D:getlastmodified>${escapeXml(new Date(item.modified || Date.now()).toUTCString())}</D:getlastmodified>`,
      "</D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat>",
      "</D:response>"
    ].join("");
  };
  const createWebDavServer = ({
    currentUser,
    getState,
    cloneEntryTree,
    createFile: createFile2,
    ensureDir,
    isWorkspacePath,
    moveEntryTree,
    readFileResponse,
    removeEntry,
    requestPath,
    saveState: saveState2,
    toObjResp,
    workspaceGet,
    workspaceList
  }) => {
    const listVirtual = (path) => {
      const state = getState();
      const entry = state.entries[path];
      if (!entry || !entry.is_dir) return null;
      const items = entry.children.map((childPath) => state.entries[childPath]).filter(Boolean);
      if (path === "/") {
        items.unshift({
          name: "@workspace",
          is_dir: true,
          size: 0,
          modified: (/* @__PURE__ */ new Date()).toISOString(),
          created: (/* @__PURE__ */ new Date()).toISOString()
        });
      }
      return { entry, items };
    };
    const getVirtual = (path) => {
      const state = getState();
      if (path === "/") {
        return { name: "", is_dir: true, size: 0, modified: (/* @__PURE__ */ new Date()).toISOString() };
      }
      return state.entries[path] || null;
    };
    const propfind2 = async (request2, path) => {
      var _a2, _b2;
      const fsPath = webdavPath(path);
      let current;
      let children = [];
      if (isWorkspacePath(fsPath)) {
        const got = await workspaceGet(fsPath);
        if (got.error) return textResponse("", got.error.code || 404);
        current = got.data;
        if (current.is_dir) {
          const listed = await workspaceList(fsPath, { page: 1, per_page: 1e5 });
          if (!listed.error) children = listed.data.content || [];
        }
      } else {
        current = getVirtual(fsPath);
        const listed = listVirtual(fsPath);
        if (listed) children = listed.items.map(toObjResp);
      }
      if (!current) return textResponse("", 404);
      const hrefBase = "/dav" + (fsPath === "/" ? "/" : fsPath);
      const responses2 = [propResponse({ href: hrefBase, item: current })];
      const depth = String(((_a2 = request2.headers) == null ? void 0 : _a2.depth) || ((_b2 = request2.headers) == null ? void 0 : _b2.Depth) || "1");
      if (current.is_dir && depth !== "0") {
        for (const child of children) {
          responses2.push(propResponse({
            href: normalizePath(hrefBase + "/" + child.name) + (child.is_dir ? "/" : ""),
            item: child
          }));
        }
      }
      return textResponse(`<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:">${responses2.join("")}</D:multistatus>`, 207, "application/xml; charset=utf-8");
    };
    const requestBodyText2 = async (requestMeta) => {
      const body = requestMeta.body || requestMeta.Body || {};
      if (body.data !== void 0 && body.data !== null) {
        if (typeof body.data === "string") return body.data;
        if (typeof body.data.text === "function") return body.data.text();
        if (body.data instanceof ArrayBuffer) return String.fromCharCode(...new Uint8Array(body.data));
        if (typeof body.data === "object") return JSON.stringify(body.data);
      }
      if (body.string && Array.isArray(body.string.values)) return body.string.values.join("");
      return "";
    };
    const headerValue2 = (requestMeta, name) => {
      const headers = requestMeta.headers || requestMeta.Headers || {};
      const lower = name.toLowerCase();
      for (const [key, value] of Object.entries(headers)) {
        if (String(key).toLowerCase() !== lower) continue;
        if (Array.isArray(value)) return value[0] || "";
        return String(value || "");
      }
      return "";
    };
    const destinationPath = (requestMeta) => {
      const raw = headerValue2(requestMeta, "Destination");
      if (!raw) return "";
      try {
        const parsed = new URL(raw);
        return webdavPath(parsed.pathname.replace(/^\/plugin\/private\/[^/]+/, ""));
      } catch (_) {
        return webdavPath(raw.replace(/^\/plugin\/private\/[^/]+/, ""));
      }
    };
    const rejectWorkspaceWrite = (fsPath) => {
      if (!isWorkspacePath(fsPath)) return null;
      return textResponse("WebDAV write operations for /@workspace are disabled until SiYuan upload/move support is proven", 501);
    };
    const lockToken = () => `opaquelocktoken:siyuan-cloud-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    const lockResponse = (token) => textResponse([
      `<?xml version="1.0" encoding="utf-8"?>`,
      `<D:prop xmlns:D="DAV:"><D:lockdiscovery><D:activelock>`,
      `<D:locktype><D:write/></D:locktype><D:lockscope><D:exclusive/></D:lockscope>`,
      `<D:depth>infinity</D:depth><D:timeout>Second-3600</D:timeout>`,
      `<D:locktoken><D:href>${escapeXml(token)}</D:href></D:locktoken>`,
      `</D:activelock></D:lockdiscovery></D:prop>`
    ].join(""), 200, "application/xml; charset=utf-8");
    return async (request2) => {
      const requestMeta = request2.request || request2.Request || {};
      const method = String(requestMeta.method || requestMeta.Method || "GET").toUpperCase();
      const path = requestPath(request2);
      const user = currentUser == null ? void 0 : currentUser(request2);
      if (method === "OPTIONS") {
        return {
          ...textResponse("", 204),
          headers: {
            Allow: ["OPTIONS, GET, HEAD, PROPFIND, MKCOL, PUT, DELETE, COPY, MOVE, LOCK, UNLOCK, PROPPATCH"],
            DAV: ["1, 2"]
          }
        };
      }
      if (!canWebdavRead(user)) return textResponse("Forbidden", 403);
      if (["PUT", "MKCOL", "MOVE", "COPY", "DELETE", "PROPPATCH"].includes(method) && !canWebdavManage(user)) {
        return textResponse("Forbidden", 403);
      }
      if (method === "PROPFIND") return propfind2(requestMeta, path);
      if (method === "GET" || method === "HEAD") return readFileResponse(webdavPath(path), request2);
      if (method === "MKCOL") {
        const fsPath = webdavPath(path);
        const rejected = rejectWorkspaceWrite(fsPath);
        if (rejected) return rejected;
        ensureDir(fsPath);
        await saveState2();
        return textResponse("", 201);
      }
      if (method === "PUT") {
        const fsPath = webdavPath(path);
        const rejected = rejectWorkspaceWrite(fsPath);
        if (rejected) return rejected;
        createFile2(fsPath, await requestBodyText2(requestMeta), headerValue2(requestMeta, "Content-Type"));
        await saveState2();
        return textResponse("", 201);
      }
      if (method === "DELETE") {
        const fsPath = webdavPath(path);
        const rejected = rejectWorkspaceWrite(fsPath);
        if (rejected) return rejected;
        removeEntry(fsPath);
        await saveState2();
        return textResponse("", 204);
      }
      if (method === "COPY" || method === "MOVE") {
        const srcPath = webdavPath(path);
        const dstPath = destinationPath(requestMeta);
        const rejected = rejectWorkspaceWrite(srcPath) || rejectWorkspaceWrite(dstPath);
        if (rejected) return rejected;
        if (!dstPath) return textResponse("missing Destination header", 400);
        if (method === "COPY") cloneEntryTree(srcPath, dstPath);
        if (method === "MOVE") moveEntryTree(srcPath, dstPath);
        await saveState2();
        return textResponse("", 201);
      }
      if (method === "LOCK") {
        const fsPath = webdavPath(path);
        const token = lockToken();
        const state = getState();
        state.webdav_locks = state.webdav_locks || {};
        state.webdav_locks[token] = { path: fsPath, created: (/* @__PURE__ */ new Date()).toISOString() };
        await saveState2();
        const response = lockResponse(token);
        response.headers["Lock-Token"] = [`<${token}>`];
        return response;
      }
      if (method === "UNLOCK") {
        const state = getState();
        const token = headerValue2(requestMeta, "Lock-Token").replace(/[<>]/g, "");
        if (state.webdav_locks && token) delete state.webdav_locks[token];
        await saveState2();
        return textResponse("", 204);
      }
      if (method === "PROPPATCH") {
        return textResponse(`<?xml version="1.0" encoding="utf-8"?><D:multistatus xmlns:D="DAV:"/>`, 207, "application/xml; charset=utf-8");
      }
      return textResponse("method not allowed", 405);
    };
  };
  (function() {
    const now = () => (/* @__PURE__ */ new Date()).toISOString();
    let state = defaultState(now);
    const {
      cloneEntryTree,
      createFile: createFile2,
      ensureDir,
      moveEntryTree,
      removeEmptyDirs,
      removeEntry,
      renameEntryInDir
    } = createVirtualFs({
      getState: () => state,
      now
    });
    const warn = (...args) => siyuan.logger.warn("[siyuan-cloud]", ...args);
    const pick = (value, lowerName, upperName) => {
      if (!value) return void 0;
      if (value[lowerName] !== void 0) return value[lowerName];
      if (value[upperName] !== void 0) return value[upperName];
      return void 0;
    };
    const extensionType = (name, isDir2) => {
      if (isDir2) return 1;
      const ext = String(name).toLowerCase().split(".").pop() || "";
      if (["jpg", "jpeg", "png", "gif", "webp", "bmp", "svg", "avif"].includes(ext)) return 2;
      if (["mp4", "mkv", "mov", "avi", "webm", "m4v"].includes(ext)) return 3;
      if (["mp3", "flac", "wav", "ogg", "m4a"].includes(ext)) return 4;
      if (["zip", "7z", "rar", "tar", "gz", "bz2"].includes(ext)) return 5;
      if (["pdf", "epub", "txt", "md", "json", "yaml", "yml", "csv", "log"].includes(ext)) return 6;
      return 0;
    };
    const toObjResp = (entry) => ({
      name: entry.name,
      size: entry.size || 0,
      is_dir: !!entry.is_dir,
      modified: entry.modified,
      created: entry.created || entry.modified,
      sign: "",
      thumb: "",
      type: extensionType(entry.name, entry.is_dir),
      hashinfo: "",
      hash_info: {}
    });
    const toFsGetResp = (entry, path) => ({
      ...toObjResp(entry),
      raw_url: entry.is_dir ? "" : "/plugin/private/siyuan-cloud/d" + normalizePath(path),
      readme: "",
      header: "",
      provider: "siyuan-storage",
      related: relatedEntries(path, entry).map(toObjResp)
    });
    const page = (items, req) => {
      const pageIndex = Math.max(1, Number(req.page || req.Page || 1));
      const perPage = Math.max(1, Number(req.per_page || req.perPage || req.PerPage || items.length || 1));
      const start = (pageIndex - 1) * perPage;
      return items.slice(start, start + perPage);
    };
    const {
      isWorkspacePath,
      siyuanApiJson,
      workspaceGet,
      workspaceList,
      workspacePublicUrl,
      workspaceReadText,
      workspaceRelPath
    } = createWorkspaceAdapter({
      client: siyuan.client,
      extensionType,
      failure,
      now,
      page,
      toObjResp
    });
    const relatedEntries = (path, entry) => {
      if (!entry || entry.is_dir) return [];
      const parent = state.entries[dirname(path)];
      if (!parent || !parent.children) return [];
      const stem = entry.name.replace(/\.[^.]+$/, "");
      return parent.children.map((childPath) => state.entries[childPath]).filter((item) => item && !item.is_dir && item.name !== entry.name && item.name.startsWith(stem));
    };
    const parseJson = async (request2) => {
      const requestMeta = pick(request2, "request", "Request");
      const body = pick(requestMeta, "body", "Body");
      if (!body) return {};
      if (body.data !== void 0 && body.data !== null) {
        if (typeof body.data === "object") {
          if (typeof body.data.json === "function") {
            try {
              return await body.data.json();
            } catch (_) {
            }
          }
          if (typeof body.data.text === "function") {
            const text2 = await body.data.text();
            if (!text2 || !String(text2).trim()) return {};
            try {
              return JSON.parse(text2);
            } catch (_) {
              return { content: text2 };
            }
          }
          return body.data;
        }
        if (typeof body.data === "string" && body.data.trim()) {
          try {
            return JSON.parse(body.data);
          } catch (_) {
            return { content: body.data };
          }
        }
      }
      if (body.form && typeof body.form === "object") {
        const values = body.form.values || body.form.Value || {};
        const files = body.form.files || body.form.File || {};
        const flattened = {};
        for (const key of Object.keys(values)) {
          const value = values[key];
          flattened[key] = Array.isArray(value) && value.length === 1 ? value[0] : value;
        }
        flattened.files = files;
        return flattened;
      }
      if (body.string && Array.isArray(body.string.values)) return { content: body.string.values.join("") };
      return {};
    };
    const queryValue = (request2, key) => {
      const url = pick(request2, "url", "URL");
      const queryMap = pick(url, "query", "Query");
      if (queryMap && typeof queryMap === "object") {
        const value = queryMap[key];
        return Array.isArray(value) ? String(value[0] || "") : String(value || "");
      }
      const query = queryMap || pick(url, "rawQuery", "RawQuery") || pick(url, "search", "Search") || "";
      const params = new URLSearchParams(query);
      return params.get(key) || "";
    };
    const decodePath = (path) => {
      try {
        return decodeURIComponent(path);
      } catch (_) {
        return path;
      }
    };
    const requestPath = (request2) => {
      const context = pick(request2, "context", "Context");
      const url = pick(request2, "url", "URL");
      const fromContext = pick(context, "path", "Path");
      const fromUrl = pick(url, "path", "Path");
      const raw = fromContext || fromUrl || "/";
      return decodePath(raw.replace(/^\/plugin\/private\/[^/]+/, "") || "/");
    };
    const requestHeaders2 = (request2) => {
      const meta = pick(request2, "request", "Request");
      return pick(meta, "headers", "Headers") || {};
    };
    const requestHeader2 = (request2, name) => {
      const target = String(name || "").toLowerCase();
      for (const [key, value] of Object.entries(requestHeaders2(request2))) {
        if (String(key).toLowerCase() !== target) continue;
        return Array.isArray(value) ? String(value[0] || "") : String(value || "");
      }
      return "";
    };
    const adminUser = () => state.users.find((item) => Number(item.role) === USER_ROLE.ADMIN) || state.users[0];
    const guestUser = () => state.users.find((item) => Number(item.role) === USER_ROLE.GUEST) || defaultGuestUser();
    const currentUser = (request2, options = {}) => {
      var _a2, _b2;
      const token = (requestHeader2(request2, "X-Siyuan-Cloud-Authorization") || requestHeader2(request2, "Authorization") || queryValue(request2, "siyuan_cloud_token")).replace(/^Bearer\s+/i, "");
      const context = (user, auth = "token") => {
        const normalized = normalizeUser(user || defaultGuestUser(), Math.max(0, Number((user == null ? void 0 : user.id) || 2) - 1));
        return { auth, error: null, user: normalized };
      };
      if (token && token === String(((_a2 = state.settings) == null ? void 0 : _a2.token) || "")) return context(adminUser(), "admin_token");
      if (token.startsWith("siyuan-cloud-port:")) {
        const id = Number(token.slice("siyuan-cloud-port:".length));
        const user = state.users.find((item) => Number(item.id) === id);
        if ((user == null ? void 0 : user.disabled) && !options.allowDisabledGuest) return { auth: "legacy_token", error: "Current user is disabled, replace please", user: normalizeUser(user) };
        return context(user || defaultGuestUser(), "legacy_token");
      }
      if (!token) {
        const guest = guestUser();
        if (guest.disabled && !options.allowDisabledGuest) return { auth: "guest", error: "Guest user is disabled, login please", user: normalizeUser(guest, 1) };
        return context(guest, "guest");
      }
      try {
        const claims = parseAuthToken(token, ((_b2 = state.settings) == null ? void 0 : _b2.token) || "siyuan-cloud-token");
        const user = state.users.find((item) => item.username === claims.username);
        if (!user) return { auth: "jwt", error: "user not found", user: normalizeUser(defaultGuestUser(), 1) };
        if ((user.logout_tokens || []).includes(tokenFingerprint(token))) return { auth: "jwt", error: "Token has been logged out, login please", user: normalizeUser(user) };
        if (Number(claims.pwd_ts || 0) !== Number(user.pwd_ts || 0)) return { auth: "jwt", error: "Password has been changed, login please", user: normalizeUser(user) };
        if (user.disabled) return { auth: "jwt", error: "Current user is disabled, replace please", user: normalizeUser(user) };
        return context(user, "jwt");
      } catch (error) {
        return { auth: "jwt", error: (error == null ? void 0 : error.message) || "couldn't handle this token", user: normalizeUser(defaultGuestUser(), 1) };
      }
    };
    const requestUser = (request2, options) => currentUser(request2, options).user;
    const requireCurrentUser = (request2, options = {}) => {
      const ctx = currentUser(request2, options);
      return ctx.error ? { error: failure(ctx.error, 401), user: ctx.user, auth: ctx.auth } : ctx;
    };
    const requireAdmin = (request2) => {
      const ctx = requireCurrentUser(request2);
      if (ctx.error) return ctx;
      return Number(ctx.user.role) !== USER_ROLE.ADMIN ? { ...ctx, error: failure("You are not an admin", 403) } : ctx;
    };
    const rawForwardHeaders = (headers = {}) => {
      const result = {};
      for (const [key, value] of Object.entries(headers || {})) {
        const normalized = String(key).toLowerCase();
        if (["accept-ranges", "content-range", "content-length", "etag", "last-modified", "cache-control"].includes(normalized)) {
          result[key] = Array.isArray(value) ? value.map(String) : [String(value)];
        }
      }
      return result;
    };
    const fileMime = (path) => {
      const ext = String(path || "").split(".").pop().toLowerCase();
      const types = {
        mp4: "video/mp4",
        m4v: "video/mp4",
        webm: "video/webm",
        mkv: "video/x-matroska",
        mov: "video/quicktime",
        mp3: "audio/mpeg",
        m4a: "audio/mp4",
        flac: "audio/flac",
        wav: "audio/wav",
        ogg: "audio/ogg"
      };
      return types[ext] || "application/octet-stream";
    };
    const downloadDisposition = (path) => {
      const name = encodeURIComponent(basename(path) || "download");
      return `attachment; filename="${name}"; filename*=UTF-8''${name}`;
    };
    const withDownloadDisposition = (response, filePath, enabled) => {
      if (!enabled) return response;
      response.headers = {
        ...response.headers || {},
        "Content-Disposition": [downloadDisposition(filePath)]
      };
      return response;
    };
    const saveState$1 = async (domains) => {
      await saveState(siyuan.storage, state, domains);
    };
    const saveConfigState = async () => saveState$1("config");
    const saveRuntimeState = async () => saveState$1("runtime");
    const saveSearchState = async () => saveState$1("search");
    const saveStorageAddition = async (storage, addition) => {
      const target = state.storages.find((item) => item.id === storage.id) || state.storages.find((item) => item.mount_path === storage.mount_path);
      if (!target) return;
      target.addition = JSON.stringify(addition || {});
      target.modified = now();
      await saveConfigState();
    };
    const driverRuntime = createDriverRuntime({
      client: siyuan.client,
      getSettings: () => state.settings,
      saveStorageAddition,
      workspaceGet,
      workspaceList,
      workspacePublicUrl,
      workspaceReadText
    });
    const searchFs = {
      async get(path) {
        const normalized = normalizePath(path);
        if (normalized === "/") return { name: "", is_dir: true, size: 0 };
        if (isWorkspacePath(normalized)) {
          const result = await workspaceGet(normalized);
          if (result.error) return null;
          return result.data;
        }
        const mount = driverRuntime.resolve(state.storages, normalized);
        if (mount) {
          return mount.driver.get(mount.storage, mount.relPath, { skipLink: true });
        }
        const entry = state.entries[normalized];
        if (entry) return toObjResp(entry);
        const mountName = normalized === "/" ? "" : normalized.split("/").filter(Boolean)[0];
        if (normalized !== "/" && state.storages.some((storage) => !storage.disabled && normalizePath(storage.mount_path || "/").split("/").filter(Boolean)[0] === mountName)) {
          return { name: basename(normalized), is_dir: true, size: 0 };
        }
        return null;
      },
      async list(path) {
        const normalized = normalizePath(path);
        if (isWorkspacePath(normalized)) {
          const result = await workspaceList(normalized, { page: 1, per_page: 1e5 });
          if (result.error) return [];
          return result.data.content || [];
        }
        const mount = driverRuntime.resolve(state.storages, normalized);
        if (mount) {
          const data = await mount.driver.list(mount.storage, mount.relPath, { page: 1, per_page: 1e5 });
          return data.content || [];
        }
        const entry = state.entries[normalized];
        const children = (entry == null ? void 0 : entry.is_dir) ? (entry.children || []).map((childPath) => state.entries[childPath]).filter(Boolean).map(toObjResp) : [];
        if (normalized === "/") {
          for (const mountEntry of driverRuntime.mountEntries(state.storages, now)) {
            if (!children.some((item) => item.name === mountEntry.name)) children.unshift(toObjResp(mountEntry));
          }
        }
        return children;
      }
    };
    const searchIndex = createSearchIndex({
      getObj: searchFs.get,
      getState: () => state,
      isIndexDisabled: (path) => {
        const normalized = normalizePath(path);
        return state.storages.some((storage) => {
          const mountPath = normalizePath(storage.mount_path || "/");
          return !!storage.disable_index && normalized !== "/" && (normalized === mountPath || normalized.startsWith(`${mountPath}/`));
        });
      },
      listObjs: searchFs.list,
      now,
      saveState: saveSearchState
    });
    const loadState$1 = async () => {
      var _a2;
      const loaded = await loadState({ now, storage: siyuan.storage });
      state = loaded.state;
      let userChanged = false;
      try {
        const conf = await siyuanApiJson("/api/system/getConf", {});
        userChanged = syncDefaultUserWithSiyuan(state, accountFromSiyuanConf(((_a2 = conf == null ? void 0 : conf.data) == null ? void 0 : _a2.conf) || (conf == null ? void 0 : conf.data) || conf));
      } catch (error) {
        warn("failed to sync SiYuan account user", (error == null ? void 0 : error.message) || String(error));
      }
      if (loaded.shouldSave) {
        await saveState$1();
      } else if (userChanged) {
        await saveConfigState();
      }
      ensureDir("/");
      ensureSearchState(state);
    };
    const reloadConfigState = async () => {
      const config = await loadConfigState({ storage: siyuan.storage });
      if (!config) return false;
      Object.assign(state, config);
      ensureDir("/");
      ensureSearchState(state);
      return true;
    };
    const settingItem = (key, value, index) => {
      const meta = settingMeta[key] || {};
      return {
        key,
        value: String(value ?? ""),
        help: meta.help || "",
        type: meta.type || "string",
        options: meta.options || "",
        group: meta.group ?? SETTING_GROUP.SINGLE,
        flag: meta.flag ?? SETTING_FLAG.PUBLIC,
        index: index || 0
      };
    };
    const requestedGroups = (request2) => {
      const raw = queryValue(request2, "groups") || queryValue(request2, "group");
      if (!raw) return null;
      const groups = raw.split(",").map((item) => Number(item.trim())).filter((item) => Number.isFinite(item));
      return groups.length ? groups : null;
    };
    const listSettings = (request2, source) => {
      const groups = request2 ? requestedGroups(request2) : null;
      return Object.entries(source || state.settings).map(([key, value], index) => settingItem(key, value, index)).filter((item) => !groups || groups.includes(item.group));
    };
    const saveToolSettings = async (req, keyMap, responseValue) => {
      for (const [settingKey, reqKey] of Object.entries(keyMap)) {
        state.settings[settingKey] = String(req[reqKey] ?? "");
      }
      await saveConfigState();
      return jsonResponse(success(responseValue === void 0 ? "ok" : responseValue));
    };
    const pageSlice = (items, request2) => {
      const pageIndex = Math.max(1, Number(queryValue(request2, "page") || 1));
      const perPage = Math.max(1, Number(queryValue(request2, "per_page") || queryValue(request2, "perPage") || items.length || 1));
      const start = (pageIndex - 1) * perPage;
      return pageResp(items.slice(start, start + perPage), items.length);
    };
    const storageResp = (storage) => ({
      ...storage,
      mount_details: storage.mount_details || {
        total_space: 0,
        used_space: 0,
        free_space: 0
      }
    });
    const { shareGet, shareList } = createShareReader({
      driverRuntime,
      getState: () => state,
      isWorkspacePath,
      page,
      saveState: saveConfigState,
      toFsGetResp,
      toObjResp,
      workspaceGet,
      workspaceList
    });
    const taskStore = createTaskStore({
      getState: () => state,
      now,
      saveState: saveRuntimeState
    });
    const shareDownloadShouldProxy = (mount, filePath) => {
      var _a2, _b2;
      const config = ((_b2 = driverInfoMap()[(_a2 = mount == null ? void 0 : mount.storage) == null ? void 0 : _a2.driver]) == null ? void 0 : _b2.config) || {};
      return shouldProxy(mount == null ? void 0 : mount.storage, config, basename(filePath));
    };
    const readFileResponse = async (filePath, request2, readOptions = {}) => {
      const asDownload = readOptions.shareDownload || readOptions.directDownload;
      if (isWorkspacePath(filePath)) {
        const file = await workspaceReadText(filePath);
        if (!file.ok) return textResponse(file.text || "not found", file.status || 404);
        return withDownloadDisposition(textResponse(file.text, 200, file.contentType), filePath, asDownload);
      }
      const mount = driverRuntime.resolve(state.storages, filePath);
      if (mount && mount.driver.read) {
        try {
          const options = proxyReadOptions(request2, filePath);
          if (asDownload && mount.driver.link && !shareDownloadShouldProxy(mount, filePath)) {
            const data2 = await mount.driver.link(mount.storage, mount.relPath, options);
            return redirectResponse(linkFromDriverData(data2).url);
          }
          const data = await mount.driver.read(mount.storage, mount.relPath, options);
          if (data.redirect) return redirectResponse(data.redirect);
          if (data.link) {
            const link2 = linkFromDriverData(data);
            if ((readOptions.shareDownload || readOptions.directDownload) && !shareDownloadShouldProxy(mount, filePath)) return redirectResponse(link2.url);
            return withDownloadDisposition(proxy(null, link2, { request_header: options.requestHeaders }, !!mount.storage.proxy_range), filePath, asDownload);
          }
          if (String(data.bodyEncoding || "").startsWith("base64")) {
            const headers = rawForwardHeaders(data.headers);
            if (!headers["Accept-Ranges"] && !headers["accept-ranges"]) headers["Accept-Ranges"] = ["bytes"];
            return withDownloadDisposition(rawResponse(
              base64ToArrayBuffer(data.body || ""),
              data.status || 200,
              data.contentType || fileMime(filePath),
              headers
            ), filePath, asDownload);
          }
          return withDownloadDisposition(textResponse(data.body || "", data.status || 200, data.contentType || "application/octet-stream"), filePath, asDownload);
        } catch (error) {
          return textResponse(error.message || "driver read failed", 502);
        }
      }
      const entry = state.entries[filePath];
      if (!entry || entry.is_dir) return textResponse("not found", 404);
      if (String(entry.body_encoding || "").startsWith("base64")) {
        return withDownloadDisposition(rawResponse(
          base64ToArrayBuffer(entry.content || ""),
          200,
          entry.mime || "application/octet-stream"
        ), filePath, asDownload);
      }
      return withDownloadDisposition(textResponse(entry.content || "", 200, entry.mime || "application/octet-stream"), filePath, asDownload);
    };
    const handleWebDav = createWebDavServer({
      cloneEntryTree,
      createFile: createFile2,
      currentUser: requestUser,
      ensureDir,
      getState: () => state,
      isWorkspacePath,
      moveEntryTree,
      readFileResponse,
      removeEntry,
      requestPath,
      saveState: saveRuntimeState,
      toObjResp,
      workspaceGet,
      workspaceList
    });
    const handleS3 = createS3Server({
      cloneEntryTree,
      createFile: createFile2,
      currentUser: requestUser,
      ensureDir,
      getState: () => state,
      removeEntry,
      requestPath,
      saveState: saveRuntimeState
    });
    const archiveDownloadResponse = createArchiveDownloadResponse({
      client: siyuan.client,
      driverRuntime,
      getState: () => state
    });
    let handlers = {};
    handlers = {
      ...createStatusHandlers({
        client: siyuan.client,
        getState: () => state,
        handlersRef: () => handlers
      }),
      ...createTaskHandlers({
        currentUser: requestUser,
        parseJson,
        queryValue,
        taskStore
      }),
      ...createAuthHandlers({
        currentUser,
        getState: () => state,
        parseJson,
        saveState: saveConfigState
      }),
      ...createCompatHandlers(),
      ...createMetaHandlers({
        getState: () => state,
        pageSlice,
        parseJson,
        queryValue,
        requireAdmin,
        saveState: saveConfigState
      }),
      ...createMessageHandlers({
        getState: () => state,
        now,
        parseJson,
        requireAdmin,
        saveState: saveRuntimeState
      }),
      ...createIndexHandlers({
        currentUser: requestUser,
        parseJson,
        requireAdmin,
        searchIndex,
        taskStore
      }),
      ...createScanHandlers({
        getState: () => state,
        now,
        requireAdmin,
        saveState: saveRuntimeState
      }),
      ...createSecurityHandlers({
        currentUser,
        getState: () => state,
        now,
        parseJson,
        queryValue,
        requireAdmin,
        saveState: saveConfigState
      }),
      ...createPublicHandlers({
        getState: () => state,
        handlersRef: () => handlers,
        settingItem
      }),
      ...createAdminHandlers({
        driverRuntime,
        getState: () => state,
        isWorkspacePath,
        listSettings,
        now,
        pageSlice,
        parseJson,
        queryValue,
        reloadConfigState,
        requireAdmin,
        saveState: saveConfigState,
        saveToolSettings,
        settingItem,
        storageResp,
        workspaceGet
      }),
      ...createFsHandlers({
        client: siyuan.client,
        cloneEntryTree,
        createFile: createFile2,
        currentUser: requestUser,
        driverRuntime,
        ensureDir,
        getState: () => state,
        isWorkspacePath,
        moveEntryTree,
        now,
        page,
        parseJson,
        removeEmptyDirs,
        removeEntry,
        renameEntryInDir,
        saveConfigState,
        saveState: saveRuntimeState,
        searchIndex,
        shareGet,
        shareClientIP,
        shareList,
        siyuanApiJson,
        taskStore,
        toFsGetResp,
        toObjResp,
        workspaceGet,
        workspaceList,
        workspaceReadText,
        workspaceRelPath
      }),
      ...createArchiveHandlers({
        client: siyuan.client,
        createFile: createFile2,
        currentUser: requestUser,
        driverRuntime,
        ensureDir,
        getState: () => state,
        page,
        parseJson,
        saveState: saveRuntimeState,
        taskStore
      }),
      ...createShareHandlers({
        currentUser: requestUser,
        driverRuntime,
        getState: () => state,
        isWorkspacePath,
        now,
        page,
        parseJson,
        queryValue,
        saveState: saveConfigState,
        workspaceGet
      })
    };
    const route = createRouter({
      archiveDownloadResponse,
      getState: () => state,
      handleS3,
      handleWebDav,
      handlers,
      isWorkspacePath,
      pick,
      queryValue,
      readFileResponse,
      requestPath,
      saveState: saveConfigState,
      warn,
      workspaceReadText
    });
    siyuan.plugin.lifecycle.onload = async () => {
      await loadState$1();
      await siyuan.rpc.bind("siyuan-cloud.status", async () => createStatusPayload({
        client: siyuan.client,
        getState: () => state,
        handlersRef: () => handlers
      }), "Return Siyuan Cloud compatibility runtime status.");
    };
    siyuan.plugin.lifecycle.onunload = async () => {
      await saveState$1(["config", "runtime", "search"]);
      await log("kernel plugin unloaded");
    };
    siyuan.server.private.http.handler = async (request2) => {
      return route(request2);
    };
  })();
})();
